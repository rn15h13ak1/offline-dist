"""実行環境の確認。入口で、ほかのモジュールより先に呼ぶ。

ほかのモジュールは Python 3.10 以上の書き方（`str | None` など）を使っているため、
古い Python で読み込むと、何が足りないのか分からないエラーで落ちる。このファイルだけは
3.9 でも読める書き方に保ち、先に確かめて案内を出す。
"""
# Python の版とライブラリの確かめ・案内の文、コンソールへの出力の手当ては、5 つのツールで共通の部品にある
from backlog_common.runtime import MIN_PYTHON, make_console_safe, require_packages, require_python  # noqa: F401

#: (import 名, pip でのパッケージ名)
REQUIRED_PACKAGES = (("yaml", "pyyaml"),)

#: 案内を出して止めるときの終了コード（このツールでは、実行する前に人が直すものを 2 にしている）
EXIT_ENVIRONMENT = 2


def ensure_runtime(version_info=None, importer=None, code=EXIT_ENVIRONMENT):
    """
    足りないものがあれば案内を出して終了する。あわせてコンソールへの出力を安全にする。
    メニューも同じ 2 で止める（5 つのツールのメニューで同じ。backlog_common.menu.EXIT_SETUP）
    """
    make_console_safe()
    require_python(version_info, code=code)
    require_packages(REQUIRED_PACKAGES, code=code, importer=importer)
