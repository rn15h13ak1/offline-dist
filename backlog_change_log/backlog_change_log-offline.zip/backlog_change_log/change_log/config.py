"""設定ファイルと API キーの読み込み。

API キーは、環境変数 BACKLOG_API_KEY → config.yaml の backlog.api_key → .env の順に探す。
config.yaml は .gitignore で除外しており、値はコミットされない。
config.example.yaml をコピーして config.yaml にキーを書く運用を、他の Backlog ツールと同じく使えるようにする。
"""
import sys
from collections.abc import Mapping
from dataclasses import dataclass, field
from pathlib import Path
from typing import NoReturn

from backlog_common import config as config_files
from backlog_common.config import API_KEY_ENV, ConfigError  # noqa: F401  （API_KEY_ENV は公開している名前）

from change_log.core import REPO_ROOT

#: 例の値。backlog: の節の例の値は共通の部品が見る。ここは target.issue_key の例
PLACEHOLDERS = {"PROJ-1"}


@dataclass
class Config:
    space_host: str
    base_path: str
    ssl_verify: bool
    issue_key: str
    api_key: str
    #: 追跡するプロジェクトのキー。空なら記録先の課題のプロジェクトだけを追跡する
    project_keys: list[str] = field(default_factory=list)
    #: API キーをどこから読んだか。認証・権限のエラーのときに示す
    api_key_source: str = ""
    #: backlog: の節の通信の設定（timeout など。BacklogClient に渡す）。書いていなければ空
    client_options: dict = field(default_factory=dict)


#: 書ける項目（知らない項目は止める。5 つのツールで同じ。backlog: の節は共通の部品が決める）
TOP_KEYS = {"backlog", "target"}
TARGET_KEYS = {"issue_key", "project_keys"}


#: 設定の誤りで止めるときの終了コード。実行する前に人が直すものなので、実行環境の不足
#: （change_log.runtime）と同じ 2 にする。1 は API・通信のエラーに使う。
EXIT_CONFIG = 2


def _fail(message: str) -> NoReturn:
    print(f"エラー: {message}", file=sys.stderr)
    sys.exit(EXIT_CONFIG)


def dotenv_candidates(config_path: Path | None = None, cwd: Path | None = None) -> list[Path]:
    """.env を探す場所。設定ファイルと同じ場所 → リポジトリ直下 → 作業ディレクトリ（共通の部品の順）"""
    return config_files.dotenv_candidates(config_path, REPO_ROOT, cwd)


def find_api_key(env: Mapping[str, str] | None = None, config_path: Path | None = None,
                 cwd: Path | None = None, config_value: object = None) -> str | None:
    """locate_api_key と同じ順で探す。見つからなければ None（終了しない。メニューの見出しが使う）"""
    try:
        return config_files.locate_api_key(config_path, config_value, tool_dir=REPO_ROOT, env=env, cwd=cwd)[0]
    except ConfigError:
        return None


def locate_api_key(env: Mapping[str, str] | None = None, config_path: Path | None = None,
                   cwd: Path | None = None, config_value: object = None) -> tuple[str, str]:
    """
    (API キー, どこから読んだか)。環境変数 → 設定ファイルの値（config_value）→ .env（dotenv_candidates の順）。
    例の値のままのものは無いものとして扱う。見つからなければ探した場所を表示して終了する。

    環境変数を先にするのは、定期実行などで設定ファイルを書き換えずに差し替えられるようにするため。
    """
    try:
        return config_files.locate_api_key(config_path, config_value, tool_dir=REPO_ROOT, env=env, cwd=cwd)
    except ConfigError as e:
        _fail(str(e))
        return "", ""  # _fail は終了する


def resolve_api_key(env: Mapping[str, str] | None = None, config_path: Path | None = None,
                    cwd: Path | None = None, config_value: object = None) -> str:
    """locate_api_key のキーだけ"""
    return locate_api_key(env, config_path, cwd, config_value)[0]


def _project_keys(raw: object) -> tuple[list[str], list[str]]:
    """target.project_keys を検証して (キーの一覧, 誤りの文) を返す。省略・空は空のリスト（記録先のプロジェクトだけを追跡）"""
    if raw is None:
        return [], []
    if not isinstance(raw, list) or not all(isinstance(k, str) and k.strip() for k in raw):
        return [], ["target.project_keys は、プロジェクトキーの一覧で書いてください（例: [PROJ, OTHER]）"]
    keys = [str(k).strip() for k in raw]
    duplicated = sorted({k for k in keys if keys.count(k) > 1})
    if duplicated:
        return keys, [f"target.project_keys に同じキーが重複しています: {', '.join(duplicated)}"]
    return keys, []


def _issue_key_problems(issue_key: str) -> list[str]:
    if issue_key in PLACEHOLDERS:
        return ["target.issue_key が例のままです"]
    if not issue_key:
        return ["target.issue_key が空です"]
    if "-" not in issue_key:
        return [f"target.issue_key は課題キー（例: MYPROJ-123）で書いてください: {issue_key}"]
    return []


def load_config(path: str, api_key: str | None = None) -> Config:
    p = Path(path)
    try:
        raw = config_files.load_config(p)
    except ConfigError as e:
        _fail(str(e))
    # 誤りはまとめて示す（1 つ直すたびに動かし直さずに済むように。5 つのツールで同じ形）
    backlog, problems = config_files.backlog_problems(raw)
    target, target_problems = config_files.section_problems(raw, "target")
    issue_key = str(target.get("issue_key") or "")
    project_keys, key_problems = _project_keys(target.get("project_keys"))
    problems = (config_files.unknown_keys(raw, TOP_KEYS)
                + problems
                + target_problems
                + config_files.unknown_keys(target, TARGET_KEYS, "target")
                + _issue_key_problems(issue_key)
                + key_problems)
    if problems:
        _fail(config_files.problems_text(p, problems))
    client_options = config_files.client_settings(backlog)
    space_host = config_files.setting(backlog, "space_host")

    if api_key is None:
        api_key, api_key_source = locate_api_key(config_path=p, config_value=backlog.get("api_key"))
    else:
        api_key_source = ""

    return Config(
        project_keys=project_keys,
        space_host=space_host,
        base_path=str(backlog.get("base_path") or ""),
        ssl_verify=bool(backlog.get("ssl_verify", True)),
        issue_key=issue_key,
        api_key=api_key,
        api_key_source=api_key_source,
        client_options=client_options,
    )
