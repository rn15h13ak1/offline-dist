"""Backlog API クライアント。

通信（送る・再送する・待つ・エラーにする）と、どのツールでも使う取得は、共通の部品 backlog_common/client.py にある。
ここには、本ツールで使う取得（コメント・アクティビティの履歴）とコメントの投稿だけを足す。

コメントの投稿（POST）は、429 を含めて再送しない。通信断や 5xx の後に再送すると、投稿済みだった場合に
同じコメントが二重に残る。429 は投稿されていないことが確かだが、二重の投稿を確実に避けるため、それも送り直さない。
"""
from collections.abc import Iterator

from backlog_common import client as _common
from backlog_common.client import BacklogAPIError

from change_log.core import API_PAGE_SIZE

__all__ = ["BacklogAPIError", "BacklogClient", "format_api_error"]


def format_api_error(err: BacklogAPIError) -> str:
    """BacklogAPIError を利用者向けの日本語メッセージに整形する（API キーを含む URL は出さない。5 つのツールで同じ文）"""
    return _common.format_api_error(err)


class BacklogClient(_common.BacklogClient):
    # 404 のときに確かめる設定の項目（このツールの設定に project_key は無い）。ほかの案内は共通の部品のもの
    HTTP_ERROR_HINTS = {
        **_common.BacklogClient.HTTP_ERROR_HINTS,
        404: "space_host・base_path・target.issue_key・target.project_keys を確認してください。",
    }

    # 再送しなかったときの案内（コメントの投稿は、届いて投稿された後かもしれない失敗でも送り直さない）
    COMMENT_NOT_RESENT = "コメントが投稿済みの可能性があるため再送しません。記録の課題のコメントを確認してください。"

    def get_issue(self, issue_id_or_key: str | int) -> dict:
        """課題を 1 件取得する。無ければ（404）エラーにする（記録の課題が無いのは設定の誤り）"""
        return self._get(f"/issues/{self._quote(issue_id_or_key)}")

    def iter_comments_desc(self, issue_id_or_key: str | int) -> Iterator[dict]:
        """課題のコメントを新しい順に返す。必要な分だけページを読む"""
        max_id: int | None = None
        while True:
            params: dict = {"count": API_PAGE_SIZE, "order": "desc"}
            if max_id is not None:
                params["maxId"] = max_id
            comments = self._get(f"/issues/{issue_id_or_key}/comments", params)
            yield from comments
            if len(comments) < API_PAGE_SIZE:
                return
            max_id = min(c["id"] for c in comments) - 1

    def iter_activities_desc(self, project_id: int, activity_type_ids: list[int]) -> Iterator[dict]:
        """プロジェクトのアクティビティを新しい順に返す。必要な分だけページを読む"""
        max_id: int | None = None
        while True:
            params: dict = {"activityTypeId": activity_type_ids, "count": API_PAGE_SIZE, "order": "desc"}
            if max_id is not None:
                params["maxId"] = max_id
            activities = self._get(f"/projects/{project_id}/activities", params)
            yield from activities
            if len(activities) < API_PAGE_SIZE:
                return
            max_id = min(a["id"] for a in activities) - 1

    def get_issues_by_ids(self, project_id: int, issue_ids: list[int]) -> list[dict]:
        """課題 ID を指定してまとめて取得する（削除済みの課題は返らない）"""
        found: list[dict] = []
        for i in range(0, len(issue_ids), API_PAGE_SIZE):
            chunk = issue_ids[i:i + API_PAGE_SIZE]
            found.extend(self._get("/issues", {"projectId": [project_id], "id": chunk, "count": API_PAGE_SIZE}))
        return found

    def add_comment(self, issue_id_or_key: str | int, content: str) -> dict:
        """コメントを投稿する。429 を含めて再送しない（二重に投稿しないため）"""
        return self._post(f"/issues/{issue_id_or_key}/comments", {"content": content},
                          retry=False, note=self.COMMENT_NOT_RESENT)
