#!/usr/bin/env python3
"""
Backlog の課題の変更（作成・更新・削除）を、1 日ごとに記録先の課題のコメントへ出力する。

前日以前で未出力の日（最大 7 日）を 1 日 1 件で投稿し、当日の変更は標準出力に表示する。
"""
import sys

# 依存と Python の版を先に確かめる。ほかのモジュールは 3.10 以上の書き方を使っており、
# 先に読み込むと、何が足りないのか分からないエラーで落ちるため。
from change_log.runtime import ensure_runtime

ensure_runtime()

import argparse

from backlog_common import cli
from backlog_common import plan as plans
from backlog_common.console import has_tty, not_tty_text
from backlog_common.runtime import EXIT_NEEDS_CONFIRMATION, exit_on_interrupt, stop_on_sigterm

from change_log.client import BacklogAPIError, BacklogClient, format_api_error
from change_log.config import load_config
from change_log.core import REPO_ROOT
from change_log.lock import AlreadyRunning, lock_path, single_run
from change_log.runner import EXIT_ALREADY_RUNNING, EXIT_FAILED, EXIT_INTERRUPTED, Interrupted, run
from version import TOOL_NAME, __version__


def build_parser() -> argparse.ArgumentParser:
    # --help の日本語と、同じ意味の引数の説明は、5 つのツールで共通の部品
    parser = cli.make_parser(__file__, description="Backlog の課題の変更を、1 日ごとに課題のコメントへ記録する")
    cli.add_version(parser, TOOL_NAME, __version__)
    cli.add_config(parser, default=str(REPO_ROOT / "config.yaml"))
    parser.add_argument("--dry-run", action="store_true",
                        help="投稿するコメントを表示するだけで、投稿しない")
    cli.add_yes(parser)
    plans.add_plan_options(parser)
    cli.add_debug(parser)
    return parser


def main(argv: list[str] | None = None) -> int:
    argv = sys.argv[1:] if argv is None else argv
    args = build_parser().parse_args(argv)
    # 外から止められたとき（コマンドを動かす道具の時間切れなど）も、Ctrl+C と同じく投稿した日を示して終える
    stop_on_sigterm()
    if plans.yes_refused(args.yes and not args.dry_run):
        # この端末では、投稿の許可を --yes で示せない（環境変数で拒んでいる）。設定も読まず、Backlog にもつながない
        print(plans.refused_yes_text(__file__, argv), file=sys.stderr)
        return EXIT_NEEDS_CONFIRMATION
    if not args.dry_run and not args.yes and not has_tty():
        # 確かめる人のいない所から引数なしで動かされても、投稿しない。ほかのツールの --execute と同じく、
        # 投稿してよいことを --yes で示させる。設定も読まず、Backlog にもつながない
        print("エラー: " + not_tty_text(
            "投稿してよいか", "何も送っていません",
            "投稿するコメントを確かめるだけなら --dry-run を、投稿するなら --yes を付けてください"
            "（定期実行で動かしている場合も --yes が要ります）。"), file=sys.stderr)
        # 設定の誤り（2）と分ける。呼び出した側が、人に許可を求めるべきだと分かるように
        return EXIT_NEEDS_CONFIRMATION
    try:
        # 計画に効く引数は無い（投稿する日とコメントは、記録先・追跡するプロジェクトと「今」で決まる）
        plan = plans.PlanRequest.from_args(args, TOOL_NAME, __version__,
                                           inputs={"config": plans.file_digest(args.config)})
    except plans.PlanError as e:
        print(f"エラー: {e}", file=sys.stderr)
        return plans.EXIT_PLAN_MISMATCH
    config = load_config(args.config)
    result = plans.ResultLog(None if args.dry_run else args.result_out, TOOL_NAME, __version__)
    client = BacklogClient(config.space_host, config.api_key, ssl_verify=config.ssl_verify,
                           base_path=config.base_path, debug=args.debug, api_key_source=config.api_key_source,
                           **config.client_options)
    try:
        if args.dry_run:
            # 投稿しないので、ほかの実行と重なっても二重投稿にはならない
            return run(client, config.issue_key, project_keys=config.project_keys, dry_run=True, plan=plan)
        with single_run(lock_path(config.space_host, config.issue_key)):
            code = run(client, config.issue_key, project_keys=config.project_keys, plan=plan, result=result)
        result.close("failed" if code in (EXIT_FAILED, plans.EXIT_PLAN_MISMATCH) else "done", code)
        return code
    except AlreadyRunning:
        print(f"エラー: {config.issue_key} への記録が、すでに実行中です。終わってから実行してください。",
              file=sys.stderr)
        result.close("failed", EXIT_ALREADY_RUNNING)
        return EXIT_ALREADY_RUNNING
    except BacklogAPIError as e:
        print(format_api_error(e), file=sys.stderr)
        result.close("failed", EXIT_FAILED)
        return EXIT_FAILED
    except Interrupted as e:
        # 中断の知らせと注意はエラーの出力に、ここまでにできたことは画面の出力に出す（5 つのツールで同じ）
        posted = "、".join(d.isoformat() for d in e.posted) or "なし"
        print("\n中断しました（Ctrl+C か、外から止められた）。残りの日は次回の実行で出力されます。\n"
              "  中断したときに投稿中だったコメントは、投稿されたか分かりません。記録先の課題のコメントを確かめてください。",
              file=sys.stderr)
        print(f"投稿した日: {posted}")
        result.close("interrupted", EXIT_INTERRUPTED)
        return EXIT_INTERRUPTED
    except KeyboardInterrupt:
        result.close("interrupted", EXIT_INTERRUPTED)
        print("\n中断しました。投稿した日は、上の「のコメントを投稿しました。」の行で確かめてください。", file=sys.stderr)
        return EXIT_INTERRUPTED


if __name__ == "__main__":
    # Ctrl+C で止めたら、トレースバックを出さずに終了コード 130 で終える
    sys.exit(exit_on_interrupt(main))
