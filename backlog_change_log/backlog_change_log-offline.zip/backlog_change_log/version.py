"""backlog_change_log の版。CHANGELOG.md の最新の版と同じにする（版を切ったら上げる）。"""

TOOL_NAME = "backlog_change_log"
__version__ = "0.14.3"
