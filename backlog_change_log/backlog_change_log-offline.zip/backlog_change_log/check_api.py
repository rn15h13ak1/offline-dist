#!/usr/bin/env python3
"""
実際のスペースの応答で、本ツールが置いている前提を確かめる。読み取りだけで、投稿はしない。

  python check_api.py
  python check_api.py --days 30
"""
import sys

# 依存と Python の版を先に確かめる（backlog_change_log.py と同じ理由）
from change_log.runtime import ensure_runtime

ensure_runtime()

import argparse

from backlog_common import cli
from backlog_common.runtime import exit_on_interrupt

from change_log.client import BacklogAPIError, BacklogClient, format_api_error
from change_log.config import load_config
from change_log.core import REPO_ROOT
from change_log.diagnose import diagnose
from version import TOOL_NAME, __version__


def build_parser() -> argparse.ArgumentParser:
    parser = cli.make_parser(__file__, description="Backlog API の応答が、本ツールの前提どおりかを確かめる")
    cli.add_version(parser, TOOL_NAME, __version__)
    cli.add_config(parser, default=str(REPO_ROOT / "config.yaml"))
    parser.add_argument("--days", type=int, default=7, help="遡って読むアクティビティの日数（既定: 7）")
    parser.add_argument("--max", type=int, default=1000, dest="max_activities",
                        help="読むアクティビティの上限件数（既定: 1000）")
    cli.add_debug(parser, read_only=True)
    return parser


def main(argv: list[str] | None = None) -> int:
    args = build_parser().parse_args(argv)

    config = load_config(args.config)
    client = BacklogClient(config.space_host, config.api_key, ssl_verify=config.ssl_verify,
                           base_path=config.base_path, debug=args.debug, api_key_source=config.api_key_source,
                           **config.client_options)
    print(f"接続先: {client.base_url}")
    try:
        return diagnose(client, config.issue_key, project_keys=config.project_keys,
                        days=args.days, max_activities=args.max_activities)
    except BacklogAPIError as e:
        print(format_api_error(e), file=sys.stderr)
        return 1


if __name__ == "__main__":
    # Ctrl+C で止めたら、トレースバックを出さずに終了コード 130 で終える
    sys.exit(exit_on_interrupt(main))
