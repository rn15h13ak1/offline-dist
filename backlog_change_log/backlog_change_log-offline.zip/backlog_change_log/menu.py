#!/usr/bin/env python3
"""
Backlog 変更記録 対話メニュー
=============================
投稿内容の確認・記録・応答の確認を、番号を選ぶだけで実行する。

  python menu.py                  # メニューを表示
  python menu.py --config my.yaml # 設定ファイルを指定

本体（backlog_change_log.py / check_api.py）は別のプロセスとして呼ぶ。
無人実行（定期実行）はこのメニューではなく本体を直接呼ぶこと:
  python backlog_change_log.py

作りは同じ種類のツールのメニューに揃えている。
"""

# 依存と Python の版を先に確かめる（backlog_change_log.py と同じ理由）。
# menu.bat のダブルクリック起動で足りない場合に、トレースバックではなく対処を表示する。
# 足りなければ 2 で止める（5 つのメニューで同じ。本体の番号とも同じ）
from change_log.runtime import ensure_runtime

ensure_runtime()

import argparse
from pathlib import Path

from backlog_common import cli
from backlog_common.config import ConfigError, is_placeholder
from backlog_common.config import load_config as load_config_file
from backlog_common.menu import (
    EXIT_EOF,  # noqa: F401  （終了コード。ツールを起動する側と、同じ種類のツールのメニューに揃える）
    EXIT_INTERRUPTED,  # noqa: F401
    EXIT_OK,  # noqa: F401
    confirm,
    exit_menu,
    hr,
    print_config_header,
    print_menu,
    run_loop,
    show_result,
    wait_enter,
)
from backlog_common.menu import describe_exit as _describe_exit
from backlog_common.menu import load_history as _load_history
from backlog_common.menu import run_script as _run_script
from backlog_common.menu import save_history as _save_history

from change_log.config import PLACEHOLDERS, find_api_key
from version import TOOL_NAME, __version__

TOOL_DIR = Path(__file__).resolve().parent
MAIN_SCRIPT = TOOL_DIR / "backlog_change_log.py"
CHECK_SCRIPT = TOOL_DIR / "check_api.py"
HISTORY_PATH = Path.home() / ".backlog_change_log_menu.json"

ACTION_DRY_RUN = "dry_run"
ACTION_POST = "post"
ACTION_CHECK = "check"

ACTIONS = [
    (ACTION_DRY_RUN, "投稿内容を確認する", "投稿するコメントを表示するだけ（投稿しません）"),
    (ACTION_POST, "記録する", "前日までの未出力の日を、記録先の課題にコメントとして投稿する"),
    (ACTION_CHECK, "API の応答を確かめる", "応答が本ツールの前提どおりかを確かめる（読み取りだけ）"),
]

#: check_api.py で遡る日数の選択肢
CHECK_DAYS = [7, 30, 90]

#: 本体の終了コードの意味（README の「終了コード」と揃える。127・130 は共通の部品が足す）
EXIT_MEANINGS = {
    0: "正常終了",
    1: "API・通信のエラー、投稿に失敗（残りの日は次回に出力されます）、または想定外のエラー",
    2: "実行する前に直すものがあります（設定ファイル、API キー、Python の版、PyYAML）",
    3: "出力しなかった日があります（理由は上の警告を見てください）",
    4: "同じ記録先への実行が、すでに動いています",
    20: "端末でない所から --yes を付けずに動かしたため、投稿しませんでした",
    21: "計画のファイル（--plan）と今の状態が違うため、何も送っていません",
}
CHECK_EXIT_MEANINGS = {
    0: "前提と違う応答はありませんでした",
    1: "前提と違う応答があります（または API・通信のエラー、想定外のエラー）",
    2: "実行する前に直すものがあります（設定ファイル、API キー、Python の版、PyYAML）",
}


# ===========================================================================
# 前回値の記憶
# ===========================================================================


def load_history() -> dict:
    """前回の選択を読む。壊れていても既定値で続行する。"""
    return _load_history(HISTORY_PATH)


def save_history(data: dict) -> None:
    """選択を保存する。書けなくても実行は妨げない。"""
    _save_history(HISTORY_PATH, data)


# ===========================================================================
# 設定の表示
# ===========================================================================


def describe_setup(config_path: str, env: dict | None = None) -> list[str]:
    """
    メニューの見出しの「設定ファイル:」の行（共通の部品の print_config_header。5 つのツールで同じ）の下に出す、
    接続先・記録先・追跡するプロジェクト・API キーの状態。設定ファイルが無いときは、「設定ファイル:」の行が示すので何も出さない。

    本体の読み込み（change_log.config.load_config）は足りないものがあると終了するため、
    ここでは共通の部品でファイルだけを読み、足りないものは「※」で示す。API キーの値は表示しない。
    UTF-8 でない（メモ帳の ANSI で保存した）ファイルも、落ちずに読めない理由を示す。
    """
    path = Path(config_path)
    if not path.is_file():
        return []
    try:
        raw = load_config_file(path)
    except ConfigError as e:
        message = str(e).splitlines()[0]
        if "空です" in message:
            return ["※ 設定ファイルの内容が空です"]
        return [f"※ {message}"]

    backlog = raw.get("backlog") or {}
    target = raw.get("target") or {}
    host = str(backlog.get("space_host") or "")
    issue_key = str(target.get("issue_key") or "")
    keys = target.get("project_keys")

    lines = [
        f"接続先: {host if host and not is_placeholder(host) else '※ backlog.space_host が未設定です'}",
        f"記録先: {issue_key if issue_key and issue_key not in PLACEHOLDERS else '※ target.issue_key が未設定です'}",
    ]
    if isinstance(keys, list) and keys:
        lines.append(f"追跡: {', '.join(str(k) for k in keys)}")
    else:
        lines.append("追跡: 記録先の課題のプロジェクト")
    found = find_api_key(env, config_path=path, config_value=backlog.get("api_key"))
    # API キーは環境変数・設定ファイル・.env のどれにも置ける。探した場所を 3 つとも示す
    lines.append("API キー: " + ("設定済み" if found else
                                   "※ 見つかりません（環境変数 BACKLOG_API_KEY・設定ファイルの backlog.api_key・.env のどれにも無い）"))
    return lines


# ===========================================================================
# 実行
# ===========================================================================


def build_args(action: str, *, config_path: str = "", days: int | None = None) -> list[str]:
    """本体に渡すコマンドライン引数を組み立てる。"""
    args = ["--config", config_path] if config_path else []
    if action == ACTION_DRY_RUN:
        args.append("--dry-run")
    elif action == ACTION_CHECK and days:
        args += ["--days", str(days)]
    return args


def script_for(action: str) -> Path:
    return CHECK_SCRIPT if action == ACTION_CHECK else MAIN_SCRIPT


def run_script(script: Path, args: list[str]) -> int:
    """本体を実行して終了コードを返す。"""
    return _run_script(script, args, TOOL_DIR)


def describe_exit(action: str, code: int) -> str:
    """「終了コード: N（意味）」の文（共通の部品。5 つのツールのメニューで同じ形）"""
    return _describe_exit(code, CHECK_EXIT_MEANINGS if action == ACTION_CHECK else EXIT_MEANINGS)


def choose_days(history: dict) -> int | None:
    """check_api.py で遡る日数を選ぶ。戻る場合は None。"""
    last = history.get("check_days")
    default = CHECK_DAYS.index(last) + 1 if last in CHECK_DAYS else 1
    choice = print_menu("遡る日数", [f"{d} 日" for d in CHECK_DAYS], default=default,
                        default_mark="前回" if last in CHECK_DAYS else "既定")
    return None if choice == 0 else CHECK_DAYS[choice - 1]


def run_action(action: str, label: str, config_path: str, history: dict) -> int | None:
    """1 つの操作を実行する。戻る場合は None。"""
    print()
    hr()
    print(f"  {label}")
    hr()

    days = None
    if action == ACTION_CHECK:
        days = choose_days(history)
        if days is None:
            return None
        history["check_days"] = days
    elif action == ACTION_POST:
        # 本体には確認が無い（定期実行で使うため）。取り消せない操作なので、ここで 1 回確認する。
        print("  前日までの未出力の日を、記録先の課題にコメントとして投稿します。")
        print("  投稿したコメントは、このツールでは取り消せません。")
        print("  先に「投稿内容を確認する」で内容を見ておくことを勧めます。")
        if not confirm("投稿しますか？"):
            print("  投稿しませんでした。")
            return None

    history["action"] = action
    save_history(history)
    return run_script(script_for(action), build_args(action, config_path=config_path, days=days))


# ===========================================================================
# エントリポイント
# ===========================================================================


def build_parser() -> argparse.ArgumentParser:
    parser = cli.make_parser(__file__, description="Backlog 変更記録 対話メニュー",
                             epilog="無人実行（定期実行）には backlog_change_log.py を直接使ってください。")
    cli.add_version(parser, TOOL_NAME, __version__)
    cli.add_config(parser, default=str(TOOL_DIR / "config.yaml"))
    return parser


def main() -> None:
    args = build_parser().parse_args()
    # 本体はツールのフォルダで動かすため、相対パスは起動した場所を基準に絶対パスにしておく。
    # そうしないと、見出しの表示と本体とで別のファイルを読む
    args.config = str(Path(args.config).resolve())
    history = load_history()
    last_action = history.get("action")
    default_choice = next((i for i, (key, _, _) in enumerate(ACTIONS, 1) if key == last_action), None)
    # 前回が「記録する」でも、既定にはしない（Enter だけで投稿の確認まで進まないように）
    if last_action == ACTION_POST:
        default_choice = None
    items = [f"{label} ― {desc}" for _, label, desc in ACTIONS]

    def loop() -> None:
        nonlocal default_choice
        while True:
            print_config_header("Backlog 変更記録", args.config, version=f"{TOOL_NAME} {__version__}")
            for line in describe_setup(args.config):
                print(f"  {line}")
            choice = print_menu("操作を選択", items, back_label="終了",
                                default=default_choice, default_mark="前回")
            if choice == 0:
                exit_menu()

            action, label, _ = ACTIONS[choice - 1]
            rc = run_action(action, label, args.config, history)
            if rc is not None:
                show_result(describe_exit(action, rc))
                if action != ACTION_POST:
                    default_choice = choice
                wait_enter()

    run_loop(loop)

if __name__ == "__main__":
    main()
