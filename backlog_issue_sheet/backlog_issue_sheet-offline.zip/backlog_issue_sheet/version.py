"""backlog_issue_sheet の版。CHANGELOG.md の最新の版と同じにする（版を切ったら上げる）。"""

TOOL_NAME = "backlog_issue_sheet"
__version__ = "0.13.5"
