"""
Excel の読み書き
================
読み込みは「登録」「更新」の 2 シートと、どのプロジェクト向けかを書く
「プロジェクト」シートを見る。ほかのシートは無視する。

書き込みはひな形・書き出し・実行結果・続きのシートの 4 つで共通に使う。
書き出しと実行結果は「更新」シート、続きのシートは「登録」シートの書式で出すため、
そのまま取り込みに戻せる。ひな形は両方のシートを持つ。
"""

from __future__ import annotations

import zipfile
from dataclasses import dataclass, field
from pathlib import Path
from xml.etree import ElementTree

# 日時のファイル名は、5 つのツールで共通の部品にある（ほかのモジュールとテストは、ここから読む）
from backlog_common.files import timestamp, unique_stamp  # noqa: F401
from openpyxl import Workbook, load_workbook
from openpyxl.styles import Alignment, Font, PatternFill
from openpyxl.utils import get_column_letter
from openpyxl.worksheet.datavalidation import DataValidation

from fields import (
    CHILD_HEADER,
    CHILD_MARK,
    CLEAR_TOKEN,
    COMMENT_PREFIX,
    DETACH_TOKEN,
    KEY_HEADER,
    PARENT_HEADER,
    REGISTER_SHEET,
    UPDATE_SHEET,
    Column,
    FormulaError,
    FormulaNoResult,
    all_columns,
    is_blank,
    name_table,
)
from master import Master

MASTER_SHEET = "_マスタ"
GUIDE_SHEET = "使い方"
PROJECT_SHEET = "プロジェクト"
PROJECT_LABEL = "プロジェクトキー"
PROJECT_NOTE = "取り込むとき、設定ファイルの project_key と照らし合わせます。違えば何も送りません。"
# 入力規則（プルダウン）を付ける行数
VALIDATION_ROWS = 1000


class SheetError(Exception):
    """Excel を読めなかった。"""


@dataclass
class SheetRow:
    row_no: int
    values: dict[int, object]          # 列番号 → セルの値


@dataclass
class SheetData:
    name: str
    headers: list[tuple[int, str]]     # (列番号, 見出し)。# で始まる列と空の見出しは除く
    rows: list[SheetRow] = field(default_factory=list)
    # 非表示の行（フィルターで隠した行を含む）。送らないが、登録シートの親子の確認と注意に使う
    hidden_rows: list[SheetRow] = field(default_factory=list)
    # 縦に結合したセルの範囲（B2:B4 など）。左上の値を下の行にも使ったもの。注意に出す
    merged_ranges: list[str] = field(default_factory=list)


class Book(dict):
    """
    {シート名: SheetData}。読み込んだブックに書かれたプロジェクトキーも持つ。

    project_key は「プロジェクト」シートが無ければ None、あっても値が空なら ""。
    """

    def __init__(self, *args, project_key: str | None = None, **kwargs):
        super().__init__(*args, **kwargs)
        self.project_key = project_key


STRICT_NAMESPACE = "http://purl.oclc.org/ooxml/spreadsheetml/main"


def is_strict_ooxml(path: Path) -> bool:
    """
    Strict Open XML の xlsx か。openpyxl は Strict に対応しておらず、そのまま読むと
    シートが見つからない・行が 0 件などの、原因と無関係な結果になる。

    xl/workbook.xml のルートの名前空間で見分ける。zip として読めないものは False を返し、
    openpyxl のエラーに任せる。
    """
    try:
        with zipfile.ZipFile(path) as z, z.open("xl/workbook.xml") as f:
            for _event, elem in ElementTree.iterparse(f, events=("start",)):
                return elem.tag.startswith(f"{{{STRICT_NAMESPACE}}}")
    except (zipfile.BadZipFile, KeyError, ElementTree.ParseError, OSError):
        return False
    return False


def read_workbook(path: str | Path) -> Book:
    """「登録」「更新」シートとプロジェクトキーを読む。どちらのシートも無ければ SheetError。"""
    path = Path(path)
    if not path.is_file():
        raise SheetError(f"ファイルが見つかりません: {path}")
    if path.suffix.lower() not in (".xlsx", ".xlsm"):
        raise SheetError(f"xlsx / xlsm 以外は読めません: {path.name}")
    if is_strict_ooxml(path):
        raise SheetError(
            f"Strict Open XML 形式のため読めません: {path.name}\n"
            "  → Excel で開き「名前を付けて保存」で、ファイルの種類を「Excel ブック (*.xlsx)」"
            "（.xlsm なら「Excel マクロ有効ブック (*.xlsm)」）にして保存し直してください"
        )
    # read_only は使わない。範囲をファイル内の dimension 記録に頼るため、
    # 記録が古いファイル（他のツールで作ったものなど）では行を取りこぼす。
    # まず数式のまま開き、数式があるときだけ計算結果（data_only）でも開く。数式のまま見ないと、
    # 計算結果を持たない数式（Excel 以外で作ったファイル）と空のセルを見分けられない。
    wb = _open(path, data_only=False)
    values_wb = None
    try:
        sheetnames = list(wb.sheetnames)
        targets = [name for name in (REGISTER_SHEET, UPDATE_SHEET, PROJECT_SHEET) if name in sheetnames]
        if any(_has_formula(wb[name]) for name in targets):
            values_wb = _open(path, data_only=True)

        def values_of(name):
            return values_wb[name] if values_wb is not None else None

        result = Book()
        for name in (REGISTER_SHEET, UPDATE_SHEET):
            if name in sheetnames:
                result[name] = _read_sheet(wb[name], name, values_of(name))
        if PROJECT_SHEET in sheetnames:
            result.project_key = _read_project_key(values_of(PROJECT_SHEET) or wb[PROJECT_SHEET])
    finally:
        wb.close()
        if values_wb is not None:
            values_wb.close()

    if not result:
        raise SheetError(
            f"「{REGISTER_SHEET}」「{UPDATE_SHEET}」のどちらのシートもありません: {path.name}"
            f"（シート名: {' / '.join(sheetnames)}）"
        )
    return result


def _read_project_key(ws) -> str:
    """A 列が「プロジェクトキー」の行の、B 列の値。その行が無ければ ""。"""
    # iter_rows は遠いセルまで作りながら回るので、持っているセルだけを見る（_read_sheet と同じ）
    for (row, col), cell in sorted(ws._cells.items()):
        if col != 1 or is_blank(cell.value) or str(cell.value).strip() != PROJECT_LABEL:
            continue
        value = ws._cells.get((row, 2))
        value = value.value if value is not None else None
        return "" if is_blank(value) else str(value).strip()
    return ""


def _open(path: Path, *, data_only: bool):
    try:
        return load_workbook(path, data_only=data_only)
    except Exception as e:  # 壊れたファイル・別形式など、openpyxl の例外は多岐にわたる
        raise SheetError(f"Excel を開けません: {path.name}（{e}）") from e


def _has_formula(ws) -> bool:
    return any(cell.data_type == "f" for cell in ws._cells.values())


def _cell_value(cell, values_ws=None):
    """
    セルの値。数式のセルは計算結果（values_ws の同じ位置）を読む。

    エラー値のセルは FormulaError、計算結果を持たない数式のセルは FormulaNoResult で包み、
    ほかの文字列と見分けられるようにする。どちらも計画で行のエラーになる。
    """
    if cell.data_type == "f":
        cached = values_ws._cells.get((cell.row, cell.column)) if values_ws is not None else None
        if cached is None or cached.value is None:
            formula = cell.value if isinstance(cell.value, str) else getattr(cell.value, "text", "=")
            return FormulaNoResult(formula or "=")
        cell = cached
    if cell.data_type == "e" and cell.value is not None:
        return FormulaError(cell.value)
    return cell.value


def _read_sheet(ws, name: str, values_ws=None) -> SheetData:
    """
    シートを読む。セルは、ワークシートが実際に持っているもの（ws._cells）だけを見る。

    iter_rows はシートの範囲（ws.max_row × ws.max_column）のセルをすべて作りながら回る。書式だけを
    付けた遠いセル（Ctrl+End の位置が XFD1048576 など）が 1 つあると、読み込みが事実上止まっていた。
    """
    cells = ws._cells   # {(行, 列): Cell}。openpyxl の内部だが、公開の手段では作らずに辿れない
    headers = []
    for (row, col), cell in sorted(cells.items()):
        if row != 1 or is_blank(cell.value):
            continue
        header = str(cell.value).strip()
        if header.startswith(COMMENT_PREFIX):
            continue
        headers.append((col, header))

    data = SheetData(name=name, headers=headers)
    wanted = {idx for idx, _ in headers}
    merged = _merged_values(ws, wanted, values_ws, data)
    row_numbers = sorted({row for (row, col) in cells if row >= 2 and col in wanted}
                         | {row for (row, _col) in merged})
    for row_no in row_numbers:
        values = {}
        for idx in sorted(wanted):
            if (row_no, idx) in merged:
                values[idx] = merged[(row_no, idx)]
                continue
            cell = cells.get((row_no, idx))
            values[idx] = _cell_value(cell, values_ws) if cell is not None else None
        if all(is_blank(v) and not isinstance(v, FormulaError) for v in values.values()):
            continue
        # フィルターで絞って見えている行だけを送るつもりの人が、隠れた行まで送らないように
        hidden = row_no in ws.row_dimensions and ws.row_dimensions[row_no].hidden
        (data.hidden_rows if hidden else data.rows).append(SheetRow(row_no=row_no, values=values))
    return data


def _merged_values(ws, wanted: set[int], values_ws, data: SheetData) -> dict[tuple[int, int], object]:
    """
    縦に結合したセルの、左上より下の行に入れる値。{(行, 列): 値}。

    openpyxl は左上のセルだけに値を持たせ、ほかは空になる。登録シートで担当者などの列を
    結合すると、2 行目以降が担当者なしで作られていた。見た目どおり、左上の値を使う。
    横の結合（見出しのように列をまたぐもの）は、別の列に値が入ってしまうので埋めない。
    """
    fill = {}
    for rng in ws.merged_cells.ranges:
        # 見出しの行から始まる結合は埋めない（見出しの文字が値になってしまう）
        if rng.min_col not in wanted or rng.max_row == rng.min_row or rng.min_row < 2:
            continue
        anchor = ws._cells.get((rng.min_row, rng.min_col))
        value = _cell_value(anchor, values_ws) if anchor is not None else None
        if is_blank(value) and not isinstance(value, FormulaError):
            continue
        for row in range(rng.min_row + 1, rng.max_row + 1):
            fill[(row, rng.min_col)] = value
        data.merged_ranges.append(rng.coord)
    return fill


# ---------------------------------------------------------------------------
# 書き込み
# ---------------------------------------------------------------------------

HEADER_FONT = Font(bold=True, color="FFFFFF")
HEADER_FILL = PatternFill("solid", fgColor="4F6D8F")
STRUCTURE_FILL = PatternFill("solid", fgColor="8F5F4F")   # 課題キー・親子の列
REFERENCE_FILL = PatternFill("solid", fgColor="8A8A8A")   # # で始まる参照用の列
WRAP = Alignment(wrap_text=True, vertical="top")
TOP = Alignment(vertical="top")

COLUMN_WIDTHS = {
    KEY_HEADER: 12, PARENT_HEADER: 12, CHILD_HEADER: 8,
    "件名": 40, "詳細": 50, "#説明": 50,
}


def register_headers(master: Master) -> list[str]:
    return [PARENT_HEADER, CHILD_HEADER] + [c.header for c in all_columns(master)]


def update_headers(master: Master) -> list[str]:
    return [KEY_HEADER, PARENT_HEADER] + [c.header for c in all_columns(master)]


def _style_header(ws, headers: list[str]) -> None:
    for idx, header in enumerate(headers, start=1):
        cell = ws.cell(row=1, column=idx, value=header)
        cell.font = HEADER_FONT
        if header.startswith(COMMENT_PREFIX):
            cell.fill = REFERENCE_FILL
        elif header in (KEY_HEADER, PARENT_HEADER, CHILD_HEADER):
            cell.fill = STRUCTURE_FILL
        else:
            cell.fill = HEADER_FILL
        width = COLUMN_WIDTHS.get(header, max(10, min(30, len(header) * 2 + 4)))
        ws.column_dimensions[get_column_letter(idx)].width = width
    ws.freeze_panes = "A2"


def _write_master_sheet(wb: Workbook, master: Master) -> dict[str, str]:
    """
    プルダウンの選択肢を隠しシートに並べる。

    返り値は {見出し: 参照式}。入力規則に直接選択肢を書くと 255 文字の
    上限があり、ユーザーやカテゴリーが多いと収まらないため、範囲で参照する。
    """
    ws = wb.create_sheet(MASTER_SHEET)
    lists: dict[str, list[str]] = {CHILD_HEADER: [CHILD_MARK]}
    for col in all_columns(master):
        if col.kind != "name":   # 複数値の列は 1 つしか選べないプルダウンに向かない
            continue
        # 同姓同名のユーザーは名前では特定できず、選んでも取り込みでエラーになる
        lists[col.header] = name_table(col, master).choices()

    refs = {}
    for idx, (header, names) in enumerate(lists.items(), start=1):
        letter = get_column_letter(idx)
        ws.cell(row=1, column=idx, value=header)
        for r, name in enumerate(names, start=2):
            ws.cell(row=r, column=idx, value=name)
        if names:
            refs[header] = f"'{MASTER_SHEET}'!${letter}$2:${letter}${len(names) + 1}"
    ws.sheet_state = "hidden"
    return refs


def _add_validations(ws, headers: list[str], refs: dict[str, str]) -> None:
    """
    プルダウンを付ける。入力の手助けであって制限ではないため、
    一覧に無い値もエラーにしない（(削除) を書けるように。名前の検査は取り込み時に行う）。
    """
    for idx, header in enumerate(headers, start=1):
        if header not in refs:
            continue
        letter = get_column_letter(idx)
        dv = DataValidation(type="list", formula1=refs[header], allow_blank=True)
        dv.showErrorMessage = False
        dv.add(f"{letter}2:{letter}{VALIDATION_ROWS + 1}")
        ws.add_data_validation(dv)


def _format_cells(ws, headers: list[str], columns: dict[str, Column], n_rows: int) -> None:
    for idx, header in enumerate(headers, start=1):
        col = columns.get(header)
        wrap = col is not None and (col.kind == "names" or header == "詳細")
        is_date = col is not None and col.kind == "date"
        for r in range(2, n_rows + 2):
            cell = ws.cell(row=r, column=idx)
            cell.alignment = WRAP if wrap else TOP
            if is_date:
                cell.number_format = "yyyy-mm-dd"


# メニュー（menu.py）の項目名で案内する。メニューから使う人はコマンド名を知らないため。
# 名前がメニューとずれないことは tests/test_menu.py で確かめる
GUIDE_LINES = [
    "このブックは backlog-issue-sheet で取り込める書式です。",
    "",
    f"■ 「{REGISTER_SHEET}」シート：課題を新しく作る",
    f"  ・{CHILD_HEADER}に {CHILD_MARK} を付けた行は、上へさかのぼって最初に見つかった"
    f" {CHILD_MARK} の無い行の子課題になります。",
    f"  ・既にある課題の子にするときは、{PARENT_HEADER}にその課題キーを書きます。",
    "  ・件名は必須です。種別は空なら「タスク」、優先度は空なら「中」になります"
    "（設定の default_issue_type / default_priority で変えられます）。",
    "",
    f"■ 「{UPDATE_SHEET}」シート：既存の課題を変更する",
    f"  ・{KEY_HEADER}は必須です。",
    "  ・空のセルは変更しません。値を消すときは "
    f"{CLEAR_TOKEN} と書きます。",
    f"  ・{PARENT_HEADER}に課題キーを書くとその子課題に、{DETACH_TOKEN} と書くと"
    "子課題ではなくなります。",
    "",
    f"■ 「{PROJECT_SHEET}」シート：どのプロジェクト向けのブックか",
    f"  ・{PROJECT_LABEL}を書きます。取り込むとき、設定ファイルの project_key と違えば何も送りません。",
    "  ・メニューの「ひな形を作る」（python backlog_issue_sheet.py template）で作ったひな形と、"
    "書き出したファイルには、はじめから入っています。",
    "  ・空のときは、取り込む先のプロジェクトキーを書いてください。"
    "空のままでも取り込めますが、プロジェクトを確かめられず、そのたびに注意が出ます。",
    "",
    "■ 共通",
    "  ・列は見出しの名前で読みます。要らない列は消して構いません。",
    "  ・見出しが # で始まる列は読み飛ばします（メモ用）。",
    "  ・カテゴリーなど複数の値は、改行（Alt+Enter）か「,」「、」で区切ります。",
    "  ・カスタム属性は、その名前を見出しにした列を足すと使えます。",
    "  ・使える名前（種別・担当者・カスタム属性など）は、"
    "メニューの「使える名前の一覧」（python backlog_issue_sheet.py master）で確かめられます。",
    f"  ・{REGISTER_SHEET}シートでは行の順番が親子関係を表すため、並べ替えないでください。",
]


EXAMPLE_NOTE_HEADER = "#説明"


def _write_project_sheet(wb: Workbook, master: Master) -> None:
    ws = wb.create_sheet(PROJECT_SHEET)
    label = ws.cell(row=1, column=1, value=PROJECT_LABEL)
    label.font = HEADER_FONT
    label.fill = STRUCTURE_FILL
    ws.cell(row=1, column=2, value=master.project_key or None)
    ws.cell(row=3, column=1, value=PROJECT_NOTE)
    ws.column_dimensions["A"].width = 16
    ws.column_dimensions["B"].width = 16


def write_workbook(path: str | Path, master: Master, **kwargs) -> Path:
    """ブックを組み立てて保存する。引数は build_workbook と同じ。"""
    path = Path(path)
    wb = build_workbook(master, **kwargs)
    try:
        path.parent.mkdir(parents=True, exist_ok=True)
        wb.save(path)
    except OSError as e:
        # Windows では、同じ名前のファイルを Excel で開いていると PermissionError になる
        raise SheetError(file_write_message(path, e)) from e
    return path


def file_write_message(path: Path, e: OSError) -> str:
    return (
        f"ファイルに書き込めません: {path}（{e.strerror or e}）\n"
        "  → 同じ名前のファイルを Excel で開いていれば閉じてください。出力先のフォルダに書き込めるかも確かめてください"
    )


def build_workbook(
    master: Master,
    *,
    register_rows: list[dict] | None = None,
    update_rows: list[dict] | None = None,
    extra_update_headers: list[str] | None = None,
    include_register: bool = True,
    include_guide: bool = False,
    examples: dict[str, tuple[str, list[dict]]] | None = None,
) -> Workbook:
    """
    ブックを組み立てる。行は {見出し: 値} の dict で渡す。

    include_register=False なら「更新」シートだけを出す（書き出し・実行結果用）。
    examples は {シート名: (書式にするシート名, 行)}。記入例のシートで、
    「登録」「更新」以外の名前なので取り込みでは読まれない。
    """
    columns = {c.header: c for c in all_columns(master)}

    wb = Workbook()
    wb.remove(wb.active)
    if include_guide:
        guide = wb.create_sheet(GUIDE_SHEET)
        for r, line in enumerate(GUIDE_LINES, start=1):
            guide.cell(row=r, column=1, value=line)
        guide.column_dimensions["A"].width = 100

    sheets = []
    if include_register:
        sheets.append((wb.create_sheet(REGISTER_SHEET), register_headers(master), register_rows or []))
    sheets.append((
        wb.create_sheet(UPDATE_SHEET),
        update_headers(master) + list(extra_update_headers or []),
        update_rows or [],
    ))
    _write_project_sheet(wb, master)
    for name, (based_on, rows) in (examples or {}).items():
        base = register_headers(master) if based_on == REGISTER_SHEET else update_headers(master)
        sheets.append((wb.create_sheet(name), base + [EXAMPLE_NOTE_HEADER], rows))

    refs = _write_master_sheet(wb, master)
    for ws, headers, rows in sheets:
        _style_header(ws, headers)
        for r, row in enumerate(rows, start=2):
            for idx, header in enumerate(headers, start=1):
                value = row.get(header)
                if value is not None:
                    ws.cell(row=r, column=idx, value=value)
        _format_cells(ws, headers, columns, max(len(rows), 1))
        _add_validations(ws, headers, refs)

    wb.active = wb.sheetnames.index(sheets[0][0].title)
    return wb
