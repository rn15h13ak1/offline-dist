"""
Backlog API クライアント
========================
通信（送る・再送する・待つ・エラーにする）と、どのツールでも使う取得・課題の作成と更新は、
共通の部品 backlog_common/client.py にある。ここには本ツールで使う取得（完了理由・カテゴリー・
バージョン・子課題）だけを足す。
"""

from backlog_common import client as _common
from backlog_common.client import BacklogAPIError, BacklogError, BacklogNoChangeError

__all__ = ["BacklogAPIError", "BacklogClient", "BacklogError", "BacklogNoChangeError"]


class BacklogClient(_common.BacklogClient):
    def get_resolutions(self) -> list:
        """完了理由の一覧（スペース共通）"""
        return self._get("/resolutions")

    def get_categories(self, project_id_or_key) -> list:
        """カテゴリーの一覧"""
        return self._get(f"/projects/{project_id_or_key}/categories")

    def get_versions(self, project_id_or_key) -> list:
        """
        バージョン（マイルストーン）の一覧。

        Backlog では「発生バージョン」と「マイルストーン」は同じ一覧から選ぶ。
        """
        return self._get(f"/projects/{project_id_or_key}/versions")

    def get_child_issues(self, project_id: int, parent_issue_id: int) -> list:
        """指定した課題の子課題を全件取得する。"""
        return self.get_issues(project_id, {"parentIssueId": [parent_issue_id]})
