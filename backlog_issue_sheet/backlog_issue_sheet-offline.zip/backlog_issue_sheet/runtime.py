"""
実行環境への手当て
==================
入口（本体・メニュー）で、ほかの処理より先に呼ぶ。

メニューはどの Python からでも起動されうるため、このファイルは 3.9 でも読める書き方に保つ
（注釈に `str | None` などを書かない。tests/test_windows.py が確かめる）。
前例は同じ種類のツールの runtime.py。
"""

import sys


def make_console_safe(streams=None):
    """
    UTF-8 でないコンソールで、表せない文字を「?」に置き換えて出すようにする。

    Windows の日本語コンソールは既定で CP932 で、CP932 に無い文字を print すると
    UnicodeEncodeError で落ちる。ソースの文字は tests/test_windows.py で CP932 に収めているが、
    課題の件名など Backlog から来る文字（絵文字など）は防げない。落ちるよりは、その文字だけ
    「?」になる方がよい。

    - コードページ（chcp）は変えない。同じ窓で次に動かすものに影響するため
    - 置き換えるのは画面の表示だけ。Backlog に送る内容や、ファイルに書く内容は変わらない
    - UTF-8 のコンソール（macOS など）では何もしない
    """
    for stream in (sys.stdout, sys.stderr) if streams is None else streams:
        encoding = (getattr(stream, "encoding", None) or "").lower().replace("-", "").replace("_", "")
        if encoding in ("", "utf8") or not hasattr(stream, "reconfigure"):
            continue
        try:
            stream.reconfigure(errors="replace")
        except (ValueError, OSError):
            pass


# 本体が動く Python の下限（pyproject.toml の requires-python と揃える）
MIN_PYTHON = (3, 10)


def require_python(version_info=None, stream=None):
    """
    Python が古ければ、入れ直す案内を出して止める（終了コード 1）。

    本体は 3.10 以上の書き方（注釈の `str | None` など）を使うため、3.9 では import の途中で
    「unsupported operand type(s) for |」のトレースバックになる。macOS 付属の python3 は 3.9。
    ほかのモジュールを読み込む前に呼ぶ。
    """
    version = tuple(version_info or sys.version_info)[:2]
    if version >= MIN_PYTHON:
        return
    out = stream or sys.stderr
    need = ".".join(str(n) for n in MIN_PYTHON)
    print("Python {} 以上を入れてください。".format(need), file=out)
    print("  実行中の Python: {}（{}）".format(".".join(str(n) for n in version), sys.executable), file=out)
    print("  https://www.python.org/ から入れ、README の「動作要件」の手順で依存も入れてください。", file=out)
    sys.exit(1)
