"""
backlog-issue-sheet
===================
Excel の「登録」「更新」シートから Backlog の課題を作成・更新する。
Backlog の課題を、同じ書式の Excel に書き出すこともできる。ツールのフォルダで動かす。

  python backlog_issue_sheet.py template                                    ひな形を作る
  python backlog_issue_sheet.py import 課題.xlsx --sheet 登録               ドライラン（既定）
  python backlog_issue_sheet.py import 課題.xlsx --sheet 更新 --execute
  python backlog_issue_sheet.py export                                      Backlog → Excel
  python backlog_issue_sheet.py master                                      使える名前の一覧
"""

from __future__ import annotations

import argparse
import sys
from pathlib import Path

from backlog_common.runtime import (
    EXIT_NEEDS_CONFIRMATION,
    exit_on_interrupt,
    make_console_safe,
    require_packages,
    require_python,
    stop_on_sigterm,
)

# 3.9 だと、下の import の途中で原因の分からないトレースバックになるため、先に確かめる
require_python()

# 依存が無ければ、入れ方を案内して 1 で止める（PyYAML は設定ファイルを読む共通の部品が使う）
require_packages([("openpyxl", "openpyxl"), ("yaml", "pyyaml")])

# 設定ファイルと API キーの読み込みは、5 つのツールで共通の部品にある
from backlog_common import cli
from backlog_common import config as config_files
from backlog_common import plan as plans
from backlog_common.client import estimate_text, format_api_error
from backlog_common.config import API_KEY_ENV, ConfigError  # noqa: F401  （テストと案内が使う）
from backlog_common.console import ask_yes, not_tty_text, pad

import executor
from backlog_client import BacklogAPIError, BacklogClient
from exporter import ExportError, ExportFilter, export, parent_key_map, write_issues
from fields import (
    CHILD_HEADER,
    PARENT_HEADER,
    REGISTER_SHEET,
    UPDATE_SHEET,
    all_columns,
    display,
    unsupported_custom_fields,
    unsupported_note,
)
from master import Master
from planner import DEFAULT_ISSUE_TYPE, DEFAULT_PRIORITY, Plan, build_plan
from resume import has_unsent_update, remaining_register_rows
from sheet_io import Book, SheetError, read_workbook, unique_stamp, write_workbook
from version import TOOL_NAME, __version__

TOOL_DIR = Path(__file__).resolve().parent

EXIT_OK = 0
EXIT_FAILED = 1        # 検証エラー・送信の失敗
EXIT_USAGE = 2         # 設定・引数の誤り
EXIT_NOT_CONFIRMED = EXIT_NEEDS_CONFIRMATION   # 20: 確認できないため、何も送らずに止めた
EXIT_INTERRUPTED = 130


class NotConfirmed(Exception):
    """端末でない所で --yes を付けずに実行した（終了コード 20）。何も送っていない。"""


# ---------------------------------------------------------------------------
# 設定
# ---------------------------------------------------------------------------

# 書ける項目（知らない項目は止める。5 つのツールで同じ）。backlog: の節は共通の部品の項目に project_key を足したもの
# （timeout・max_retries・retry_backoff・retry_max_delay の通信の設定も、共通の部品が確かめて BacklogClient に渡す）
ALLOWED_KEYS = {"backlog", "output_dir", "default_issue_type", "default_priority"}
ALLOWED_BACKLOG_KEYS = set(config_files.BACKLOG_KEYS) | {"project_key"}


def find_config(explicit: str | None) -> Path:
    """--config が無ければ、ツールのフォルダの config.yaml（5 つのツールで同じ。以前は作業フォルダを先に探した）。"""
    return config_files.find_config(explicit, (TOOL_DIR / "config.yaml",))


def load_config(path: Path) -> dict:
    config = config_files.load_config(path)

    problems = config_files.unknown_keys(config, ALLOWED_KEYS)
    # 節の形・知らない項目・通信の設定と ssl_verify・必須の項目は、共通の部品が 5 つのツールで同じ文で確かめる
    problems += config_files.backlog_problems(config, ["space_host", "project_key"], ALLOWED_BACKLOG_KEYS)[1]
    problems += config_files.text_problems(config, ["output_dir"])
    for key, label, example in (("default_issue_type", "種別", "タスク"), ("default_priority", "優先度", "中")):
        value = config.get(key)
        if value is not None and (not isinstance(value, str) or not value.strip()):
            problems.append(f"{key} は{label}の名前（例: {example}）で書いてください")
    if problems:
        raise ConfigError(config_files.problems_text(path, problems))
    return config


def find_api_key(config_path: Path, config: dict | None = None) -> str:
    return locate_api_key(config_path, config)[0]


def locate_api_key(config_path: Path, config: dict | None = None) -> tuple[str, str]:
    """
    (API キー, どこから読んだか)。環境変数 → 設定ファイルの backlog.api_key → .env
    （設定ファイルの隣 → このフォルダ → 作業フォルダ）の順。どこから読んだかは、
    認証・権限のエラーのときに、どこを直せばよいかを示すのに使う。
    """
    in_config = ((config or {}).get("backlog") or {}).get("api_key")
    return config_files.locate_api_key(config_path, in_config, tool_dir=TOOL_DIR)


def output_dir(config: dict, config_path: Path, override: str | None) -> Path:
    if override:
        return Path(override)
    out = Path(config.get("output_dir") or "output")
    return out if out.is_absolute() else config_path.parent / out


def stamped_path(out_dir: Path, name: str) -> Path:
    """name の {} に日時を入れたパス。既にあるファイルとは重ならない。"""
    return out_dir / name.format(unique_stamp(out_dir, [name]))


def make_client(config: dict, api_key: str, debug: bool) -> BacklogClient:
    b = config["backlog"]
    return BacklogClient(
        space_host=b["space_host"],
        api_key=api_key,
        ssl_verify=b.get("ssl_verify", True),
        base_path=b.get("base_path", ""),
        debug=debug,
        **config_files.client_settings(b),
    )


# ---------------------------------------------------------------------------
# 表示
# ---------------------------------------------------------------------------

def print_problems(plan: Plan) -> None:
    if plan.warnings:
        print(f"\n注意（{len(plan.warnings)} 件）:")
        for w in plan.warnings:
            print(f"  ! {w}")
    if plan.problems:
        print(f"\nエラー（{len(plan.problems)} 件）: 直すまで Backlog には何も送りません")
        for p in plan.problems:
            print(f"  NG {p}")


def error_rows(plan: Plan, sheet: str) -> set[int]:
    """エラーのある行の行番号。"""
    return {p.row for p in plan.problems if p.sheet == sheet and p.row is not None}


def row_mark(row_no: int, errors: set[int]) -> str:
    """
    行の頭に付ける印。エラーのある行は NG。

    予定の一覧は、エラーのある行も読めた値だけで組み立てて並べる。印が無いと、
    件名が空の行や項目の抜けた行まで「作られる」ように読めてしまう。
    """
    # チェックやバツの記号は Windows の日本語コンソール（CP932）で出せず、落ちるため文字で示す
    return "NG " if row_no in errors else "   "


def error_note(rows: list[int], errors: set[int]) -> str:
    n = sum(1 for r in rows if r in errors)
    return f"（うちエラー {n} 行）" if n else ""


def print_plan(plan: Plan, master: Master) -> None:
    if plan.creates:
        errors = error_rows(plan, REGISTER_SHEET)
        note = error_note([cp.row_no for cp in plan.creates], errors)
        print(f"\n■ {REGISTER_SHEET}シート（作成 {len(plan.creates)} 件{note}）")
        for cp in plan.creates:
            is_child = cp.parent_row is not None or cp.parent_key
            branch = "  └ " if is_child else ""
            parent = ""
            if cp.parent_row is not None:
                parent = f"（親: {cp.parent_row}行目）"
            elif cp.parent_key:
                parent = f"（親: {cp.parent_key}）"
            print(f"{row_mark(cp.row_no, errors)}{pad(f'{cp.row_no}行目', 8)}{branch}{cp.summary}{parent}")
            attrs = [
                f"{cp.columns[k].header}={display(cp.columns[k], v, master)}"
                + ("（既定）" if k in cp.defaulted else "")
                for k, v in cp.values.items() if k != "summary"
            ]
            attrs += [
                f"{cp.columns[k].header}={display(cp.columns[k], v, master)}（作成後に更新）"
                for k, v in cp.follow_up.items()
            ]
            if attrs:
                print(" " * 12 + " / ".join(attrs))

    errors = error_rows(plan, UPDATE_SHEET)
    listed = {u.row_no for u in plan.updates}
    # 課題キーの誤り（空・形・存在しない・別プロジェクト・重複）で、どの課題か決まらない行は
    # 一覧に載らない。見出しの件数だけでは、その行があることに気づけないため別に示す
    unlisted = sorted(r for r in errors if r >= 2 and r not in listed)
    if plan.updates or unlisted:
        changed = [u for u in plan.updates if u.has_changes]
        note = error_note([u.row_no for u in plan.updates], errors)
        print(
            f"\n■ {UPDATE_SHEET}シート（更新 {len(changed)} 件 / "
            f"変更なし {len(plan.updates) - len(changed)} 件{note}）"
        )
        if unlisted:
            rows = "、".join(str(r) for r in unlisted)
            print(f"NG ほかに、課題キーの誤りで一覧に載らない行が {len(unlisted)} 行あります（{rows} 行目）")
        for up in plan.updates:
            mark = "" if up.has_changes else "  変更なし"
            print(f"{row_mark(up.row_no, errors)}{pad(f'{up.row_no}行目', 8)}{up.issue_key} {up.summary}{mark}")
            if up.parent_change:
                kind, parent, old_key = up.parent_change
                new = parent["issueKey"] if kind == "set" else "（なし）"
                print(" " * 12 + f"{PARENT_HEADER}: {old_key or '（なし）'} → {new}")
            for c in up.changes:
                print(
                    " " * 12 + f"{c.column.header}: "
                    f"{display(c.column, c.old, master)} → {display(c.column, c.new, master)}"
                )


def menu_execute_label(sheet: str) -> str:
    """メニュー（menu.py）で、そのシートを実行する項目の表示名。ドライランの案内に使う。"""
    return f"{sheet}（実行）"


def _stop_without_tty() -> bool:
    # 0 で終えると、タスクスケジューラなどの無人実行で成功と見分けが付かない
    raise NotConfirmed(not_tty_text("送ってよいか", "何も送っていません", "自動で実行するなら --yes を付けてください。"))


def ask(prompt: str, assume_yes: bool) -> bool:
    """[y/N] の確認を取る。端末でない所からは止める（終了コード 20。聞き方は共通の部品）。"""
    return ask_yes(prompt, assume_yes, _stop_without_tty)


# ---------------------------------------------------------------------------
# サブコマンド
# ---------------------------------------------------------------------------

def print_api_key_source(args) -> None:
    """認証・権限のエラーのとき、今回どこの API キーを使ったかを示す。直す場所が分かるように。"""
    source = getattr(args, "api_key_source", None)
    if source:
        print(config_files.api_key_source_line(source), file=sys.stderr)


def connect(args) -> tuple[dict, Path, BacklogClient, Master]:
    config_path = find_config(args.config)
    config = load_config(config_path)
    api_key, args.api_key_source = locate_api_key(config_path, config)
    client = make_client(config, api_key, args.debug)
    print(f"接続先: {config['backlog']['space_host']} / {config['backlog']['project_key']}")
    try:
        master = Master.load(client, config["backlog"]["project_key"])
    except BacklogAPIError as e:
        if e.status is not None:
            raise   # HTTP の応答があった（404 などは、通信層が案内を付けている）
        raise BacklogAPIError(
            f"{e}\n{connect_hint(config, config_path, e.detail)}", endpoint=e.endpoint, detail=e.detail,
        ) from e
    return config, config_path, client, master


def connect_hint(config: dict, config_path: Path, detail: str) -> str:
    """
    最初の接続で、応答が無かったときの案内。OS の理由（英語）だけでは、どこを直せばよいか分からない。

    名前解決の失敗・証明書の検証の失敗・プロキシは、どれも同じ「通信に失敗しました」になる。
    理由の文から見当が付くものは先頭に出す。
    """
    b = config["backlog"]
    checks = [
        f"backlog.space_host（{b['space_host']}）の書き間違い。`https://` を付けず、ホスト名だけを書きます",
        "社内のプロキシやファイアウォール。ブラウザで Backlog を開けるか確かめてください",
        "オンプレ版で自己署名の証明書を使っているなら、backlog.ssl_verify を false にする",
        "オンプレ版でパスが付くなら、backlog.base_path（例: /backlog）",
    ]
    if "CERTIFICATE_VERIFY_FAILED" in detail or "certificate" in detail.lower():
        checks.insert(0, checks.pop(2))
    return f"  → 次を確かめてください（設定ファイル: {config_path}）\n" + "\n".join(f"    ・{c}" for c in checks)


def cmd_template(args) -> int:
    config, config_path, _, master = connect(args)
    out_dir = output_dir(config, config_path, args.output_dir)
    path = Path(args.output) if args.output else stamped_path(out_dir, "課題シート_{}.xlsx")
    write_workbook(path, master, include_guide=True)
    print(f"ひな形を作りました: {path}")
    columns = len(all_columns(master))
    print(f"  列: {columns} 項目（うちカスタム属性 {len(master.custom_fields) - len(unsupported_custom_fields(master))}）")
    note = unsupported_note(master)
    if note:
        print(f"  ! {note}")
    return EXIT_OK


def cmd_master(args) -> int:
    _, _, _, master = connect(args)
    labels = [
        ("種別", "issue_types"), ("優先度", "priorities"), ("状態", "statuses"),
        ("完了理由", "resolutions"), ("担当者（括弧内はログイン ID）", "users"), ("カテゴリー", "categories"),
        ("発生バージョン / マイルストーン", "versions"),
    ]
    for label, key in labels:
        names = master.table(key).labels()
        print(f"\n{label}")
        print("  " + (" / ".join(names) if names else "（なし）"))
    print("\nカスタム属性（列の見出しにこの名前を書く）")
    if not master.custom_fields:
        print("  （なし）")
    for cf in master.custom_fields:
        flags = []
        if not cf.is_supported:
            flags.append("本ツールでは扱えない種類。Backlog の画面で入力する")
        if cf.required:
            flags.append("必須")
        if cf.applicable_issue_types:
            types = master.table("issue_types")
            flags.append("種別: " + "、".join(types.name_of(t) for t in cf.applicable_issue_types))
        extra = f"（{' / '.join(flags)}）" if flags else ""
        print(f"  {cf.name}  [{cf.type_name}]{extra}")
        if cf.items:
            print(f"      選択肢: {' / '.join(cf.items.names())}")
    if not master.subtasking_enabled:
        print("\n※ このプロジェクトでは親子課題が無効です")
    return EXIT_OK


def select_sheet(book: Book, name: str, excel: str) -> tuple[Book, list[str]]:
    """
    指定したシートだけを残す。返り値の 2 つ目は、読まなかったシートについての知らせ。

    両方のシートを一度に読むと、前に書いたまま残っていた行まで送ってしまう。
    そのつもりの無いシートは、行があっても読まない。
    """
    if name not in book:
        others = " / ".join(book) or "なし"
        raise SheetError(f"「{name}」シートがありません: {Path(excel).name}（取り込めるシート: {others}）")
    notes = [
        f"※ 「{other}」シートにも {len(sheet.rows)} 行ありますが、今回は読みません（取り込むのは「{name}」シートだけ）"
        for other, sheet in book.items() if other != name and sheet.rows
    ]
    return Book({name: book[name]}, project_key=book.project_key), notes


def cmd_import(args) -> int:
    # 計画のファイルは、つなぐ前に読む（読めなければ、何も送らずに止める）
    plan_request = plans.PlanRequest.from_args(
        args, TOOL_NAME, __version__,
        plan_args={"sheet": args.sheet, "limit": args.limit, "allow_duplicates": args.allow_duplicates},
        inputs={"excel": plans.file_digest(args.excel)},
    )
    config, config_path, client, master = connect(args)
    plan_request.inputs["config"] = plans.file_digest(config_path)
    sheets, notes = select_sheet(read_workbook(args.excel), args.sheet, args.excel)
    print(f"読み込み: {args.excel}（{args.sheet} {len(sheets[args.sheet].rows)} 行）")
    for note in notes:
        print(note)
    print("Backlog の現在の状態と照らし合わせています…")
    plan = build_plan(
        sheets, master, client, allow_duplicates=args.allow_duplicates,
        default_issue_type=config.get("default_issue_type") or DEFAULT_ISSUE_TYPE,
        default_priority=config.get("default_priority") or DEFAULT_PRIORITY,
    )

    print_plan(plan, master)
    print_problems(plan)
    if plan.duplicate_rows:
        how = "コマンドで --allow-duplicates を付けて" if args.from_menu else "--allow-duplicates を付けて"
        print(f"\n  同じ件名で意図して作るときは、{how}実行してください。")
    if not plan.ok:
        return EXIT_FAILED

    full_plan = plan
    held: list[int] = []
    if args.limit is not None:
        plan, held = executor.limit_plan(plan, args.limit)
    n_actions = executor.count_actions(plan)
    operations = executor.plan_operations(plan, master.project_id)
    if n_actions == 0:
        print("\n送信するものはありません。")
        return EXIT_OK if plan_request.settle(operations) else plans.EXIT_PLAN_MISMATCH
    if held:
        rows = "、".join(str(n) for n in held)
        print(f"\n--limit {args.limit} のため、今回は {len(held)} 行を送りません（{rows} 行目）。")
    if not args.execute:
        # オプション名は前後を空白で区切る（日本語に続けて書くと読みにくい）。メニューの案内は日本語どうしなので詰める
        how = f"メニューの「{menu_execute_label(args.sheet)}」を選んでください" if args.from_menu else " --execute を付けてください"
        print(f"\nドライランです（送信予定 {n_actions} 件）。Backlog に反映するには{how}。")
        print(estimate_text(executor.count_calls(plan)))
        return EXIT_OK if plan_request.settle(operations) else plans.EXIT_PLAN_MISMATCH

    # 計画と違えば、確認を出さずに止める
    if not plan_request.settle(operations):
        return plans.EXIT_PLAN_MISMATCH
    if not ask(f"\nBacklog に反映しますか？ 送信 {n_actions} 件 [y/N]: ", args.yes):
        print("送信しませんでした。")
        return EXIT_OK

    with plans.ResultLog(args.result_out, TOOL_NAME, __version__) as result:
        result.start(plan_request.current)
        code = send(args, config, config_path, client, master, sheets, full_plan, plan, held, result)
        result.close({EXIT_OK: "done", EXIT_INTERRUPTED: "interrupted"}.get(code, "failed"), code)
    return code


def send(args, config, config_path, client, master, sheets, full_plan, plan, held, result) -> int:
    """確認の済んだ計画を送り、結果を示す。終了コードを返す。"""

    out_dir = output_dir(config, config_path, args.output_dir)
    ts = unique_stamp(out_dir, ["run_{}.csv", "結果_{}.xlsx", "残り_{}.xlsx"])
    log_path = out_dir / f"run_{ts}.csv"
    print()
    interrupted = False
    def to_result(r: executor.Result) -> None:
        op = "create" if r.sheet == REGISTER_SHEET else "update"
        result.add(executor.operation_id(r.sheet, r.row_no), op, executor.RESULT_STATUS.get(r.outcome, "failed"),
                   issue=r.issue_key, summary=r.summary, message=r.message)

    with executor.RunLog(log_path, on_write=to_result) as log:
        try:
            results = executor.execute(plan, master.project_id, client, log=log)
        except KeyboardInterrupt:
            # 反映済みの行が分からないまま終わると、続きを送れない。ここまでの結果を出してから終える
            interrupted = True
            results = log.results

    if interrupted:
        sent = len(results)
        # 中断の知らせと注意はエラーの出力に、ここまでにできたこと（下の「結果:」の行）は画面の出力に、この順で出す（5 つのツールで同じ）
        print(f"\n中断しました（Ctrl+C か、外から止められた）。{sent} 行を処理し、残りの行は送っていません。", file=sys.stderr)
        # 送信中に止めると、Backlog が受け付けたのに記録されない行がありうる
        print("  中断したときに送信中だった行は、反映されたか分かりません。Backlog の画面で確かめてください。", file=sys.stderr)
    counts: dict[str, int] = {}
    for r in results:
        counts[r.outcome] = counts.get(r.outcome, 0) + 1
    print("\n結果: " + " / ".join(f"{k} {v} 件" for k, v in counts.items()) if counts else "\n結果: なし")
    if any(r.fatal for r in results):
        # 接続は通っても、課題の追加・編集の権限が無いと送る段階で 403 になる
        print("エラー: 認証・権限のエラーで中止しました。", file=sys.stderr)
        print_api_key_source(args)
    print(f"実行ログ: {log_path}")

    touched = [r.issue for r in results if r.issue]
    if touched:
        result_path = out_dir / f"結果_{ts}.xlsx"
        try:
            _, warnings = write_issues(
                result_path, touched, master, parent_key_map(touched, client, master.project_id), base_url=client.base_url,
            )
        except (SheetError, BacklogAPIError) as e:
            # 送信は済んでいる。ここで止めると「結果」の終了コードが失われるので、知らせて続ける
            print(f"警告: 結果のファイルを出せませんでした: {e}", file=sys.stderr)
            print("  作成・更新した課題は、実行ログで確かめてください。", file=sys.stderr)
        else:
            print(f"作成・更新した課題（{UPDATE_SHEET}シートの書式）: {result_path}")
            for w in warnings:
                print(f"  ! {w}")
    print_next_steps(args, sheets[args.sheet], full_plan, results, master, out_dir / f"残り_{ts}.xlsx", held)
    if interrupted:
        return EXIT_INTERRUPTED
    return EXIT_FAILED if counts.get(executor.FAILED) or counts.get(executor.NOT_RUN) or counts.get(executor.SKIPPED) else EXIT_OK


def print_next_steps(args, sheet, plan: Plan, results, master: Master, rest_path: Path,
                     held: list[int] | None = None) -> None:
    """
    反映できなかった行（--limit で送らなかった行を含む）があれば、続きの送り方を示す。登録シートなら、
    未反映の行だけを残した続きのシートも出す。plan は --limit で絞る前の計画。
    """
    if args.sheet == UPDATE_SHEET:
        if has_unsent_update(results):
            # 更新は、反映済みの行が「変更なし」になるので、同じシートを戻せば残りだけを送る
            print("\n続き: 失敗の理由を直して、同じ更新シートをもう一度取り込んでください。"
                  "反映済みの行は「変更なし」になり、残りだけを送ります。")
        elif held:
            print(f"\n続き: --limit で送らなかった行が {len(held)} 行あります。同じ更新シートをもう一度取り込んでください。"
                  "反映済みの行は「変更なし」になり、残りだけを送ります（まずドライランで確かめる）。")
        return

    rest = remaining_register_rows(sheet, plan, results, master, held=set(held or []))
    for row_no, key in rest.follow_up_failed:
        print(f"\n{row_no}行目（{key}）は作成済みですが、状態・完了理由の更新に失敗しました。"
              f"結果のファイル（{UPDATE_SHEET}シート）でその行の状態を書いて取り込んでください。")
    if not rest.rows:
        return
    try:
        write_workbook(rest_path, master, register_rows=rest.rows)
    except SheetError as e:
        print(f"\n続きのシートを出せませんでした: {e}")
        print("  反映済みの行は、実行ログで確かめてください。")
        return
    print(f"\n未反映の行が {len(rest.rows)} 行あります。続きは、次のシートを{REGISTER_SHEET}シートとして取り込んでください"
          "（まずドライランで確かめる）。")
    print(f"  続きのシート: {rest_path}")
    print("  反映済みの行は入っていません。失敗した行は、理由（上の一覧と実行ログ）を見て直してから取り込んでください。")
    if rest.reparented:
        rows = "、".join(str(n) for n in rest.reparented)
        print(f"  元の {rows}行目は、親が作成済みのため、{CHILD_HEADER}の印を消して{PARENT_HEADER}に親の課題キーを書きました。")
    if rest.held:
        print(f"  --limit で送らなかった {len(rest.held)} 行も入っています。")
    if rest.unknown:
        rows = "、".join(str(n) for n in rest.unknown)
        print(f"  元の {rows}行目は、中断で送っていないか、送信中だった行です。送信中だった行は作成済みかもしれません"
              "（作成済みなら、取り込むときに二重登録の防止で止まります）。")


def cmd_export(args) -> int:
    config, config_path, client, master = connect(args)
    out_dir = output_dir(config, config_path, args.output_dir)
    path = Path(args.output) if args.output else stamped_path(out_dir, "書き出し_{}.xlsx")
    flt = ExportFilter(
        statuses=args.status or [],
        types=args.type or [],
        keyword=args.keyword or "",
        parent_key=(args.parent or "").upper(),
        keys=[k.upper() for k in (args.key or [])],
        include_closed=args.include_closed,
    )
    if flt.keys:
        # --key は課題を 1 件ずつ取るので、ほかの絞り込みは使われない。黙って無視しない
        others = [name for name, given in (
            ("--status", args.status), ("--type", args.type), ("--keyword", args.keyword),
            ("--parent", args.parent), ("--include-closed", args.include_closed),
        ) if given]
        if others:
            raise ExportError(
                f"--key は {'・'.join(others)} と一緒に使えません（--key で指定した課題をそのまま書き出し、"
                "ほかの絞り込みは使わないため）"
            )
    out, count, warnings = export(client, master, path, flt)
    note = unsupported_note(master)
    if note:
        warnings = [note] + warnings
    for w in warnings:
        print(f"  ! {w}")
    print(f"{count} 件を書き出しました: {out}")
    return EXIT_OK


# ---------------------------------------------------------------------------
# 引数
# ---------------------------------------------------------------------------

EXAMPLES = """使い方の例:
  ひな形を作る
    python backlog_issue_sheet.py template
  ドライラン（既定。何も送らない）
    python backlog_issue_sheet.py import 課題.xlsx --sheet 登録
  Backlog に反映する
    python backlog_issue_sheet.py import 課題.xlsx --sheet 登録 --execute
  Backlog の課題を Excel に書き出す
    python backlog_issue_sheet.py export
  Excel に書ける名前を一覧する
    python backlog_issue_sheet.py master

コマンドごとの説明は、python backlog_issue_sheet.py <コマンド> --help で出ます。"""


def build_parser() -> argparse.ArgumentParser:
    # --help の日本語と、同じ意味の引数の説明は、5 つのツールで共通の部品
    common = argparse.ArgumentParser(add_help=False, allow_abbrev=False)
    cli.add_config(common)
    cli.add_output_dir(common, "output_dir", "output")
    cli.add_debug(common)

    # 使い方の表示に出す名前は、打ち込む形と同じ「python backlog_issue_sheet.py」（以前は使えないコマンド名を出していた）
    parser = cli.make_parser(__file__, description="Excel の「登録」「更新」シートから Backlog の課題を作成・更新する",
                             epilog=EXAMPLES)
    cli.add_version(parser, TOOL_NAME, __version__)
    sub = parser.add_subparsers(dest="command", required=True, metavar="コマンド")

    def add_command(name: str, help: str) -> argparse.ArgumentParser:
        return cli.add_command(sub, name, help, parents=[common])

    p = add_command("template", "ひな形の Excel を作る")
    p.add_argument("-o", "--output", metavar="PATH", help="出力するファイル")
    p.set_defaults(func=cmd_template)

    p = add_command("import", "Excel の内容を Backlog に反映する（既定はドライラン）")
    p.add_argument("excel", help="取り込む Excel（xlsx / xlsm）")
    p.add_argument(
        "--sheet", required=True, choices=[REGISTER_SHEET, UPDATE_SHEET],
        help=f"取り込むシート。{REGISTER_SHEET}＝課題を新しく作る / {UPDATE_SHEET}＝既存の課題を変更する。"
        "もう一方のシートは読まない",
    )
    cli.add_execute(p)
    cli.add_yes(p)
    p.add_argument(
        "--limit", type=cli.positive_int, metavar="N",
        help="先頭から N 行だけを送る。親と同じシートの子は親と一緒に送る（N を超えることがある）。"
        "登録シートの残りは続きのシートに出る",
    )
    plans.add_plan_options(p)
    p.add_argument(
        "--allow-duplicates", action="store_true",
        help="同じ親の下に同じ件名の未完了の課題があっても作る（同じ件名で意図して作るとき）",
    )
    # メニューから呼ばれたとき、案内をメニューの操作で示す。利用者が打つものではないため隠す
    p.add_argument("--from-menu", action="store_true", help=argparse.SUPPRESS)
    p.set_defaults(func=cmd_import)

    p = add_command("export", "Backlog の課題を Excel に書き出す")
    p.add_argument("-o", "--output", metavar="PATH", help="出力するファイル")
    p.add_argument("--status", nargs="+", metavar="名前", help="状態で絞る（既定: 完了以外）")
    p.add_argument("--type", nargs="+", metavar="名前", help="種別で絞る")
    p.add_argument("--keyword", metavar="文字列", help="キーワードで絞る")
    p.add_argument("--parent", metavar="課題キー", help="この課題とその子課題を書き出す（完了した子も含める）")
    p.add_argument("--key", nargs="+", metavar="課題キー", help="課題キーを指定して書き出す（ほかの絞り込みとは一緒に使えない）")
    p.add_argument("--include-closed", action="store_true", help="完了した課題も含める")
    p.set_defaults(func=cmd_export)

    p = add_command("master", "Excel に書ける名前（種別・担当者・カスタム属性など）を一覧する")
    p.set_defaults(func=cmd_master)
    return parser


def main(argv: list[str] | None = None) -> int:
    # 課題の件名など Backlog から来る文字で、Windows のコンソールが落ちないように（ほかより先に）
    make_console_safe()
    # 外から止められたとき（コマンドを動かす道具の時間切れなど）も、Ctrl+C と同じく記録と続きの案内を出す
    stop_on_sigterm()
    argv = sys.argv[1:] if argv is None else argv
    args = build_parser().parse_args(argv)
    if plans.yes_refused(getattr(args, "yes", False) and getattr(args, "execute", False)):
        # この端末では、送る許可を --yes で示せない（環境変数で拒んでいる）。設定も読まず、Backlog にもつながない
        print(plans.refused_yes_text(__file__, argv), file=sys.stderr)
        return EXIT_NOT_CONFIRMED
    try:
        return args.func(args)
    except plans.PlanError as e:
        print(f"エラー: {e}", file=sys.stderr)
        return plans.EXIT_PLAN_MISMATCH
    except (ConfigError, SheetError, ExportError) as e:
        print(f"エラー: {e}", file=sys.stderr)
        return EXIT_USAGE
    except NotConfirmed as e:
        print(f"エラー: {e}", file=sys.stderr)
        return EXIT_NOT_CONFIRMED
    except BacklogAPIError as e:
        # 文の形は共通の部品（5 つのツールで同じ）。クライアントは API キーの出どころを知らないので、ここで渡す
        e.api_key_source = e.api_key_source or getattr(args, "api_key_source", "") or ""
        print(format_api_error(e), file=sys.stderr)
        return EXIT_FAILED
    except KeyboardInterrupt:
        print("\n中断しました。", file=sys.stderr)
        return EXIT_INTERRUPTED
    except OSError as e:
        # 実行ログを作れないなど。送る前に開くので、ここに来たときは何も送っていない。
        # ファイルの誤りとして扱う（終了コード 2）
        print(f"エラー: ファイルを読み書きできません: {e.filename or ''}（{e.strerror or e}）", file=sys.stderr)
        print("  → 出力先のフォルダに書き込めるか、ファイルを Excel で開いていないかを確かめてください", file=sys.stderr)
        return EXIT_USAGE


if __name__ == "__main__":
    # main() の try より前（openpyxl の読み込み・引数の解釈）で Ctrl+C を押しても、トレースバックでなく 130 で止める
    sys.exit(exit_on_interrupt(main))
