"""
続きのシート
============
登録シートの送信が途中で失敗・中断したとき、未反映の行だけを残した登録シートを作る。
そのまま取り込めば続きが送れる形にする。

- 反映済み（作成できた）行は入れない。もう一度送ると二重登録の防止で止まるため
- 作成はできたが状態・完了理由の更新に失敗した行も入れない。課題は作成済みで、続きは
  結果のファイル（更新シートの書式）で状態を書いて取り込む
- `○` の行の親が反映済みなら、`○` を消し、親の課題キーを「親課題キー」に書く。親の行を
  入れないので、`○` のままだと別の行を親と取り違えるか、親を失ってエラーになる

元の Excel は開き直さない（数式などが失われるため）。
読んだ値から、ひな形の書式で作り直す。# で始まるメモの列は入らない。
"""

from __future__ import annotations

from dataclasses import dataclass, field

from executor import FAILED, NOT_RUN, SKIPPED, Result
from fields import CHILD_HEADER, PARENT_HEADER, REGISTER_SHEET, Column
from master import Master
from planner import Plan, map_headers
from sheet_io import SheetData

# 続きのシートに入れる結果。作成済みの課題を持つものは除く
_REMAINING = (FAILED, SKIPPED, NOT_RUN)


@dataclass
class Remaining:
    rows: list[dict] = field(default_factory=list)          # {見出し: 値}。build_workbook の register_rows
    row_numbers: list[int] = field(default_factory=list)    # 元のシートの行番号
    reparented: dict[int, str] = field(default_factory=dict)  # 元の行番号 → 書き込んだ親の課題キー
    unknown: list[int] = field(default_factory=list)        # 結果の無い行（中断で送っていない、または送信中だった）
    follow_up_failed: list[tuple[int, str]] = field(default_factory=list)  # (行番号, 課題キー)


def remaining_register_rows(sheet: SheetData, plan: Plan, results: list[Result], master: Master) -> Remaining:
    by_row = {r.row_no: r for r in results if r.sheet == REGISTER_SHEET}
    created = {row_no: r.issue_key for row_no, r in by_row.items() if r.issue}
    raw_rows = {row.row_no: row for row in sheet.rows}
    headers = {
        idx: (target.header if isinstance(target, Column) else target)
        for idx, target in map_headers(sheet, master, []).items()
    }

    out = Remaining()
    for cp in plan.creates:
        result = by_row.get(cp.row_no)
        if result is not None and result.issue:
            if result.outcome == FAILED:
                out.follow_up_failed.append((cp.row_no, result.issue_key))
            continue
        if result is not None and result.outcome not in _REMAINING:
            continue
        if result is None:
            out.unknown.append(cp.row_no)

        row = {headers[idx]: raw for idx, raw in raw_rows[cp.row_no].values.items() if idx in headers}
        if cp.parent_row is not None and cp.parent_row in created:
            row[CHILD_HEADER] = None
            row[PARENT_HEADER] = created[cp.parent_row]
            out.reparented[cp.row_no] = created[cp.parent_row]
        out.rows.append(row)
        out.row_numbers.append(cp.row_no)
    return out


def has_unsent_update(results: list[Result]) -> bool:
    return any(r.outcome in _REMAINING for r in results if r.sheet != REGISTER_SHEET)

