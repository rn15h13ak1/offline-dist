"""
backlog-issue-sheet 対話メニュー
================================
コマンドのオプションを覚えなくても、番号を選んで実行できるようにする。
作りは同じ種類のツールのメニューにならった。

  python menu.py
  python menu.py --config my.yaml

無人実行にはメニューではなく本体を使うこと:
  python backlog_issue_sheet.py import 課題.xlsx --sheet 登録 --execute --yes
"""

from __future__ import annotations

from pathlib import Path

from backlog_common import cli
from backlog_common.menu import (
    EXIT_EOF,  # noqa: F401  （終了コード。テストとツールを起動する側が見る）
    EXIT_INTERRUPTED,  # noqa: F401
    EXIT_OK,  # noqa: F401
    EXIT_SETUP,  # noqa: F401
    check_runtime,
    clean_path,
    describe_exit,
    exit_menu,
    input_text,
    print_config_header,
    print_menu,
    run_loop,
    run_script,
    show_result,
    wait_enter,
)
from backlog_common.menu import load_history as _load_history
from backlog_common.menu import save_history as _save_history
from backlog_common.runtime import make_console_safe

from version import TOOL_NAME, __version__

# 本体を選んだところで止まる前に、メニューを開くときに確かめる（足りなければ 2。5 つのメニューで同じ）
check_runtime([("openpyxl", "openpyxl"), ("yaml", "pyyaml")])

TOOL_DIR = Path(__file__).resolve().parent
SCRIPT = TOOL_DIR / "backlog_issue_sheet.py"
HISTORY_PATH = Path.home() / ".backlog_issue_sheet_menu.json"

ACTIONS = [
    ("template", "ひな形を作る", "登録・更新シートの空の Excel を作る（プルダウン付き）"),
    ("register_dry", "登録（確認だけ）", "「登録」シートを検証し、作成する課題を表示する"),
    ("register_execute", "登録（実行）", "確認のうえで「登録」シートの課題を Backlog に作る"),
    ("update_dry", "更新（確認だけ）", "「更新」シートを検証し、変わる項目を表示する"),
    ("update_execute", "更新（実行）", "確認のうえで「更新」シートの変更を Backlog に反映する"),
    ("export", "書き出し", "Backlog の課題を更新シートの書式で Excel に出す"),
    ("master", "使える名前の一覧", "種別・担当者・カスタム属性などの名前を表示する"),
]


#: 本体の終了コードの意味（README の「終了コード」と揃える。127・130 は共通の部品が足す）
EXIT_MEANINGS = {
    0: "成功、ドライラン、または確認で N と答えて中止しました",
    1: "検証エラー、送信の失敗・スキップ・未実行の行、API・通信のエラー、Python の版・ライブラリの不足、または想定外のエラー",
    2: "設定・引数・ファイルの誤り",
    20: "端末でない所から --yes を付けずに --execute したため、何も送っていません",
    21: "計画のファイル（--plan）と今の状態が違うため、何も送っていません",
}

#: 送信する操作。前回の操作でも既定にしない
EXECUTE_ACTIONS = ("register_execute", "update_execute")


def load_history() -> dict:
    return _load_history(HISTORY_PATH)


def save_history(data: dict) -> None:
    _save_history(HISTORY_PATH, data)


def ask_excel(history: dict) -> str | None:
    # 前回のファイルを移動・削除していると、空 Enter で毎回それが選ばれ、メニューに戻れなくなる
    last = history.get("excel", "")
    default = last if last and Path(last).is_file() else ""
    while True:
        answer = input_text("Excel ファイル（ドラッグ＆ドロップ可）", default)
        if answer is None:
            return None
        # 本体はツールのフォルダで動くため、相対パスは今の場所を基準に絶対パスへ直す
        path = str(Path(clean_path(answer)).resolve())
        if Path(path).is_file():
            history["excel"] = path
            save_history(history)
            return path
        print(f"  ※ ファイルが見つかりません: {path}")


# 取り込みの項目 → (読むシート, 実行するか)。もう一方のシートは読まないので、
# 書いたまま残った行を送らない。登録と更新を最初のメニューで選び分ける
IMPORTS = {
    "register_dry": ("登録", False),
    "register_execute": ("登録", True),
    "update_dry": ("更新", False),
    "update_execute": ("更新", True),
}


def build_args(action: str, config: str | None, history: dict) -> list[str] | None:
    common = ["--config", config] if config else []
    if action == "template":
        return ["template", *common]
    if action == "master":
        return ["master", *common]
    if action in IMPORTS:
        sheet, execute = IMPORTS[action]
        excel = ask_excel(history)
        if excel is None:
            return None
        # 「--execute を付けて」などの案内を、メニューの操作に置き換えてもらう
        args = ["import", excel, "--sheet", sheet, *common, "--from-menu"]
        if execute:
            args.append("--execute")
        return args
    if action == "export":
        choice = print_menu("書き出す範囲", [
            "完了以外のすべて",
            "完了も含めてすべて",
            "ある課題とその子課題",
            "キーワードで絞る",
        ])
        if choice == 0:
            return None
        args = ["export", *common]
        if choice == 2:
            args.append("--include-closed")
        elif choice == 3:
            key = input_text("親の課題キー（例: PROJ-123）")
            if not key:
                return None
            args += ["--parent", key]
        elif choice == 4:
            keyword = input_text("キーワード")
            if not keyword:
                return None
            args += ["--keyword", keyword]
        return args
    raise AssertionError(action)


def run(args: list[str]) -> int:
    return run_script(SCRIPT, args, TOOL_DIR)


def main() -> None:
    # 入力されたパスなどに CP932 に無い文字があっても、Windows のコンソールが落ちないように
    make_console_safe()
    parser = cli.make_parser(__file__, description="Backlog 課題シート 対話メニュー",
                             epilog="無人実行には backlog_issue_sheet.py を直接使ってください。")
    cli.add_version(parser, TOOL_NAME, __version__)
    cli.add_config(parser)
    config = parser.parse_args().config
    if config:
        config = str(Path(config).resolve())
    history = load_history()
    # 前回の操作を既定にする（ほかのツールのメニューと同じ）。実行の項目は既定にしない（Enter だけで送信の確認まで進まないように）
    last_action = history.get("action")
    default_choice = None if last_action in EXECUTE_ACTIONS else next(
        (i for i, (key, _, _) in enumerate(ACTIONS, 1) if key == last_action), None)
    items = [f"{label} ― {desc}" for _, label, desc in ACTIONS]

    def loop() -> None:
        nonlocal default_choice
        while True:
            # 見出しに読む設定ファイルを出す（ほかのツールのメニューと同じ）
            print_config_header("Backlog 課題シート", config or TOOL_DIR / "config.yaml", version=TOOL_NAME + " " + __version__)
            choice = print_menu("操作を選択", items, back_label="終了", default=default_choice, default_mark="前回")
            if choice == 0:
                exit_menu()
            action = ACTIONS[choice - 1][0]
            args = build_args(action, config, history)
            if args is None:
                continue
            history["action"] = action
            save_history(history)
            show_result(describe_exit(run(args), EXIT_MEANINGS))
            default_choice = None if action in EXECUTE_ACTIONS else choice
            wait_enter()

    run_loop(loop)


if __name__ == "__main__":
    main()
