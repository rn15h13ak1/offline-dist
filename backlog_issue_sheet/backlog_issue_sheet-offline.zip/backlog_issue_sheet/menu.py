"""
backlog-issue-sheet 対話メニュー
================================
コマンドのオプションを覚えなくても、番号を選んで実行できるようにする。
作りは同じ種類のツールのメニューにならった。

  python menu.py
  python menu.py --config my.yaml

無人実行にはメニューではなく本体を使うこと:
  backlog-issue-sheet import 課題.xlsx --sheet 登録 --execute --yes
"""

from __future__ import annotations

import argparse
from pathlib import Path

from backlog_common.menu import (
    EXIT_EOF,  # noqa: F401  （終了コード。テストとツールを起動する側が見る）
    EXIT_INTERRUPTED,  # noqa: F401
    EXIT_OK,  # noqa: F401
    clean_path,
    exit_menu,
    input_text,
    print_menu,
    run_loop,
    run_script,
    show_result,
    wait_enter,
)
from backlog_common.menu import load_history as _load_history
from backlog_common.menu import save_history as _save_history
from backlog_common.runtime import make_console_safe

TOOL_DIR = Path(__file__).resolve().parent
SCRIPT = TOOL_DIR / "backlog_issue_sheet.py"
HISTORY_PATH = Path.home() / ".backlog_issue_sheet_menu.json"

ACTIONS = [
    ("template", "ひな形を作る", "登録・更新シートの空の Excel を作る（プルダウン付き）"),
    ("register_dry", "登録（確認だけ）", "「登録」シートを検証し、作成する課題を表示する"),
    ("register_execute", "登録（実行）", "確認のうえで「登録」シートの課題を Backlog に作る"),
    ("update_dry", "更新（確認だけ）", "「更新」シートを検証し、変わる項目を表示する"),
    ("update_execute", "更新（実行）", "確認のうえで「更新」シートの変更を Backlog に反映する"),
    ("export", "書き出し", "Backlog の課題を更新シートの書式で Excel に出す"),
    ("master", "使える名前の一覧", "種別・担当者・カスタム属性などの名前を表示する"),
]


def load_history() -> dict:
    return _load_history(HISTORY_PATH)


def save_history(data: dict) -> None:
    _save_history(HISTORY_PATH, data)


def ask_excel(history: dict) -> str | None:
    # 前回のファイルを移動・削除していると、空 Enter で毎回それが選ばれ、メニューに戻れなくなる
    last = history.get("excel", "")
    default = last if last and Path(last).is_file() else ""
    while True:
        answer = input_text("Excel ファイル（ドラッグ＆ドロップ可）", default)
        if answer is None:
            return None
        # 本体はツールのフォルダで動くため、相対パスは今の場所を基準に絶対パスへ直す
        path = str(Path(clean_path(answer)).resolve())
        if Path(path).is_file():
            history["excel"] = path
            save_history(history)
            return path
        print(f"  ※ ファイルが見つかりません: {path}")


# 取り込みの項目 → (読むシート, 実行するか)。もう一方のシートは読まないので、
# 書いたまま残った行を送らない。登録と更新を最初のメニューで選び分ける
IMPORTS = {
    "register_dry": ("登録", False),
    "register_execute": ("登録", True),
    "update_dry": ("更新", False),
    "update_execute": ("更新", True),
}


def build_args(action: str, config: str | None, history: dict) -> list[str] | None:
    common = ["--config", config] if config else []
    if action == "template":
        return ["template", *common]
    if action == "master":
        return ["master", *common]
    if action in IMPORTS:
        sheet, execute = IMPORTS[action]
        excel = ask_excel(history)
        if excel is None:
            return None
        # 「--execute を付けて」などの案内を、メニューの操作に置き換えてもらう
        args = ["import", excel, "--sheet", sheet, *common, "--from-menu"]
        if execute:
            args.append("--execute")
        return args
    if action == "export":
        choice = print_menu("書き出す範囲", [
            "完了以外のすべて",
            "完了も含めてすべて",
            "ある課題とその子課題",
            "キーワードで絞る",
        ])
        if choice == 0:
            return None
        args = ["export", *common]
        if choice == 2:
            args.append("--include-closed")
        elif choice == 3:
            key = input_text("親の課題キー（例: PROJ-123）")
            if not key:
                return None
            args += ["--parent", key]
        elif choice == 4:
            keyword = input_text("キーワード")
            if not keyword:
                return None
            args += ["--keyword", keyword]
        return args
    raise AssertionError(action)


def run(args: list[str]) -> int:
    return run_script(SCRIPT, args, TOOL_DIR)


def main() -> None:
    # 入力されたパスなどに CP932 に無い文字があっても、Windows のコンソールが落ちないように
    make_console_safe()
    parser = argparse.ArgumentParser(description="backlog-issue-sheet 対話メニュー")
    parser.add_argument("--config", help="設定ファイル（既定: ツールの場所の config.yaml）")
    config = parser.parse_args().config
    if config:
        config = str(Path(config).resolve())
    history = load_history()
    items = [f"{label} ― {desc}" for _, label, desc in ACTIONS]

    def loop() -> None:
        while True:
            choice = print_menu("Backlog 課題シート", items, back_label="終了")
            if choice == 0:
                exit_menu()
            args = build_args(ACTIONS[choice - 1][0], config, history)
            if args is None:
                continue
            show_result(f"終了コード: {run(args)}")
            wait_enter()

    run_loop(loop)


if __name__ == "__main__":
    main()
