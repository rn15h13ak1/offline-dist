"""
backlog-issue-sheet 対話メニュー
================================
コマンドのオプションを覚えなくても、番号を選んで実行できるようにする。
作りは同じ種類のツールのメニューにならった。

  python menu.py
  python menu.py --config my.yaml

無人実行にはメニューではなく本体を使うこと:
  backlog-issue-sheet import 課題.xlsx --sheet 登録 --execute --yes
"""

from __future__ import annotations

import argparse
import json
import subprocess
import sys
from pathlib import Path

from runtime import make_console_safe

WIDTH = 60
TOOL_DIR = Path(__file__).resolve().parent
SCRIPT = TOOL_DIR / "backlog_issue_sheet.py"
HISTORY_PATH = Path.home() / ".backlog_issue_sheet_menu.json"

EXIT_OK = 0
EXIT_EOF = 1
EXIT_INTERRUPTED = 130

ACTIONS = [
    ("template", "ひな形を作る", "登録・更新シートの空の Excel を作る（プルダウン付き）"),
    ("register_dry", "登録（確認だけ）", "「登録」シートを検証し、作成する課題を表示する"),
    ("register_execute", "登録（実行）", "確認のうえで「登録」シートの課題を Backlog に作る"),
    ("update_dry", "更新（確認だけ）", "「更新」シートを検証し、変わる項目を表示する"),
    ("update_execute", "更新（実行）", "確認のうえで「更新」シートの変更を Backlog に反映する"),
    ("export", "書き出し", "Backlog の課題を更新シートの書式で Excel に出す"),
    ("master", "使える名前の一覧", "種別・担当者・カスタム属性などの名前を表示する"),
]


def hr(char="="):
    print(char * WIDTH)


def print_menu(title: str, items: list[str], back_label: str = "戻る") -> int:
    while True:
        print()
        hr()
        print(f"  {title}")
        hr()
        for i, item in enumerate(items, 1):
            print(f"  {i}. {item}")
        hr("-")
        print(f"  0. {back_label}")
        hr()
        choice = input("番号を入力してください: ").strip()
        if choice == "0":
            return 0
        if choice.isdigit() and 1 <= int(choice) <= len(items):
            return int(choice)
        print("  ※ 無効な入力です。もう一度入力してください。")


def clean_path(text: str) -> str:
    """ドラッグ＆ドロップで付く引用符や前後の空白を除く。"""
    text = text.strip()
    if len(text) >= 2 and text[0] == text[-1] and text[0] in "\"'":
        text = text[1:-1]
    return text.replace("\\ ", " ") if sys.platform != "win32" else text


def input_text(prompt: str, default: str = "") -> str | None:
    suffix = f" [Enter={default}]" if default else "（空 Enter で戻る）"
    answer = input(f"  {prompt}{suffix}: ").strip()
    if not answer:
        return default or None
    return answer


def load_history() -> dict:
    try:
        return json.loads(HISTORY_PATH.read_text(encoding="utf-8"))
    except (OSError, ValueError):
        return {}


def save_history(data: dict) -> None:
    try:
        HISTORY_PATH.write_text(json.dumps(data, ensure_ascii=False), encoding="utf-8")
    except OSError:
        pass   # 記憶できなくても動作には影響しない


def ask_excel(history: dict) -> str | None:
    # 前回のファイルを移動・削除していると、空 Enter で毎回それが選ばれ、メニューに戻れなくなる
    last = history.get("excel", "")
    default = last if last and Path(last).is_file() else ""
    while True:
        answer = input_text("Excel ファイル（ドラッグ＆ドロップ可）", default)
        if answer is None:
            return None
        # 本体はツールのフォルダで動くため、相対パスは今の場所を基準に絶対パスへ直す
        path = str(Path(clean_path(answer)).resolve())
        if Path(path).is_file():
            history["excel"] = path
            save_history(history)
            return path
        print(f"  ※ ファイルが見つかりません: {path}")


# 取り込みの項目 → (読むシート, 実行するか)。もう一方のシートは読まないので、
# 書いたまま残った行を送らない。登録と更新を最初のメニューで選び分ける
IMPORTS = {
    "register_dry": ("登録", False),
    "register_execute": ("登録", True),
    "update_dry": ("更新", False),
    "update_execute": ("更新", True),
}


def build_args(action: str, config: str | None, history: dict) -> list[str] | None:
    common = ["--config", config] if config else []
    if action == "template":
        return ["template", *common]
    if action == "master":
        return ["master", *common]
    if action in IMPORTS:
        sheet, execute = IMPORTS[action]
        excel = ask_excel(history)
        if excel is None:
            return None
        # 「--execute を付けて」などの案内を、メニューの操作に置き換えてもらう
        args = ["import", excel, "--sheet", sheet, *common, "--from-menu"]
        if execute:
            args.append("--execute")
        return args
    if action == "export":
        choice = print_menu("書き出す範囲", [
            "完了以外のすべて",
            "完了も含めてすべて",
            "ある課題とその子課題",
            "キーワードで絞る",
        ])
        if choice == 0:
            return None
        args = ["export", *common]
        if choice == 2:
            args.append("--include-closed")
        elif choice == 3:
            key = input_text("親の課題キー（例: PROJ-123）")
            if not key:
                return None
            args += ["--parent", key]
        elif choice == 4:
            keyword = input_text("キーワード")
            if not keyword:
                return None
            args += ["--keyword", keyword]
        return args
    raise AssertionError(action)


def run(args: list[str]) -> int:
    print()
    hr("-")
    process = subprocess.Popen([sys.executable, str(SCRIPT), *args], cwd=TOOL_DIR)
    try:
        return process.wait()
    except KeyboardInterrupt:
        # 子も同じ Ctrl+C を受け、反映済みの行を実行ログと結果のファイルに書き出している。
        # subprocess.run は子をすぐ止めてしまうため、書き終えるまで待つ（もう一度押せば止める）
        try:
            process.wait()
        except KeyboardInterrupt:
            process.kill()
            process.wait()
        print("\n  中断しました。")
        return EXIT_INTERRUPTED


def main() -> None:
    # 入力されたパスなどに CP932 に無い文字があっても、Windows のコンソールが落ちないように
    make_console_safe()
    parser = argparse.ArgumentParser(description="backlog-issue-sheet 対話メニュー")
    parser.add_argument("--config", help="設定ファイル（既定: ツールの場所の config.yaml）")
    config = parser.parse_args().config
    if config:
        config = str(Path(config).resolve())
    history = load_history()
    items = [f"{label} ― {desc}" for _, label, desc in ACTIONS]

    try:
        while True:
            choice = print_menu("Backlog 課題シート", items, back_label="終了")
            if choice == 0:
                print("  終了します。")
                sys.exit(EXIT_OK)
            args = build_args(ACTIONS[choice - 1][0], config, history)
            if args is None:
                continue
            rc = run(args)
            print()
            hr("-")
            print(f"  終了コード: {rc}")
            input("\n  Enter キーでメニューに戻ります...")
    except EOFError:
        print("\n  入力が終了しました。")
        sys.exit(EXIT_EOF)
    except KeyboardInterrupt:
        print("\n  中断しました。")
        sys.exit(EXIT_INTERRUPTED)


if __name__ == "__main__":
    main()
