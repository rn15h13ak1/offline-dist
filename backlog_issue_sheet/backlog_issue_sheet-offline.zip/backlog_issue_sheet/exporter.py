"""
書き出し（Backlog → Excel）
===========================
課題を「更新」シートの書式で書き出す。編集してそのまま取り込みに戻せる。

空のセルは「変更しない」と読まれるため、書き出した値を変えずに戻しても
差分は出ない。tests/test_roundtrip.py がこれを確かめている。
"""

from __future__ import annotations

import re
from dataclasses import dataclass, field
from pathlib import Path

from fields import KEY_HEADER, PARENT_HEADER, all_columns, current_value, to_cell, unknown_ids
from master import STATUS_CLOSED_ID, Master, ResolveError
from sheet_io import write_workbook

# Excel のセルに入る文字数の上限
EXCEL_CELL_LIMIT = 32767

# Excel のセルに入れられない文字。タブ・改行・復帰は入れられる。
# openpyxl の ILLEGAL_CHARACTERS_RE は制御文字だけで、サロゲートを含まない。
UNSAFE_TEXT_RE = re.compile(r"[\x00-\x08\x0b\x0c\x0e-\x1f\ud800-\udfff]")


def unsafe_chars(text: str) -> list[str]:
    """Excel のセルに入れられない文字を、出てきた順に重複なく見える表記（\\x07 など）で返す。"""
    found = dict.fromkeys(UNSAFE_TEXT_RE.findall(text))
    return [f"\\x{ord(c):02x}" if ord(c) < 0x100 else f"\\u{ord(c):04x}" for c in found]

URL_HEADER = "#URL"
UPDATED_HEADER = "#更新日時"
REFERENCE_HEADERS = [URL_HEADER, UPDATED_HEADER]


class ExportError(Exception):
    """書き出しの条件が不正。"""


@dataclass
class ExportFilter:
    statuses: list[str] = field(default_factory=list)   # 状態の名前
    types: list[str] = field(default_factory=list)      # 種別の名前
    keyword: str = ""
    parent_key: str = ""
    keys: list[str] = field(default_factory=list)
    include_closed: bool = False


def issue_url(base_url: str, issue_key: str) -> str:
    """API の URL（…/api/v2）から課題の画面の URL を作る。"""
    return re.sub(r"/api/v2$", "", base_url) + f"/view/{issue_key}"


def issue_to_row(
    issue: dict,
    master: Master,
    parent_key: str | None,
    *,
    base_url: str = "",
    warnings: list[str] | None = None,
) -> dict:
    """課題 1 件を {見出し: セルの値} にする。"""
    row = {KEY_HEADER: issue.get("issueKey"), PARENT_HEADER: parent_key}
    for col in all_columns(master):
        current = current_value(col, issue)
        unknown = unknown_ids(col, current, master)
        if unknown:
            # ID のまま書くと、取り込みに戻したときに「見つかりません」でシート全体が止まる。
            # 空のセルは「変更しない」なので、空にすれば戻しても値は変わらない
            if warnings is not None:
                ids = "、".join(str(i) for i in unknown)
                warnings.append(
                    f"{issue.get('issueKey')}: {col.header}（ID {ids}）が今のプロジェクトに無いため空にしました"
                    "（プロジェクトから外れたユーザーなど）。取り込みに戻しても、この項目は変わりません"
                )
            row[col.header] = None
            continue
        value = to_cell(col, current, master)
        if isinstance(value, str) and len(value) > EXCEL_CELL_LIMIT:
            # 切り詰めて書くと、取り込みに戻したときに切り詰めた内容で上書きしてしまう。
            # 空のセルは「変更しない」なので、空にしておけば安全。
            if warnings is not None:
                warnings.append(
                    f"{issue.get('issueKey')}: {col.header}が Excel の上限"
                    f"（{EXCEL_CELL_LIMIT} 文字）を超えるため空にしました"
                )
            value = None
        elif isinstance(value, str) and (unsafe := unsafe_chars(value)):
            # 制御文字は保存で例外になり、書き出し全体が失われる。サロゲートは保存できてしまい、
            # 開けない xlsx ができる。置き換えて書くと戻したときにその文字で上書きするので、
            # 上限を超えたときと同じく空にする。何が入っていたかは警告に見える表記で残す。
            if warnings is not None:
                warnings.append(
                    f"{issue.get('issueKey')}: {col.header}に Excel で使えない文字"
                    f"（{' '.join(unsafe)}）があるため空にしました"
                )
            value = None
        row[col.header] = value
    if base_url:
        row[URL_HEADER] = issue_url(base_url, issue.get("issueKey", ""))
    updated = issue.get("updated")
    row[UPDATED_HEADER] = updated.replace("T", " ").replace("Z", "") if updated else None
    return row


def _key_number(issue: dict) -> int:
    try:
        return int(str(issue.get("issueKey", "")).rsplit("-", 1)[1])
    except (IndexError, ValueError):
        return 0


def order_issues(issues: list[dict]) -> list[dict]:
    """親の直後にその子が並ぶようにする。それ以外は課題番号の順。"""
    by_id = {i["id"]: i for i in issues}
    children: dict[int, list[dict]] = {}
    roots = []
    for issue in issues:
        parent_id = issue.get("parentIssueId")
        if parent_id and parent_id in by_id:
            children.setdefault(parent_id, []).append(issue)
        else:
            roots.append(issue)
    ordered = []
    for root in sorted(roots, key=_key_number):
        ordered.append(root)
        ordered.extend(sorted(children.get(root["id"], []), key=_key_number))
    return ordered


def _resolve_names(names: list[str], table) -> list[int]:
    try:
        return [table.resolve(n) for n in names]
    except ResolveError as e:
        raise ExportError(str(e)) from None


def fetch_issues(client, master: Master, flt: ExportFilter) -> list[dict]:
    """条件に合う課題を集める。子だけが当たった場合は、その親も加える。"""
    # 課題キーで 1 件ずつ取る指定は、Backlog がプロジェクトを問わず返すため、取る前に確かめる
    for key in [*flt.keys, *([flt.parent_key] if flt.parent_key else [])]:
        foreign = master.foreign_key_message(key)
        if foreign:
            raise ExportError(foreign)
    if flt.keys:
        issues = []
        for key in flt.keys:
            issue = client.get_issue(key)
            if issue is None:
                raise ExportError(f"{key} が見つかりません")
            issues.append(issue)
    else:
        params: dict = {}
        if flt.statuses:
            params["statusId"] = _resolve_names(flt.statuses, master.table("statuses"))
        # --parent は「その課題の子を全部見たい」ときに使うので、完了した子も含める
        elif not flt.include_closed and not flt.parent_key:
            params["statusId"] = [
                item["id"] for item in master.table("statuses").items
                if item["id"] != STATUS_CLOSED_ID
            ]
        if flt.types:
            params["issueTypeId"] = _resolve_names(flt.types, master.table("issue_types"))
        if flt.keyword:
            params["keyword"] = flt.keyword
        issues = []
        if flt.parent_key:
            parent = client.get_issue(flt.parent_key)
            if parent is None:
                raise ExportError(f"{flt.parent_key} が見つかりません")
            params["parentIssueId"] = [parent["id"]]
            issues.append(parent)
        issues += client.get_issues(master.project_id, params)

    # 重複を除く（--parent の親が条件にも当たった場合など）
    unique = {i["id"]: i for i in issues}
    missing = [pid for pid in dict.fromkeys(i.get("parentIssueId") for i in unique.values()) if pid and pid not in unique]
    unique.update(fetch_by_ids(client, master.project_id, missing))
    return order_issues(list(unique.values()))


# 一覧の取得 1 回で指定する ID の数。URL が長くなりすぎないように区切る
IDS_PER_REQUEST = 100


def fetch_by_ids(client, project_id: int, ids: list[int]) -> dict[int, dict]:
    """
    ID を指定して課題を集める。{ID: 課題}。見つからない ID は含まない。

    1 件ずつ取ると、親の数だけ問い合わせが増える。一覧の取得（id[] で指定）にまとめ、
    それで取れなかったものだけを 1 件ずつ取る。返ってきたものは指定した ID に絞るので、
    Backlog が id[] を受け付けない場合も、結果は 1 件ずつ取ったときと同じになる。
    """
    wanted = list(dict.fromkeys(ids))
    found: dict[int, dict] = {}
    for start in range(0, len(wanted), IDS_PER_REQUEST):
        chunk = wanted[start:start + IDS_PER_REQUEST]
        for issue in client.get_issues(project_id, {"id": chunk}):
            if issue.get("id") in chunk:
                found[issue["id"]] = issue
    for issue_id in wanted:
        if issue_id not in found:
            issue = client.get_issue(str(issue_id))
            if issue:
                found[issue["id"]] = issue
    return found


def parent_key_map(issues: list[dict], client, project_id: int) -> dict[int, str]:
    """課題 ID → 課題キー。親のキーを書くために使う。"""
    keys = {i["id"]: i["issueKey"] for i in issues}
    missing = [pid for i in issues if (pid := i.get("parentIssueId")) and pid not in keys]
    parents = fetch_by_ids(client, project_id, missing)
    for parent_id in missing:
        keys[parent_id] = parents[parent_id]["issueKey"] if parent_id in parents else str(parent_id)
    return keys


def write_issues(
    path: str | Path, issues: list[dict], master: Master, keys: dict[int, str], *, base_url: str = ""
) -> tuple[Path, list[str]]:
    warnings: list[str] = []
    rows = []
    for i in issues:
        parent_id = i.get("parentIssueId")
        parent_key = keys.get(parent_id) if parent_id is not None else None
        rows.append(issue_to_row(i, master, parent_key, base_url=base_url, warnings=warnings))
    out = write_workbook(
        path, master, update_rows=rows, extra_update_headers=REFERENCE_HEADERS,
        include_register=False,
    )
    return out, warnings


def export(client, master: Master, path: str | Path, flt: ExportFilter) -> tuple[Path, int, list[str]]:
    issues = fetch_issues(client, master, flt)
    keys = parent_key_map(issues, client, master.project_id)
    out, warnings = write_issues(path, issues, master, keys, base_url=getattr(client, "base_url", ""))
    return out, len(issues), warnings
