"""
ファイル同期チェック 対話メニュー
=================================
CLI オプションを覚えなくても、番号を選ぶだけで実行できる。

  python3 menu.py                  # メニューを表示
  python3 menu.py --config my.yaml # 設定ファイルを指定

実行前に比較対象の拠点を表示するので、設定の取り違えに気付ける。

無人実行 (cron / タスクスケジューラ) はこのメニューではなく本体を直接呼ぶこと:
  python3 main.py --no-progress
"""
# 注釈の `str | None` を Python 3.9 でも書けるようにする (PEP 563)。
# 無いと def の時点で注釈が評価され、起動前に TypeError になる。
from __future__ import annotations

import argparse
import json
import subprocess
import sys
from pathlib import Path

# 標準ライブラリだけなので、依存の確認より前に読める
from utils import (
    DEPENDENCY_MODULES,
    make_console_safe,
    make_parser,
    missing_library_lines,
    pad,
    require_python,
    stop_on_sigterm,
)

require_python()

TOOL_DIR = Path(__file__).resolve().parent

try:
    import config as fsc_config
except ModuleNotFoundError as e:
    # menu.bat のダブルクリック起動で依存が入っていない場合に、
    # トレースバックではなく対処を表示する
    if e.name not in DEPENDENCY_MODULES:
        raise
    make_console_safe()
    for line in missing_library_lines(e.name, TOOL_DIR):
        print(line, file=sys.stderr)
    sys.exit(2)

from version import __version__  # noqa: E402

WIDTH = 60
SCRIPT = TOOL_DIR / "main.py"
HISTORY_PATH = Path.home() / ".file_sync_checker_menu.json"

MODE_RUN = "run"
MODE_CUSTOM = "custom"
MODE_SWITCH = "switch"
MODE_SHOW = "show"
MODE_OPEN = "open"

MODES = [
    (MODE_RUN, "チェックを実行", "設定ファイルのとおりに照合する"),
    (MODE_CUSTOM, "条件を選んで実行", "ハッシュ方式・出力形式・再試行回数を選ぶ"),
    # 比較が複数定義されているときだけ出す
    (MODE_SWITCH, "比較対象を変更", "設定に定義された比較を切り替える"),
    (MODE_SHOW, "設定を確認", "比較する拠点・除外パターン・出力先を表示する"),
    (MODE_OPEN, "前回のレポートを開く", "出力先にある最新のレポートを開く"),
]

# 本体の終了コード (README の「終了コード」と対応)。127 はメニューが自分で返す (本体が見つからない)
EXIT_MEANINGS = {
    0: "全拠点一致・エラーなし",
    1: "差分を検出（スキャン自体は完走）",
    2: "設定の誤り・依存ライブラリ不足",
    3: "読み取りエラーあり（スキャンが不完全）",
    4: "予期しないエラー",
    127: "本体（main.py）が見つからない",
    130: "中断",
}

# 表に無い番号の説明 (同じ種類のツールと同じ文)
UNKNOWN_EXIT = "想定外の終了コードです"

# 終了コードの重さ。複数の比較をまとめて実行したとき、どれを代表として
# 返すかを決めるのに使う (数字の大小ではなく、対処の必要度で並べる)。
_SEVERITY = {0: 0, 1: 1, 3: 2, 4: 3, 127: 3, 130: 4}


def worst_exit_code(codes: list) -> int:
    """最も重い終了コードを返す。"""
    return max(codes, key=lambda c: (_SEVERITY.get(c, 3), c), default=0)


# メニュー自身の終了コード (同じ種類のツールと揃える)。依存が無いときの 2 は本体と同じ番号
EXIT_OK = 0
EXIT_EOF = 1
EXIT_USAGE = 2
EXIT_NOT_FOUND = 127
EXIT_INTERRUPTED = 130


# ===========================================================================
# 表示・入力
# ===========================================================================


def hr(char="="):
    print(char * WIDTH)


def print_menu(title: str, items: list, back_label: str = "戻る",
               default: int | None = None, default_mark: str = "既定") -> int:
    """
    メニューを表示して選択番号を返す。0 = 戻る / 終了。
    default_mark は既定値の由来を示すラベル (前回の選択なら「前回」)。
    """
    while True:
        print()
        hr()
        print(f"  {title}")
        hr()
        for i, item in enumerate(items, 1):
            mark = f" ←{default_mark}" if default == i else ""
            print(f"  {i}. {item}{mark}")
        hr("-")
        print(f"  0. {back_label}")
        hr()
        prompt = ("番号を入力してください"
                  + (f" [Enter={default}]: " if default else ": "))
        choice = input(prompt).strip()
        if not choice and default:
            return default
        if choice == "0":
            return 0
        if choice.isdigit() and 1 <= int(choice) <= len(items):
            return int(choice)
        print("  ※ 無効な入力です。もう一度入力してください。")


def input_text(prompt: str, default: str = "", validate=None,
               hint: str = "") -> str | None:
    """
    文字列を入力させる。空 Enter は default を採用する。
    default が無い状態で空 Enter を押した場合は None (キャンセル) を返す。
    """
    suffix = f" [Enter={default}]" if default else "（空 Enter で戻る）"
    while True:
        answer = input(f"  {prompt}{suffix}: ").strip()
        if not answer:
            if default:
                return default
            return None
        if validate is None or validate(answer):
            return answer
        print(f"  ※ {hint}")


def is_retry_count(value: str) -> bool:
    return value.isdigit()


# ===========================================================================
# 前回値の記憶
# ===========================================================================


def load_history() -> dict:
    """前回の入力値を読む。壊れていても既定値で続行する。"""
    try:
        with open(HISTORY_PATH, encoding="utf-8") as f:
            data = json.load(f)
        return data if isinstance(data, dict) else {}
    except (OSError, ValueError):
        return {}


def save_history(data: dict) -> None:
    """入力値を保存する。書けなくても実行は妨げない。"""
    try:
        with open(HISTORY_PATH, "w", encoding="utf-8") as f:
            json.dump(data, f, ensure_ascii=False, indent=2)
    except OSError:
        pass


# ===========================================================================
# 設定の読み取り
# ===========================================================================


def load_config_or_none(config_path: str, comparison: str = ""):
    """設定を読む。読めない場合は (None, 理由) を返す。

    比較名を渡さない場合でも、選択を求めずに読む (拠点名の表示や
    比較の一覧取得に使うため)。
    """
    try:
        return fsc_config.load_config(
            config_path, comparison=comparison or None,
            require_selection=bool(comparison),
        ), ""
    except fsc_config.ConfigError as e:
        return None, str(e)
    except Exception as e:  # YAML パースエラー等
        return None, f"設定ファイルを読めません: {e}"


def list_comparisons(config_path: str) -> list:
    """設定に定義されている比較の名前。従来形式なら空リスト。"""
    config, _ = load_config_or_none(config_path)
    return config.comparison_names if config else []


def choose_comparison(config_path: str, current: str) -> str | None:
    """比較対象を選ぶ。戻る場合は None。"""
    names = list_comparisons(config_path)
    if not names:
        print("  ※ この設定には比較が 1 組しかありません。切り替える対象がありません。")
        return None
    default = names.index(current) + 1 if current in names else 1
    choice = print_menu("比較対象を選択", comparison_items(config_path, names),
                        default=default)
    if choice == 0:
        return None
    return names[choice - 1]


def comparison_items(config_path: str, names: list) -> list:
    """比較名に拠点名を添えた表示用の一覧。"""
    items = []
    for name in names:
        config, _ = load_config_or_none(config_path, name)
        locs = " / ".join(loc.name for loc in config.locations) if config else "?"
        items.append(f"{name} ({locs})")
    return items


def select_run_targets(config_path: str, current: str) -> list | None:
    """実行する比較を選ぶ。戻る場合は None。

    戻り値は比較名のリスト。比較が 1 組しか無い設定 (従来形式を含む) では
    選択を挟まずそのまま実行する。複数ある場合は 1 つ選ぶか、まとめて実行できる。
    """
    names = list_comparisons(config_path)
    if len(names) <= 1:
        return [names[0] if names else ""]

    items = comparison_items(config_path, names) + [f"すべて実行 ({len(names)} 件)"]
    default = names.index(current) + 1 if current in names else 1
    choice = print_menu("実行する比較を選択", items, default=default)
    if choice == 0:
        return None
    if choice == len(items):
        return list(names)
    return [names[choice - 1]]


def describe_targets(config_path: str, comparison: str = "") -> str:
    """比較対象を 1 行で表す。読めない場合は理由を返す。

    設定を取り違えたまま実行する事故を、実行前に気付けるようにする。
    """
    config, reason = load_config_or_none(config_path, comparison)
    if config is None:
        return f"※ {reason}"
    names = " / ".join(loc.name for loc in config.locations)
    label = f"[{comparison}] " if comparison else ""
    return f"{label}{names} ({len(config.locations)} 拠点)"


def print_config(config_path: str, comparison: str = "") -> None:
    """設定の内容を一覧表示する。"""
    config, reason = load_config_or_none(config_path, comparison)
    print()
    hr()
    print("  設定内容")
    hr()
    print(f"  設定ファイル: {config_path}")
    if config is None:
        print(f"  ※ {reason}")
        return

    names = config.comparison_names
    if names:
        print(f"  定義されている比較: {', '.join(names)}")

    print()
    print(f"  比較する拠点{f' [{comparison}]' if comparison else ''}:")
    for loc in config.locations:
        print(f"    - {loc.name}: {loc.path}")

    print()
    print("  除外パターン:")
    if config.exclude_patterns:
        for pat in config.exclude_patterns:
            target = "相対パス全体" if "/" in pat else "ファイル名"
            print(f"    - {pat}  ({target}と照合)")
    else:
        print("    (なし)")

    print()
    print("  出力:")
    print(f"    形式        : {config.output.format}")
    print(f"    出力先      : {config.output.output_dir}")
    print(f"    表の行数上限: {config.output.max_table_rows or '無制限'}")
    keep = config.output.keep_reports
    print(f"    レポート保持: {f'直近 {keep} 回分' if keep else '削除しない'}")

    print()
    print("  照合:")
    print(f"    ハッシュ方式: {config.performance.hash_algorithm} / "
          f"{config.performance.hash_mode}")
    if config.performance.hash_mode == fsc_config.HASH_MODE_ALWAYS:
        print("      (全ファイルの内容を読んで照合する)")
    else:
        print("      (サイズ・更新日時が全拠点一致なら読み取りを省略する)")
    print(f"    並列数      : {config.performance.parallel_workers}")
    print(f"    Unicode正規化: {'あり (NFC)' if config.matching.normalize_unicode else 'なし'}")
    print(f"    大文字小文字: {'区別する' if config.matching.case_sensitive else '区別しない'}")


# ===========================================================================
# 実行内容の組み立て
# ===========================================================================


def build_args(config_path: str = "", hash_mode: str = "",
               output_format: str = "", retry: str = "",
               comparison: str = "") -> list:
    """本体に渡すコマンドライン引数を組み立てる。

    空文字の項目は指定しない (設定ファイルの値がそのまま使われる)。
    """
    args = []
    if config_path:
        args += ["--config", config_path]
    if comparison:
        args += ["--comparison", comparison]
    if hash_mode:
        args += ["--hash-mode", hash_mode]
    if output_format:
        args += ["--format", output_format]
    if retry and retry != "0":
        args += ["--retry", retry]
    return args


def run_checker(args: list) -> int:
    """本体を実行して終了コードを返す。

    Ctrl+C は本体も同じものを受け、書きかけのレポートを片付けてから止まる。subprocess.run は
    本体をすぐ止めてしまうため、終わるまで待つ (もう一度押せば止める)。
    """
    if not SCRIPT.is_file():
        print(f"\n  ※ 本体が見つかりません: {SCRIPT}")
        return EXIT_NOT_FOUND
    print()
    hr("-")
    process = subprocess.Popen([sys.executable, str(SCRIPT), *args], cwd=TOOL_DIR)
    try:
        return process.wait()
    except KeyboardInterrupt:
        try:
            process.wait()
        except KeyboardInterrupt:
            process.kill()
            process.wait()
        print("\n  中断しました。")
        return EXIT_INTERRUPTED


# ===========================================================================
# レポートを開く
# ===========================================================================


def latest_report(config_path: str, comparison: str = ""):
    """出力先にある最新のレポートを返す。無ければ None。

    比較名を指定すると、その比較のレポートだけを対象にする。
    """
    config, _ = load_config_or_none(config_path, comparison)
    if config is None:
        return None
    out_dir = config.output.output_dir
    if not out_dir.is_dir():
        return None
    prefix = f"sync-check-{comparison}" if comparison else "sync-check"
    reports = [p for p in out_dir.iterdir()
               if p.is_file() and p.suffix in (".html", ".xlsx")
               and p.name.startswith(prefix)]
    if not reports:
        return None
    return max(reports, key=lambda p: p.stat().st_mtime)


def open_file(path: Path) -> int:
    """OS の既定のアプリでファイルを開く。"""
    try:
        if sys.platform == "win32":
            import os
            os.startfile(str(path))  # noqa: S606  Windows のみ
        elif sys.platform == "darwin":
            subprocess.run(["open", str(path)], check=True)
        else:
            subprocess.run(["xdg-open", str(path)], check=True)
    except (OSError, subprocess.CalledProcessError) as e:
        print(f"  ※ 開けませんでした: {e}")
        return 1
    return 0


# ===========================================================================
# 各モードの対話
# ===========================================================================


def _choose_option(title: str, items: list, values: list, last) -> str | None:
    """選択肢から 1 つ選ぶ。戻る場合は None。

    前回の選択 (`last`。記憶が無い・今は無い値なら None) があれば、それを既定にする。
    同じ条件で繰り返し実行するとき、毎回選び直さずに Enter で済むようにする。
    """
    if last in values:
        choice = print_menu(title, items, default=values.index(last) + 1,
                            default_mark="前回")
    else:
        choice = print_menu(title, items, default=1)
    if choice == 0:
        return None
    return values[choice - 1]


def choose_hash_mode(history: dict) -> str | None:
    """ハッシュ方式を選ぶ。戻る場合は None、設定どおりなら空文字。"""
    items = [
        "設定ファイルのとおり",
        "always ― 全ファイルの内容を読む (更新日時を信用しない)",
        "smart ― サイズ・更新日時が全拠点一致なら読み飛ばす (速い)",
    ]
    values = ["", fsc_config.HASH_MODE_ALWAYS, "smart"]
    return _choose_option("ハッシュ方式", items, values, history.get("hash_mode"))


def choose_format(history: dict) -> str | None:
    """出力形式を選ぶ。戻る場合は None、設定どおりなら空文字。"""
    items = ["設定ファイルのとおり", "excel", "html", "both (Excel と HTML の両方)"]
    values = ["", "excel", "html", "both"]
    return _choose_option("出力形式", items, values, history.get("format"))


def run_targets(config_path: str, targets: list, *, hash_mode: str = "",
                output_format: str = "", retry: str = "") -> int:
    """選ばれた比較を順に実行し、最も重い終了コードを返す。

    1 つが失敗しても残りは実行する (2 件目で止まると 3 件目以降を
    確認できないため)。中断されたときだけ打ち切る。
    """
    results = []
    for i, name in enumerate(targets, 1):
        if len(targets) > 1:
            print()
            hr("=")
            print(f"  [{i}/{len(targets)}] {name}")
            hr("=")
        rc = run_checker(build_args(
            config_path=config_path, comparison=name,
            hash_mode=hash_mode, output_format=output_format, retry=retry,
        ))
        results.append((name, rc))
        if rc == EXIT_INTERRUPTED:
            print("  中断されたため、残りの比較は実行しません。")
            break

    if len(results) > 1:
        print()
        hr()
        print("  実行結果")
        hr()
        for name, rc in results:
            print(f"  {pad(name, 16)} {rc:>3}  {EXIT_MEANINGS.get(rc, UNKNOWN_EXIT)}")
        hr("-")
    return worst_exit_code([rc for _, rc in results])


def run_custom(config_path: str, history: dict, targets: list) -> int | None:
    """条件を選んで実行する。戻る場合は None。"""
    hash_mode = choose_hash_mode(history)
    if hash_mode is None:
        return None

    output_format = choose_format(history)
    if output_format is None:
        return None

    retry = input_text(
        "読み取り失敗時の再試行回数",
        default=history.get("retry", "0"),
        validate=is_retry_count,
        hint="0 以上の整数を入力してください (0 = 再試行しない)。",
    )
    if retry is None:
        return None

    history.update({"hash_mode": hash_mode, "format": output_format, "retry": retry})
    save_history(history)

    return run_targets(config_path, targets, hash_mode=hash_mode,
                       output_format=output_format, retry=retry)


def run_mode(mode: str, label: str, config_path: str, history: dict,
             comparison: str = "", targets: list | None = None) -> int | None:
    """1 つのモードを実行する。戻る場合は None。

    実行系 (MODE_RUN / MODE_CUSTOM) は見出しを呼び出し側で出しているため、
    ここでは出さない。
    """
    if mode not in (MODE_RUN, MODE_CUSTOM):
        print()
        hr()
        print(f"  {label}")
        hr()

    if mode == MODE_RUN:
        return run_targets(config_path, targets or [comparison])

    if mode == MODE_CUSTOM:
        return run_custom(config_path, history, targets or [comparison])

    if mode == MODE_SHOW:
        print_config(config_path, comparison)
        return None

    if mode == MODE_OPEN:
        report = latest_report(config_path, comparison)
        if report is None:
            print("  ※ レポートが見つかりません。先にチェックを実行してください。")
            return None
        print(f"  開きます: {report}")
        open_file(report)
        return None

    return None


# ===========================================================================
# エントリポイント
# ===========================================================================


def build_parser() -> argparse.ArgumentParser:
    parser = make_parser(
        __file__, "ファイル同期チェック 対話メニュー",
        epilog="無人実行（定期実行）には main.py を直接使ってください。",
    )
    parser.add_argument(
        "--config", default=str(TOOL_DIR / "config.yaml"), metavar="PATH",
        help="設定ファイルのパス（既定: ツールのフォルダの config.yaml）",
    )
    parser.add_argument(
        "--version", action="version", version=f"file_sync_checker {__version__}",
        help="版を出して終わる",
    )
    return parser


def available_modes(config_path: str) -> list:
    """この設定で選べる操作。比較が 1 組だけなら「比較対象を変更」は出さない。"""
    if len(list_comparisons(config_path)) > 1:
        return MODES
    return [m for m in MODES if m[0] != MODE_SWITCH]


def initial_comparison(config_path: str, history: dict) -> str:
    """起動時に選ばれている比較を決める。

    前回の選択が今も設定にあればそれを使う。無ければ先頭の比較。
    比較が定義されていない従来形式では空文字。
    """
    names = list_comparisons(config_path)
    if not names:
        return ""
    last = history.get("comparison", "")
    return last if last in names else names[0]


def main() -> None:
    # 外からの SIGTERM も Ctrl+C と同じに扱う。本体を待っている間に受けたら、
    # Ctrl+C の 1 回目と同じく本体の終わりを待つ (本体には届かない。もう一度で本体を止める)
    stop_on_sigterm()
    make_console_safe()
    args = build_parser().parse_args()
    # 本体はツールのフォルダで動かすため、相対パスは起動した場所を基準に絶対パスにしておく。
    # そうしないと、見出しの表示と本体とで別のファイルを読む
    args.config = str(Path(args.config).resolve())
    history = load_history()
    comparison = initial_comparison(args.config, history)
    modes = available_modes(args.config)
    last_mode = history.get("mode")
    default_choice = next(
        (i for i, (key, _, _) in enumerate(modes, 1) if key == last_mode), None
    )

    items = [f"{label} ― {desc}" for _, label, desc in modes]

    try:
        while True:
            print()
            hr()
            print(f"  ファイル同期チェック（file_sync_checker {__version__}）")
            hr()
            print(f"  比較対象: {describe_targets(args.config, comparison)}")
            choice = print_menu("実行内容を選択", items, back_label="終了",
                                default=default_choice, default_mark="前回")
            if choice == 0:
                print("  終了します。")
                sys.exit(EXIT_OK)

            mode, label, _ = modes[choice - 1]

            if mode == MODE_SWITCH:
                print()
                hr()
                print(f"  {label}")
                hr()
                picked = choose_comparison(args.config, comparison)
                if picked:
                    comparison = picked
                    history["comparison"] = comparison
                    save_history(history)
                    print(f"  比較対象を「{comparison}」にしました。")
                default_choice = choice
                input("\n  Enter キーでメニューに戻ります...")
                continue

            targets = None
            if mode in (MODE_RUN, MODE_CUSTOM):
                # 比較が複数あるときは、ここで実行対象を選ぶ
                # (「比較対象を変更」を先に選ばなくても実行できるようにする)
                print()
                hr()
                print(f"  {label}")
                hr()
                targets = select_run_targets(args.config, comparison)
                if targets is None:
                    continue
                # 1 つだけ選んだ場合は、以降の既定もそれに合わせる
                if len(targets) == 1 and targets[0]:
                    comparison = targets[0]
                    history["comparison"] = comparison

            rc = run_mode(mode, label, args.config, history, comparison, targets)
            history["mode"] = mode
            save_history(history)
            default_choice = choice
            if rc is not None:
                print()
                hr("-")
                meaning = EXIT_MEANINGS.get(rc, UNKNOWN_EXIT)
                print(f"  終了コード: {rc}（{meaning}）")
            input("\n  Enter キーでメニューに戻ります...")
    except EOFError:
        print("\n  入力が終了しました。")
        sys.exit(EXIT_EOF)
    except KeyboardInterrupt:
        print("\n  中断しました。")
        sys.exit(EXIT_INTERRUPTED)


if __name__ == "__main__":
    main()
