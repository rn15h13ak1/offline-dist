"""設定ファイル(YAML)の読み込みと検証。

知らない項目は止める (書き間違えた項目が黙って無視され、設定が効いていないことに
気付けないため)。似た名前の項目があれば示す。
"""
from __future__ import annotations

import difflib
import math
import os
from dataclasses import dataclass, field, replace
from pathlib import Path
from typing import Dict, List

import yaml

from scanner import DEFAULT_MTIME_TOLERANCE_SEC, HASH_MODE_ALWAYS, HASH_MODES


SUPPORTED_FORMATS = {"excel", "html", "both"}

# HTML レポートの 1 つの表に出す最大行数。
# 設定ファイルに書かれていない場合の既定値 (既に配布済みの config.yaml でも
# 巨大なレポートが開けなくなる問題を避けられるようにするため)。
# 実測: 20,000 行はロード 1.1 秒で操作可能、50,000 行はブラウザが 30 秒以上無応答。
DEFAULT_MAX_TABLE_ROWS = 20_000
SUPPORTED_HASH_ALGOS = {"sha256"}

# 書ける項目。ここに無いものは書き間違いとして止める。
# 最上位の locations は従来形式 (comparisons が無かった頃の配布済みの config.yaml)。
TOP_KEYS = ("comparisons", "locations", "exclude_patterns", "matching", "output", "performance")
SECTION_KEYS = {
    "output": ("format", "output_dir", "max_table_rows", "keep_reports"),
    "performance": ("parallel_workers", "hash_algorithm", "hash_mode", "mtime_tolerance_sec"),
    "matching": ("normalize_unicode", "case_sensitive"),
}
LOCATION_KEYS = ("name", "path")
EXAMPLE_NAME = "config.example.yaml"


@dataclass(frozen=True)
class Location:
    name: str
    path: Path


@dataclass(frozen=True)
class OutputConfig:
    format: str
    output_dir: Path
    # HTML の 1 表あたりの最大行数。0 は無制限。Excel には適用しない。
    max_table_rows: int = DEFAULT_MAX_TABLE_ROWS
    # 残す過去レポートの実行回数。0 は削除しない (既定)。
    # 削除は元に戻せないので、明示的に指定したときだけ動かす。
    keep_reports: int = 0


@dataclass(frozen=True)
class PerformanceConfig:
    parallel_workers: int
    hash_algorithm: str
    hash_mode: str = HASH_MODE_ALWAYS
    mtime_tolerance_sec: float = DEFAULT_MTIME_TOLERANCE_SEC


@dataclass(frozen=True)
class MatchingConfig:
    """拠点間で「同じファイル」とみなす条件。"""

    normalize_unicode: bool = True
    case_sensitive: bool = True


@dataclass(frozen=True)
class Comparison:
    """1 組の比較対象。

    `name` が空文字なら、設定ファイルにトップレベルの `locations:` だけが
    書かれている従来の形式 (名前の無い 1 組) を表す。
    """

    name: str
    locations: List[Location]


@dataclass(frozen=True)
class Config:
    comparisons: List[Comparison]
    # 実行対象として選ばれている比較の名前 (従来形式では空文字)
    selected: str = ""
    exclude_patterns: List[str] = field(default_factory=list)
    matching: MatchingConfig = field(default_factory=MatchingConfig)
    output: OutputConfig = field(default_factory=lambda: OutputConfig("excel", Path("./reports")))
    performance: PerformanceConfig = field(
        default_factory=lambda: PerformanceConfig(4, "sha256")
    )

    @property
    def locations(self) -> List[Location]:
        """選ばれている比較の拠点一覧。

        比較対象が 1 組だけだった頃の呼び出し側をそのまま動かすための入口。
        """
        for c in self.comparisons:
            if c.name == self.selected:
                return c.locations
        return self.comparisons[0].locations

    @property
    def comparison_names(self) -> List[str]:
        """定義されている比較の名前。従来形式では空リスト。"""
        return [c.name for c in self.comparisons if c.name]


class ConfigError(ValueError):
    pass


def apply_overrides(
    config: Config,
    *,
    output_format: str | None = None,
    output_dir: str | None = None,
    hash_mode: str | None = None,
) -> Config:
    """コマンドラインからの上書きを設定に反映する。

    CI から実行するときに config.yaml を書き換えずに出力先や形式を変えられるようにする。
    None の項目は設定ファイルの値をそのまま使う。
    `output_dir` は設定ファイル内の相対パスと違い、CWD からの相対として解決する
    (コマンドラインに書いたパスは打った場所から見た相対と考えるのが自然なため)。
    """
    if output_format is not None and output_format not in SUPPORTED_FORMATS:
        raise ConfigError(
            f"--format は {sorted(SUPPORTED_FORMATS)} のいずれかを指定してください "
            f"(現在: {output_format})"
        )
    if hash_mode is not None and hash_mode not in HASH_MODES:
        raise ConfigError(
            f"--hash-mode は {sorted(HASH_MODES)} のいずれかを指定してください "
            f"(現在: {hash_mode})"
        )

    output = config.output
    if output_format is not None or output_dir is not None:
        output = replace(
            output,
            format=output_format if output_format is not None else output.format,
            # absolute() を先に挟む。Python 3.9 の Windows では、まだ無いフォルダの相対パスに
            # resolve() だけを使うと、相対パスのまま返る
            output_dir=(
                Path(output_dir).absolute().resolve() if output_dir is not None
                else output.output_dir
            ),
        )
    performance = config.performance
    if hash_mode is not None:
        performance = replace(performance, hash_mode=hash_mode)
    return replace(config, output=output, performance=performance)


def _suggest_key(key, candidates) -> str | None:
    """書き間違いと思われる項目に、似た項目を 1 つ返す。無ければ None。

    大文字・小文字だけの違いを先に見る。候補は名前順に並べてから比べるので、
    同じ書き間違いには毎回同じ項目を示す。
    """
    names = sorted(str(c) for c in candidates)
    lowered = str(key).lower()
    for name in names:
        if name.lower() == lowered:
            return name
    close = difflib.get_close_matches(str(key), names, n=1, cutoff=0.6)
    return close[0] if close else None


def _unknown_keys(section, allowed, path: str = "") -> List[str]:
    """section (辞書) の中の、allowed に無い項目の文の一覧。

    文は「performance.paralel_workers は知らない項目です (parallel_workers の書き間違いでは？)」の形。
    """
    if not isinstance(section, dict):
        return []
    problems = []
    for key in section:
        if key in allowed:
            continue
        name = f"{path}.{key}" if path else str(key)
        near = _suggest_key(key, allowed)
        hint = f" ({near} の書き間違いでは？)" if near else ""
        problems.append(f"{name} は知らない項目です{hint}")
    return problems


def _check_unknown_keys(raw: dict) -> None:
    """設定の全体を見て、知らない項目があればまとめて ConfigError にする。

    1 つ直すたびに次が出るより、一度に全部を示す方が直しやすい。
    """
    problems = _unknown_keys(raw, TOP_KEYS)
    for section, allowed in SECTION_KEYS.items():
        problems += _unknown_keys(raw.get(section), allowed, section)

    groups = []
    if isinstance(raw.get("locations"), list):
        groups.append(("locations", raw["locations"]))
    if isinstance(raw.get("comparisons"), dict):
        groups += [(f"comparisons.{name}", items) for name, items in raw["comparisons"].items()
                   if isinstance(items, list)]
    for where, items in groups:
        for i, item in enumerate(items):
            problems += _unknown_keys(item, LOCATION_KEYS, f"{where}[{i}]")

    if problems:
        raise ConfigError(
            "\n".join(problems)
            + "\n  → 書き間違いなら直し、要らない項目なら消してください (config.example.yaml に書ける項目があります)"
        )


def _read_yaml(config_path: Path) -> dict:
    """UTF-8 (BOM 付きでもよい) の YAML を読む。

    メモ帳の ANSI (CP932) で保存した設定は、トレースバックの文ではなく保存し直す手順を示して止める。
    """
    try:
        text = config_path.read_text(encoding="utf-8-sig")
    except UnicodeDecodeError:
        raise ConfigError(
            f"設定ファイルを UTF-8 として読めません: {config_path}\n"
            "  → メモ帳で開き、「名前を付けて保存」で文字コードを「UTF-8」にして保存し直してください"
        ) from None
    try:
        raw = yaml.safe_load(text)
    except yaml.YAMLError as e:
        raise ConfigError(
            f"設定ファイルを YAML として読めません: {config_path}\n  {e}\n"
            "  → 示された行の字下げ（空白の数）と、「:」の後の空白を確かめてください。"
            "値に「:」や「#」を含むときは \"\" で囲みます"
        ) from None
    if raw is None:
        raise ConfigError(f"設定ファイルが空です: {config_path}（{EXAMPLE_NAME} を参考に書いてください）")
    if not isinstance(raw, dict):
        raise ConfigError(
            f"設定ファイルの形が不正です: {config_path}（「locations:」などの項目を並べる形で書いてください。"
            f"{EXAMPLE_NAME} を参考にしてください）"
        )
    return raw


def _check_sections(raw: dict) -> None:
    """節 (output・performance・matching) が「項目: 値」を並べた形であることを確かめる。

    確かめないと、`output: [a]` が後の `.get` で AttributeError になり、どの項目かも直し方も出なかった。
    書いていない (値が空) なら、従来どおり既定値で動く。
    """
    for section in SECTION_KEYS:
        value = raw.get(section)
        if value is not None and not isinstance(value, dict):
            example = SECTION_KEYS[section][0]
            raise ConfigError(
                f"{section}: の節の形が不正です (現在: {value!r})\n"
                f"  → 「{example}: ...」のように、項目を字下げして並べてください"
            )


# 数の項目の受け付け方は、すべての項目で同じにする (同じ種類のツールとも揃える)。
# 真偽値 (YAML の true は 1 と等しい) と文字列 ("8") は数として扱わない。整数の項目は小数 (2.0 も) を止める。
# 以前は項目ごとに違い、parallel_workers は "8" と 2.0 を、mtime_tolerance_sec は true と "5" を通していた。


def _int_at_least(value, key: str, minimum: int) -> int:
    """minimum 以上の整数として検証する。"""
    if isinstance(value, bool) or not isinstance(value, int) or value < minimum:
        raise ConfigError(f"{key} は {minimum} 以上の整数で指定してください (現在: {value!r})")
    return value


def _number_at_least(value, key: str, minimum: float) -> float:
    """minimum 以上の数 (整数か小数) として検証する。

    nan は比べると常に偽で、inf は下限を超えるので、大小だけでは通ってしまう。
    大きな int を isfinite に渡すと OverflowError になるので、見るのは float のときだけ。
    """
    if (isinstance(value, bool) or not isinstance(value, (int, float)) or value < minimum
            or (isinstance(value, float) and not math.isfinite(value))):
        raise ConfigError(f"{key} は {minimum} 以上の数で指定してください (現在: {value!r})")
    return float(value)


def _resolve(p: Path, base: Path) -> Path:
    """相対パスは base からの相対として解決し、絶対パスはそのまま返す。"""
    return p if p.is_absolute() else (base / p).resolve()


# 比較の名前に使えない文字。レポートのファイル名に含めるため、
# パス区切りや Windows のファイル名で使えない文字を弾く。
_INVALID_NAME_CHARS = set('\\/:*?"<>|')


def _parse_locations(items, base_dir: Path, where: str) -> List[Location]:
    """拠点の一覧を検証して組み立てる。`where` はエラーメッセージ用の位置。"""
    if not items or not isinstance(items, list):
        raise ConfigError(f"{where} は1件以上指定してください")

    locations: List[Location] = []
    seen_names: set[str] = set()
    for i, item in enumerate(items):
        if not isinstance(item, dict):
            raise ConfigError(f"{where}[{i}] が不正です")
        name = item.get("name")
        path = item.get("path")
        if not name or not path:
            raise ConfigError(f"{where}[{i}] は name と path が必須です")
        if name in seen_names:
            raise ConfigError(f"拠点名が重複しています: {name} ({where})")
        # バックスラッシュ表記は YAML パース時に潰れて壊れることが多く、
        # またコピー機能でのパス組み立てを単純化するためフォワードスラッシュに統一する。
        path_str = str(path)
        if "\\" in path_str:
            raise ConfigError(
                f"{where}[{i}].path にバックスラッシュが含まれています: {path_str!r}\n"
                f"  → フォワードスラッシュで記述してください "
                f"(例: '//server-a/share/docs')"
            )
        seen_names.add(name)
        locations.append(Location(name=str(name), path=_resolve(Path(path_str), base_dir)))

    if len(locations) < 2:
        raise ConfigError(f"{where} は2件以上必要です")

    # パス重複検出: 同じ実体パスを複数拠点として登録すると常に一致してしまうため弾く。
    # 比較をまたいで同じパスを使うのは問題ないので、検査は 1 組の中だけで行う。
    # os.path.normcase は Windows では大小無視・スラッシュ統一、UNIX では no-op。
    seen_paths: Dict[str, str] = {}
    for loc in locations:
        key = os.path.normcase(os.path.normpath(str(loc.path)))
        if key in seen_paths:
            raise ConfigError(
                f"拠点 '{loc.name}' のパスが拠点 '{seen_paths[key]}' と重複しています: "
                f"{loc.path} ({where})"
            )
        seen_paths[key] = loc.name
    return locations


def _parse_comparisons(raw: dict, base_dir: Path) -> List[Comparison]:
    """`comparisons:` または従来の `locations:` から比較の一覧を組み立てる。"""
    comparisons_raw = raw.get("comparisons")
    if comparisons_raw is None:
        # 従来形式: トップレベルの locations だけ。名前の無い 1 組として扱う。
        return [Comparison(name="", locations=_parse_locations(
            raw.get("locations"), base_dir, "locations"))]

    if raw.get("locations"):
        raise ConfigError(
            "comparisons と locations は同時に指定できません。\n"
            "  → 比較を複数定義する場合は locations を comparisons の中に移してください"
        )
    if not isinstance(comparisons_raw, dict) or not comparisons_raw:
        raise ConfigError(
            "comparisons は「名前: 拠点の一覧」の形式で1件以上指定してください"
        )

    comparisons: List[Comparison] = []
    for name, items in comparisons_raw.items():
        label = str(name)
        if not label.strip():
            raise ConfigError("comparisons の名前が空です")
        bad = sorted(_INVALID_NAME_CHARS & set(label))
        if bad:
            raise ConfigError(
                f"比較の名前に使えない文字が含まれています: {label!r} ({''.join(bad)})\n"
                f"  → レポートのファイル名に使うため、"
                f"{''.join(sorted(_INVALID_NAME_CHARS))} は使えません"
            )
        comparisons.append(Comparison(
            name=label,
            locations=_parse_locations(items, base_dir, f"comparisons.{label}"),
        ))
    return comparisons


def _select_comparison(comparisons: List[Comparison], requested: str | None) -> str:
    """実行対象の比較を決める。見つからなければ候補を添えてエラーにする。"""
    names = [c.name for c in comparisons if c.name]
    if requested:
        if requested not in names:
            raise ConfigError(
                f"比較 '{requested}' は設定にありません。\n"
                f"  → 定義されているのは: {', '.join(names) if names else '(名前なし)'}"
            )
        return requested
    if len(comparisons) == 1:
        return comparisons[0].name
    raise ConfigError(
        "比較対象を指定してください (--comparison NAME)。\n"
        f"  → 定義されているのは: {', '.join(names)}"
    )


def load_config(
    path: str | Path,
    comparison: str | None = None,
    *,
    require_selection: bool = True,
) -> Config:
    config_path = Path(path).resolve()
    if not config_path.is_file():
        raise ConfigError(f"設定ファイルが見つかりません: {config_path}")

    base_dir = config_path.parent

    raw = _read_yaml(config_path)
    try:
        return _build_config(raw, base_dir, comparison, require_selection)
    except ConfigError as e:
        # どのファイルを直せばよいかが分かるように、中身の誤りにはパスを添える
        raise ConfigError(f"{e}\n  設定ファイル: {config_path}") from None


def _build_config(raw: dict, base_dir: Path, comparison: str | None, require_selection: bool) -> Config:
    """読んだ設定 (辞書) を検証して Config にする。"""
    _check_sections(raw)
    _check_unknown_keys(raw)

    comparisons = _parse_comparisons(raw, base_dir)
    # 一覧表示のときは選択を求めない (名前を知るために名前が要る状態を避ける)
    selected = (
        _select_comparison(comparisons, comparison) if require_selection
        else (comparison or "")
    )

    exclude_patterns = raw.get("exclude_patterns") or []
    if not isinstance(exclude_patterns, list):
        raise ConfigError("exclude_patterns はリスト形式で指定してください")
    exclude_patterns = [str(p) for p in exclude_patterns]

    output_raw = raw.get("output") or {}
    fmt = str(output_raw.get("format", "excel")).lower()
    if fmt not in SUPPORTED_FORMATS:
        raise ConfigError(
            f"output.format は {sorted(SUPPORTED_FORMATS)} のいずれかを指定してください (現在: {fmt})"
        )
    output_dir = _resolve(Path(str(output_raw.get("output_dir", "./reports"))), base_dir)
    # 0 は「無制限 / 削除しない」
    raw_limit = _int_at_least(
        output_raw.get("max_table_rows", DEFAULT_MAX_TABLE_ROWS), "output.max_table_rows", 0
    )
    keep_reports = _int_at_least(output_raw.get("keep_reports", 0), "output.keep_reports", 0)
    output = OutputConfig(
        format=fmt,
        output_dir=output_dir,
        max_table_rows=raw_limit,
        keep_reports=keep_reports,
    )

    perf_raw = raw.get("performance") or {}
    workers = _int_at_least(perf_raw.get("parallel_workers", 4), "performance.parallel_workers", 1)
    algo = str(perf_raw.get("hash_algorithm", "sha256")).lower()
    if algo not in SUPPORTED_HASH_ALGOS:
        raise ConfigError(
            f"performance.hash_algorithm は {sorted(SUPPORTED_HASH_ALGOS)} のみ対応 (現在: {algo})"
        )
    hash_mode = str(perf_raw.get("hash_mode", HASH_MODE_ALWAYS)).lower()
    if hash_mode not in HASH_MODES:
        raise ConfigError(
            f"performance.hash_mode は {sorted(HASH_MODES)} のいずれかを指定してください "
            f"(現在: {hash_mode})"
        )
    # nan は smart の走査を終えた後に int() で落ちていた。走査の前に止める
    tolerance = _number_at_least(
        perf_raw.get("mtime_tolerance_sec", DEFAULT_MTIME_TOLERANCE_SEC),
        "performance.mtime_tolerance_sec", 0,
    )
    performance = PerformanceConfig(
        parallel_workers=workers,
        hash_algorithm=algo,
        hash_mode=hash_mode,
        mtime_tolerance_sec=tolerance,
    )

    matching_raw = raw.get("matching") or {}
    for bool_key in ("normalize_unicode", "case_sensitive"):
        if bool_key in matching_raw and not isinstance(matching_raw[bool_key], bool):
            raise ConfigError(f"matching.{bool_key} は true / false で指定してください")
    matching = MatchingConfig(
        normalize_unicode=bool(matching_raw.get("normalize_unicode", True)),
        case_sensitive=bool(matching_raw.get("case_sensitive", True)),
    )

    return Config(
        comparisons=comparisons,
        selected=selected,
        exclude_patterns=exclude_patterns,
        matching=matching,
        output=output,
        performance=performance,
    )
