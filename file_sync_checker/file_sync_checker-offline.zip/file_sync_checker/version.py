"""file_sync_checker の版。CHANGELOG の最新の版と同じにする。"""

__version__ = "0.9.1"
