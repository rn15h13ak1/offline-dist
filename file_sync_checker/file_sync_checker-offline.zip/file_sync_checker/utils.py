"""ロギングと共通ユーティリティ。"""
from __future__ import annotations

import logging
import sys
import unicodedata
from datetime import datetime
from pathlib import Path


def setup_logging(verbose: bool = False) -> logging.Logger:
    logger = logging.getLogger("file_sync_checker")
    if logger.handlers:
        return logger
    handler = logging.StreamHandler(sys.stderr)
    handler.setFormatter(logging.Formatter("%(asctime)s [%(levelname)s] %(message)s", "%H:%M:%S"))
    logger.addHandler(handler)
    logger.setLevel(logging.DEBUG if verbose else logging.INFO)
    return logger


def timestamp_slug(dt: datetime | None = None) -> str:
    """レポートファイル名向けのタイムスタンプ (YYYYMMDD-HHMMSS)。"""
    return (dt or datetime.now()).strftime("%Y%m%d-%H%M%S")


def human_bytes(n: int) -> str:
    if n < 1024:
        return f"{n} B"
    units = ["KB", "MB", "GB", "TB"]
    size = float(n)
    for u in units:
        size /= 1024
        if size < 1024:
            return f"{size:.2f} {u}"
    # ループを抜けた時点で size は TB 単位。PB として出すにはもう一段割る
    # (割り忘れると 1PB が "1024.00 PB" になる)
    size /= 1024
    return f"{size:.2f} PB"


def display_width(text: str) -> int:
    """端末に表示したときの桁数。全角は 2 桁、結合文字 (濁点の NFD など) は 0 桁と数える。

    文字数で詰める (`f"{name:<10}"`) と、日本語の拠点名で後ろの列がずれる。
    幅が曖昧な文字 (○ など) は 2 桁とする。利用者の環境である Windows の
    日本語コンソール (CP932) では全角で表示されるため。
    """
    width = 0
    for ch in text:
        if unicodedata.combining(ch):
            continue
        width += 2 if unicodedata.east_asian_width(ch) in ("W", "F", "A") else 1
    return width


def pad(text: str, width: int) -> str:
    """表示幅が width になるよう右に空白を足す (左寄せ)。超えていればそのまま返す。"""
    return text + " " * max(0, width - display_width(text))


def ensure_dir(path: Path) -> Path:
    path.mkdir(parents=True, exist_ok=True)
    return path
