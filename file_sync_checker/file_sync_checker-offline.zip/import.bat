@echo off
rem ===========================================================
rem  Import this folder into the Git repository on the file server.
rem  Double-click it, then type the folder of the Git repositories
rem  (e.g. \\fileserver\share\git). It can also be given:
rem
rem    import.bat \\fileserver\share\git
rem
rem  Creates <folder>\<tool>.git (bare) if missing, replaces its
rem  contents with the folder next to this file, and commits it as
rem  one commit. A folder that was already imported is refused.
rem
rem  Files listed in SOURCE.txt "keep=" may be edited here. When only
rem  this side changed one, the edited file is kept. When GitHub also
rem  changed it, this shows the changes from GitHub and asks: type
rem  KEEP once they are in the file here, or Enter to stop.
rem
rem  Messages here are ASCII on purpose: this file must stay
rem  readable in any console code page.
rem ===========================================================
setlocal

pushd "%~dp0" || (
    echo [ERROR] Cannot enter the folder of this script.
    if "%~1"=="" pause
    exit /b 1
)

set RC=0
set WORK=
set MSG=

git --version >nul 2>&1 || (
    echo [ERROR] Git was not found. Install Git for Windows.
    set RC=1
    goto :done
)

if not exist "SOURCE.txt" (
    echo [ERROR] SOURCE.txt is missing. Copy the whole folder again.
    set RC=1
    goto :done
)
for /f "usebackq tokens=1,* delims==" %%A in ("SOURCE.txt") do set "SRC_%%A=%%B"
set "TOOL=%SRC_tool%"
set "HASH=%SRC_content%"
if "%TOOL%"=="" goto :badsource
if "%HASH%"=="" goto :badsource
if not exist "%TOOL%\" goto :badsource

echo Importing %TOOL% ^(%HASH%^)

rem The folder of the Git repositories: the argument, or ask.
set "ROOTDIR=%~1"
if defined ROOTDIR goto :haveroot
call :askroot
goto :gotroot
:haveroot
call :cleanroot
if not exist "%ROOTDIR%\" goto :badroot
:gotroot
if not defined ROOTDIR (
    echo Stopped. Nothing was changed.
    goto :done
)

set "REMOTE=%ROOTDIR%\%TOOL%.git"
if not exist "%REMOTE%\HEAD" (
    echo.
    echo %REMOTE% does not exist yet. It will be created.
    set ANS=
    set /p "ANS=Type Y to create it, or Enter to stop: "
    call :isyes || (
        echo Stopped. Nothing was changed.
        goto :done
    )
)
rem Never run git inside the repository on the file server itself
rem (git -C "%REMOTE%" ...): git refuses it there with "detected dubious
rem ownership", because the share is owned by another account. Only
rem init (to create it), clone and push are used, which are allowed.
rem The default branch is made main at creation; otherwise "git clone"
rem checks out nothing ("remote HEAD refers to nonexistent ref").
if not exist "%REMOTE%\HEAD" (
    echo Creating %REMOTE%
    git init --bare --initial-branch=main "%REMOTE%" || ( set RC=1& goto :done )
)

set "WORK=%TEMP%\offline-import-%TOOL%-%RANDOM%%RANDOM%"
git clone --quiet "%REMOTE%" "%WORK%"
if errorlevel 1 (
    echo [ERROR] Cannot clone %REMOTE%
    echo         If git says "dubious ownership", run the command that
    echo         git shows ^(git config --global --add safe.directory ...^)
    echo         and try again.
    set RC=1
    goto :done
)

rem Work on main, whatever the clone checked out. Without this, an
rem empty checkout would miss the last import and make a new root
rem commit, which the push then rejects (non-fast-forward).
git -C "%WORK%" rev-parse --verify --quiet refs/remotes/origin/main >nul
if errorlevel 1 goto :newbranch
git -C "%WORK%" checkout --quiet -B main origin/main
if errorlevel 1 (
    echo [ERROR] Cannot check out main of %REMOTE%
    set RC=1
    goto :done
)
goto :onmain
:newbranch
rem A repository with no commit yet: start the main branch.
git -C "%WORK%" symbolic-ref HEAD refs/heads/main
:onmain

rem Find the last import by its marker line. Commits made here may
rem come after it, so the last commit is not always the import.
set LASTIMPORT=
for /f %%C in ('git -C "%WORK%" log -1 --grep^=Offline-Import: --format^=%%H 2^>nul') do set "LASTIMPORT=%%C"

rem Refuse the same folder twice.
if defined LASTIMPORT (
    git -C "%WORK%" log -1 --format=%%B %LASTIMPORT% | findstr /c:"Offline-Import: %HASH%" >nul && (
        echo [STOP] This folder ^(%HASH%^) is already the latest import. Nothing to do.
        goto :done
    )
)

rem Replace everything except .git. Robocopy returns 0-7 on success.
robocopy "%~dp0%TOOL%" "%WORK%" /MIR /XD .git /NFL /NDL /NJH /NJS /NP >nul
if errorlevel 8 (
    echo [ERROR] Copying the files failed.
    set RC=1
    goto :done
)

rem Files that may be edited here: keep them, or stop on a conflict.
rem The commit message gets one line per file for the next import.
set "MSG=%WORK%.msg"
copy /y "%~dp0COMMIT_MSG.txt" "%MSG%" >nul || ( set RC=1& goto :done )
set CONFLICT=
set RECORD=
if defined LASTIMPORT for %%F in (%SRC_keep%) do call :keepfile "%%F"
if not defined LASTIMPORT for %%F in (%SRC_keep%) do call :record "%%F"
if defined CONFLICT (
    echo.
    echo [STOP] Changed both here and on GitHub:%CONFLICT%
    echo        Nothing was changed. Add the changes from GitHub shown
    echo        above to the file here ^(clone, edit, commit, push^),
    echo        then run import.bat again and type KEEP.
    set RC=1
    goto :done
)

git -C "%WORK%" add -A || ( set RC=1& goto :done )
rem With no change in the files, commit only to write down a new
rem version from GitHub of a kept file (else the next import would
rem stop on the same conflict again).
set EMPTY=
git -C "%WORK%" diff --cached --quiet
if not errorlevel 1 (
    if not defined RECORD (
        echo [OK] No changes since the last import. Nothing to do.
        goto :done
    )
    set EMPTY=--allow-empty
)

git -C "%WORK%" commit --quiet %EMPTY% -F "%MSG%"
if errorlevel 1 (
    echo [ERROR] Commit failed. If git asks who you are, set
    echo         git config --global user.name  "Your Name"
    echo         git config --global user.email "you@example.com"
    set RC=1
    goto :done
)
git -C "%WORK%" push --quiet origin HEAD:refs/heads/main || ( set RC=1& goto :done )
echo [OK] Imported %TOOL% ^(%HASH%^) into %REMOTE%

rem Check the default branch the way clone sees it.
git -C "%WORK%" ls-remote --symref origin HEAD | findstr /b /c:"ref: refs/heads/main" >nul || (
    echo.
    echo [WARN] The default branch of %REMOTE% is not main.
    echo        "git clone" without -b main will check out nothing.
    echo        Clone with:  git clone -b main %REMOTE% ^<folder^>
)
goto :done

:badsource
echo [ERROR] SOURCE.txt or the %TOOL% folder is broken. Copy the whole folder again.
set RC=1
goto :done

:badroot
echo [ERROR] Folder not found: %ROOTDIR%
set RC=1

:done
if defined WORK if exist "%WORK%" rmdir /s /q "%WORK%"
if defined MSG if exist "%MSG%" del /q "%MSG%"
popd
if not "%RC%"=="0" echo.& echo [exit code %RC%]

rem Pause only when double-clicked, so the window stays open to read
rem the result. With an argument the caller owns the console.
if "%~1"=="" pause
exit /b %RC%

rem -----------------------------------------------------------
rem  :askroot  Ask for the folder until it exists, or Enter to stop
rem -----------------------------------------------------------
:askroot
echo.
echo Type the folder of the Git repositories on the file server.
echo   e.g. \\fileserver\share\git
echo Press Enter without typing to stop.
set ROOTDIR=
set /p "ROOTDIR=Folder: "
if not defined ROOTDIR exit /b 0
call :cleanroot
if exist "%ROOTDIR%\" exit /b 0
echo [ERROR] Folder not found: %ROOTDIR%
goto :askroot

rem  :cleanroot  Drop quotes and a trailing backslash (from paste)
:cleanroot
set ROOTDIR=%ROOTDIR:"=%
if "%ROOTDIR:~-1%"=="\" set "ROOTDIR=%ROOTDIR:~0,-1%"
exit /b 0

rem  :isyes  Errorlevel 0 when ANS is Y or YES
:isyes
if /i "%ANS%"=="y" exit /b 0
if /i "%ANS%"=="yes" exit /b 0
exit /b 1

rem -----------------------------------------------------------
rem  :keepfile <path>  (after robocopy; WORK has the new files)
rem
rem  BASE is the file as GitHub had it at the last import. It is
rem  recorded in that commit ("Offline-Upstream: <path> <blob>"),
rem  because the committed file may be the one kept from here.
rem -----------------------------------------------------------
:keepfile
set "F=%~1"
set BASE=
set NEWBLOB=
set HEADBLOB=
for /f "tokens=2,3" %%A in ('git -C "%WORK%" log -1 --format^=%%B %LASTIMPORT% ^| findstr /b /c:"Offline-Upstream: "') do if "%%A"=="%F%" set "BASE=%%B"
if not defined BASE for /f %%H in ('git -C "%WORK%" rev-parse --verify --quiet %LASTIMPORT%:%F%') do set "BASE=%%H"
for /f %%H in ('git -C "%WORK%" hash-object "%F%"') do set "NEWBLOB=%%H"
for /f %%H in ('git -C "%WORK%" rev-parse --verify --quiet HEAD:%F%') do set "HEADBLOB=%%H"
>>"%MSG%" echo Offline-Upstream: %F% %NEWBLOB%
if not "%NEWBLOB%"=="%BASE%" set RECORD=1
rem Not changed here since the last import: take the new one.
if "%HEADBLOB%"=="%BASE%" exit /b 0
rem Changed here only: keep it.
if "%NEWBLOB%"=="%BASE%" goto :keepit
rem Changed on both sides: show the changes from GitHub and ask.
echo.
echo [CONFLICT] %F% was changed both here and on GitHub.
echo            Changes from GitHub since the last import:
git --no-pager -C "%WORK%" diff %BASE% -- "%F%"
echo.
echo   If these changes are already in the file here, type KEEP to
echo   keep the file from here. Otherwise press Enter to stop.
set ANS=
set /p "ANS=KEEP or Enter: "
if /i "%ANS%"=="keep" goto :keepit
set "CONFLICT=%CONFLICT% %F%"
exit /b 0
:keepit
git -C "%WORK%" checkout HEAD -- "%F%"
echo [KEEP] %F%: kept the version edited here.
exit /b 0

rem  :record <path>  (first import: only write down the blob)
:record
set "F=%~1"
set NEWBLOB=
for /f %%H in ('git -C "%WORK%" hash-object "%F%"') do set "NEWBLOB=%%H"
>>"%MSG%" echo Offline-Upstream: %F% %NEWBLOB%
exit /b 0
