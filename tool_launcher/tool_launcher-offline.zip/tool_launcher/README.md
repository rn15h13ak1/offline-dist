# tool_launcher

`~/ws/` 配下の各種ツールをメニュー形式で起動するランチャー。

各ツールの CLI オプションを覚えなくても、番号を選ぶだけで実行できます。

## 必要環境

- Python 3.9 以上
- ランチャー自体は標準ライブラリのみで動作します。
  `tools.yaml` でツールや置き場を追加する場合のみ PyYAML が必要です。

### セットアップ

```bash
python3 -m venv .venv
.venv/bin/pip install -r requirements.txt    # Windows: .venv\Scripts\pip
```

`python menu.py` で使うだけなら仮想環境は不要です。`tools.yaml` でツールを追加するときは
PyYAML が要ります（Anaconda の Python なら入っています）。

Homebrew や OS 同梱の Python は PEP 668 で保護されており、
`pip install` が `externally-managed-environment` で拒否されます。
仮想環境を作るのが確実です。

### 各ツールの依存ライブラリ

ツールのディレクトリに `.venv` があれば**その中の Python で実行**されるため、
ランチャー側に依存を入れる必要はありません。`.venv` が無いツールは、
ランチャーを動かしている Python で実行されます。
ツールをまとめて置いている場合の `.venv` の探し方は、下の「[ツールを別の置き場から起動する](#ツールを別の置き場から起動する)」にあります。

```bash
# .venv を用意する場合（例: file_sync_checker）
cd ../file_sync_checker
python -m venv .venv
.venv/bin/pip install -r requirements.txt      # Windows: .venv\Scripts\pip
```

## ファイルサーバーから使う

インターネットに接続できない環境では、ファイルサーバーに置いた Git のリポジトリから取得します。
Git for Windows が要ります。

**初めて使うとき** は、手元のフォルダに clone します（`\\fileserver\share\git` は置き場に読み替えてください）。

```cmd
git clone -b main \\fileserver\share\git\tool_launcher.git C:\tools\tool_launcher
```

**メニューから起動するツールも、同じフォルダ（ここでは `C:\tools\`）の下に clone します。**
ランチャーは、自分のひとつ上の階層に並んだツールを起動します（下の「ディレクトリ構成」）。
clone していないツールは、メニューに `※未配置` と表示されます。

その後は、上の「必要環境」と、下の「起動」のとおりに使います。

**新しい版に更新する** ときは、clone したフォルダの `update.bat` をダブルクリックします。
中で `git pull --ff-only` を実行します。

- `tools.yaml` や `.venv\` など、Git が扱わないファイルには触れません
- ツールのファイルを手元で書き換えていると、更新せずに止まり、変えたファイルを示します。
  `undo_changes.bat` をダブルクリックすると、変えたファイルを `backup\<日時>\` に退避してから元に戻します
  （一覧を見て `Y` を入力したときだけ）。その後、もう一度 `update.bat` を実行してください。
  退避したものには、変えたファイルと、変更の一覧（`CHANGES.txt`）・差分（`changes.diff`）が入ります

**`tools.example.yaml` は、この環境に合わせて直してかまいません**（この環境で足すツールの例など）。
clone したフォルダで直して commit・push すると、使う人は `update.bat` で受け取れます。
新しい版を取り込んでも、直した `tools.example.yaml` は残ります。

clone や更新で `detected dubious ownership` と出たら、Git が示す
`git config --global --add safe.directory …` のコマンドを実行してから、やり直してください。

## 起動

```bash
python menu.py           # メニューを表示
python menu.py 4         # 4番のツールを直接起動（サブメニューは対話）
python menu.py --list    # ツール一覧
python menu.py --log     # 直近の実行ログ
python menu.py --version # 版を表示
```

Windows では `menu.bat` をダブルクリックしても起動できます。`py -3` → `python` の
順に Python を探し、見つからなければその旨を表示します。引数はそのまま渡るため、
`menu.bat 3 2 1` のような無人実行にも使えます。

直接起動では**ツールの終了コードがそのまま返る**ため、バッチやタスク
スケジューラから成否を判定できます。

## 無人実行（cron / タスクスケジューラ）

ツール番号に続けてサブメニューの選択を並べると、**入力待ちなし**で実行します。

```bash
python menu.py 2 1           # Excel → Backlog 課題登録 → ドライラン
python menu.py 3 2 1         # 課題クローン → 来週 → ドライラン
python menu.py 3 2 2 --yes   # 課題クローン → 来週 → 実行（確認を承認）
```

| 状況 | 動作 |
|---|---|
| Backlog を書き換える確認 | `--yes` が無ければ**実行せずエラー終了**（exit 2） |
| 実行中のエラーで「続行しますか？」 | 無人実行では**中断**し、ツールの終了コードを返す |
| 選択が足りない / 範囲外 | エラー終了（exit 2）。何を指定すべきか表示する |
| 選択が余った | 警告を表示する（指定が実際のメニューとずれている可能性がある） |
| 日付の手動入力 | 無人実行では使用不可（週プリセットを指定する） |

**自前の対話メニューを持つツール（4・7・8）は無人実行できません。**
ランチャー側にサブメニューを持たず、ツール自身の対話メニューを起動するためです。
自動化する場合は、それぞれの本体を直接呼び出してください。

| # | 自動化する場合に呼ぶもの |
|---|---|
| 4 | `file_sync_checker/main.py --no-progress` |
| 7 | `docmold/docmold.py` |
| 8 | `backlog_change_log/backlog_change_log.py` |

3番の「その他の操作」も同じ理由で無人実行できません（`3 4` を指定すると
ツール側のメニューが入力待ちになります）。1〜3 の週次一括は無人実行できます。

`--yes` は破壊的操作を自動承認するため、**登録内容を確認したうえで**設定して
ください。ドライラン（`3 2 1` など）には不要です。

### 子ツールへの `--yes` 伝播

`excel_to_backlog` と `backlog_issue_cloner` は、非対話環境を検知すると
「確認できないのでスキップ」して**正常終了**します。そのためランチャーは、
`--yes` を付けた無人実行のときだけ子ツールにも `--yes` を渡します。

| 実行方法 | 子ツールに渡す引数 |
|---|---|
| メニューから対話実行 | `--execute`（子ツール側で1件ずつ確認する） |
| `menu.py 2 3 --yes` | `--execute --yes` |
| ドライラン | `--yes` は付けない |

これが無いと、cron から実行したときに**1件も登録されないまま成功扱い**に
なります。

## 実行ログ

実行したコマンドと終了コードを直近50件まで記録します
（`~/.tool_launcher_history.json`）。Backlog を書き換える操作を
いつ実行したか後から確認できます。

```
$ python menu.py --log
  直近の実行 2 件（新しい順）  ~/.tool_launcher_history.json
--------------------------------------------------------------
    2026-08-29 10:37:07  excel_to_backlog/excel_to_backlog.py --execute   → 0
  ! 2026-08-29 10:37:06  excel_to_backlog/excel_to_backlog.py --preview   → 2
```

先頭の `!` は終了コードが 0 以外だったことを示します。

前回実行したツールには `←前回` が付き、**空 Enter でそのまま再実行**できます
（履歴は `~/.tool_launcher_history.json`。ラベルで記憶するため、ツールが増減して
番号がずれても追従します）。

## メニュー一覧

| # | ラベル | 呼び出すツール | サブメニュー |
|---|---|---|---|
| 1 | Backlog 週次レポート生成 | `backlog_report/backlog_weekly_report.py` | 土〜金の週プリセット4件＋日付手動入力 |
| 2 | Excel → Backlog 課題登録 | `excel_to_backlog/excel_to_backlog.py` | ドライラン / プレビュー / 実行 / 列名一覧 / 設定名一覧 |
| 3 | Backlog 課題クローン（週次登録） | `backlog_issue_cloner/` | 今週・来週・再来週 × ドライラン / 実行、その他の操作はツール側メニューへ |
| 4 | ファイル同期チェック | `file_sync_checker/menu.py` | file_sync_checker 側の対話メニューに委譲 |
| 5 | （欠番） | | |
| 6 | （欠番） | | |
| 7 | docmold（Markdown → HTML 変換） | `docmold/menu.py` | docmold 側の対話メニューに委譲 |
| 8 | Backlog 変更記録 | `backlog_change_log/menu.py` | backlog_change_log 側の対話メニューに委譲 |

自前の対話メニューを持つツール（4・7・8）は、ランチャー側にサブメニューを置かず
そのメニューをそのまま起動します。オプションの追加はツール側だけで完結します。

**5・6 は欠番です。** ファイルリスト生成（5）と docgrep（6）はメニューから外しました。
番号を詰めると `menu.py 7` のような登録済みのコマンドの意味が変わるため、空けたままにしています。
欠番はメニューに出ず、`menu.py 5` のように指定するとエラー終了（exit 2）します。

### 3. Backlog 課題クローン

操作メニューは次の4項目です。

| 選択 | 動作 |
|---|---|
| 1〜3（今週 / 来週 / 再来週） | その週の月〜金を1日ずつ登録する（ランチャー側で組み立てる） |
| 4（その他の操作） | `backlog_issue_cloner/menu.py` を起動する（単純複製・直接更新） |

**週次一括だけはランチャー側に残しています。** ツール側のメニューは1日ぶんしか
扱わないため、委譲すると月〜金の一括登録ができなくなるためです。
委譲の選択肢を末尾に置いているのは、`menu.py 3 2 1` のような既存の無人実行
コマンドの番号を変えないためです。

日付のルール: 選択した週の月〜金を1日ずつ処理します。**今週を選んだ場合、当日以前は
スキップ**され、翌日以降の日付だけが登録対象になります。来週・再来週は5日分すべてが
対象です。

## ディレクトリ構成

ツールは `menu.py` から見て**ひとつ上の階層**に並んでいる前提です。

```
ws/
├── tool_launcher/
│   ├── menu.py               ← このランチャー
│   ├── menu.bat              Windows 用の起動口（ダブルクリック可）
│   ├── update.bat            ファイルサーバーから更新する（Windows でダブルクリック）
│   ├── undo_changes.bat      手元の変更を backup\ に退避して元に戻す（Windows でダブルクリック）
│   ├── undo_changes.py       その本体
│   ├── tools.example.yaml    tools.yaml のひな形
│   ├── requirements.txt      PyYAML（tools.yaml 用）
│   ├── README.md             この文書
│   ├── .gitignore            Git で扱わないファイル（tools.yaml・.venv/ など）
│   └── .gitattributes        .bat の改行コードを CRLF に固定
├── backlog_report/
├── excel_to_backlog/
├── backlog_issue_cloner/
├── file_sync_checker/
├── docmold/
└── backlog_change_log/
```

ツールが配置されていない場合、メニューには `※未配置` と表示され、
選択してもランチャーは落ちずにメッセージを出してメニューに戻ります。

### ツールを別の置き場から起動する

いくつかのツールをひとつのフォルダにまとめて置いている場合は、`tools.yaml` の `tool_paths` に
その置き場を書きます。ランチャーは**先にこの置き場を探し**、無ければこれまでどおりひとつ上の階層を見ます。
`tools.yaml` が無ければ、`tools.example.yaml` をコピーして作ります（PyYAML が要ります）。

```yaml
# ws/tool-suite/tools/backlog_report/ などを起動する
tool_paths:
  - tool-suite/tools
```

- 相対パスは、ひとつ上の階層（上の図の `ws/`）から見ます
- 複数書くときは、上から順に探します

まとめたフォルダが `.venv` を上の階層で共有している場合（`ws/tool-suite/.venv` など）は、その `.venv` を使います。
ツールのフォルダ自身の `.venv` があれば、そちらが先です。ひとつ上の階層（`ws/`）の `.venv` は使いません。

## 新しいツールを追加する

「選択肢を選んで引数付きで実行するだけ」のツールは、**ハンドラを書かずに**
`COMMANDS` へ宣言を追加するだけで済みます。

```python
COMMANDS = [
    ...
    {
        "label":    "新しいツール名",
        "tool_dir": "new_tool",        # 未配置チェックにも使う
        "script":   "main.py",         # 省略時 main.py
        "options": [                   # 省略時は引数なしで即実行
            {"label": "通常実行", "args": []},
            {"label": "詳細ログ付き実行", "args": ["-v"]},
            # 取り消せない操作には confirm を付ける
            {"label": "実行", "args": ["--execute"],
             "confirm": "実際に書き込みます。よろしいですか？"},
        ],
    },
]
```

`confirm` を付けた選択肢は実行前に y/N を確認し、**無人実行では `--yes` が無いと
実行されません**。

日付選択のように独自の操作が必要な場合だけ、ハンドラ関数を書いて `handler`
に渡します（`Backlog 週次レポート生成` と `Backlog 課題クローン` がこの形です）。

```python
def run_new_tool():
    """新しいツール"""
    ...
    return run_script("new_tool", "main.py", args)   # 終了コードを返す
    # キャンセル時は None を返す

COMMANDS = [
    ...
    {"label": "新しいツール名", "handler": run_new_tool, "tool_dir": "new_tool"},
]
```

### `tools.yaml` で追加する（Python を書かない方法）

`menu.py` を編集せずに、同じ宣言を YAML で書けます。組み込みツールと**同じ仕組み**
で動くため、`confirm` も使えます。

```bash
cp tools.example.yaml tools.yaml
```

```yaml
tools:
  - label: "新しいツール"
    tool_dir: "new_tool"
    script: "main.py"        # 省略時 main.py
    options:                 # 省略時は引数なしで即実行
      - {label: "通常実行", args: []}
      - {label: "詳細ログ", args: ["-v"]}
      - {label: "実行", args: ["--execute"],
         confirm: "実際に書き込みます。よろしいですか？"}
```

`tools.yaml` は起動のたびに読み直されるため、メニューを開いたまま編集しても
次の表示から反映されます。

### `run_script()` の使い方

```python
rc = run_script(tool_dir_name, script_name, args=None, wait=True)
```

| 引数 | 説明 |
|---|---|
| `tool_dir_name` | `ws/` 配下のディレクトリ名 |
| `script_name` | 実行する Python スクリプト名 |
| `args` | コマンドライン引数のリスト |
| `wait` | `False` にすると終了後の Enter 待ちをスキップ（連続実行用） |

戻り値は子プロセスの終了コード。ツールやスクリプトが見つからない場合は
`127` を返し、例外は投げません。

## 終了コード

直接起動・無人実行では、**ツールが返した終了コードがそのまま返ります**。
ランチャー自身が返すのは次のコードです。

| コード | 意味 |
|---|---|
| 0 | 正常終了（メニューを終了した / ツールが 0 を返した） |
| 1 | 標準入力が閉じられた（対話の途中で EOF） |
| 2 | 引数が不正、または無人実行に必要な指定が足りない（`--yes` 不足・選択の過不足） |
| 127 | ツールのディレクトリまたはスクリプトが見つからない |
| 130 | Ctrl+C で中断 |
| その他 | 実行したツールの終了コード |

終了コード 2 は「ランチャーの使い方の誤り」と「ツールが 2 を返した」の
どちらもあり得ます。区別が必要な場合は出力メッセージを確認してください。

メニュー操作中の `Ctrl+C` は実行中のツールを中断してメニューに戻ります
（ランチャー自体は終了しません）。

