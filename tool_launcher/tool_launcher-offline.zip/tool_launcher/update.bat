@echo off
rem ===========================================================
rem  Tool launcher - update from the file server
rem  Double-click this file in the folder you cloned with
rem  "git clone". It runs "git pull --ff-only".
rem  Files that git does not track (tools.yaml, .venv\ ...)
rem  are never touched.
rem
rem  Messages here are ASCII on purpose: this file must stay
rem  readable in any console code page.
rem ===========================================================

pushd "%~dp0" || (
    echo [ERROR] Cannot enter the folder of this script.
    pause
    exit /b 1
)

set RC=0
git --version >nul 2>&1 || (
    echo [ERROR] Git was not found. Install Git for Windows.
    set RC=1
    goto :done
)

if not exist ".git" (
    echo [ERROR] This folder was not made by "git clone".
    echo         See README.md, "Use from the file server".
    set RC=1
    goto :done
)

rem Stop before pulling if tracked files were changed here, so that
rem nothing is overwritten or half-merged. The exit code tells it, so
rem no "for /f" is needed (inside it, "=" would turn into a space).
git diff --quiet HEAD --
if errorlevel 1 (
    echo [ERROR] These files were changed in this folder:
    git status --short --untracked-files=no
    echo.
    echo         To back them up and undo them, double-click
    echo         undo_changes.bat ^(copies them to backup\ first^),
    echo         then run this again.
    set RC=1
    goto :done
)

rem "git pull" may replace this very file. cmd reads a .bat from the
rem disk line by line, so after the pull it would go on reading the
rem new file at the old position. Everything from here on is one
rem block: cmd reads the whole block before running it, and the block
rem ends the script without reading the file again. So no %RC%, goto
rem or call inside it (%RC% would be expanded when the block is read).
(
    git pull --ff-only
    if errorlevel 1 (
        echo.
        echo [ERROR] Update failed. Nothing was changed.
        echo         If git says "dubious ownership", run the command that
        echo         git shows ^(git config --global --add safe.directory ...^)
        echo         and try again.
        popd
        echo.
        echo [exit code 1]
        if "%~1"=="" pause
        exit /b 1
    )
    echo.
    echo [OK] Updated.
    popd
    if "%~1"=="" pause
    exit /b 0
)

rem Reached only by "goto :done" above, before the pull.
:done
popd
if not "%RC%"=="0" echo.& echo [exit code %RC%]

rem Pause only when double-clicked. With arguments this runs unattended,
rem where pause would wait forever.
if "%~1"=="" pause
exit /b %RC%
