"""システム構成図 (system) のルール。

区画を見出し 2、要素を見出し 3 で書き、要素の節の最初の箇条書きに種別・層・接続を書く。

    ---
    type: system
    対象: 受注システム            ← どの区画が対象のシステムか（省くと最初の区画）
    層: [画面, 業務, データ]      ← 対象の中の行の並び（上から）
    ---

    ## 受注システム               ← 区画。見出しのすぐ下の本文は区画の説明
    ### Web サーバー              ← 要素
    - 種別: サーバー
    - 層: 画面
    - 枠: クラウド / 公開サブネット ← 図で囲む枠。/ で区切ると入れ子（対象の区画の要素だけ）
    - 接続: → AP サーバー（HTTP）  ← → は相手へ、← は相手から、<-> は両向き
    画面を返す。                  ← ほかは要素の詳細（押したときに欄に出る）

    #### 接続: AP サーバー（HTTP） ← その接続の詳細。括弧を省くと、相手とのすべての接続の説明

    ## 利用者側
    ### 社内 PC
    - 種別: 端末
    - 数: 300 台
    - 位置: 左                    ← 図で置く側（左・右・上・下）。省くと配置の決まりで決める

ルールは区画・要素・接続の一覧を ``derived["system"]`` に入れ、本文を「区画 → 要素」の並びと
接続の一覧表に組み直す。本文は JavaScript が動かない環境と印刷のためのもので、図と詳細の欄は
``templates/system.html`` の JavaScript が一覧から組む（欄に出す詳細は、本文の要素を写す）。
"""
from __future__ import annotations

import re
from typing import Any, Dict, List, Optional, Tuple

from rules import derived, keywords, rule, warn
from rules.common import add_class, heading_level, normalize

#: 箇条書きの行（``キー: 値``）。全角のコロンでも書ける。
_FIELD_RE = re.compile(r"\A(?P<key>[^:：]+?)\s*[:：]\s*(?P<value>.*)\Z", re.S)

#: 接続の向きの印。長いものから見る（``<->`` を ``<-`` と読まないため）。
#: ``\u2194`` は両向きの矢印。画面に出すソースは CP932 に収めるため、エスケープで書く。
_ARROWS = (
    ("<->", "both"), ("\u2194", "both"), ("⇔", "both"), ("\u21c4", "both"),
    ("->", "out"), ("→", "out"), ("⇒", "out"),
    ("<-", "in"), ("←", "in"), ("\u21d0", "in"),
)

#: ``相手（方式）`` の括弧。全角・半角のどちらでも書ける。
_PEER_RE = re.compile(r"\A(?P<name>.+?)\s*(?:[（(](?P<method>.*)[）)])?\s*\Z", re.S)

#: ``枠:`` の入れ子の区切り。全角でも書ける。
_FRAME_SEP_RE = re.compile(r"\s*[/／]\s*")

#: 行の終わりの ``［流れの名前］``。全角でも半角でも書け、``,`` で区切ると複数の流れに入る。
_FLOW_RE = re.compile(r"\s*[［\[](?P<names>[^\]］]*)[\]］]\s*\Z")

#: 区画の区切りに使う値の区切り（``層: 画面, 業務``）。
_LIST_SEP_RE = re.compile(r"\s*[,、，]\s*")

#: ``位置:`` の値 → 図で置く側。
_POSITIONS = {"左": "L", "left": "L", "右": "R", "right": "R",
              "上": "T", "top": "T", "下": "B", "bottom": "B"}

#: 種別の語の組 → 図の印。語は rules/keywords.py にあり、config.yaml で差し替えられる。
_ICON_GROUPS = (("person", "system_icon_person"), ("device", "system_icon_device"),
                ("app", "system_icon_app"), ("db", "system_icon_db"),
                ("server", "system_icon_server"))

#: 向き → 本文の表に出す矢印（相手から見た向きではなく、書いた要素から見た向き）。
_ARROW_TEXT = {"out": "→", "in": "←", "both": "\u2194"}


# ---------------------------------------------------------------- front matter


def _lookup(meta: Dict[str, Any], group: str) -> List[Tuple[str, Any]]:
    names = {normalize(word) for word in keywords.get(group)}
    return [(key, value) for key, value in meta.items() if normalize(str(key)) in names]


def _target_name(meta: Dict[str, Any]) -> Optional[str]:
    found = _lookup(meta, "system_target")
    if not found:
        return None
    text = str(found[-1][1] or "").strip()
    return text or None


def _layers(meta: Dict[str, Any]) -> Optional[List[str]]:
    """``層:`` の並び。書いていなければ None。"""
    found = _lookup(meta, "system_layers")
    if not found:
        return None
    key, value = found[-1]
    if isinstance(value, str):
        items = [v for v in _LIST_SEP_RE.split(value.strip()) if v]
    elif isinstance(value, list):
        items = [str(v).strip() for v in value if str(v).strip()]
    else:
        warn(meta, f"{key}: は層の名前の並びで書きます（例: {key}: [画面, 業務, データ]）")
        return None
    out: List[str] = []
    for item in items:
        if item in out:
            warn(meta, f"{key}: に同じ層が 2 度あります: {item}")
            continue
        out.append(item)
    return out or None


# ---------------------------------------------------------------- 本文を読む


def _flatten_sections(soup: Any) -> None:
    """converter が見出しごとに包んだ ``<section>`` をほどく（区画と要素はここで包み直す）。"""
    for section in soup.find_all("section"):
        if "dm-section" in (section.get("class") or []):
            section.unwrap()


def _text(node: Any) -> str:
    return " ".join(node.get_text(" ").split()) if hasattr(node, "get_text") else " ".join(str(node).split())


def _is_blank(node: Any) -> bool:
    return getattr(node, "name", None) is None and not str(node).strip()


def _connect_heading(node: Any) -> Optional[str]:
    """``#### 接続: 相手（方式）`` なら ``相手（方式）`` の部分。違えば None。"""
    if getattr(node, "name", None) != "h4":
        return None
    match = _FIELD_RE.match(_text(node))
    if match and normalize(match.group("key")) in {normalize(w) for w in keywords.get("system_connect")}:
        return match.group("value").strip()
    return None


def _split_body(soup: Any) -> Tuple[List[Any], List[Dict[str, Any]]]:
    """本文を区画（見出し 2）と要素（見出し 3）に分ける。区画より前のノードは別に返す。"""
    lead: List[Any] = []
    zones: List[Dict[str, Any]] = []
    zone: Optional[Dict[str, Any]] = None
    node_: Optional[Dict[str, Any]] = None
    detail: Optional[Dict[str, Any]] = None
    for child in list(soup.contents):
        child.extract()
        level = heading_level(child)
        if level == 2:
            zone = {"heading": child, "name": _text(child), "intro": [], "nodes": []}
            zones.append(zone)
            node_, detail = None, None
            continue
        if level == 3:
            if zone is None:
                zone = {"heading": None, "name": "", "intro": [], "nodes": []}
                zones.append(zone)
            node_ = {"heading": child, "name": _text(child), "body": [], "details": [], "zone": zone}
            zone["nodes"].append(node_)
            detail = None
            continue
        if node_ is not None:
            peer = _connect_heading(child)
            if peer is not None:
                detail = {"heading": child, "peer": peer, "body": []}
                node_["details"].append(detail)
                continue
            (detail["body"] if detail is not None else node_["body"]).append(child)
            continue
        (zone["intro"] if zone is not None else lead).append(child)
    return lead, zones


def _read_fields(node_: Dict[str, Any], meta: Dict[str, Any]) -> None:
    """要素の節の最初の箇条書きから、種別・層・接続・位置・数の行を読み、本文から外す。

    読むのは最初の箇条書きだけ。詳細の途中の箇条書きに「接続: 〜」と書いた説明を
    取り違えないため（process の担当の読み方と同じ）。
    """
    groups = {name: {normalize(w) for w in keywords.get(f"system_{name}")}
              for name in ("kind", "layer", "connect", "position", "count", "frame", "redirect")}
    node_.update(kind="", layer=None, pos=None, count=None, links=[], frame=[])
    first = next((n for n in node_["body"] if not _is_blank(n)), None)
    if getattr(first, "name", None) not in ("ul", "ol"):
        return
    for item in first.find_all("li", recursive=False):
        match = _FIELD_RE.match(_text(item))
        if not match:
            continue
        key, value = normalize(match.group("key")), match.group("value").strip()
        if key in groups["kind"]:
            node_["kind"] = value
        elif key in groups["layer"]:
            node_["layer"] = value
        elif key in groups["count"]:
            node_["count"] = value or None
        elif key in groups["frame"]:
            node_["frame"] = [part for part in _FRAME_SEP_RE.split(value) if part]
        elif key in groups["position"]:
            side = _POSITIONS.get(normalize(value))
            if side is None:
                warn(meta, f"位置は 左・右・上・下 のどれかで書きます: {value}（{node_['name']}）")
            node_["pos"] = side
        elif key in groups["connect"] or key in groups["redirect"]:
            redirect = key in groups["redirect"]
            link = _parse_link(value)
            if link is None:
                warn(meta, f"接続の書き方を読めません（「→ 相手（方式）」と書きます）: {value}（{node_['name']}）")
            elif redirect and link["via"]:
                warn(meta, f"リダイレクトには経由を書けません: {value}（{node_['name']}）")
            else:
                link["redirect"] = redirect
                node_["links"].append(link)
        else:
            continue
        item.decompose()
    if not first.find("li"):
        node_["body"].remove(first)
        first.decompose()


def _parse_link(value: str) -> Optional[Dict[str, Any]]:
    """``→ 経由 → 相手（方式）`` を ``{dir, peer, via, method}`` にする。向きの印が無ければ → とみなす。

    ``via`` は書いた要素の側から順の経由の名前。矢印をつなげて、いくつでも書ける。
    行の終わりの ``［名前］`` は ``flows``（その接続が入る流れの名前）にする。
    """
    text = value.strip()
    flows: List[str] = []
    found = _FLOW_RE.search(text)
    if found:
        flows = [name for name in _LIST_SEP_RE.split(found.group("names").strip()) if name]
        text = text[:found.start()].strip()
    direction, mark0 = "out", None
    for mark, name in _ARROWS:
        if text.startswith(mark):
            direction, mark0, text = name, mark, text[len(mark):].strip()
            break
    match = _PEER_RE.match(text)
    if not text or not match or not match.group("name").strip():
        return None
    marks = [m for m, name in _ARROWS if name == direction]
    parts = [match.group("name")]
    for mark in sorted(marks, key=len, reverse=True):
        parts = [piece for part in parts for piece in part.split(mark)]
    parts = [part.strip() for part in parts]
    if any(not part for part in parts):
        return None
    return {"dir": direction, "peer": parts[-1], "via": parts[:-1], "flows": flows,
            "method": (match.group("method") or "").strip()}


def _icon(kind: str) -> str:
    """種別の語に当たる図の印の名前。当たらなければ空。"""
    value = normalize(kind)
    if not value:
        return ""
    for icon, group in _ICON_GROUPS:
        if value in {normalize(w) for w in keywords.get(group)}:
            return icon
    return ""


# ---------------------------------------------------------------- ルール


@rule("system")
def system(soup: Any, meta: Dict[str, Any]) -> None:
    """区画・要素・接続を読み取り、構成図の一覧と、区画ごとの本文・接続の一覧表にする。"""
    _flatten_sections(soup)
    lead, zones = _split_body(soup)
    for node in lead:
        soup.append(node)
    if not zones:
        warn(meta, "区画（見出し 2）と要素（見出し 3）がありません")
        derived(meta)["system"] = None
        return

    target = _pick_target(zones, meta)
    layers = _layers(meta)
    nodes: List[Dict[str, Any]] = []
    index: Dict[str, int] = {}
    for zone in zones:
        for node_ in zone["nodes"]:
            _read_fields(node_, meta)
            key = normalize(node_["name"])
            if key in index:
                warn(meta, f"同じ名前の要素が 2 つあります: {node_['name']}（接続は最初のものにつなぎます）")
            else:
                index[key] = len(nodes)
            node_["i"] = len(nodes)
            nodes.append(node_)
    _assign_layers(target, layers, meta)
    frames = _collect_frames(nodes, target, meta)
    conns, pairs = _collect_links(nodes, index, meta)
    flows = _collect_flows(conns, nodes, meta)
    _attach_details(nodes, conns, pairs, index, meta)
    _build_body(soup, zones, target, nodes, conns, flows)

    store = derived(meta)
    store["system"] = {
        "target": zones.index(target),
        "layers": target.get("layers", []),
        "zones": [{"name": z["name"], "id": f"dm-sys-z{n}", "anchor": z["heading"].get("id") if z["heading"] else None}
                  for n, z in enumerate(zones)],
        "nodes": [{"name": n["name"], "kind": n["kind"], "icon": _icon(n["kind"]),
                   "zone": zones.index(n["zone"]), "layer": n.get("row"),
                   "pos": n["pos"], "count": n["count"], "frame": n.get("frame_index"), "id": f"dm-sys-n{n['i']}",
                   "anchor": n["heading"].get("id")} for n in nodes],
        "frames": frames,
        "conns": [{"a": c["a"], "b": c["b"], "p": c["method"], "both": c["dir"] == "both",
                   "via": c["via"], "r": c["redirect"], "note": c.get("note"),
                   "flows": [n for n, f in enumerate(flows) if c in f["members"]]} for c in conns],
        "pairs": [{"a": a, "b": b, "note": note} for (a, b), note in pairs.items() if note],
        "flows": [{"name": f["name"], "steps": f["steps"]} for f in flows],
    }


def _pick_target(zones: List[Dict[str, Any]], meta: Dict[str, Any]) -> Dict[str, Any]:
    name = _target_name(meta)
    named = [z for z in zones if z["heading"] is not None]
    if name is None:
        target = named[0] if named else zones[0]
        warn(meta, f"対象: がありません（最初の区画「{target['name'] or '見出しなし'}」を対象のシステムにします）")
        return target
    for zone in zones:
        if normalize(zone["name"]) == normalize(name):
            return zone
    target = named[0] if named else zones[0]
    warn(meta, f"対象: の「{name}」という区画がありません（最初の区画「{target['name'] or '見出しなし'}」を対象のシステムにします）")
    return target


def _assign_layers(target: Dict[str, Any], layers: Optional[List[str]], meta: Dict[str, Any]) -> None:
    """対象の要素を層の行に割り当てる。``層:`` が無ければ、要素に書いた層を出てきた順に並べる。"""
    inner = target["nodes"]
    if layers is None:
        layers = []
        for node_ in inner:
            if node_["layer"] and node_["layer"] not in layers:
                layers.append(node_["layer"])
        if layers and any(not n["layer"] for n in inner):
            layers.append("")
    known = {normalize(name): n for n, name in enumerate(layers)}
    for node_ in inner:
        if not layers:
            node_["row"] = None
            continue
        value = node_["layer"]
        if value and normalize(value) in known:
            node_["row"] = known[normalize(value)]
            continue
        if value:
            warn(meta, f"層: に無い層です: {value}（{node_['name']}。最後の層に置きます）")
        elif layers[-1]:
            warn(meta, f"層の無い要素があります: {node_['name']}（最後の層に置きます）")
        node_["row"] = len(layers) - 1
    target["layers"] = layers


def _collect_frames(nodes: List[Dict[str, Any]], target: Dict[str, Any],
                    meta: Dict[str, Any]) -> List[Dict[str, Any]]:
    """``枠:`` の道（``クラウド / VPC``）から、入れ子の枠の一覧を作る。

    枠は道で見分ける（別の枠の中にある同じ名前の枠は、別の枠）。並びは最初に出てきた順で、
    親は子より前に来る。要素には、いちばん内側の枠の番号を ``frame_index`` に入れる。
    """
    frames: List[Dict[str, Any]] = []
    index: Dict[Tuple[str, ...], int] = {}
    for node_ in nodes:
        path = node_["frame"]
        node_["frame_index"] = None
        if not path:
            continue
        if node_["zone"] is not target:
            warn(meta, f"枠: は対象の区画の要素にだけ書けます: {node_['name']}（枠に入れずに置きます）")
            node_["frame"] = []
            continue
        parent: Optional[int] = None
        for depth in range(len(path)):
            key = tuple(normalize(part) for part in path[:depth + 1])
            if key not in index:
                index[key] = len(frames)
                frames.append({"name": path[depth], "path": path[:depth + 1], "parent": parent})
            parent = index[key]
        node_["frame_index"] = parent
    return frames


def _collect_links(nodes: List[Dict[str, Any]], index: Dict[str, int],
                   meta: Dict[str, Any]) -> Tuple[List[Dict[str, Any]], Dict[Tuple[int, int], Optional[str]]]:
    """要素に書いた接続を、向きをそろえた一覧にする。両側に書いた同じ接続は 1 つにまとめる。"""
    conns: List[Dict[str, Any]] = []
    seen: Dict[Tuple[int, int, str, str], Dict[str, Any]] = {}
    pairs: Dict[Tuple[int, int], Optional[str]] = {}
    for node_ in nodes:
        mine: set = set()
        for link in node_["links"]:
            other = index.get(normalize(link["peer"]))
            where = f"{node_['name']} の接続"
            if other is None:
                warn(meta, f"接続の相手がありません: {link['peer']}（{where}）")
                continue
            if other == node_["i"]:
                warn(meta, f"自分への接続は書けません: {link['peer']}（{where}）")
                continue
            via = [index.get(normalize(name)) for name in link["via"]]
            missing = [name for name, v in zip(link["via"], via) if v is None]
            if missing:
                warn(meta, f"経由の相手がありません: {', '.join(missing)}（{where}）")
                continue
            if link["dir"] == "in":
                a, b, via = other, node_["i"], via[::-1]
            else:
                a, b = node_["i"], other
            direction = "both" if link["dir"] == "both" else "out"
            method = link["method"]
            kind = "redirect" if link.get("redirect") else "conn"
            if direction == "both":
                key = (min(a, b), max(a, b), normalize(method), "both", kind,
                       tuple(via if a < b else via[::-1]))
            else:
                key = (a, b, normalize(method), "out", kind, tuple(via))
            if key in mine:
                warn(meta, f"同じ接続を 2 度書いています: {link['peer']}（{method or '方式なし'}。{where}）")
                continue
            mine.add(key)
            if key in seen:  # 相手の側にも同じ接続を書いた。流れの名前は合わせる
                known_flows = seen[key]["flows"]
                known_flows.extend(f for f in link["flows"] if f not in known_flows)
                continue
            conn = {"a": a, "b": b, "method": method, "dir": direction, "written": node_["i"],
                    "via": via, "redirect": kind == "redirect", "flows": list(dict.fromkeys(link["flows"]))}
            seen[key] = conn
            conns.append(conn)
            pairs.setdefault((min(a, b), max(a, b)), None)
    return conns, pairs


def _collect_flows(conns: List[Dict[str, Any]], nodes: List[Dict[str, Any]],
                   meta: Dict[str, Any]) -> List[Dict[str, Any]]:
    """``［名前］`` を付けた接続とリダイレクトを、名前ごとの流れにし、たどる順に並べる。

    順は、リダイレクトの元へ来る接続 → リダイレクト → 転送先への接続（リダイレクトが続けば、その後ろへ同じく）。
    リダイレクトの無い流れと、この順に入らなかった接続は、書いた順に後ろへ足す。
    """
    flows: List[Dict[str, Any]] = []
    by_name: Dict[str, Dict[str, Any]] = {}
    for conn in conns:
        for name in conn["flows"]:
            flow = by_name.get(normalize(name))
            if flow is None:
                flow = by_name[normalize(name)] = {"name": name, "members": []}
                flows.append(flow)
            flow["members"].append(conn)
    for flow in flows:
        members = flow["members"]
        redirects = [c for c in members if c["redirect"]]
        plain = [c for c in members if not c["redirect"]]
        targets = {c["b"] for c in redirects}
        order: List[Dict[str, Any]] = []

        def put(conn: Dict[str, Any]) -> None:
            if conn not in order:
                order.append(conn)

        for head in [c for c in redirects if c["a"] not in targets] or redirects[:1]:
            for conn in plain:
                if conn["b"] == head["a"]:
                    put(conn)
            current = head
            while current is not None and current not in order:
                put(current)
                for conn in plain:
                    if conn["b"] == current["b"]:
                        put(conn)
                current = next((c for c in redirects if c["a"] == current["b"] and c not in order), None)
        for conn in members:
            put(conn)
        flow["steps"] = [conns.index(c) for c in order]
        if len(members) == 1:
            warn(meta, f"流れ「{flow['name']}」に入る接続が 1 つしかありません（名前の打ち間違いかもしれません）")
    return flows


def _attach_details(nodes: List[Dict[str, Any]], conns: List[Dict[str, Any]],
                    pairs: Dict[Tuple[int, int], Optional[str]], index: Dict[str, int],
                    meta: Dict[str, Any]) -> None:
    """``#### 接続: 相手（方式）`` の詳細を、当たる接続か、相手との組に結びつける。"""
    count = 0
    for node_ in nodes:
        for detail in node_["details"]:
            match = _PEER_RE.match(detail["peer"])
            peer = match.group("name").strip() if match else detail["peer"]
            method = (match.group("method") or "").strip() if match else ""
            other = index.get(normalize(peer))
            detail["id"] = f"dm-sys-d{count}"
            count += 1
            where = f"{node_['name']} の「{detail['peer']}」"
            if other is None:
                warn(meta, f"接続の詳細の相手がありません（{where}）")
                continue
            pair = (min(node_["i"], other), max(node_["i"], other))
            if not method:
                if pair not in pairs:
                    warn(meta, f"接続の詳細に当たる接続がありません（{where}）")
                    continue
                pairs[pair] = detail["id"]
                continue
            hit = [c for c in conns if (min(c["a"], c["b"]), max(c["a"], c["b"])) == pair
                   and normalize(c["method"]) == normalize(method)]
            if not hit:
                warn(meta, f"接続の詳細に当たる接続がありません（{where}）")
                continue
            for conn in hit:
                conn["note"] = detail["id"]


# ---------------------------------------------------------------- 本文を組む


def _build_body(soup: Any, zones: List[Dict[str, Any]], target: Dict[str, Any],
                nodes: List[Dict[str, Any]], conns: List[Dict[str, Any]],
                flows: List[Dict[str, Any]]) -> None:
    """区画 → 要素の並びと、接続の一覧表を本文に置く。JavaScript が無いときと印刷で読むもの。"""
    box = soup.new_tag("div", id="dm-sys")
    add_class(box, "dm-sys")
    for z, zone in enumerate(zones):
        section = soup.new_tag("section")
        add_class(section, "dm-sys-area")
        if zone is target:
            add_class(section, "dm-sys-area--target")
        if zone["heading"] is not None:
            section.append(zone["heading"])
        intro = soup.new_tag("div", id=f"dm-sys-z{z}")
        add_class(intro, "dm-sys-area__intro")
        for node in zone["intro"]:
            intro.append(node)
        section.append(intro)
        for node_ in zone["nodes"]:
            section.append(_node_section(soup, node_, nodes, conns, target))
        box.append(section)
    if conns:
        box.append(_conn_table(soup, nodes, conns))
    if flows:
        box.append(_flow_table(soup, nodes, conns, flows))
    soup.append(box)


def _node_link(soup: Any, node_: Dict[str, Any]) -> Any:
    anchor = node_["heading"].get("id")
    if not anchor:
        return node_["name"]
    tag = soup.new_tag("a", href=f"#{anchor}")
    tag.string = node_["name"]
    return tag


def _node_section(soup: Any, node_: Dict[str, Any], nodes: List[Dict[str, Any]],
                  conns: List[Dict[str, Any]], target: Dict[str, Any]) -> Any:
    section = soup.new_tag("section")
    add_class(section, "dm-sys-item")
    section.append(node_["heading"])
    facts = []
    if node_["kind"]:
        facts.append(f"種別: {node_['kind']}")
    if node_["zone"] is target and node_.get("row") is not None and target["layers"][node_["row"]]:
        facts.append(f"層: {target['layers'][node_['row']]}")
    if node_["frame"]:
        facts.append(f"枠: {' / '.join(node_['frame'])}")
    if node_["count"]:
        facts.append(f"数: {node_['count']}")
    if facts:
        line = soup.new_tag("p")
        add_class(line, "dm-sys-item__facts")
        line.string = " / ".join(facts)
        section.append(line)
    detail = soup.new_tag("div", id=f"dm-sys-n{node_['i']}")
    add_class(detail, "dm-sys-item__detail")
    for child in node_["body"]:
        detail.append(child)
    section.append(detail)

    mine = [c for c in conns if node_["i"] in (c["a"], c["b"])]
    if mine:
        table = soup.new_tag("table")
        add_class(table, "dm-sys-item__conns")
        head = soup.new_tag("tr")
        for label in ("相手", "向き", "方式"):
            th = soup.new_tag("th")
            th.string = label
            head.append(th)
        thead = soup.new_tag("thead")
        thead.append(head)
        table.append(thead)
        tbody = soup.new_tag("tbody")
        for conn in mine:
            other = conn["b"] if conn["a"] == node_["i"] else conn["a"]
            direction = "both" if conn["dir"] == "both" else ("out" if conn["a"] == node_["i"] else "in")
            row = soup.new_tag("tr")
            for value in (_node_link(soup, nodes[other]), _ARROW_TEXT[direction], _method_text(conn, nodes)):
                td = soup.new_tag("td")
                td.append(value)
                row.append(td)
            tbody.append(row)
        table.append(tbody)
        section.append(table)

    for detail_ in node_["details"]:
        block = soup.new_tag("div", id=detail_["id"])
        add_class(block, "dm-sys-item__conn-detail")
        block.append(detail_["heading"])
        for child in detail_["body"]:
            block.append(child)
        section.append(block)
    return section


def _method_text(conn: Dict[str, Any], nodes: List[Dict[str, Any]]) -> str:
    """表の方式の欄。リダイレクトと経由も、ここに書き添える。"""
    text = conn["method"] or ("" if conn["redirect"] else "-")
    if conn["redirect"]:
        text = f"リダイレクト {text}".strip()
    if conn["via"]:
        text += f"（経由: {' → '.join(nodes[v]['name'] for v in conn['via'])}）"
    if conn["flows"]:
        text += f"（流れ: {', '.join(conn['flows'])}）"
    return text


def _flow_table(soup: Any, nodes: List[Dict[str, Any]], conns: List[Dict[str, Any]],
                flows: List[Dict[str, Any]]) -> Any:
    """流れの一覧。流れごとに、たどる順の接続を並べる。"""
    section = soup.new_tag("section")
    add_class(section, "dm-sys-list")
    heading = soup.new_tag("h2", id="dm-sys-flows")
    heading.string = "流れの一覧"
    section.append(heading)
    table = soup.new_tag("table")
    thead = soup.new_tag("thead")
    head = soup.new_tag("tr")
    for label in ("流れ", "順", "から", "向き", "へ", "方式"):
        th = soup.new_tag("th")
        th.string = label
        head.append(th)
    thead.append(head)
    table.append(thead)
    tbody = soup.new_tag("tbody")
    for flow in flows:
        for n, i in enumerate(flow["steps"], 1):
            conn = conns[i]
            row = soup.new_tag("tr")
            method = conn["method"] or ("" if conn["redirect"] else "-")
            if conn["redirect"]:
                method = f"リダイレクト {method}".strip()
            for value in (flow["name"] if n == 1 else "", str(n), _node_link(soup, nodes[conn["a"]]),
                          _ARROW_TEXT[conn["dir"]], _node_link(soup, nodes[conn["b"]]), method):
                td = soup.new_tag("td")
                td.append(value)
                row.append(td)
            tbody.append(row)
    table.append(tbody)
    section.append(table)
    return section


def _conn_table(soup: Any, nodes: List[Dict[str, Any]], conns: List[Dict[str, Any]]) -> Any:
    section = soup.new_tag("section")
    add_class(section, "dm-sys-list")
    heading = soup.new_tag("h2", id="dm-sys-list")
    heading.string = "接続の一覧"
    section.append(heading)
    table = soup.new_tag("table")
    thead = soup.new_tag("thead")
    head = soup.new_tag("tr")
    for label in ("から", "向き", "へ", "方式"):
        th = soup.new_tag("th")
        th.string = label
        head.append(th)
    thead.append(head)
    table.append(thead)
    tbody = soup.new_tag("tbody")
    for conn in conns:
        row = soup.new_tag("tr")
        for value in (_node_link(soup, nodes[conn["a"]]), _ARROW_TEXT[conn["dir"]],
                      _node_link(soup, nodes[conn["b"]]), _method_text(conn, nodes)):
            td = soup.new_tag("td")
            td.append(value)
            row.append(td)
        tbody.append(row)
    table.append(tbody)
    section.append(table)
    return section
