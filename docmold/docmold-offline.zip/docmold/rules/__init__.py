"""ルール層 (意味づけ) のレジストリ。

ルールは「Markdown → HTML 変換後の DOM を BeautifulSoup で触る関数」。
Markdown 拡張を書くより読み書きしやすく、種類の追加が
**関数 1 つ + YAML 数行** で済むようにしている。

    @rule("todo_checklist")
    def todo_checklist(soup, meta):
        '''「## ToDo」直下のリストをチェックボックス付きにする。'''
        ...

シグネチャは ``(soup: BeautifulSoup, meta: dict) -> None``。戻り値は見ない。
テンプレートに値を渡したいときは ``derived(meta)`` の dict に入れる
（テンプレート側から ``derived.summary`` のように参照できる）。
書き方の誤りを指摘したいときは ``warn(meta, ...)``。
"""
from __future__ import annotations

import hashlib
import importlib
import importlib.util
import pkgutil
import sys
from pathlib import Path
from typing import Any, Callable, Dict, Iterable, List, Set

RuleFunc = Callable[[Any, Dict[str, Any]], None]

#: 名前 → ルール関数。``@rule`` で登録される。
RULES: Dict[str, RuleFunc] = {}

#: ルールがテンプレートへ値を渡すための、meta 内の予約キー。
DERIVED_KEY = "_derived"


class RuleError(RuntimeError):
    """ルールの登録・実行に関する問題。"""


def rule(name: str) -> Callable[[RuleFunc], RuleFunc]:
    """ルール関数を ``name`` で登録するデコレータ。"""
    def decorator(func: RuleFunc) -> RuleFunc:
        if name in RULES:
            raise RuleError(
                f"ルール名が重複しています: {name}"
                f"（{_defined_in(RULES[name])} と {_defined_in(func)}）"
            )
        RULES[name] = func
        return func
    return decorator


def _defined_in(func: RuleFunc) -> str:
    """ルール関数を定義したファイル。重複の報告で、どこを直せばよいか示すため。"""
    code = getattr(func, "__code__", None)
    return code.co_filename if code is not None else repr(func)


def derived(meta: Dict[str, Any]) -> Dict[str, Any]:
    """ルールがテンプレートへ渡す値の置き場を返す (無ければ作る)。"""
    store = meta.get(DERIVED_KEY)
    if not isinstance(store, dict):
        store = {}
        meta[DERIVED_KEY] = store
    return store


#: ルールが出した警告の置き場 (``derived(meta)`` の中のキー)。
WARNINGS_KEY = "warnings"


def warn(meta: Dict[str, Any], message: str) -> None:
    """ルールから警告を出す。converter が変換結果の警告に混ぜる。"""
    derived(meta).setdefault(WARNINGS_KEY, []).append(message)


def take_warnings(meta: Dict[str, Any]) -> List[str]:
    """ルールが出した警告を取り出す (二重に数えないよう、取り出したら消す)。"""
    return derived(meta).pop(WARNINGS_KEY, [])


PrepareFunc = Callable[[str, Dict[str, Any]], str]

#: ルール名 → Markdown に通す前の本文を直す関数。``@prepare`` で登録される。
PREPARERS: Dict[str, PrepareFunc] = {}


def prepare(name: str) -> Callable[[PrepareFunc], PrepareFunc]:
    """ルール ``name`` を使う種類で、Markdown に通す前の本文を直す関数を登録するデコレータ。

    シグネチャは ``(body: str, meta: dict) -> str``。Markdown に崩される書き方
    （``\\\\server`` の ``\\``、行頭の ``#`` など）を、ルールが読める形で守るためのもの。
    """
    def decorator(func: PrepareFunc) -> PrepareFunc:
        if name in PREPARERS:
            raise RuleError(f"前処理の名前が重複しています: {name}")
        PREPARERS[name] = func
        return func
    return decorator


def prepare_text(names: Iterable[str], body: str, meta: Dict[str, Any]) -> str:
    """``names`` のルールのうち、前処理を持つものを順に本文に当てる。"""
    for name in names:
        func = PREPARERS.get(name)
        if func is None:
            continue
        try:
            body = func(body, meta)
        except RuleError:
            raise
        except Exception as e:
            raise RuleError(f"ルール '{name}' の前処理に失敗しました: {e}") from e
    return body


def unknown_rules(names: Iterable[str]) -> Set[str]:
    """未登録のルール名を返す。設定の検証用。"""
    return {name for name in names if name not in RULES}


def apply_rules(names: Iterable[str], soup: Any, meta: Dict[str, Any]) -> None:
    """``names`` のルールを順に適用する。未登録なら ``RuleError``。

    ルール内で落ちた場合も、どのルールが原因かを添えて ``RuleError`` にする
    （1 ファイルの失敗で一括変換全体が止まらないようにするため）。
    """
    for name in names:
        try:
            func = RULES[name]
        except KeyError:
            raise RuleError(f"未登録のルール: {name}") from None
        try:
            func(soup, meta)
        except RuleError:
            raise
        except Exception as e:
            raise RuleError(f"ルール '{name}' の適用に失敗しました: {e}") from e


def rule_descriptions() -> List[tuple]:
    """``(名前, 説明)`` の一覧を名前順で返す。``--list-rules`` 用。"""
    out = []
    for name in sorted(RULES):
        doc = (RULES[name].__doc__ or "").strip().splitlines()
        out.append((name, doc[0].strip() if doc else ""))
    return out


#: 読み込み済みのルールのファイル (解決済みのパス)。設定を読み直しても二重に登録しないため。
_LOADED_FILES: Set[Path] = set()


def load_rule_file(path: Path) -> None:
    """``rules/`` の外にあるルールのファイルを読み込み、``@rule`` を登録する。

    config.yaml の ``rule_modules:`` 用。同じファイルは 1 度しか読まない。
    読み込みに失敗したら、そのファイルが途中まで登録したルールを外して ``RuleError`` にする。
    """
    path = Path(path).resolve()
    if path in _LOADED_FILES:
        return
    if not path.is_file():
        raise RuleError(f"ルールのファイルが見つかりません: {path}")
    digest = hashlib.sha1(str(path).encode("utf-8")).hexdigest()[:12]
    module_name = f"_docmold_rule_module_{path.stem}_{digest}"
    spec = importlib.util.spec_from_file_location(module_name, path)
    if spec is None or spec.loader is None:
        raise RuleError(f"ルールのファイルを読み込めません: {path}")
    module = importlib.util.module_from_spec(spec)
    before, before_prepare = set(RULES), set(PREPARERS)
    sys.modules[module_name] = module
    try:
        spec.loader.exec_module(module)
    except Exception as e:
        sys.modules.pop(module_name, None)
        for name in set(RULES) - before:
            del RULES[name]
        for name in set(PREPARERS) - before_prepare:
            del PREPARERS[name]
        if isinstance(e, RuleError):
            raise
        raise RuleError(f"ルールのファイルを読み込めません: {path}: {e}") from e
    _LOADED_FILES.add(path)


#: ``rules/`` の読み込みで起きた問題。import の時点では止めず、設定を読むときに設定エラーにする。
#: import で落とすと、メニューやコマンドが Python のエラーの表示のまま終わるため。
_BUNDLED_ERRORS: List[str] = []


def _load_bundled() -> None:
    """``rules/`` の中のモジュールをすべて読み込む。ファイルを置くだけで登録されるようにするため。"""
    _BUNDLED_ERRORS.clear()
    for name in sorted(info.name for info in pkgutil.iter_modules(__path__)):
        before, before_prepare = set(RULES), set(PREPARERS)
        try:
            importlib.import_module(f"{__name__}.{name}")
        except Exception as e:
            # 途中まで登録したルールは外す (重なった名前が、どちらのものか曖昧にならないように)。
            for added in set(RULES) - before:
                del RULES[added]
            for added in set(PREPARERS) - before_prepare:
                del PREPARERS[added]
            if isinstance(e, RuleError):
                _BUNDLED_ERRORS.append(str(e))
            else:
                _BUNDLED_ERRORS.append(f"rules/{name}.py を読み込めません: {e}")


def check_bundled() -> None:
    """``rules/`` の読み込みで問題があれば ``RuleError`` にする。設定の読み込みの最初に呼ぶ。"""
    if _BUNDLED_ERRORS:
        raise RuleError(" / ".join(_BUNDLED_ERRORS))


# ルール関数の登録。import した時点で RULES が埋まる。
_load_bundled()
