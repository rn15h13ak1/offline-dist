r"""リンクを主にして、タグで絞り込むリンク集 (links) のルール。

1 つのリンクを箇条書きの 1 項目に書き、項目の中の行を字下げして続ける。行の中身で見分ける。

    ---
    type: links
    プロトコル: file                 ← フルパスからリンク先を作るときの頭（省くと file）
    タグ:
      部署: [営業, 開発, 総務]        ← 分類と値。分類ごとに絞り込みのプルダウンが出る
    ---

    ## 申請                           ← 任意のまとまり
    - 経費精算                        ← 1 行目は名前（1 行目がリンクなら名前を省ける）
      https://example.com/expense     ← URL の行
      \\fileserver\share\申請書.xlsx  ← フルパスの行
      部署: 総務                      ← タグの行（タグ: に定義した分類だけ）
      #よく使う                       ← 定義しない自由なタグ
      月末締め。                      ← ほかの行は補足（Markdown が効く）

リンクとタグの行は、Markdown に通す前に目印の文字に置き換え（:func:`protect`）、ルールが元の行に戻す。
Markdown は ``\\fileserver`` の ``\`` を 1 つ消し、``a_b_c`` の ``_`` を斜体にし、行頭の ``#`` を
見出しにするため。補足の行は Markdown に通す。

カードは変換のときに HTML に書いておき、テンプレートの JavaScript は見せる・隠すを切り替えるだけにする。
リンクが数千あっても、性能の低い端末で引っかからずに絞り込めるようにするため。
"""
from __future__ import annotations

import re
from typing import Any, Dict, List, Optional, Tuple
from urllib.parse import quote

from rules import derived, keywords, prepare, rule, warn
from rules.common import add_class

#: 既定のプロトコル（フルパスの行からリンク先を作るときの頭）。
DEFAULT_PROTOCOL = "file"

#: プロトコルに使えない名前。script が動くもの。
_SCRIPT_SCHEMES = ("javascript", "vbscript", "data")

_SCHEME_NAME_RE = re.compile(r"\A[A-Za-z][A-Za-z0-9+.-]*\Z")

#: URL の行。``<スキーム>://…`` か ``mailto:…`` で、空白を含まない。
_URL_RE = re.compile(r"\A(?:(?P<scheme>[A-Za-z][A-Za-z0-9+.-]*)://\S+|mailto:\S+)\Z")

#: フルパスの行。``\\server\…`` か ``C:\…``。パスは空白を含みうるので、行の残り全部をパスとみる。
_UNC_RE = re.compile(r"\A\\\\(?P<host>[^\\/\s]+)(?P<rest>(?:\\.*)?)\Z")
_DRIVE_RE = re.compile(r"\A(?P<drive>[A-Za-z]):\\(?P<rest>.*)\Z")

#: 自由なタグの行（``#よく使う #新着``）。``# 見出し`` のように ``#`` の後が空白なら見出しのまま。
_FREE_RE = re.compile(r"\A#[^\s#]+(?:\s+#[^\s#]+)*\Z")

#: タグの行の区切り（``部署: 総務``）。全角のコロンでも書ける。
_TAG_LINE_RE = re.compile(r"\A(?P<key>[^:\uff1a]+?)\s*[:\uff1a]\s*(?P<values>.+)\Z")

#: タグの値の区切り。
_VALUE_SEP_RE = re.compile(r"\s*[,\u3001\uff0c]\s*")

#: 箇条書きの項目の始まり（字下げ 3 文字まで）。
_ITEM_RE = re.compile(r"\A(?P<lead> {0,3}[-*+][ \t]+)(?P<text>.*)\Z")

#: 入れ子の箇条書き・番号付きの項目の始まり。項目の続きの行のうち、これは守らない。
_NESTED_RE = re.compile(r"\A\s*(?:[-*+]|\d+[.)])[ \t]+")

#: コードブロックの囲み。中は触らない。
_FENCE_RE = re.compile(r"\A[ ]{0,3}(`{3,}|~{3,})")

#: 目印の文字。Markdown が触らない英数字だけで作る。
_TOKEN = "DMLINKSLINE{}Q"
_TOKEN_RE = re.compile(r"\ADMLINKSLINE(\d+)Q\Z")

#: 前処理が守った行の置き場（``derived(meta)`` の中のキー）。
_LINES_KEY = "links_lines"


# ---------------------------------------------------------------- front matter


def _lookup(meta: Dict[str, Any], group: str) -> List[Tuple[str, Any]]:
    """キーの語の組に当たる ``(キー, 値)`` を、front matter の順に返す。"""
    names = set(keywords.get(group))
    return [(key, value) for key, value in meta.items() if key in names]


def protocol(meta: Dict[str, Any]) -> str:
    """``プロトコル:`` の名前。書いていなければ :data:`DEFAULT_PROTOCOL`。"""
    found = _lookup(meta, "links_protocol")
    if not found:
        return DEFAULT_PROTOCOL
    key, value = found[-1]
    text = str(value or "").strip()
    name = re.sub(r":(?://)?\Z", "", text)
    if not _SCHEME_NAME_RE.match(name) or name.lower() in _SCRIPT_SCHEMES:
        warn(meta, f"{key}: に使えない名前です: {text}（{DEFAULT_PROTOCOL} で作ります）")
        return DEFAULT_PROTOCOL
    return name


def tag_definitions(meta: Dict[str, Any]) -> Dict[str, List[str]]:
    """``タグ:`` の分類 → 値の並び。キーを複数書いていれば、後のものが分類ごとに勝つ。"""
    definitions: Dict[str, List[str]] = {}
    for key, value in _lookup(meta, "links_tags"):
        if not isinstance(value, dict):
            warn(meta, f"{key}: は「分類: [値, 値]」の並びで書きます")
            continue
        for name, values in value.items():
            name = str(name).strip()
            if isinstance(values, str):
                values = [v for v in _VALUE_SEP_RE.split(values.strip()) if v]
            elif not isinstance(values, list):
                warn(meta, f"{key}: の {name} は値の並びで書きます（例: {name}: [値, 値]）")
                continue
            seen: List[str] = []
            for item in values:
                text = str(item).strip()
                if text and text not in seen:
                    seen.append(text)
            definitions[name] = seen
    return definitions


# ---------------------------------------------------------------- 行の見分け


def link_of(line: str, scheme: str) -> Optional[Dict[str, str]]:
    r"""リンクの行なら ``{text, href, type}``（type は url・mail・path）。違えば None。

    - URL（``https://…`` ``<スキーム>://…`` ``mailto:…``）はそのまま
    - ``\\server\a\b`` → ``<プロトコル>://server/a/b``
    - ``C:\a\b`` → ``<プロトコル>:///C:/a/b``

    パスの ``\`` は ``/`` に変え、日本語・空白・``#`` などは ``%xx`` にする。
    """
    match = _URL_RE.match(line)
    if match:
        if (match.group("scheme") or "").lower() in _SCRIPT_SCHEMES:
            return None
        kind = "mail" if line.lower().startswith("mailto:") else "url"
        return {"text": line, "href": line, "type": kind}
    match = _UNC_RE.match(line)
    if match:
        rest = match.group("rest").replace("\\", "/")
        href = f"{scheme}://{quote(match.group('host'), safe='')}{quote(rest)}"
        return {"text": line, "href": href, "type": "path"}
    match = _DRIVE_RE.match(line)
    if match:
        rest = match.group("rest").replace("\\", "/")
        href = f"{scheme}:///{match.group('drive')}:/{quote(rest)}"
        return {"text": line, "href": href, "type": "path"}
    return None


def _script_url(line: str) -> bool:
    match = _URL_RE.match(line)
    return bool(match) and (match.group("scheme") or "").lower() in _SCRIPT_SCHEMES


def _kind_of(line: str, first: bool, names: Dict[str, List[str]],
             scheme: str) -> Optional[Dict[str, Any]]:
    """項目の 1 行が、守る行（リンク・タグ・自由なタグ）なら、その中身。名前と補足の行は None。"""
    link = link_of(line, scheme)
    if link is not None:
        return {"kind": "link", **link}
    if first:
        return None
    if _FREE_RE.match(line):
        return {"kind": "free", "tags": line.split()}
    match = _TAG_LINE_RE.match(line)
    if match and match.group("key").strip() in names:
        values = [v for v in _VALUE_SEP_RE.split(match.group("values").strip()) if v]
        return {"kind": "tag", "key": match.group("key").strip(), "values": values}
    return None


# ---------------------------------------------------------------- 前処理


@prepare("links")
def protect(body: str, meta: Dict[str, Any]) -> str:
    """箇条書きの項目の中の、リンク・タグの行を目印の文字に置き換える。

    置き換えた行の中身は ``derived(meta)`` に積み、:func:`links` が読む。コードブロックの中と、
    箇条書きの外の行は触らない。
    """
    names = tag_definitions(meta)
    scheme = protocol(meta)
    store: List[Dict[str, Any]] = []
    derived(meta)[_LINES_KEY] = store
    derived(meta)["links_tag_names"] = names

    out: List[str] = []
    fence = ""
    in_item = False
    for line in body.split("\n"):
        if fence:
            stripped = line.strip()
            if stripped.startswith(fence[0] * len(fence)) and not stripped.strip(fence[0]):
                fence = ""
            out.append(line)
            continue
        match = _FENCE_RE.match(line)
        if match:
            fence = match.group(1)
            out.append(line)
            continue

        item = _ITEM_RE.match(line)
        if item:
            in_item = True
            out.append(item.group("lead") + _guard(item.group("text"), True, names, scheme, store, meta))
            continue
        if not line.strip():
            out.append(line)
            continue
        if line[:1] not in (" ", "\t"):
            in_item = False
            out.append(line)
            continue
        if not in_item or _NESTED_RE.match(line):
            out.append(line)
            continue
        indent = line[:len(line) - len(line.lstrip())]
        out.append(indent + _guard(line.strip(), False, names, scheme, store, meta))
    return "\n".join(out)


def _guard(text: str, first: bool, names: Dict[str, List[str]], scheme: str,
           store: List[Dict[str, Any]], meta: Dict[str, Any]) -> str:
    """守る行なら目印に置き換える。違えばそのまま返す。"""
    stripped = text.strip()
    if _script_url(stripped):
        warn(meta, f"使えないリンクです（スキームが script を動かすもの）: {stripped}")
    found = _kind_of(stripped, first, names, scheme)
    if found is None:
        return text
    store.append(found)
    return _TOKEN.format(len(store) - 1)


# ---------------------------------------------------------------- ルール


@rule("links")
def links(soup: Any, meta: Dict[str, Any]) -> None:
    """箇条書きの項目をリンクのカードにし、タグの絞り込みに使う一覧を作る。"""
    store = derived(meta)
    lines: List[Dict[str, Any]] = store.pop(_LINES_KEY, [])
    names: Dict[str, List[str]] = store.pop("links_tag_names", None)
    if names is None:
        names = tag_definitions(meta)

    _flatten_sections(soup)
    box = soup.new_tag("div")
    add_class(box, "dm-links")
    box["id"] = "dm-links"
    target = box  # 今のまとまりの中身を入れる先
    grid = None
    rows: List[Dict[str, Any]] = []
    group_title = ""

    for node in list(soup.contents):
        name = getattr(node, "name", None)
        if name == "h2":
            section = soup.new_tag("section")
            add_class(section, "dm-links-group")
            node.extract()
            section.append(node)
            count = soup.new_tag("span")
            add_class(count, "dm-links-group__count")
            node.append(count)
            box.append(section)
            target, grid = section, None
            group_title = node.get_text(" ", strip=True)
            continue
        if name in ("ul", "ol"):
            node.extract()
            if grid is None:
                grid = soup.new_tag("div")
                add_class(grid, "dm-links-grid")
                target.append(grid)
            for item in node.find_all("li", recursive=False):
                card, row = _card(soup, item, lines, names, meta, group_title, len(rows))
                grid.append(card)
                rows.append(row)
            continue
        node.extract()
        if name is not None or str(node).strip():
            target.append(node)
            if name is not None:
                grid = None
    soup.append(box)

    used: Dict[str, List[str]] = {key: [] for key in names}
    for row in rows:
        for key, values in row["t"].items():
            used[key].extend(v for v in values if v not in used[key])
    store["links"] = {
        "tags": [{"name": key, "values": [v for v in values if v in used[key]]}
                 for key, values in names.items() if used[key]],
        "rows": rows,
    }


def _flatten_sections(soup: Any) -> None:
    """converter が見出しごとに包んだ ``<section>`` をほどく（まとまりはここで包み直す）。"""
    for section in soup.find_all("section"):
        if "dm-section" in (section.get("class") or []):
            section.unwrap()


def _item_lines(item: Any) -> Tuple[List[List[Any]], List[Any]]:
    """箇条書き 1 項目を、行ごとのノードの並びにする。入れ子の箇条書きは別に返す（補足に入れる）。

    段落（空行で区切った）の境目と、文字の中の改行で行を切る。
    """
    lines: List[List[Any]] = [[]]
    nested: List[Any] = []

    def push(nodes: List[Any]) -> None:
        for node in nodes:
            if getattr(node, "name", None) is None:
                parts = str(node).split("\n")
                for index, part in enumerate(parts):
                    if index:
                        lines.append([])
                    if not lines[-1]:
                        part = part.lstrip()  # 続きの行の字下げ
                    if part:
                        lines[-1].append(part)
            elif node.name == "br":
                lines.append([])
            else:
                lines[-1].append(node)

    for child in list(item.children):
        name = getattr(child, "name", None)
        if name in ("ul", "ol"):
            nested.append(child)
        elif name == "p":
            if lines[-1]:
                lines.append([])
            push(list(child.children))
            lines.append([])
        else:
            push([child])
    return [line for line in lines if _line_text(line).strip() or any(getattr(n, "name", None) for n in line)], nested


def _line_text(nodes: List[Any]) -> str:
    return "".join(node.get_text() if hasattr(node, "get_text") else str(node) for node in nodes)


def _card(soup: Any, item: Any, lines: List[Dict[str, Any]], names: Dict[str, List[str]],
          meta: Dict[str, Any], group: str, index: int) -> Tuple[Any, Dict[str, Any]]:
    """箇条書き 1 項目をカードにし、絞り込みに使う行を返す。"""
    item_lines, nested = _item_lines(item)
    title = ""
    links_found: List[Dict[str, str]] = []
    tags: Dict[str, List[str]] = {}
    free: List[str] = []
    notes: List[List[Any]] = []

    for number, nodes in enumerate(item_lines):
        text = _line_text(nodes).strip()
        match = _TOKEN_RE.match(text)
        found = lines[int(match.group(1))] if match and int(match.group(1)) < len(lines) else None
        if found is None:
            if number == 0:
                title = " ".join(text.split())
            else:
                notes.append(nodes)
            continue
        if found["kind"] == "link":
            links_found.append(found)
        elif found["kind"] == "free":
            free.extend(tag for tag in found["tags"] if tag not in free)
        else:
            key = found["key"]
            for value in found["values"]:
                if value in names.get(key, []):
                    bucket = tags.setdefault(key, [])
                    if value not in bucket:
                        bucket.append(value)
                else:
                    shown = f"{key}: {value}"
                    warn(meta, f"タグ「{shown}」は タグ: の {key} にありません"
                               f"（{_where(group, title, links_found)}。自由なタグとして出します）")
                    if shown not in free:
                        free.append(shown)

    if not title and links_found:
        title = _name_from(links_found[0])
    if not links_found:
        warn(meta, f"リンクの行がありません（{_where(group, title, links_found)}）")

    card = soup.new_tag("div")
    add_class(card, "dm-links-card")
    card["data-i"] = str(index)
    head = soup.new_tag("div")
    add_class(head, "dm-links-card__name")
    head.string = title or "（名前なし）"
    card.append(head)

    for link in links_found:
        line = soup.new_tag("div")
        add_class(line, "dm-links-card__link")
        kind = soup.new_tag("span")
        add_class(kind, "dm-links-card__kind")
        kind.string = {"path": "パス", "mail": "メール"}.get(link["type"], "URL")
        anchor = soup.new_tag("a", href=link["href"], title=link["href"], target="_blank", rel="noopener")
        anchor.string = link["text"]
        copy = soup.new_tag("button", type="button")
        add_class(copy, "dm-links-card__copy")
        copy["data-dm-links-copy"] = link["text"]
        copy.string = "コピー"
        line.extend([kind, anchor, copy])
        card.append(line)
    if not links_found:
        none = soup.new_tag("div")
        add_class(none, "dm-links-card__nolink")
        none.string = "（リンクなし）"
        card.append(none)

    if tags or free:
        box = soup.new_tag("div")
        add_class(box, "dm-links-card__tags")
        for key in names:
            for value in sorted(tags.get(key, []), key=names[key].index):
                tag = soup.new_tag("button", type="button")
                add_class(tag, "dm-links-tag")
                tag["data-k"], tag["data-v"] = key, value
                tag.string = f"{key}: {value}"
                box.append(tag)
        for value in free:
            tag = soup.new_tag("button", type="button")
            add_class(tag, "dm-links-tag", "dm-links-tag--free")
            tag["data-k"], tag["data-v"] = "#", value
            tag.string = value
            box.append(tag)
        card.append(box)

    if notes or nested:
        note = soup.new_tag("div")
        add_class(note, "dm-links-card__note")
        for number, nodes in enumerate(notes):
            if number:
                note.append(soup.new_tag("br"))
            for node in nodes:
                note.append(node.extract() if getattr(node, "name", None) else str(node))
        for block in nested:
            note.append(block.extract())
        card.append(note)

    # 値は、書いた順ではなく定義の順にそろえる（カードごとに並びが揺れないように）。
    ordered = {key: sorted(tags[key], key=names[key].index) for key in names if key in tags}
    return card, {"t": ordered, "f": free}


def _name_from(link: Dict[str, str]) -> str:
    """名前を省いた項目の名前。パスは最後の名前、URL とメールはそのまま。"""
    if link["type"] != "path":
        return link["text"][len("mailto:"):] if link["type"] == "mail" else link["text"]
    parts = [part for part in re.split(r"[\\/]", link["text"]) if part]
    return parts[-1] if parts else link["text"]


def _where(group: str, title: str, links_found: List[Dict[str, str]]) -> str:
    """警告に添える、項目の場所。"""
    name = title or (_name_from(links_found[0]) if links_found else "名前なし")
    return f"{group} の「{name}」" if group else f"「{name}」"

