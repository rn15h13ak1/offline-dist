r"""まとまり・段階・項目で引くリンク集 (catalog) のルール。

まとまり（案件・コースなど）ごとの .md に、段階の見出しと項目の箇条書きを書く。
親の .md が取り込み（include）でまとまりを束ねると、まとまりを横断して見られる。

    ## 要件定義                                          ← 段階
    - 要件定義書｜[\\srv\a.xlsx](file://srv/a.xlsx)｜補足  ← 項目（名前・リンク・補足）
    - 業務フロー｜来月から着手                           ← リンクの無い項目

取り込みで差し込まれた ``## まとまり`` と、子に書いた ``## 段階`` は同じ深さに並ぶ。
**取り込みの記録にある見出しをまとまり、それ以外の見出し 2 を直前のまとまりの段階**として読む。
子の見出しをずらさずに済み、子を単独で変換しても同じ書き方で読めるため。

ここでは本文を読み取って行の一覧にし、JavaScript の無い環境や印刷でも読める
並び（まとまり → 段階 → 項目）に組み直すだけ。見方の切り替えと絞り込みは、
テンプレートが行の一覧を読んで組み立てる。
"""
from __future__ import annotations

import re
from typing import Any, Dict, List, Optional, Tuple
from urllib.parse import unquote, urlsplit

from rules import derived, keywords, rule, warn
from rules.common import add_class, heading_level, normalize

#: 項目の欄の区切り。全角・半角の縦棒どちらでも書ける。
_SEPARATOR_RE = re.compile(r"[｜|]")

#: 表示するパスをリンク先から作らないスキーム（URL のまま見せる）。
_WEB_SCHEMES = ("http", "https", "mailto")

#: ドライブ文字で始まるパス（``/C:/...`` の先頭の ``/`` を含む）。
_DRIVE_RE = re.compile(r"\A/?[A-Za-z]:")

#: パスとして書いた表示（``\\srv\...`` ``C:\...``）。円記号（U+00A5）と全角の逆斜線で書いたものも含む。
_PATH_TEXT_RE = re.compile(r"\A(?:[\\\u00a5\uff3c]|[A-Za-z]:)")

#: 呼び名の既定と、``呼び名:`` の中で使えるキー。値は画面に出す名前。
NAME_KEYS: Dict[str, Tuple[str, ...]] = {
    "group": ("まとまり", "group"),
    "stage": ("段階", "stage"),
    "item": ("項目", "item"),
}

#: 見出しを最初から開いておく上限。超えたら畳み、開いたときに中身を描く。
OPEN_LIMIT = 20

#: 一覧表に並べる列（まとまり）の上限。人が見比べられる幅に収めるため。
COLUMN_LIMIT = 30

#: まとまり・段階の見出しの深さ。
SECTION_LEVEL = 2


@rule("catalog")
def catalog(soup: Any, meta: Dict[str, Any]) -> None:
    """段階の見出しと項目の箇条書きを読み取り、まとまり・段階・項目の一覧にする。"""
    names = _names(meta)
    store = derived(meta)
    group_titles = [normalize(entry["heading"]) for entry in store.get("includes") or []]

    _flatten_sections(soup)
    nodes = [node for node in soup.contents]

    groups: List[str] = []
    stages_seen: List[str] = []
    rows: List[Dict[str, Any]] = []
    intro: List[Any] = []
    seen_keys: set = set()
    dropped_text: List[str] = []

    group: Optional[str] = None
    stage: Optional[str] = None
    started = False
    standalone = not group_titles
    if standalone:
        group = _standalone_group(soup, meta, names)

    for node in nodes:
        name = getattr(node, "name", None)
        level = heading_level(node)
        if level:
            text = node.get_text(" ", strip=True)
            if level == SECTION_LEVEL and not standalone and normalize(text) in group_titles:
                group, stage, started = text, None, True
                if group not in groups:
                    groups.append(group)
            elif level == SECTION_LEVEL:
                started = True
                if group is None:
                    warn(meta, f"{names['group']}の外にある{names['stage']}は出しません: {text}")
                    stage = None
                else:
                    stage = text
                    if stage not in stages_seen:
                        stages_seen.append(stage)
            elif not started:
                # 最初の段階より前の見出し（文書の題など）は前置きとして残す
                intro.append(node)
            # それより深い見出しと、まとまりの中の見出し 1（子の題）は読まない
            continue

        if not started:
            intro.append(node)
            continue
        if name in ("ul", "ol"):
            if group is None or stage is None:
                for item in node.find_all("li", recursive=False):
                    label = _fields(item)[0]["text"]
                    warn(meta, f"{names['stage']}の見出しより前の{names['item']}は出しません: {label}")
                continue
            for item in node.find_all("li", recursive=False):
                row = _row(item, group, stage, meta, names)
                if row is None:
                    continue
                key = (group, stage, row["item"])
                if key in seen_keys:
                    warn(meta, f"同じ{names['item']}が 2 度あります: {group} / {stage} / {row['item']}")
                    continue
                seen_keys.add(key)
                rows.append(row)
        elif name is not None or str(node).strip():
            where = f"{group} / {stage}" if stage else (group or "")
            if where not in dropped_text:
                dropped_text.append(where)

    for where in dropped_text:
        warn(meta, f"箇条書き以外は出しません: {where}")
    if standalone and rows and group not in groups:
        groups.append(group)
    if not rows:
        warn(meta, f"{names['item']}がありません（「## {names['stage']}」の下に箇条書きで書きます）")

    stages = _order_stages(meta, names, stages_seen)

    soup.clear()
    for node in intro:
        soup.append(node)
    soup.append(_static_view(soup, groups, stages, rows))

    store["catalog"] = {
        "names": names,
        "groups": groups,
        "stages": stages,
        "rows": [
            {"g": groups.index(row["group"]), "s": stages.index(row["stage"]),
             "item": row["item"], "href": row["href"], "path": row["path"], "note": row["note"]}
            for row in rows
        ],
        "limits": {"open": OPEN_LIMIT, "columns": COLUMN_LIMIT},
    }


def _names(meta: Dict[str, Any]) -> Dict[str, str]:
    """画面に出す呼び名。``呼び名:`` に書いたものが既定を上書きする。"""
    names = {key: aliases[0] for key, aliases in NAME_KEYS.items()}
    value = _meta_value(meta, "catalog_names")
    if value is None:
        return names
    if not isinstance(value, dict):
        warn(meta, f"{keywords.get('catalog_names')[0]}: は「まとまり: 案件」のように書きます")
        return names
    for raw_key, raw_value in value.items():
        key = next((k for k, aliases in NAME_KEYS.items()
                    if normalize(str(raw_key)) in (normalize(a) for a in aliases)), None)
        if key is None:
            choices = "・".join(aliases[0] for aliases in NAME_KEYS.values())
            warn(meta, f"{keywords.get('catalog_names')[0]}: の '{raw_key}' は使えません（使えるもの: {choices}）")
            continue
        text = str(raw_value or "").strip()
        if text:
            names[key] = text
    return names


def _meta_value(meta: Dict[str, Any], group: str, extra: Tuple[str, ...] = ()) -> Any:
    """front matter から、検出語のグループ（と ``extra``）に一致するキーの値を返す。"""
    words = {normalize(word) for word in (*keywords.get(group), *extra)}
    for key, value in meta.items():
        if isinstance(key, str) and not key.startswith("_") and normalize(key) in words:
            return value
    return None


def _order_stages(meta: Dict[str, Any], names: Dict[str, str], seen: List[str]) -> List[str]:
    """段階の並び。front matter に並べた順を先にし、並べていないものは出てきた順で後ろに足す。

    並べたのに出てこない段階も残す（一覧表で「どのまとまりにも無い」ことがわかるように）。
    段階の呼び名（``局面:`` など）をキーにしても書ける。
    """
    value = _meta_value(meta, "catalog_stages", (names["stage"],))
    if value is None:
        return list(seen)
    if not isinstance(value, list):
        warn(meta, f"{keywords.get('catalog_stages')[0]}: は [要件定義, 基本設計] のように並べます")
        return list(seen)
    order = [str(stage).strip() for stage in value if str(stage or "").strip()]
    for stage in seen:
        if stage not in order:
            warn(meta, f"{names['stage']}「{stage}」は front matter の並びにありません（表記の揺れではありませんか）")
            order.append(stage)
    return order


def _standalone_group(soup: Any, meta: Dict[str, Any], names: Dict[str, str]) -> str:
    """取り込みを使わない（まとまり 1 つだけの）ファイルの、まとまりの名前。"""
    title = meta.get("title")
    if title:
        return str(title).strip()
    heading = soup.find("h1")
    if heading is not None:
        return heading.get_text(" ", strip=True)
    return names["group"]


def _flatten_sections(soup: Any) -> None:
    """converter が見出しごとに包んだ ``<section>`` をほどき、本文を平らな並びに戻す。"""
    for section in soup.find_all("section", recursive=False):
        if "dm-section" in (section.get("class") or []):
            section.unwrap()


def _line(item: Any) -> List[Any]:
    """箇条書き 1 項目の 1 行目の子。入れ子の箇条書きと 2 段落目以降は含めない。"""
    nodes: List[Any] = []
    for child in item.children:
        if getattr(child, "name", None) in ("ul", "ol"):
            continue
        if getattr(child, "name", None) == "p" and nodes and _text(nodes).strip():
            break  # 2 段落目以降は読まない
        nodes.append(child)
    return nodes


def _text(nodes: List[Any]) -> str:
    return "".join(node.get_text() if hasattr(node, "get_text") else str(node) for node in nodes)


def _fields(item: Any) -> List[Dict[str, Any]]:
    """箇条書き 1 項目の 1 行目を、``｜`` ``|`` で欄に分ける。

    区切りはリンク（``<a>``）の外の文字でだけ拾う。リンクの文字に縦棒があっても欄が切れないようにするため
    （Windows のファイル名には全角の ``｜`` を使える）。欄ごとに、文字（空白を詰めたもの）・中のリンク・
    リンクで始まるか・前の区切りの文字（補足を書いたまま戻すため）を持つ。
    """
    pieces: List[Tuple[str, Any]] = []  # (text | link | sep, 文字かリンク)

    def walk(nodes: List[Any]) -> None:
        for node in nodes:
            name = getattr(node, "name", None)
            if name == "a" and node.get("href"):
                pieces.append(("link", node))
            elif name is not None:
                walk(list(node.children))
            else:
                text = str(node)
                start = 0
                for match in _SEPARATOR_RE.finditer(text):
                    pieces.append(("text", text[start:match.start()]))
                    pieces.append(("sep", match.group()))
                    start = match.end()
                pieces.append(("text", text[start:]))

    walk(_line(item))
    fields: List[Dict[str, Any]] = [{"parts": [], "links": []}]
    for kind, value in pieces:
        if kind == "sep":
            fields.append({"parts": [], "links": [], "sep": value})
            continue
        field = fields[-1]
        if kind == "link":
            field["links"].append(value)
            field["parts"].append(("link", value.get_text()))
        else:
            field["parts"].append(("text", value))
    for field in fields:
        field["text"] = _squeeze("".join(text for _, text in field["parts"]))
        first = next((kind for kind, text in field["parts"] if kind == "link" or text.strip()), None)
        field["starts_with_link"] = first == "link"
    return fields


def _squeeze(text: str) -> str:
    return " ".join(text.split())


def _single_link(field: Dict[str, Any]) -> Optional[Any]:
    """欄がリンク 1 つだけなら、そのリンク。"""
    links = field["links"]
    if len(links) == 1 and field["text"] == _squeeze(links[0].get_text()):
        return links[0]
    return None


def _joined(fields: List[Dict[str, Any]]) -> str:
    """欄を、書いた区切りのまま 1 つの文字にする（補足に使う）。"""
    text = ""
    for index, field in enumerate(fields):
        if index:
            text += field["sep"]
        text += "".join(part for _, part in field["parts"])
    return _squeeze(text)


def _row(item: Any, group: str, stage: str, meta: Dict[str, Any],
         names: Dict[str, str]) -> Optional[Dict[str, Any]]:
    """箇条書き 1 項目を行にする。名前が空なら None。

    ``名前｜[表示](リンク先)｜補足`` と書く。2 つ目の欄がリンク 1 つだけなら、それを
    項目のリンクにする。前からの ``[名前](リンク先)｜補足`` も読む（名前の欄のリンク）。
    補足の中のリンクは項目のリンクにしない。画面に出すパスはリンク先から作る（:func:`display_path`）。
    名前の欄か 2 つ目の欄がリンクで始まるのに項目のリンクにならなければ（リンクを 2 つ書いたなど）、警告する。
    """
    fields = _fields(item)
    label = fields[0]["text"]
    if not label:
        return None
    href, note = "", _joined(fields[1:])
    name_link = _single_link(fields[0])
    second_link = _single_link(fields[1]) if len(fields) > 1 else None
    if name_link is not None:
        href = name_link["href"]
    elif second_link is not None:
        href = second_link["href"]
        note = _joined(fields[2:])
        _check_path_text(meta, names, label, fields[1]["text"], href)
    elif fields[0]["links"] or (len(fields) > 1 and fields[1]["starts_with_link"]):
        warn(meta, f"{names['item']}「{label}」のリンクを読めません"
                   f"（「名前｜[パス](リンク先)｜補足」のように、リンクは 1 つだけで 1 つの欄に書きます）")
    path = display_path(href) if href else ""
    return {"group": group, "stage": stage, "item": label, "href": href, "path": path, "note": note}


def display_path(href: str) -> str:
    r"""リンク先から、画面に出すパスを作る。

    - ``<スキーム>://server/a/b`` → ``\\server\a\b``（``file:`` も、OS に開かせる独自のスキームも同じ）
    - ``file:///C:/a/b`` → ``C:\a\b``
    - ``http:`` ``https:`` ``mailto:`` と相対パスは、そのまま（``%xx`` だけ戻す）

    ``[]`` の中に書いたパスを使わないのは、Markdown が ``\\`` を ``\`` に変えて
    UNC パスの先頭が崩れるため。スキームの名前は見ないので、環境ごとのスキームでも同じに出る。
    """
    parts = urlsplit(href)
    scheme = parts.scheme.lower()
    if not scheme or len(scheme) == 1 or scheme in _WEB_SCHEMES:
        return unquote(href)
    path = unquote(parts.path)
    if parts.netloc and parts.netloc.lower() != "localhost":
        return "\\\\" + parts.netloc + path.replace("/", "\\")
    if _DRIVE_RE.match(path):
        return path.lstrip("/").replace("/", "\\")
    return unquote(href)


def _check_path_text(meta: Dict[str, Any], names: Dict[str, str], label: str,
                     text: str, href: str) -> None:
    """``[]`` にパスを書いたのに、リンク先と食い違うなら警告する（片方だけ直したときに気付くため）。"""
    if not _PATH_TEXT_RE.match(text):
        return
    shown = display_path(href)
    if _same_path(text) != _same_path(shown):
        warn(meta, f"{names['item']}「{label}」の [] のパスとリンク先が違います（出すのはリンク先: {shown}）")


def _same_path(text: str) -> str:
    r"""比べるための形。円記号と全角の逆斜線を ``\`` にし、続く ``\`` を 1 つにまとめる
    （Markdown が ``\\`` を ``\`` に変えるため）。大小は区別しない。"""
    text = text.replace("\u00a5", "\\").replace("\uff3c", "\\").replace("/", "\\")
    return re.sub(r"\\+", r"\\", text).strip().casefold()


def _static_view(soup: Any, groups: List[str], stages: List[str],
                 rows: List[Dict[str, Any]]) -> Any:
    """JavaScript の無い環境と印刷で読む並び（まとまり → 段階 → 項目）。

    JavaScript が動けば、テンプレートの組み立てがこれを置き換える。
    """
    buckets: Dict[Tuple[str, str], List[Dict[str, Any]]] = {}
    for row in rows:
        buckets.setdefault((row["group"], row["stage"]), []).append(row)

    box = soup.new_tag("div")
    add_class(box, "dm-catalog")
    box["id"] = "dm-catalog"
    for group in groups:
        section = soup.new_tag("section")
        add_class(section, "dm-catalog__group")
        title = soup.new_tag("h2")
        title.string = group
        section.append(title)
        for stage in stages:
            mine = buckets.get((group, stage))
            if not mine:
                continue
            sub = soup.new_tag("h3")
            sub.string = stage
            section.append(sub)
            section.append(_item_list(soup, mine))
        box.append(section)
    return box


def _item_list(soup: Any, rows: List[Dict[str, Any]]) -> Any:
    items = soup.new_tag("ul")
    add_class(items, "dm-catalog__items")
    for row in rows:
        item = soup.new_tag("li")
        name = soup.new_tag("span")
        add_class(name, "dm-catalog__name" if row["href"] else "dm-catalog__nolink")
        name.string = row["item"]
        item.append(name)
        if row["note"]:
            note = soup.new_tag("span")
            add_class(note, "dm-catalog__note")
            note.string = row["note"]
            item.append(note)
        if row["href"]:
            # 項目の名前とリンクを分け、リンクはパスをそのまま見せる
            link = soup.new_tag("a", href=row["href"])
            add_class(link, "dm-catalog__path")
            link.string = row["path"]
            item.append(link)
        items.append(item)
    return items
