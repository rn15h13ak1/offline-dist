r"""まとまり・段階・項目で引くリンク集 (catalog) のルール。

まとまり（案件・コースなど）ごとの .md に、段階の見出しと項目の箇条書きを書く。
親の .md が取り込み（include）でまとまりを束ねると、まとまりを横断して見られる。

    ## 要件定義                                          ← 段階
    - 要件定義書｜[\\srv\a.xlsx](file://srv/a.xlsx)｜補足  ← 項目（名前・リンク・補足）
    - 業務フロー｜来月から着手                           ← リンクの無い項目

取り込みで差し込まれた ``## まとまり`` と、子に書いた ``## 段階`` は同じ深さに並ぶ。
**取り込みの記録にある見出しをまとまり、それ以外の見出し 2 を直前のまとまりの段階**として読む。
子の見出しをずらさずに済み、子を単独で変換しても同じ書き方で読めるため。

親の front matter の ``段: [案件, 工程, 区分, 資料]`` で、段の名前と数（2〜5 個）を決める（最初が取り込みの
単位、最後が項目）。2 段目を ``##``、3 段目を ``###`` と深くして書く。``段:`` が無ければ
``[まとまり, 段階, 項目]`` と書いたものとして、同じ処理で読む。

ここでは本文を読み取って行の一覧にし、JavaScript の無い環境や印刷でも読める
並び（段の順 → 項目）に組み直すだけ。見方の切り替えと絞り込みは、
テンプレートが行の一覧を読んで組み立てる。
"""
from __future__ import annotations

import re
from typing import Any, Dict, List, Optional, Tuple
from urllib.parse import unquote, urlsplit

from rules import derived, keywords, rule, warn
from rules.common import add_class, heading_level, normalize

#: 項目の欄の区切り。全角・半角の縦棒どちらでも書ける。
_SEPARATOR_RE = re.compile(r"[｜|]")

#: 表示するパスをリンク先から作らないスキーム（URL のまま見せる）。
_WEB_SCHEMES = ("http", "https", "mailto")

#: ドライブ文字で始まるパス（``/C:/...`` の先頭の ``/`` を含む）。
_DRIVE_RE = re.compile(r"\A/?[A-Za-z]:")

#: パスとして書いた表示（``\\srv\...`` ``C:\...``）。円記号（U+00A5）と全角の逆斜線で書いたものも含む。
_PATH_TEXT_RE = re.compile(r"\A(?:[\\\u00a5\uff3c]|[A-Za-z]:)")

#: ``段:`` を省いたときの段の並び。
DEFAULT_LEVELS = ("まとまり", "段階", "項目")

#: 前の版で読んでいた、段の名前のキーと並びのキー。今は読まないので、書いてあれば知らせる。
_RETIRED_NAME_KEYS = ("呼び名", "names")
_RETIRED_ORDER_KEYS = ("段階", "stages")

#: 見出しを最初から開いておく上限。超えたら畳み、開いたときに中身を描く。
OPEN_LIMIT = 20

#: 一覧表に並べる列（まとまり）の上限。人が見比べられる幅に収めるため。
COLUMN_LIMIT = 30

#: まとまり・段階の見出しの深さ。段を増やしたときは、2 段目がこの深さで、以降 1 つずつ深くなる。
SECTION_LEVEL = 2

#: ``段:`` に書ける段の数。1 段は束ねる単位が無く、6 段以上はタブと絞り込みの帯が読みにくくなるため。
MIN_LEVELS = 2
MAX_LEVELS = 5


@rule("catalog")
def catalog(soup: Any, meta: Dict[str, Any]) -> None:
    """見出しと項目の箇条書きを読み取り、段ごとの値と項目の一覧にする。"""
    # 上から順の段の名前。最後が項目。
    level_names = _levels(meta)
    _warn_ignored_keys(meta, level_names)
    item_name = level_names[-1]
    uppers = len(level_names) - 1  # 項目より上の段の数
    deepest = SECTION_LEVEL + uppers - 2  # 読む見出しの一番深いところ（2 段なら読む見出しは無い）

    store = derived(meta)
    group_titles = [normalize(entry["heading"]) for entry in store.get("includes") or []]

    _flatten_sections(soup)
    nodes = [node for node in soup.contents]

    # 段ごとの、出てきた順の値。最上段は取り込みの順。
    seen: List[List[str]] = [[] for _ in range(uppers)]
    rows: List[Dict[str, Any]] = []
    intro: List[Any] = []
    seen_keys: set = set()
    dropped_text: List[str] = []

    # 今いる場所。段ごとの見出しの文字で、まだ無ければ None。
    path: List[Optional[str]] = [None] * uppers
    started = False
    standalone = not group_titles
    if standalone:
        path[0] = _standalone_group(soup, meta, level_names[0])

    for node in nodes:
        name = getattr(node, "name", None)
        level = heading_level(node)
        if level:
            text = node.get_text(" ", strip=True)
            index = level - SECTION_LEVEL + 1  # この見出しが表す段
            if level == SECTION_LEVEL and not standalone and normalize(text) in group_titles:
                path = [text] + [None] * (uppers - 1)
                started = True
                if text not in seen[0]:
                    seen[0].append(text)
            elif SECTION_LEVEL <= level <= deepest and (started or level == SECTION_LEVEL):
                started = True
                path[index:] = [None] * (uppers - index)
                if path[0] is None:
                    warn(meta, f"{level_names[0]}の外にある{level_names[index]}は出しません: {text}")
                else:
                    path[index] = text
                    if None not in path[:index] and text not in seen[index]:
                        seen[index].append(text)
            elif not started:
                # 最初の段より前の見出し（文書の題など）は前置きとして残す
                intro.append(node)
            elif level > deepest and level >= SECTION_LEVEL:
                warn(meta, f"段より深い見出しは読みません: {text}")
            # 最上段の中の見出し 1（子の題）は読まない
            continue

        if name in ("ul", "ol") and uppers == 1 and standalone:
            started = True  # 2 段のファイルだけのときは、読む見出しが無いので最初の箇条書きから
        if not started:
            intro.append(node)
            continue
        if name in ("ul", "ol"):
            missing = next((i for i in range(1, uppers) if path[i] is None), 0 if path[0] is None else None)
            if missing is not None:
                for item in node.find_all("li", recursive=False):
                    label = _fields(item)[0]["text"]
                    warn(meta, f"{level_names[missing]}の見出しより前の{item_name}は出しません: {label}")
                continue
            for item in node.find_all("li", recursive=False):
                row = _row(item, list(path), meta, item_name)
                if row is None:
                    continue
                key = (*path, row["item"])
                if key in seen_keys:
                    warn(meta, f"同じ{item_name}が 2 度あります: {' / '.join(key)}")
                    continue
                seen_keys.add(key)
                rows.append(row)
        elif name is not None or str(node).strip():
            where = " / ".join(part for part in path if part)
            if where not in dropped_text:
                dropped_text.append(where)

    for where in dropped_text:
        warn(meta, f"箇条書き以外は出しません: {where}")
    if standalone and rows and path[0] not in seen[0]:
        seen[0].append(path[0])
    if not rows:
        warn(meta, f"{item_name}がありません（{_where_to_write(level_names)}箇条書きで書きます）")

    values = [seen[0]]
    for index in range(1, uppers):
        values.append(_order_level(meta, level_names[index], seen[index]))

    soup.clear()
    for node in intro:
        soup.append(node)
    soup.append(_static_view(soup, values, rows))

    numbered = [[values[i].index(part) for i, part in enumerate(row["levels"])] for row in rows]
    store["catalog"] = {
        "levels": [{"name": n, "values": v} for n, v in zip(level_names, values)],
        "item": item_name,
        "rows": [
            {"l": l, "item": row["item"], "href": row["href"], "path": row["path"], "note": row["note"]}
            for l, row in zip(numbered, rows)
        ],
        "limits": {"open": OPEN_LIMIT, "columns": COLUMN_LIMIT},
    }


def _levels(meta: Dict[str, Any]) -> List[str]:
    """``段:`` に書いた段の並び。無いか、読めなければ既定の 3 段。"""
    value = _meta_value(meta, "catalog_levels")
    if value is None:
        return list(DEFAULT_LEVELS)
    key = keywords.get("catalog_levels")[0]
    if not isinstance(value, list):
        warn(meta, f"{key}: は [案件, 工程, 資料] のように並べます（3 段として読みます）")
        return list(DEFAULT_LEVELS)
    levels = [str(level).strip() for level in value if str(level or "").strip()]
    if not MIN_LEVELS <= len(levels) <= MAX_LEVELS:
        warn(meta, f"{key}: は {MIN_LEVELS} から {MAX_LEVELS} 個で書きます"
                   f"（{len(levels)} 個あります。3 段として読みます）")
        return list(DEFAULT_LEVELS)
    twice = [level for index, level in enumerate(levels) if level in levels[:index]]
    if twice:
        warn(meta, f"{key}: に同じ名前が 2 度あります: {twice[0]}（3 段として読みます）")
        return list(DEFAULT_LEVELS)
    return levels


def _warn_ignored_keys(meta: Dict[str, Any], level_names: List[str]) -> None:
    """書いても読まないキーを知らせる（黙って効かないと気付けないため）。

    段の名前と同じキーは、その段の並びとして読むので知らせない（既定の 3 段の ``段階:`` など）。
    """
    key = keywords.get("catalog_levels")[0]
    named = {normalize(name) for name in level_names}
    retired = (
        (_RETIRED_NAME_KEYS, f"段の名前は {key}: [案件, 局面, 作成物] のように書きます"),
        (_RETIRED_ORDER_KEYS, "並びは段の名前をキーにして書きます"),
    )
    for words, how in retired:
        for raw in meta:
            if isinstance(raw, str) and normalize(raw) in words and normalize(raw) not in named:
                warn(meta, f"{raw}: は読みません（{how}）")
    for name, why in ((level_names[0], "取り込みの順に並びます"), (level_names[-1], "出てきた順に並びます")):
        if _meta_value(meta, None, (name,)) is not None:
            warn(meta, f"{name}: の並びは読みません（{why}）")


def _where_to_write(level_names: List[str]) -> str:
    """項目を書く場所の案内。「## 段階」の下に、のように見出しの深さを見せる。"""
    headings = [f"「{'#' * (SECTION_LEVEL + i)} {name}」" for i, name in enumerate(level_names[1:-1])]
    return f"{''.join(headings)}の下に" if headings else ""


def _meta_value(meta: Dict[str, Any], group: Optional[str], extra: Tuple[str, ...] = ()) -> Any:
    """front matter から、検出語のグループ（と ``extra``）に一致するキーの値を返す。"""
    words = {normalize(word) for word in (*(keywords.get(group) if group else ()), *extra)}
    for key, value in meta.items():
        if isinstance(key, str) and not key.startswith("_") and normalize(key) in words:
            return value
    return None


def _order_level(meta: Dict[str, Any], name: str, seen: List[str]) -> List[str]:
    """段の値の並び。front matter に並べた順を先にし、並べていないものは出てきた順で後ろに足す。

    並べたのに出てこない値も残す（一覧表で「どのまとまりにも無い」ことがわかるように）。
    段の名前（``局面:`` など）をキーにして書く。
    """
    value = _meta_value(meta, None, (name,))
    if value is None:
        return list(seen)
    if not isinstance(value, list):
        warn(meta, f"{name}: は [要件定義, 基本設計] のように並べます")
        return list(seen)
    order = [str(part).strip() for part in value if str(part or "").strip()]
    for part in seen:
        if part not in order:
            warn(meta, f"{name}「{part}」は front matter の並びにありません（表記の揺れではありませんか）")
            order.append(part)
    return order


def _standalone_group(soup: Any, meta: Dict[str, Any], name: str) -> str:
    """取り込みを使わない（まとまり 1 つだけの）ファイルの、まとまりの名前。"""
    title = meta.get("title")
    if title:
        return str(title).strip()
    heading = soup.find("h1")
    if heading is not None:
        return heading.get_text(" ", strip=True)
    return name


def _flatten_sections(soup: Any) -> None:
    """converter が見出しごとに包んだ ``<section>`` をほどき、本文を平らな並びに戻す。"""
    for section in soup.find_all("section", recursive=False):
        if "dm-section" in (section.get("class") or []):
            section.unwrap()


def _line(item: Any) -> List[Any]:
    """箇条書き 1 項目の 1 行目の子。入れ子の箇条書きと 2 段落目以降は含めない。"""
    nodes: List[Any] = []
    for child in item.children:
        if getattr(child, "name", None) in ("ul", "ol"):
            continue
        if getattr(child, "name", None) == "p" and nodes and _text(nodes).strip():
            break  # 2 段落目以降は読まない
        nodes.append(child)
    return nodes


def _text(nodes: List[Any]) -> str:
    return "".join(node.get_text() if hasattr(node, "get_text") else str(node) for node in nodes)


def _fields(item: Any) -> List[Dict[str, Any]]:
    """箇条書き 1 項目の 1 行目を、``｜`` ``|`` で欄に分ける。

    区切りはリンク（``<a>``）の外の文字でだけ拾う。リンクの文字に縦棒があっても欄が切れないようにするため
    （Windows のファイル名には全角の ``｜`` を使える）。欄ごとに、文字（空白を詰めたもの）・中のリンク・
    リンクで始まるか・前の区切りの文字（補足を書いたまま戻すため）を持つ。
    """
    pieces: List[Tuple[str, Any]] = []  # (text | link | sep, 文字かリンク)

    def walk(nodes: List[Any]) -> None:
        for node in nodes:
            name = getattr(node, "name", None)
            if name == "a" and node.get("href"):
                pieces.append(("link", node))
            elif name is not None:
                walk(list(node.children))
            else:
                text = str(node)
                start = 0
                for match in _SEPARATOR_RE.finditer(text):
                    pieces.append(("text", text[start:match.start()]))
                    pieces.append(("sep", match.group()))
                    start = match.end()
                pieces.append(("text", text[start:]))

    walk(_line(item))
    fields: List[Dict[str, Any]] = [{"parts": [], "links": []}]
    for kind, value in pieces:
        if kind == "sep":
            fields.append({"parts": [], "links": [], "sep": value})
            continue
        field = fields[-1]
        if kind == "link":
            field["links"].append(value)
            field["parts"].append(("link", value.get_text()))
        else:
            field["parts"].append(("text", value))
    for field in fields:
        field["text"] = _squeeze("".join(text for _, text in field["parts"]))
        first = next((kind for kind, text in field["parts"] if kind == "link" or text.strip()), None)
        field["starts_with_link"] = first == "link"
    return fields


def _squeeze(text: str) -> str:
    return " ".join(text.split())


def _single_link(field: Dict[str, Any]) -> Optional[Any]:
    """欄がリンク 1 つだけなら、そのリンク。"""
    links = field["links"]
    if len(links) == 1 and field["text"] == _squeeze(links[0].get_text()):
        return links[0]
    return None


def _joined(fields: List[Dict[str, Any]]) -> str:
    """欄を、書いた区切りのまま 1 つの文字にする（補足に使う）。"""
    text = ""
    for index, field in enumerate(fields):
        if index:
            text += field["sep"]
        text += "".join(part for _, part in field["parts"])
    return _squeeze(text)


def _row(item: Any, levels: List[str], meta: Dict[str, Any], item_name: str) -> Optional[Dict[str, Any]]:
    """箇条書き 1 項目を行にする。名前が空なら None。

    ``名前｜[表示](リンク先)｜補足`` と書く。2 つ目の欄がリンク 1 つだけなら、それを
    項目のリンクにする。前からの ``[名前](リンク先)｜補足`` も読む（名前の欄のリンク）。
    補足の中のリンクは項目のリンクにしない。画面に出すパスはリンク先から作る（:func:`display_path`）。
    名前の欄か 2 つ目の欄がリンクで始まるのに項目のリンクにならなければ（リンクを 2 つ書いたなど）、警告する。
    """
    fields = _fields(item)
    label = fields[0]["text"]
    if not label:
        return None
    href, note = "", _joined(fields[1:])
    name_link = _single_link(fields[0])
    second_link = _single_link(fields[1]) if len(fields) > 1 else None
    if name_link is not None:
        href = name_link["href"]
    elif second_link is not None:
        href = second_link["href"]
        note = _joined(fields[2:])
        _check_path_text(meta, item_name, label, fields[1]["text"], href)
    elif fields[0]["links"] or (len(fields) > 1 and fields[1]["starts_with_link"]):
        warn(meta, f"{item_name}「{label}」のリンクを読めません"
                   f"（「名前｜[パス](リンク先)｜補足」のように、リンクは 1 つだけで 1 つの欄に書きます）")
    path = display_path(href) if href else ""
    return {"levels": levels, "item": label, "href": href, "path": path, "note": note}


def display_path(href: str) -> str:
    r"""リンク先から、画面に出すパスを作る。

    - ``<スキーム>://server/a/b`` → ``\\server\a\b``（``file:`` も、OS に開かせる独自のスキームも同じ）
    - ``file:///C:/a/b`` → ``C:\a\b``
    - ``http:`` ``https:`` ``mailto:`` と相対パスは、そのまま（``%xx`` だけ戻す）

    ``[]`` の中に書いたパスを使わないのは、Markdown が ``\\`` を ``\`` に変えて
    UNC パスの先頭が崩れるため。スキームの名前は見ないので、環境ごとのスキームでも同じに出る。
    """
    parts = urlsplit(href)
    scheme = parts.scheme.lower()
    if not scheme or len(scheme) == 1 or scheme in _WEB_SCHEMES:
        return unquote(href)
    path = unquote(parts.path)
    if parts.netloc and parts.netloc.lower() != "localhost":
        return "\\\\" + parts.netloc + path.replace("/", "\\")
    if _DRIVE_RE.match(path):
        return path.lstrip("/").replace("/", "\\")
    return unquote(href)


def _check_path_text(meta: Dict[str, Any], item_name: str, label: str,
                     text: str, href: str) -> None:
    """``[]`` にパスを書いたのに、リンク先と食い違うなら警告する（片方だけ直したときに気付くため）。"""
    if not _PATH_TEXT_RE.match(text):
        return
    shown = display_path(href)
    if _same_path(text) != _same_path(shown):
        warn(meta, f"{item_name}「{label}」の [] のパスとリンク先が違います（出すのはリンク先: {shown}）")


def _same_path(text: str) -> str:
    r"""比べるための形。円記号と全角の逆斜線を ``\`` にし、続く ``\`` を 1 つにまとめる
    （Markdown が ``\\`` を ``\`` に変えるため）。大小は区別しない。"""
    text = text.replace("\u00a5", "\\").replace("\uff3c", "\\").replace("/", "\\")
    return re.sub(r"\\+", r"\\", text).strip().casefold()


def _static_view(soup: Any, values: List[List[str]], rows: List[Dict[str, Any]]) -> Any:
    """JavaScript の無い環境と印刷で読む並び（段の順 → 項目。段の数だけ見出しを深くする）。

    JavaScript が動けば、テンプレートの組み立てがこれを置き換える。
    """
    box = soup.new_tag("div")
    add_class(box, "dm-catalog")
    box["id"] = "dm-catalog"
    for top in values[0]:
        section = soup.new_tag("section")
        add_class(section, "dm-catalog__group")
        title = soup.new_tag("h2")
        title.string = top
        section.append(title)
        _fill_level(soup, section, values, [row for row in rows if row["levels"][0] == top], 1)
        box.append(section)
    return box


def _fill_level(soup: Any, parent: Any, values: List[List[str]], rows: List[Dict[str, Any]], depth: int) -> None:
    """``depth`` 番目の段の見出しと、その下を足す。段が尽きたら項目の箇条書きにする。"""
    if depth == len(values):
        if rows:
            parent.append(_item_list(soup, rows))
        return
    for value in values[depth]:
        mine = [row for row in rows if row["levels"][depth] == value]
        if not mine:
            continue
        sub = soup.new_tag(f"h{depth + SECTION_LEVEL}")
        sub.string = value
        parent.append(sub)
        _fill_level(soup, parent, values, mine, depth + 1)


def _item_list(soup: Any, rows: List[Dict[str, Any]]) -> Any:
    items = soup.new_tag("ul")
    add_class(items, "dm-catalog__items")
    for row in rows:
        item = soup.new_tag("li")
        name = soup.new_tag("span")
        add_class(name, "dm-catalog__name" if row["href"] else "dm-catalog__nolink")
        name.string = row["item"]
        item.append(name)
        if row["note"]:
            note = soup.new_tag("span")
            add_class(note, "dm-catalog__note")
            note.string = row["note"]
            item.append(note)
        if row["href"]:
            # 項目の名前とリンクを分け、リンクはパスをそのまま見せる
            link = soup.new_tag("a", href=row["href"])
            add_class(link, "dm-catalog__path")
            link.string = row["path"]
            item.append(link)
        items.append(item)
    return items
