"""複数の担当が関わる業務の手順 (process) のルール。

グループを見出し 2、作業を見出し 3 で、上から作業の順に書く。作業の節の最初の箇条書きに、
担当と、更新する台帳（Excel など）の項目を書く。

    ## 審査                                          ← グループ
    ### 与信を承認する                               ← 作業
    - 担当: 審査                                      ← 複数なら「経理, 営業」
    - 更新: 与信管理表 / 与信上限, 承認者            ← 台帳 / 項目, 項目
    - 更新: 取引先台帳 / 状態=審査済                 ← 項目=値 で書き込む値も書ける

front matter の ``担当:`` に担当の並び、``台帳:`` に台帳ごとの項目（列）の並びを書く。
見出しの頭の ``[x]``（``## [x] 審査`` ``### [x] 与信を承認する``）は、初めから付いているチェック。
開いた HTML から保存した Markdown は、この形でチェックを書き戻す。

ここでは本文を読み取り、JavaScript の無い環境や印刷でも読める並び（グループ → 作業、
台帳ごとの更新表）に組み直すだけ。担当での絞り込み・チェック・記入状況・未実施のまとめは、
テンプレートが作業の一覧を読んで組み立てる。
"""
from __future__ import annotations

import re
from typing import Any, Dict, List, Optional, Tuple

from rules import derived, keywords, rule, warn
from rules.common import add_class, heading_level, normalize

#: グループ・作業の見出しの深さ。
GROUP_LEVEL = 2
TASK_LEVEL = 3

#: 担当の色の数。超えたら最初の色に戻る（テーマの CSS が --0 から順に色を持つ）。
OWNER_COLORS = 6

#: 更新表の列の幅（字数）。項目名と値の長いほうに合わせ、この範囲に収める。
GRID_MIN_CHARS = 3
GRID_MAX_CHARS = 8

#: 担当・項目の区切り。全角の読点・カンマでも書ける。
_LIST_SEP_RE = re.compile(r"[,，、]")

#: 台帳と項目の区切り。
_BOOK_SEP_RE = re.compile(r"[/／]")

#: 項目と値の区切り。
_VALUE_SEP_RE = re.compile(r"[=＝]")

#: 箇条書きの行の頭のキー（``担当:`` など）。
_FIELD_RE = re.compile(r"\A\s*([^:：]+?)\s*[:：]\s*(.*)\Z", re.S)

#: 見出しの頭のチェック（``[x]`` は付いている、``[ ]`` は付いていない）。
_CHECK_RE = re.compile(r"\A\[([ xX])\][ \t]*")

#: 原文の ATX 見出し（``## 題``）。字下げは 3 文字まで、閉じの ``#`` は題に含めない。
_ATX_RE = re.compile(r"\A {0,3}(#{1,6})(?:[ \t]+(.*?))?(?:[ \t]+#+)?[ \t]*\r?\Z")

#: 原文のコードブロックの柵。
_FENCE_RE = re.compile(r"\A {0,3}(`{3,}|~{3,})")

#: グループの見出しより前に書いた作業を入れるグループの名前。
LOOSE_GROUP = "（グループなし）"


@rule("process")
def process(soup: Any, meta: Dict[str, Any]) -> None:
    """グループ・作業・担当・更新する台帳の項目を読み取り、絞り込みとチェックの元にする。"""
    owners = _owners_from_meta(meta)
    books, books_given = _books_from_meta(meta)
    owners_given = bool(owners)

    _flatten_sections(soup)
    intro: List[Any] = []
    groups: List[Dict[str, Any]] = []
    group: Optional[Dict[str, Any]] = None
    task: Optional[Dict[str, Any]] = None

    for node in list(soup.contents):
        level = heading_level(node)
        if level == GROUP_LEVEL:
            name, done = _checked(node.get_text(" ", strip=True))
            group = {"name": name, "done": done, "intro": [], "tasks": []}
            groups.append(group)
            task = None
            continue
        if level == TASK_LEVEL:
            title, done = _checked(node.get_text(" ", strip=True))
            if group is None:
                warn(meta, f"グループ（見出し 2）より前の作業は「{LOOSE_GROUP}」にまとめます: {title}")
                group = {"name": LOOSE_GROUP, "done": False, "loose": True, "intro": [], "tasks": []}
                groups.append(group)
            task = {"title": title, "done": done, "body": [], "owners": [], "updates": []}
            group["tasks"].append(task)
            continue
        if task is not None:
            task["body"].append(node)
        elif group is not None:
            group["intro"].append(node)
        else:
            intro.append(node)

    tasks: List[Dict[str, Any]] = []
    for gi, group in enumerate(groups, start=1):
        if not group["tasks"]:
            warn(meta, f"作業（見出し 3）の無いグループがあります: {group['name']}")
        for ti, task in enumerate(group["tasks"], start=1):
            task["no"] = f"{gi}-{ti}"
            task["id"] = f"dm-task-{gi}-{ti}"
            task["group"] = gi - 1
            _read_fields(task, meta)
            for name in task["owners"]:
                if name not in owners:
                    if owners_given:
                        warn(meta, f"front matter の担当に無い担当です: {name}（作業 {task['no']} {task['title']}）")
                    owners.append(name)
            for update in task["updates"]:
                _check_update(update, task, books, books_given, meta)
            tasks.append(task)
    if not tasks:
        warn(meta, "作業がありません（「## グループ」の下に「### 作業」で書きます）")

    soup.clear()
    for node in intro:
        soup.append(node)
    soup.append(_static_view(soup, groups, owners, books))

    store = derived(meta)
    store["process"] = {
        "owners": owners,
        "books": [{"name": name, "cols": cols} for name, cols in books.items()],
        "groups": [{"name": group["name"], "id": f"dm-group-{gi}", "closed": group["done"]}
                   for gi, group in enumerate(groups, start=1)],
        "source": _source(store.get("source"), groups, meta) if tasks else None,
        "tasks": [
            {"id": task["id"], "no": task["no"], "g": task["group"], "title": task["title"], "done": task["done"],
             "owners": [owners.index(name) for name in task["owners"]],
             "updates": [{"book": update["book"], "cols": [[col, value] for col, value in update["cols"]]}
                         for update in task["updates"]]}
            for task in tasks
        ],
    }


def _checked(text: str) -> Tuple[str, bool]:
    """見出しの頭の ``[x]`` ``[ ]`` を外し、(題, チェックが付いているか) を返す。"""
    match = _CHECK_RE.match(text)
    if not match:
        return text, False
    return text[match.end():].strip(), match.group(1) != " "


def _source(source: Optional[Dict[str, Any]], groups: List[Dict[str, Any]],
            meta: Dict[str, Any]) -> Optional[Dict[str, Any]]:
    """原文と、グループ・作業の見出しの行の番号。開いた HTML がチェックを書き戻した Markdown を作るため。

    原文の見出し 2・3 を上から拾い、本文の見出しと順に突き合わせる。数か題が合わなければ
    （取り込み・下線の見出し・HTML で書いた見出しなど）、書き戻す行を決められないので渡さない。
    """
    if not source:
        return None
    found = _source_headings(source["text"], source["body_line"])
    expected = []
    for group in groups:
        if not group.get("loose"):
            expected.append((GROUP_LEVEL, group["name"]))
        expected.extend((TASK_LEVEL, task["title"]) for task in group["tasks"])
    if [(level, normalize(title)) for level, title, _ in found] != [(level, normalize(title)) for level, title in expected]:
        warn(meta, "見出しを原文の行と突き合わせられないため、Markdown の保存は使えません"
                   "（取り込み・下線の見出し・HTML の見出しを使わず、「## 」「### 」で書きます）")
        return None
    return {"text": source["text"], "name": source["name"],
            **_assign_lines(groups, [line for _, _, line in found])}


def _assign_lines(groups: List[Dict[str, Any]], lines: List[int]) -> Dict[str, List[Optional[int]]]:
    """突き合わせた行を、グループと作業に順に割り当てる。"""
    rest = iter(lines)
    group_lines: List[Optional[int]] = []
    task_lines: List[int] = []
    for group in groups:
        group_lines.append(None if group.get("loose") else next(rest))
        task_lines.extend(next(rest) for _ in group["tasks"])
    return {"groups": group_lines, "tasks": task_lines}


def _source_headings(text: str, body_line: int) -> List[Tuple[int, str, int]]:
    """原文の本文から、見出し 2・3 を (深さ, 題, 行の番号) で拾う。コードブロックの中は見ない。"""
    found: List[Tuple[int, str, int]] = []
    fence = ""
    for index, line in enumerate(text.split("\n")):
        if index < body_line:
            continue
        mark = _FENCE_RE.match(line)
        if fence:
            if mark and mark.group(1)[0] == fence[0] and len(mark.group(1)) >= len(fence):
                fence = ""
            continue
        if mark:
            fence = mark.group(1)
            continue
        match = _ATX_RE.match(line)
        if match and len(match.group(1)) in (GROUP_LEVEL, TASK_LEVEL):
            found.append((len(match.group(1)), _checked(_squeeze(match.group(2) or ""))[0], index))
    return found


# ---- front matter -----------------------------------------------------------

def _meta_value(meta: Dict[str, Any], group: str) -> Any:
    """front matter から、検出語のグループに一致するキーの値を返す。"""
    words = {normalize(word) for word in keywords.get(group)}
    for key, value in meta.items():
        if isinstance(key, str) and not key.startswith("_") and normalize(key) in words:
            return value
    return None


def _owners_from_meta(meta: Dict[str, Any]) -> List[str]:
    """``担当:`` に並べた担当。帯のボタンと色の順になる。"""
    value = _meta_value(meta, "process_owner")
    if value is None:
        return []
    if isinstance(value, str):
        value = _split(value)
    if not isinstance(value, list):
        warn(meta, f"{keywords.get('process_owner')[0]}: は [営業, 経理] のように並べます")
        return []
    owners: List[str] = []
    for name in value:
        text = str(name or "").strip()
        if text and text not in owners:
            owners.append(text)
    return owners


def _books_from_meta(meta: Dict[str, Any]) -> Tuple[Dict[str, List[str]], bool]:
    """``台帳:`` に書いた台帳ごとの項目（列）の並び。書いていなければ空で、作業から集める。"""
    value = _meta_value(meta, "process_book")
    if value is None:
        return {}, False
    key = keywords.get("process_book")[0]
    if not isinstance(value, dict):
        warn(meta, f"{key}: は「台帳の名前: [項目, 項目]」の並びで書きます")
        return {}, False
    books: Dict[str, List[str]] = {}
    for raw_name, raw_cols in value.items():
        name = str(raw_name).strip()
        if isinstance(raw_cols, str):
            raw_cols = _split(raw_cols)
        if raw_cols is None:
            raw_cols = []
        if not isinstance(raw_cols, list):
            warn(meta, f"{key}: の {name} は [項目, 項目] のように並べます")
            raw_cols = []
        cols: List[str] = []
        for col in raw_cols:
            text = str(col if col is not None else "").strip()
            if not text:
                continue
            if text in cols:
                warn(meta, f"{key}: の {name} に同じ項目が 2 度あります: {text}")
                continue
            cols.append(text)
        books[name] = cols
    return books, True


# ---- 本文 ---------------------------------------------------------------------

def _flatten_sections(soup: Any) -> None:
    """converter が見出しごとに包んだ ``<section>`` をほどき、本文を平らな並びに戻す。"""
    for section in soup.find_all("section", recursive=False):
        if "dm-section" in (section.get("class") or []):
            section.unwrap()


def _split(text: str) -> List[str]:
    return [part.strip() for part in _LIST_SEP_RE.split(text) if part.strip()]


def _squeeze(text: str) -> str:
    return " ".join(text.split())


def _read_fields(task: Dict[str, Any], meta: Dict[str, Any]) -> None:
    """作業の節の最初の箇条書きから ``担当:`` ``更新:`` の行を読み、本文から外す。

    読むのは最初の箇条書きだけ。本文の途中の箇条書きに「担当: 〜」と書いた説明を
    取り違えないため。キーで始まらない行は本文に残す。
    """
    owner_words = {normalize(word) for word in keywords.get("process_owner")}
    update_words = {normalize(word) for word in keywords.get("process_update")}
    first = next((node for node in task["body"]
                  if getattr(node, "name", None) is not None or str(node).strip()), None)
    if getattr(first, "name", None) not in ("ul", "ol"):
        warn(meta, f"担当の無い作業があります: {task['no']} {task['title']}")
        return
    for item in first.find_all("li", recursive=False):
        match = _FIELD_RE.match(_squeeze(item.get_text(" ")))
        if not match:
            continue
        key, value = normalize(match.group(1)), match.group(2).strip()
        if key in owner_words:
            for name in _split(value):
                if name not in task["owners"]:
                    task["owners"].append(name)
            item.decompose()
        elif key in update_words:
            update = _parse_update(value, task, meta)
            if update is not None:
                task["updates"].append(update)
            item.decompose()
    if not first.find("li"):
        task["body"].remove(first)
        first.decompose()
    if not task["owners"]:
        warn(meta, f"担当の無い作業があります: {task['no']} {task['title']}")


def _parse_update(value: str, task: Dict[str, Any], meta: Dict[str, Any]) -> Optional[Dict[str, Any]]:
    """``台帳 / 項目, 項目=値`` を読む。"""
    parts = _BOOK_SEP_RE.split(value, maxsplit=1)
    if len(parts) < 2 or not parts[0].strip() or not parts[1].strip():
        warn(meta, f"更新の書き方を読めません（「台帳 / 項目, 項目=値」と書きます）: "
                   f"{value}（作業 {task['no']} {task['title']}）")
        return None
    book = parts[0].strip()
    cols: List[Tuple[str, Optional[str]]] = []
    seen: List[str] = []
    for piece in _split(parts[1]):
        pair = _VALUE_SEP_RE.split(piece, maxsplit=1)
        col = pair[0].strip()
        text = pair[1].strip() if len(pair) > 1 else None
        if not col:
            continue
        if col in seen:
            warn(meta, f"同じ項目を 2 度書いています: {book} / {col}（作業 {task['no']} {task['title']}）")
            continue
        seen.append(col)
        cols.append((col, text or None))
    if not cols:
        warn(meta, f"更新する項目がありません: {book}（作業 {task['no']} {task['title']}）")
        return None
    return {"book": book, "cols": cols}


def _check_update(update: Dict[str, Any], task: Dict[str, Any], books: Dict[str, List[str]],
                  books_given: bool, meta: Dict[str, Any]) -> None:
    """front matter に無い台帳・項目を警告し、後ろに足す（並びは作業に出てきた順）。"""
    name = update["book"]
    where = f"（作業 {task['no']} {task['title']}）"
    if name not in books:
        if books_given:
            warn(meta, f"front matter の台帳に無い台帳です: {name}{where}")
        books[name] = []
    for col, _ in update["cols"]:
        if col not in books[name]:
            if books_given and books[name]:
                warn(meta, f"台帳 {name} の front matter に無い項目です: {col}{where}")
            books[name].append(col)


# ---- 組み直した本文 -------------------------------------------------------------

def _tag(soup: Any, name: str, cls: str = "", text: Optional[str] = None, **attrs: Any) -> Any:
    tag = soup.new_tag(name, attrs=attrs)
    if cls:
        add_class(tag, *cls.split())
    if text is not None:
        tag.string = text
    return tag


def _all_tasks(groups: List[Dict[str, Any]]) -> List[Dict[str, Any]]:
    return [task for group in groups for task in group["tasks"]]


def _owner_badge(soup: Any, name: str, owners: List[str]) -> Any:
    index = owners.index(name) % OWNER_COLORS
    return _tag(soup, "span", f"dm-process-who dm-process-who--{index}", name)


def _letter(index: int) -> str:
    """Excel の列の文字（0 → A、26 → AA）。"""
    text = ""
    index += 1
    while index:
        index, rest = divmod(index - 1, 26)
        text = chr(65 + rest) + text
    return text


def _static_view(soup: Any, groups: List[Dict[str, Any]], owners: List[str],
                 books: Dict[str, List[str]]) -> Any:
    """グループ → 作業の並びと、台帳ごとの更新表。

    JavaScript の無い環境と印刷ではこのまま読む。JavaScript が動けば、テンプレートが
    担当の帯・チェックの保存・記入状況・未実施のまとめを足す。
    """
    box = _tag(soup, "div", "dm-process", id="dm-process")
    layout = _tag(soup, "div", "dm-process-layout")
    main = _tag(soup, "div", "dm-process-main")
    for gi, group in enumerate(groups, start=1):
        section = _tag(soup, "section", "dm-process-group", id=f"dm-group-{gi}")
        head = _tag(soup, "div", "dm-process-group__head")
        title = _tag(soup, "h2", "dm-process-group__title")
        title.append(_tag(soup, "span", "dm-process-group__no", str(gi)))
        title.append(group["name"])
        head.append(title)
        check = _tag(soup, "label", "dm-process-gcheck")
        box_attrs = {"checked": ""} if group["done"] else {}
        check.append(_tag(soup, "input", "dm-process-gcheck__box", type="checkbox", **box_attrs))
        check.append("グループ完了")
        head.append(check)
        section.append(head)
        if group["intro"]:
            note = _tag(soup, "div", "dm-process-group__intro")
            for node in group["intro"]:
                note.append(node.extract() if hasattr(node, "extract") else node)
            section.append(note)
        for task in group["tasks"]:
            section.append(_task_view(soup, task, owners))
        main.append(section)
    layout.append(main)
    layout.append(_tag(soup, "aside", "dm-process-side", id="dm-process-side", hidden=""))
    box.append(layout)
    if any(books.values()):
        box.append(_books_view(soup, groups, owners, books))
    pending = _tag(soup, "section", "dm-process-pending", id="dm-process-pending", hidden="")
    box.append(pending)
    return box


def _task_view(soup: Any, task: Dict[str, Any], owners: List[str]) -> Any:
    card = _tag(soup, "article", "dm-process-task", id=task["id"])
    box_attrs = {"aria-label": f"{task['no']} {task['title']} を完了"}
    if task["done"]:
        box_attrs["checked"] = ""
    card.append(_tag(soup, "input", "dm-process-task__box", type="checkbox", **box_attrs))
    body = _tag(soup, "div", "dm-process-task__body")
    title = _tag(soup, "h3", "dm-process-task__title")
    title.append(_tag(soup, "span", "dm-process-task__no", task["no"]))
    title.append(_tag(soup, "span", "dm-process-task__name", task["title"]))
    body.append(title)
    if task["owners"]:
        tags = _tag(soup, "div", "dm-process-task__owners")
        for name in task["owners"]:
            tags.append(_owner_badge(soup, name, owners))
        body.append(tags)
    for update in task["updates"]:
        line = _tag(soup, "div", "dm-process-upd")
        line.append(_tag(soup, "span", "dm-process-upd__book", update["book"]))
        # 値を書く項目（状態など）を先に出す。項目が多いとき、畳んでも見えるように
        ordered = ([c for c in update["cols"] if c[1] is not None]
                   + [c for c in update["cols"] if c[1] is None])
        for col, value in ordered:
            item = _tag(soup, "span", "dm-process-upd__col", col)
            if value is not None:
                item.append(" = ")
                item.append(_tag(soup, "b", "", value))
            line.append(item)
        body.append(line)
    for node in task["body"]:
        body.append(node.extract() if hasattr(node, "extract") else node)
    card.append(body)
    return card


def _books_view(soup: Any, groups: List[Dict[str, Any]], owners: List[str],
                books: Dict[str, List[str]]) -> Any:
    """台帳ごとの更新表。行が作業（作業の順）、列が台帳の項目。"""
    box = _tag(soup, "section", "dm-process-books", id="dm-process-books")
    box.append(_tag(soup, "h2", "dm-process-books__title", "台帳の更新表"))
    box.append(_tag(soup, "p", "dm-process-books__lead",
                    "行が作業（上から作業の順）、列が台帳の項目です。色の付いたセルが、その作業で更新する項目です。"))
    box.append(_tag(soup, "div", "dm-process-tabs", id="dm-process-tabs", role="tablist", hidden=""))
    for bi, (name, cols) in enumerate(books.items(), start=1):
        if not cols:
            continue
        sheet = _tag(soup, "div", "dm-process-sheet", id=f"dm-book-{bi}")
        sheet["data-book"] = name
        sheet.append(_tag(soup, "h3", "dm-process-sheet__name", name))
        scroll = _tag(soup, "div", "dm-table-scroll dm-process-grid-wrap")
        table = _tag(soup, "table", "dm-process-grid")
        thead = _tag(soup, "thead")
        letters = _tag(soup, "tr", "dm-process-grid__letters")
        names = _tag(soup, "tr", "dm-process-grid__names")
        letters.append(_tag(soup, "th", "dm-process-grid__task"))
        names.append(_tag(soup, "th", "dm-process-grid__task", "作業"))
        for ci, col in enumerate(cols):
            letters.append(_tag(soup, "th", "", _letter(ci)))
            # 日本語は折り返す位置を選ばないので、列の幅を文字数から決め、細切れにしない
            longest = max([len(col)] + [len(value or "") for task in _all_tasks(groups)
                                        for update in task["updates"] if update["book"] == name
                                        for c, value in update["cols"] if c == col])
            width = min(max(longest, GRID_MIN_CHARS), GRID_MAX_CHARS) + 1.2
            names.append(_tag(soup, "th", "", col, style=f"min-width: {width}em"))
        thead.append(letters)
        thead.append(names)
        table.append(thead)
        tbody = _tag(soup, "tbody")
        for group in groups:
            rows = []
            for task in group["tasks"]:
                values = {col: value for update in task["updates"] if update["book"] == name
                          for col, value in update["cols"]}
                if values:
                    rows.append((task, values))
            if not rows:
                continue
            band = _tag(soup, "tr", "dm-process-grid__group")
            band.append(_tag(soup, "th", "dm-process-grid__task", group["name"]))
            fill = _tag(soup, "td")
            fill["colspan"] = str(len(cols))
            band.append(fill)
            tbody.append(band)
            for task, values in rows:
                row = _tag(soup, "tr", "dm-process-grid__row")
                row["data-task"] = task["id"]
                head = _tag(soup, "th", "dm-process-grid__task")
                head.append(_tag(soup, "a", "", f"{task['no']} {task['title']}", href=f"#{task['id']}"))
                for owner in task["owners"]:
                    head.append(_owner_badge(soup, owner, owners))
                row.append(head)
                for col in cols:
                    if col in values:
                        cell = _tag(soup, "td", "dm-process-grid__upd",
                                    values[col] if values[col] is not None else "記入")
                    else:
                        cell = _tag(soup, "td")
                    row.append(cell)
                tbody.append(row)
        table.append(tbody)
        scroll.append(table)
        sheet.append(scroll)
        box.append(sheet)
    return box
