"""
docmold の対話メニュー（Markdown → 自己完結 HTML）
==================================================
変換対象・種類・出力先を対話形式で選んで実行する。

  python3 menu.py                  # メニューを表示
  python3 menu.py --config my.yaml # 設定ファイルを指定

種類（type）は本来 .md の front matter に書くもので、このメニューでは
「front matter に従う」が既定。別の表現で出したいときだけ上書きを選ぶ。

無人実行はこのメニューではなく本体を直接呼ぶこと:
  python3 docmold.py docs -o out --index
"""

import argparse
import json
import os
import subprocess
import sys
from pathlib import Path

# menu.bat のダブルクリック起動や、別ツールの Python で起動された場合に
# トレースバックではなく対処を表示する。cli の import より先に確認すること
# （cli は markdown / jinja2 / bs4 を引き込むため）。
from deps import ensure, make_console_safe, require_python  # noqa: E402

# CP932 のコンソールで、落としたファイルの名前などに CP932 に無い文字があっても落ちないようにする
make_console_safe()
require_python()
ensure()

import cli as docmold_cli  # noqa: E402
import config as docmold_config  # noqa: E402
from version import __version__  # noqa: E402

WIDTH = 60
TOOL_DIR = Path(__file__).resolve().parent
SCRIPT = TOOL_DIR / "docmold.py"
HISTORY_PATH = Path.home() / ".docmold_menu.json"

#: 変換対象として数える拡張子（本体と揃える）。
MARKDOWN_EXTS = (".md", ".markdown")

ACTION_CONVERT = "convert"
ACTION_TYPES = "types"
ACTION_RULES = "rules"

ACTIONS = [
    (ACTION_CONVERT, "変換する", "Markdown を自己完結 HTML に変換する"),
    (ACTION_TYPES, "種類の一覧", "front matter の type に書ける名前を表示する"),
    (ACTION_RULES, "ルールの一覧", "種類ごとの意味づけ（後処理）を表示する"),
]

#: メニューの名前。見出しと --help で揃える
MENU_NAME = "Markdown → 自己完結 HTML"

# 終了コード
EXIT_OK = 0
EXIT_EOF = 1
EXIT_USAGE = 2
EXIT_NOT_FOUND = 127
EXIT_INTERRUPTED = 130

#: 本体の終了コードの意味。README の「終了コード」と揃える。127 はメニューの側の番号
EXIT_MEANINGS = {
    0: "すべて変換した",
    1: "変換に失敗したファイルがある、変換する .md が無い、または --strict で警告があった",
    2: "設定・引数の誤り、出力フォルダを作れない、または依存が足りない",
    EXIT_NOT_FOUND: "本体が見つからない",
    130: "中断した（Ctrl+C か、外から止められた）",
}


def describe_exit(code: int) -> str:
    """本体を動かした後の「終了コード: N（意味）」の文。表に無ければ想定外と示す（ほかのツールと同じ形）。"""
    return f"終了コード: {code}（{EXIT_MEANINGS.get(code, '想定外の終了コードです')}）"


# ===========================================================================
# 表示・入力
# ===========================================================================


def hr(char="="):
    print(char * WIDTH)


def print_menu(title: str, items: list, back_label: str = "戻る",
               default: int = None, default_mark: str = "既定") -> int:
    """
    メニューを表示して選択番号を返す。0 = 戻る / 終了。
    default_mark は既定値の由来を示すラベル（前回の選択なら「前回」）。
    """
    while True:
        print()
        hr()
        print(f"  {title}")
        hr()
        for i, item in enumerate(items, 1):
            mark = f" ←{default_mark}" if default == i else ""
            print(f"  {i}. {item}{mark}")
        hr("-")
        print(f"  0. {back_label}")
        hr()
        prompt = ("番号を入力してください"
                  + (f" [Enter={default}]: " if default else ": "))
        choice = input(prompt).strip()
        if not choice and default:
            return default
        if choice == "0":
            return 0
        if choice.isdigit() and 1 <= int(choice) <= len(items):
            return int(choice)
        print("  ※ 無効な入力です。もう一度入力してください。")


def input_text(prompt: str, default: str = "", validate=None,
               hint: str = "") -> str:
    """
    文字列を入力させる。空 Enter は default を採用する。
    default が無い状態で空 Enter を押した場合は None（キャンセル）を返す。
    """
    suffix = f" [Enter={default}]" if default else "（空 Enter で戻る）"
    while True:
        answer = input(f"  {prompt}{suffix}: ").strip()
        if not answer:
            if default:
                return default
            return None
        # ドラッグ＆ドロップで付く引用符を落とす（Windows のパスでよく付く）。
        answer = answer.strip('"').strip("'")
        if validate is None or validate(answer):
            return answer
        print(f"  ※ {hint}")


def confirm(prompt: str, default_yes: bool = True) -> bool:
    """y/n を尋ねる。空 Enter は default_yes。"""
    suffix = " [Y/n]: " if default_yes else " [y/N]: "
    while True:
        answer = input(f"  {prompt}{suffix}").strip().lower()
        if not answer:
            return default_yes
        if answer in ("y", "yes"):
            return True
        if answer in ("n", "no"):
            return False
        print("  ※ y か n で答えてください。")


# ===========================================================================
# 入力パスの検証
# ===========================================================================


def resolve_input(value: str) -> Path:
    """入力文字列をパスにする（相対パスはメニューの実行位置基準）。"""
    return Path(value).expanduser()


def is_convertible(value: str) -> bool:
    """変換対象として成立するパスか（.md か、.md を含むディレクトリ）。"""
    path = resolve_input(value.strip('"').strip("'"))
    if path.is_file():
        return path.suffix.lower() in MARKDOWN_EXTS
    if path.is_dir():
        return any(count_markdown(path))
    return False


def count_markdown(directory: Path):
    """ディレクトリ配下の変換される .md を列挙する（存在確認にも使う）。

    本体と同じ数え方にする（隠しフォルダの中と、取り込み専用の断片は外す）。
    """
    return docmold_cli.markdown_in_dir(directory)


def describe_input(value: str) -> str:
    """入力パスを 1 行で説明する。"""
    path = resolve_input(value)
    if path.is_file():
        return f"{path}（1 ファイル）"
    if path.is_dir():
        return f"{path}（{len(count_markdown(path))} ファイル）"
    return f"{path}（見つかりません）"


# ===========================================================================
# 前回値の記憶
# ===========================================================================


def load_history() -> dict:
    """前回の入力値を読む。壊れていても既定値で続行する。"""
    try:
        with open(HISTORY_PATH, encoding="utf-8") as f:
            data = json.load(f)
        return data if isinstance(data, dict) else {}
    except (OSError, ValueError):
        return {}


def save_history(data: dict) -> None:
    """入力値を保存する。書けなくても実行は妨げない。"""
    try:
        with open(HISTORY_PATH, "w", encoding="utf-8") as f:
            json.dump(data, f, ensure_ascii=False, indent=2)
    except OSError:
        pass


# ===========================================================================
# 種類の選択
# ===========================================================================


def load_profiles(config_path: str):
    """設定を読む。読めない場合は (None, 理由) を返す。"""
    try:
        return docmold_config.load_config(config_path or None,
                                          default_search_dir=TOOL_DIR), ""
    except docmold_config.ConfigError as e:
        return None, str(e)


def choose_type(config, history: dict = None) -> str:
    """種類の上書きを選ぶ。「front matter に従う」なら空文字、戻るなら None。

    前回選んだものを既定にする。前回の種類が設定から消えている場合は
    「front matter に従う」に戻す。
    """
    names = config.type_names
    items = ["front matter に従う（.md の指定をそのまま使う）"] + [
        f"{name} ― {config.profile(name).description or '説明なし'}" for name in names
    ]
    default, mark = 1, "既定"
    if history is not None and "type" in history:
        last = history["type"]
        if not last:
            mark = "前回"
        elif last in names:
            default, mark = names.index(last) + 2, "前回"

    choice = print_menu("種類（type）", items, default=default, default_mark=mark)
    if choice == 0:
        return None
    if choice == 1:
        return ""
    return names[choice - 2]


def choose_output(history: dict) -> str:
    """出力先を選ぶ。既定なら空文字（-o を渡さない）、戻るなら None。

    既定はツール同梱の out/<タイムスタンプ>/。実行のたびにフォルダが分かれるため、
    複数回実行しても結果が混ざらず、前回の出力も消えない。
    """
    last = history.get("output", "")
    items = [
        f"既定（{docmold_cli.DEFAULT_OUTPUT_DIR}/<日時>/）",
        "場所を指定する",
    ]
    choice = print_menu("出力先", items,
                        default=2 if last else 1,
                        default_mark="前回" if last else "既定")
    if choice == 0:
        return None
    if choice == 1:
        return ""
    return input_text("出力先のパス", default=last)


# ===========================================================================
# config.yaml の出力先の定義（menu_outputs）
# ===========================================================================


def plan_outputs(config, input_path: str):
    """``menu_outputs:`` に従って、変換する .md を出力先ごとに分ける。

    戻り値は ``(決まったもの, 残り)``。決まったものは ``[(定義, [.md, ...]), ...]`` を定義の順に、
    残りは出力先を尋ねる入力の並び（文字列）。定義に当たったものが無ければ、残りは入力そのまま
    （フォルダなら階層を保ち、索引も作れる）。
    """
    path = resolve_input(input_path)
    if not config.menu_outputs:
        return [], [input_path]
    files = [path] if path.is_file() else count_markdown(path) if path.is_dir() else []

    groups = {}
    rest = []
    for source in files:
        entry = config.menu_output_for(source)
        if entry is None:
            rest.append(source)
        else:
            groups.setdefault(id(entry), (entry, []))[1].append(source)
    if not groups:
        return [], [input_path]
    order = {id(entry): i for i, entry in enumerate(config.menu_outputs)}
    planned = [groups[key] for key in sorted(groups, key=order.get)]
    return planned, [str(source) for source in rest]


def describe_plan(planned) -> None:
    """定義で出力先が決まったファイルを示す。"""
    for entry, sources in planned:
        print(f"    → {entry.output}（config.yaml の定義: {entry.source}）")
        for source in sources:
            print(f"        {source.name}")


# ===========================================================================
# 実行内容の組み立て
# ===========================================================================


def build_args(input_path, *, config_path: str = "", output: str = "",
               type_override: str = "", index: bool = False,
               dry_run: bool = False) -> list:
    """本体に渡すコマンドライン引数を組み立てる。``input_path`` は 1 つか、その並び。"""
    args = [input_path] if isinstance(input_path, str) else [str(p) for p in input_path]
    if config_path:
        args += ["--config", config_path]
    if output:
        args += ["-o", output]
    if type_override:
        args += ["--type", type_override]
    if index:
        args.append("--index")
    if dry_run:
        args.append("--dry-run")
    args.append("--verbose")
    return args


def working_dir() -> Path:
    """本体を動かすフォルダ。ふだんはメニューの作業フォルダ（相対パスの基準）。

    メニューを開いたまま作業フォルダを消したり作り直したりすると、``Path.cwd()`` は
    ``FileNotFoundError`` を出す。そのときは案内して、ツールのフォルダで動かす。
    """
    try:
        return Path.cwd()
    except FileNotFoundError:
        print(f"  ※ 作業フォルダが見つかりません（消されたか、作り直されました）。ツールのフォルダで動かします: {TOOL_DIR}")
        print("    相対パスで書いた入力は見つからないことがあります。困るときはメニューを開き直してください。")
        return TOOL_DIR


def run_docmold(args: list) -> int:
    """本体を実行して終了コードを返す。本体が無ければ 127、中断したら 130。

    Ctrl+C は本体も同じものを受け、書きかけの HTML を片付けてから止まる。subprocess.run は
    本体をすぐ止めてしまうため、終わるまで待つ（もう一度押せば止める）。ほかのツールのメニューと同じ形。
    """
    if not SCRIPT.is_file():
        print(f"\n  ※ 本体が見つかりません: {SCRIPT}")
        return EXIT_NOT_FOUND
    print()
    hr("-")
    process = subprocess.Popen([sys.executable, str(SCRIPT), *args], cwd=working_dir())
    try:
        return process.wait()
    except KeyboardInterrupt:
        try:
            process.wait()
        except KeyboardInterrupt:
            process.kill()
            process.wait()
        print("\n  中断しました。")
        return EXIT_INTERRUPTED


def latest_output(output: str):
    """開くべき出力先を返す。無ければ None。

    既定（-o なし）のときは本体がタイムスタンプ付きのフォルダを作るため、
    out/ 配下の最新のフォルダを開く。
    """
    if output:
        destination = resolve_input(output)
        if destination.is_dir():
            return destination
        return destination.parent if destination.parent.is_dir() else None

    base = docmold_cli.DEFAULT_OUTPUT_DIR
    if not base.is_dir():
        return None
    folders = [child for child in base.iterdir() if child.is_dir()]
    return max(folders, key=lambda child: child.name) if folders else None


def open_in_explorer(path: Path) -> bool:
    """出力先をエクスプローラ / Finder で開く。開けなければ False。"""
    try:
        if sys.platform == "win32":
            os.startfile(str(path))  # noqa: S606 - Windows の既定動作で開く
        elif sys.platform == "darwin":
            subprocess.run(["open", str(path)], check=True)
        else:
            subprocess.run(["xdg-open", str(path)], check=True)
        return True
    except (OSError, subprocess.SubprocessError, AttributeError):
        return False


# ===========================================================================
# 各操作の対話
# ===========================================================================


def collect_inputs(config, history: dict) -> dict:
    """変換に必要な入力を集める。戻る場合は None。"""
    input_path = input_text(
        "変換する .md またはディレクトリ",
        default=history.get("input", ""),
        validate=is_convertible,
        hint=".md ファイルか、.md を含むディレクトリを指定してください。",
    )
    if not input_path:
        return None
    print(f"    → {describe_input(input_path)}")

    type_override = choose_type(config, history)
    if type_override is None:
        return None

    planned, rest = plan_outputs(config, input_path)
    if planned:
        print()
        print("  出力先は config.yaml の定義で決まりました:")
        describe_plan(planned)
    runs = [{"inputs": [str(p) for p in sources], "output": str(entry.output), "index": False}
            for entry, sources in planned]

    # 定義に当たらなかったものだけ、出力先を尋ねる。
    output = history.get("output", "")
    asked = bool(rest)
    if rest:
        if planned:
            print(f"\n  定義に当たらないファイルが {len(rest)} 件あります。出力先を選んでください。")
        output = choose_output(history)
        if output is None:
            return None

        # 索引は複数ファイルをまとめたときだけ意味があるので、ディレクトリ入力時に尋ねる。
        # 定義で振り分けたフォルダには作らない（ほかの実行の分まで並ぶ索引を上書きしないため）。
        index = False
        if not planned and resolve_input(input_path).is_dir():
            index = confirm("索引 HTML（index.html）も作りますか？",
                            default_yes=bool(history.get("index", True)))
        runs.append({"inputs": rest, "output": output, "index": index})

    return {"input": input_path, "type": type_override, "output": output,
            "asked_output": asked, "index": any(run["index"] for run in runs), "runs": runs}


def run_convert(config, config_path: str, history: dict):
    """変換を対話で実行する。戻る場合は None。"""
    print()
    hr()
    print("  変換する")
    hr()

    inputs = collect_inputs(config, history)
    if inputs is None:
        return None

    choice = print_menu(
        "実行モード",
        ["変換して書き出す", "検証のみ（--dry-run・HTML を書き出しません）"],
        default=1,
    )
    if choice == 0:
        return None
    dry_run = (choice == 2)

    # 記憶するのは入力値のみ。実行前に保存し、途中で失敗しても次回に活きるようにする。
    # 出力先と索引は、尋ねたときだけ覚える（定義で決まったものを次の既定にしない）。
    history.update({
        "action": ACTION_CONVERT,
        "input": inputs["input"],
        "type": inputs["type"],
    })
    if inputs.get("asked_output", True):
        history["output"] = inputs["output"]
        history["index"] = inputs["index"]
    save_history(history)

    runs = inputs.get("runs") or [
        {"inputs": [inputs["input"]], "output": inputs["output"], "index": inputs["index"]}]
    rc = EXIT_OK
    for run in runs:
        code = run_docmold(build_args(
            run["inputs"],
            config_path=config_path,
            output=run["output"],
            type_override=inputs["type"],
            index=run["index"],
            dry_run=dry_run,
        ))
        # 出力先が複数なら、いちばん重い終了コードを返す。中断したら残りは動かさない。
        rc = max(rc, code)
        if code in (EXIT_INTERRUPTED, EXIT_NOT_FOUND):
            return code

    if rc == EXIT_OK and not dry_run:
        targets = []
        for run in runs:
            target = latest_output(run["output"])
            if target is not None and target not in targets:
                targets.append(target)
        question = "出力先を開きますか？" if len(targets) == 1 else f"出力先（{len(targets)} か所）を開きますか？"
        if targets and confirm(question, default_yes=False):
            for target in targets:
                if not open_in_explorer(target):
                    print(f"  ※ 開けませんでした。手動で確認してください: {target}")
    return rc


def show_listing(option: str, config_path: str) -> int:
    """--list-types / --list-rules を本体に委譲して表示する。"""
    args = [option]
    if config_path:
        args += ["--config", config_path]
    return run_docmold(args)


# ===========================================================================
# エントリポイント
# ===========================================================================


def describe_config(config_path: str) -> str:
    """設定の状態を 1 行で表す。読めない場合は理由を返す。"""
    config, error = load_profiles(config_path)
    if config is None:
        return f"※ {error}"
    defined = f"・出力先の定義 {len(config.menu_outputs)} 件" if config.menu_outputs else ""
    return f"{config.config_path}（{len(config.profiles)} 種類{defined}）"


def heading() -> str:
    """メニューの見出し。ほかのツールのメニューと同じ「<説明>（<ツール名> <版>）」の形。"""
    return f"  {MENU_NAME}（docmold {__version__}）"


def build_parser() -> argparse.ArgumentParser:
    parser = docmold_cli.japanese(argparse.ArgumentParser(
        prog="python menu.py",
        description=MENU_NAME,
        formatter_class=docmold_cli.HelpFormatter,
        epilog="無人実行には docmold.py を直接使ってください。",
        add_help=False,
        allow_abbrev=False,
    ))
    parser.add_argument("--config", default="", metavar="PATH", help=docmold_cli.HELP_CONFIG)
    parser.add_argument(
        "inputs",
        nargs="*",
        help="変換する .md かフォルダ（menu.bat に落としたときに入る）。「変換する」の既定値になる",
    )
    parser.add_argument("--version", action="version", version=f"docmold {__version__}", help="版を出して終わる")
    return parser


def apply_dropped(history: dict, inputs: list) -> bool:
    """menu.bat に落としたパスを、変換対象の既定値にする。落とされていれば True。

    複数落とされたときは最初の 1 つだけを使う（変換対象は 1 つずつ尋ねるため）。
    """
    if not inputs:
        return False
    history["input"] = inputs[0].strip('"').strip("'")
    print(f"  変換対象: {history['input']}（Enter でこのまま使えます）")
    if len(inputs) > 1:
        print("  ※ 2 つ目以降は無視しました")
    return True


def main() -> None:
    args = build_parser().parse_args()
    history = load_history()
    # 前回の選択があればそれを既定にする。記録が無ければ既定を付けない（ほかのツールと同じ）。
    # 落としたファイルがあれば「変換する」を既定にするが、前回の選択ではないので「既定」と示す
    default_choice = next(
        (i for i, (key, _, _) in enumerate(ACTIONS, 1) if key == history.get("action")), None
    )
    default_mark = "前回"
    if apply_dropped(history, args.inputs):
        default_choice, default_mark = 1, "既定"

    items = [f"{label} ― {desc}" for _, label, desc in ACTIONS]

    try:
        while True:
            print()
            hr()
            print(heading())
            hr()
            print(f"  設定: {describe_config(args.config)}")

            choice = print_menu("操作を選択", items, back_label="終了",
                                default=default_choice, default_mark=default_mark)
            if choice == 0:
                print("  終了します。")
                sys.exit(EXIT_OK)

            action = ACTIONS[choice - 1][0]
            if action == ACTION_CONVERT:
                config, error = load_profiles(args.config)
                if config is None:
                    print(f"\n  ※ 設定を読めません: {error}")
                    input("\n  Enter キーでメニューに戻ります...")
                    continue
                rc = run_convert(config, args.config, history)
            elif action == ACTION_TYPES:
                rc = show_listing("--list-types", args.config)
            else:
                rc = show_listing("--list-rules", args.config)

            if rc is not None:
                print()
                hr("-")
                print(f"  {describe_exit(rc)}")
                default_choice, default_mark = choice, "前回"
                history["action"] = action
                save_history(history)
                input("\n  Enter キーでメニューに戻ります...")
    except EOFError:
        print("\n  入力が終了しました。")
        sys.exit(EXIT_EOF)
    except KeyboardInterrupt:
        print("\n  中断しました。")
        sys.exit(EXIT_INTERRUPTED)


if __name__ == "__main__":
    main()
