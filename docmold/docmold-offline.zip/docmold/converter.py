"""Markdown → HTML 変換パイプライン。

    front matter 分離
      → type からプロファイル決定（未指定なら default）
      → Markdown → HTML（拡張はプロファイル依存）
      → ② ルール層: DOM 後処理
      → ① テンプレート描画 + ③ テーマ CSS 埋め込み
    自己完結 HTML（1 ファイル）

種類の判定は **書き手が明示した種類だけ** を見る。パス名や本文からの自動判定は
誤判定で事故るうえ保守コストが乗るため行わない。
"""
from __future__ import annotations

import difflib
import re
import unicodedata
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, Dict, List, Optional

try:
    import markdown
except ImportError as e:  # pragma: no cover - 依存が無い環境向けの案内
    raise ImportError("Markdown is required. Install with: pip install markdown") from e

try:
    from bs4 import BeautifulSoup
except ImportError as e:  # pragma: no cover
    raise ImportError("beautifulsoup4 is required. Install with: pip install beautifulsoup4") from e

from assets import embed_images
from config import DEFAULT_PROFILE, Config, Profile
from frontmatter import meta_to_text, split_front_matter
from include import expand as expand_includes
from list_indent import ListIndentExtension
from mermaid_ext import MermaidExtension
from renderer import render
from rules import DERIVED_KEY, apply_rules, derived as derived_store, keywords, take_warnings
from sanitize import format_reasons, sanitize
from rules.common import HEADING_TAGS, add_class, heading_level, wrap_section

#: 本文からタイトルを拾えなかったときの表示名。
FALLBACK_TITLE = "(無題)"

#: front matter で常に意味を持つキー。
RESERVED_META_KEYS = ("type", "title")

#: 打ち間違いとみなす類似度。下げると無関係なキーまで指摘し始める。
TYPO_CUTOFF = 0.75

#: 文書間リンクとして書き換える拡張子（変換後は .html になる）。
LINK_EXTS = (".md", ".markdown")

#: 書き換えないリンク。外部参照とページ内アンカー。
_EXTERNAL_LINK_RE = re.compile(r"\A(?:[a-z][a-z0-9+.-]*:|//|#)", re.IGNORECASE)


#: コードブロックの囲み（``` か ~~~ を 3 つ以上）。閉じるのは同じ文字で、開きと同じ数以上。
_FENCE_RE = re.compile(r"^[ ]{0,3}(`{3,}|~{3,})")

#: 行頭から始まる生の HTML のブロック。中の行には空行を補わない。
_HTML_OPEN_RE = re.compile(r"^<([A-Za-z][A-Za-z0-9-]*)")

#: 閉じタグを持たない要素。行頭にあっても、その行で終わる。
_VOID_TAGS = frozenset({"area", "base", "br", "col", "embed", "hr", "img", "input",
                        "link", "meta", "source", "track", "wbr"})


def separate_headings(body: str) -> str:
    """見出しの行（``#`` で始まる行）の直前が空行でなければ、空行を補う。

    python-markdown は空行で区切ったまとまり（ブロック）ごとに処理し、見出しを見つけると
    そこで切って残りを別のブロックとして処理し直す。admonition 拡張の判定は、そのたびに
    残り全体を正規表現で探すため、空行の無い文書では「見出しの数 × 文書の長さ」で遅くなる
    （1 万行・見出し 1,000 個で 5.8 秒。補うと 0.8 秒）。

    python-markdown は空行が無くても ``#`` で始まる行を見出しにするので、補っても読み方は
    変わらない。例外は 2 つで、コードブロックと生の HTML のブロックの中は触らない（空行が
    そのまま出る）。表の直後の見出しは、補うと表の行に吸い込まれず見出しになる（GitHub と同じ）。
    """
    out: List[str] = []
    fence = ""          # 開いているコードブロックの囲み
    html_end = ""       # 開いている HTML のブロックの閉じタグ
    previous = ""
    for line in body.split("\n"):
        if fence:
            stripped = line.strip()
            if stripped.startswith(fence[0] * len(fence)) and not stripped.strip(fence[0]):
                fence = ""
        elif html_end:
            if html_end in line.lower():
                html_end = ""
        elif _FENCE_RE.match(line):
            fence = _FENCE_RE.match(line).group(1)
        elif line.startswith("<!--"):
            if "-->" not in line:
                html_end = "-->"
        elif _HTML_OPEN_RE.match(line):
            tag = _HTML_OPEN_RE.match(line).group(1).lower()
            closing = f"</{tag}>"
            if tag not in _VOID_TAGS and closing not in line.lower() and not line.rstrip().endswith("/>"):
                html_end = closing
        elif line.startswith("#") and previous.strip():
            out.append("")
        out.append(line)
        previous = line
    return "\n".join(out)


class ConversionError(RuntimeError):
    """変換に失敗したときに送出。"""


@dataclass
class ConversionResult:
    """1 ファイル分の変換結果。"""

    html: str
    title: str
    profile_name: str
    meta: Dict[str, Any] = field(default_factory=dict)
    warnings: List[str] = field(default_factory=list)
    source_path: Optional[Path] = None


def resolve_profile(config: Config, meta: Dict[str, Any],
                    type_override: Optional[str] = None) -> tuple:
    """使用するプロファイルと警告を決める。

    未知の type は黙って default に落とさず、警告のうえ default で処理する
    （タイプミスに気づけないまま変換されるのを防ぐ）。
    """
    warnings: List[str] = []
    requested = type_override or meta.get("type") or DEFAULT_PROFILE
    requested = str(requested).strip() or DEFAULT_PROFILE

    if requested not in config.profiles:
        warnings.append(
            f"未知の type '{requested}': {DEFAULT_PROFILE} で処理します"
            f" (指定できる type: {', '.join(config.type_names)})"
        )
        requested = DEFAULT_PROFILE

    return config.profile(requested), warnings


def convert_text(text: str, config: Config, *,
                 type_override: Optional[str] = None,
                 source_path: Optional[Path] = None,
                 title_override: Optional[str] = None) -> ConversionResult:
    """Markdown 文字列を自己完結 HTML に変換する。"""
    meta, body = split_front_matter(text)
    profile, warnings = resolve_profile(config, meta, type_override)
    # 原文を書き戻すルール（process のダウンロード）のために、原文と本文の始まる行を渡す。
    # 名前はファイル名だけにする（端末のパスを出力に残さないため）。
    derived_store(meta)["source"] = {
        "text": text,
        "body_line": text[:len(text) - len(body)].count("\n"),
        "name": source_path.stem if source_path is not None else None,
    }

    # 検出語は設定で差し替えられる。取り込みの目印も見るため、ここで有効にする。
    keywords.use(config.keywords)

    # 取り込みは Markdown のまま差し込む。HTML にした後で継ぐと、採番や列の
    # 組み替えが文書をまたげない。
    body, include_warnings = expand_includes(meta, body, source_path)
    warnings.extend(include_warnings)
    body = separate_headings(body)

    # 2 文字の字下げ（エディタの整形の既定）でも入れ子にする。
    extensions = list(profile.markdown_extensions) + [ListIndentExtension()]
    if profile.mermaid.enabled:
        # ```mermaid を codehilite に食われる前に横取りする。
        extensions.append(MermaidExtension())

    md = markdown.Markdown(
        extensions=extensions,
        extension_configs=_extension_configs(profile),
    )
    html = md.convert(body)

    warnings.extend(_check_meta_typos(meta, profile))

    soup = BeautifulSoup(html, "html.parser")

    # 生 HTML の絞り込みは、本文だけが対象。ルール層やテンプレートが作る要素は
    # docmold 自身の生成物なので、この後に組み立てる。
    if profile.sanitize == "strict":
        reasons: Dict[str, int] = {}
        removed = sanitize(soup, profile.allow_schemes, reasons)
        if removed:
            warnings.append(
                f"本文の HTML を {removed} 箇所ほど除きました"
                f"（sanitize: strict。素通しにするには sanitize: false）。"
                f"内訳: {format_reasons(reasons)}"
            )

    _unescape_table_pipes(soup)
    warnings.extend(_rewrite_document_links(soup))
    _wrap_sections(soup)
    apply_rules(profile.rules, soup, meta)
    warnings.extend(take_warnings(meta))
    # 表を包むのはルールの後。ルールは表の親をたどって節を見分けるものがあるため。
    _compact_short_columns(soup)
    _wrap_tables(soup)

    # 目次はルール適用後の DOM から作るため、画像埋め込みより先に確定させる。
    toc = _build_toc(soup, profile)
    base_dir = source_path.parent if source_path is not None else None
    warnings.extend(embed_images(soup, base_dir))

    # 図が 1 つも無ければ mermaid.js を読み込まない。ルールの後に見るのは、
    # 取り込みや絞り込みを経て実際に残った描画対象だけを数えるため。
    has_diagrams = profile.mermaid.enabled and soup.find("pre", class_="mermaid") is not None

    title = title_override or _resolve_title(meta, soup, source_path)
    derived = meta.get(DERIVED_KEY) or {}

    return ConversionResult(
        html=render(
            config=config,
            profile=profile,
            content=str(soup),
            title=title,
            meta=meta,
            derived=derived,
            toc=toc,
            meta_header=_build_meta_header(profile, meta),
            warnings=warnings,
            has_diagrams=has_diagrams,
        ),
        title=title,
        profile_name=profile.name,
        meta=meta,
        warnings=warnings,
        source_path=source_path,
    )


def convert_file(path: Path, config: Config, *,
                 type_override: Optional[str] = None) -> ConversionResult:
    """``.md`` ファイルを読み込んで変換する。"""
    path = Path(path)
    try:
        text = path.read_text(encoding="utf-8")
    except UnicodeDecodeError:
        # Windows で作られた .md は cp932 のことがある。
        try:
            text = path.read_text(encoding="cp932")
        except (UnicodeDecodeError, LookupError) as e:
            raise ConversionError(f"{path}: 文字コードを判別できません (utf-8 / cp932): {e}") from e
    except OSError as e:
        raise ConversionError(f"{path}: 読み込めません: {e}") from e

    return convert_text(text, config, type_override=type_override, source_path=path)


#: 見出しの id に残す文字の一般カテゴリ。文字・結合文字・十進数字・数値文字・
#: 連結用の記号（``_`` など）。GitHub が残すものと同じ範囲。
_SLUG_KEEP_CATEGORIES = frozenset({"Nd", "Nl", "Pc"})


def github_slug(value: str, separator: str = "-") -> str:
    r"""見出しの id を GitHub と同じ規則で作る。

    同じ ``.md`` を GitHub でも HTML でも読む使い方では、文書内リンク
    ``[概要](#概要)`` が両方で成立してほしい。id の作り方が食い違うと、
    GitHub に合わせて書けば HTML で切れ、HTML に合わせれば GitHub で切れる。

    GitHub（github-slugger）の規則は 3 手だけで、**空白をまとめない**のが要。

    1. 小文字にする
    2. 文字・数字・結合文字・連結記号・``-``・半角空白**以外**を取り除く
    3. 残った半角空白をそれぞれ ``separator`` に置き換える

    記号の前後に空白があると、記号が消えて空白が 2 つ隣り合い、``--`` になる
    （``常設の指示 \u2014 利用する`` (\u2014 は em dash) → ``常設の指示--利用する``）。Python-Markdown の
    ``slugify`` はここを 1 つに畳むため、食い違っていた。

    **全角空白は半角空白ではない**ため、2 で取り除かれ、区切りにはならない
    （``A-6 世代管理　実装仕様書`` → ``a-6-世代管理実装仕様書``）。日本語の見出しで
    よく使われるので、``\s`` でまとめて扱うと GitHub と食い違う。
    """
    kept = []
    for char in value.lower():
        category = unicodedata.category(char)
        if char == "-" or char == " " or category[0] in ("L", "M") or category in _SLUG_KEEP_CATEGORIES:
            kept.append(char)
    return "".join(kept).replace(" ", separator)


def _slugifier():
    """1 文書分の slugify。同じ見出しが 2 度目からは ``-1`` ``-2`` と続き番号になる。

    GitHub も同じ規則で重複を避ける（github-slugger が出現回数を数えている）。
    Python-Markdown の重複回避は ``_1`` を足すため、``## 概要`` が 2 つある文書で
    食い違っていた。数えるのは 1 文書の中だけなので、変換ごとに作り直す。
    """
    seen: Dict[str, int] = {}

    def slugify(value: str, separator: str) -> str:
        base = github_slug(value, separator)
        slug = base
        while slug in seen:
            seen[base] += 1
            slug = f"{base}{separator}{seen[base]}"
        seen[slug] = 0
        return slug

    return slugify


def _extension_configs(profile: Profile) -> Dict[str, Dict[str, Any]]:
    configs: Dict[str, Dict[str, Any]] = {
        # CDN も外部 CSS も使えない前提なので、色は Pygments の生成 CSS で埋め込む。
        "codehilite": {"guess_lang": False, "noclasses": False},
        # 見出しの id は GitHub と同じ規則で作る（github_slug のコメントを参照）。
        # 既定の slugify は日本語見出しを空にしてしまい、アンカーが _1 / _2 になる。
        "toc": {
            "toc_depth": profile.toc.depth,
            "anchorlink": False,
            "permalink": False,
            "slugify": _slugifier(),
        },
    }
    return {name: cfg for name, cfg in configs.items() if name in profile.markdown_extensions}


def _check_meta_typos(meta: Dict[str, Any], profile: Profile) -> List[str]:
    """front matter のキーの打ち間違いらしきものを指摘する。

    未知のキーをすべて警告すると、覚え書きとして自由に書いた項目まで指摘してしまう。
    「意味を持つキーによく似ているのに一致しない」ものだけを対象にする。
    """
    known = _known_meta_keys(profile)
    warnings: List[str] = []

    for key in meta:
        if key.startswith("_") or key in known:
            continue
        matches = difflib.get_close_matches(key, sorted(known), n=1, cutoff=TYPO_CUTOFF)
        # 似ているキーが同じ front matter に既にあるなら、書き分けているだけ。
        if matches and matches[0] not in meta:
            warnings.append(
                f"front matter の '{key}' は '{matches[0]}' の打ち間違いではありませんか"
            )
    return warnings


def _known_meta_keys(profile: Profile) -> set:
    """そのプロファイルで意味を持つ front matter のキー。"""
    return {
        *RESERVED_META_KEYS,
        *profile.meta_header,
        *keywords.get("index_date"),
        *keywords.get("severity"),
        *keywords.get("include"),
        *keywords.get("catalog_names"),
        *keywords.get("catalog_stages"),
        *keywords.get("process_owner"),
        *keywords.get("process_book"),
        *keywords.get("period"),
        *keywords.get("period_start"),
    }


#: 「短い語が並ぶ列」とみなす文字数の上限。これを超える列は文章とみなす。
COMPACT_COLUMN_CHARS = 12

#: 列を詰める対象にする列数の上限。これを超える表は詰めない。
#:
#: 列が多い表はもともと余りが無く、詰めても得るものが小さい。一方で、詰めた列は
#: 折り返せないため紙幅を超えやすい。**紙では横スクロールで逃げられず切れる。**
#: A4（左右 12mm 余白 = 703px）で 3,338 表を実測したところ、切れた 26 表は
#: すべて 6 列以上だった。5 列までに絞ると 0 件になる。
COMPACT_MAX_COLUMNS = 5


def _compact_short_columns(soup: BeautifulSoup) -> None:
    """短い語しか入らない列に印を付け、内容なりの幅まで詰めさせる。

    表は紙面いっぱいに広げるため、中身が少ないと余りが全列へ均等に配られ、
    どの列もすかすかになる（``区分 | 件数 | 前週比`` が 292px ずつなど）。
    短い列を内容なりに詰めれば、余りは残った列――多くは最後の列――に集まる。

    **最後の列に ``width: 100%`` を与える手は採らない。** それだと他の列が下限まで
    潰され、文章の入った列が 1 文字ずつ縦に積まれる（この既定は 2026-09-18 に
    同じ理由で外している）。詰めるのは短い列だけにして、文章の列には触らない。

    判定は列ごと。見出しを含むどのセルも ``COMPACT_COLUMN_CHARS`` 以下で、箇条書きや
    段落を抱えていないことを見る。最後の列は余りの受け皿なので対象にしない。
    """
    for table in soup.find_all("table"):
        if "dm-meta" in (table.get("class") or []):
            continue
        rows = [row for row in table.find_all("tr") if row.find(["td", "th"])]
        columns = _table_columns(rows)
        if len(columns) > COMPACT_MAX_COLUMNS:
            continue
        for index, cells in enumerate(columns[:-1]):
            if _is_compact_column(cells):
                for cell in cells:
                    add_class(cell, "dm-cell-compact")


def _table_columns(rows: List[Any]) -> List[List[Any]]:
    """行の並びを列ごとのセルの並びに組み替える。

    ``colspan`` を持つ行（索引のディレクトリ見出しなど）は桁が合わないため、
    列として数えない。
    """
    columns: List[List[Any]] = []
    for row in rows:
        cells = row.find_all(["td", "th"], recursive=False)
        if any(cell.get("colspan") or cell.get("rowspan") for cell in cells):
            continue
        for index, cell in enumerate(cells):
            while len(columns) <= index:
                columns.append([])
            columns[index].append(cell)
    return columns


def _is_compact_column(cells: List[Any]) -> bool:
    """列のどのセルも短い語だけか。"""
    if not cells:
        return False
    for cell in cells:
        if cell.find(["ul", "ol", "p", "table", "pre", "br"]):
            return False
        if len(cell.get_text(strip=True)) > COMPACT_COLUMN_CHARS:
            return False
    return True


def _wrap_tables(soup: BeautifulSoup) -> None:
    """表を ``<div class="dm-table-scroll">`` で包む。

    列が多い表や、折り返せない語を含む表は、紙面より広くなることがある。包まずに
    ``overflow-x`` を表そのものへ与えるには ``display: block`` にするしかなく、それだと
    表が紙面いっぱいに広がらなくなる（内側の表が内容の幅まで縮む）。包みの方を
    スクロールさせれば、収まる表は今までどおり紙面いっぱいのまま、はみ出す表だけが
    横スクロールになる。

    画面が狭いほど効く。スマートフォンの幅では多くの表がスクロールに逃げる。
    """
    for table in soup.find_all("table"):
        parent = table.parent
        if parent is not None and "dm-table-scroll" in (parent.get("class") or []):
            continue
        wrapper = soup.new_tag("div")
        wrapper["class"] = ["dm-table-scroll"]
        table.insert_before(wrapper)
        wrapper.append(table.extract())


def _unescape_table_pipes(soup: BeautifulSoup) -> None:
    r"""表のセルのコードに残る ``\|`` を ``|`` に戻す。

    Markdown の表はセルの区切りをインラインコードより先に判定するため、コードの中でも
    パイプは ``\|`` と書かないと列が割れる。ところがコードの中は元の文字をそのまま出す
    決まりなので、エスケープが外れずバックスラッシュが残る。GitHub は表の中に限って
    先に外すため、同じ ``.md`` が両方で違って見えていた。

    コードの外は Markdown が外してくれるので、ここで見るのはコードの中だけでよい。
    """
    for cell in soup.find_all(["td", "th"]):
        for code in cell.find_all("code"):
            for text in code.find_all(string=True):
                if r"\|" in text:
                    text.replace_with(text.replace(r"\|", "|"))


def _rewrite_document_links(soup: BeautifulSoup) -> List[str]:
    """``[設計書](設計書.md)`` のような文書間リンクを ``.html`` に向け直す。

    ディレクトリを一括変換すると入力の階層をそのまま出力に写すため、相対リンクは
    拡張子だけ替えれば通る。書き換えないと、配布した HTML のリンクが軒並み切れる。

    外部 URL（``http:`` ``mailto:`` など）とページ内アンカー（``#...``）は触らない。
    リンク先が実際に変換されるかまでは見ない（入力に含まれない .md への参照は
    書き換えても切れたままだが、含まれる場合のほうが圧倒的に多いため）。

    ``[ADR](adr/)`` のようなディレクトリへのリンクは警告する。GitHub 上では
    ディレクトリを開けるため Markdown としては正しいが、HTML には向け先が無く、
    変換したときだけ切れる。書き換えようがないので、書き手に気づかせる。
    """
    warnings: List[str] = []
    for link in soup.find_all("a", href=True):
        href = link["href"].strip()
        if not href or _EXTERNAL_LINK_RE.match(href):
            continue

        # フラグメントとクエリは温存する（設計書.md#概要 → 設計書.html#概要）。
        path, separator, suffix = _split_link(href)
        if path.lower().endswith(LINK_EXTS):
            base = path.rsplit(".", 1)[0]
            link["href"] = f"{base}.html{separator}{suffix}"
        elif _looks_like_directory(path):
            warnings.append(
                f"ディレクトリへのリンクは HTML では開けません: {href}"
                "（リンク先のファイルを指してください）"
            )
    return warnings


def _looks_like_directory(path: str) -> bool:
    """リンク先がディレクトリを指していそうなら True。

    ``/`` で終わるもののほか、拡張子を持たない相対パスも対象にする。
    ``.`` や ``..`` だけの段は、それ自体が向け先ではないので数えない。
    """
    if not path or path.startswith("#"):
        return False
    if path.endswith("/"):
        return True
    last = path.rsplit("/", 1)[-1]
    if not last or set(last) == {"."}:
        return False
    return "." not in last


def _split_link(href: str) -> tuple:
    """``href`` を (パス, 区切り文字, 残り) に分ける。区切りが無ければ ("", "")。"""
    for separator in ("#", "?"):
        if separator in href:
            path, suffix = href.split(separator, 1)
            return path, separator, suffix
    return href, "", ""


def _wrap_sections(soup: BeautifulSoup) -> None:
    """トップレベルの見出しごとに ``<section>`` で包む。

    ダッシュボードのカード配置や ``@media print`` の改ページを、テンプレート側の
    CSS だけで書けるようにするための構造の正規化。ルールより先に行う。
    """
    levels = sorted({heading_level(h) for h in soup.find_all(HEADING_TAGS)} - {0})
    if not levels:
        return
    top = levels[0]
    for heading in list(soup.find_all(f"h{top}")):
        if heading.parent is not soup:
            continue
        section = wrap_section(soup, heading, "dm-section", f"dm-section--h{top}")
        if heading.get("id"):
            section["data-heading-id"] = heading["id"]


def _build_toc(soup: BeautifulSoup, profile: Profile) -> List[Dict[str, Any]]:
    """目次の項目を DOM から組み立てる。

    Markdown 拡張の ``md.toc`` ではなく、ルール適用後の DOM から作る。
    ルールが見出しを足したり消したりしても目次と本文がずれない。
    """
    if not profile.toc.enabled:
        return []

    items: List[Dict[str, Any]] = []
    for heading in soup.find_all(HEADING_TAGS):
        level = heading_level(heading)
        if level > profile.toc.depth:
            continue
        anchor = heading.get("id")
        if not anchor:
            anchor = f"dm-heading-{len(items) + 1}"
            heading["id"] = anchor
        items.append({"level": level, "text": _heading_text(heading), "anchor": anchor})

    if profile.toc.numbering:
        _number_toc(items, soup)
    return items


#: 見出しに差し込む UI 要素。目次の文言からは除く。
UI_CLASSES = ("dm-step__number", "dm-step__check", "dm-heading__number",
              "dm-topic__number")


def _heading_text(heading: Any) -> str:
    """見出しの文言。ルールが差し込んだ番号やチェック欄は含めない。

    ``<h2><span class="dm-step__number">1</span>手順 1: 事前確認<label …>完了</label></h2>``
    のような見出しから ``手順 1: 事前確認`` だけを取り出す。
    """
    parts = [
        str(node) for node in heading.find_all(string=True)
        if not node.find_parent(class_=list(UI_CLASSES))
    ]
    return "".join(parts).strip()


def _number_toc(items: List[Dict[str, Any]], soup: BeautifulSoup) -> None:
    """章番号 (1. / 1.1 / 1.1.1) を目次と見出しの両方に振る。"""
    counters: List[int] = []
    for item in items:
        level = item["level"]
        if len(counters) < level:
            counters.extend([0] * (level - len(counters)))
        else:
            del counters[level:]
        counters[level - 1] += 1
        number = ".".join(str(n) for n in counters[:level])
        item["number"] = number

        heading = soup.find(id=item["anchor"])
        if heading is not None:
            label = soup.new_tag("span")
            add_class(label, "dm-heading__number")
            label.string = number
            heading.insert(0, label)


def _build_meta_header(profile: Profile, meta: Dict[str, Any]) -> List[Dict[str, str]]:
    """``meta_header`` に並べたキーを、front matter の値と組にして返す。"""
    rows = []
    for key in profile.meta_header:
        text = meta_to_text(meta.get(key))
        if text:
            rows.append({"label": key, "value": text})
    return rows


def _resolve_title(meta: Dict[str, Any], soup: BeautifulSoup,
                   source_path: Optional[Path]) -> str:
    """front matter の title → 最初の見出し → ファイル名 の順で決める。"""
    title = meta_to_text(meta.get("title"))
    if title:
        return title

    heading = soup.find(HEADING_TAGS)
    if heading is not None:
        # 章番号や完了チェックはルールが差し込んだ UI なので、タイトルに含めない
        # （spec で「1概要」のようになるのを防ぐ）。
        text = _heading_text(heading)
        if text:
            return text

    return source_path.stem if source_path is not None else FALLBACK_TITLE
