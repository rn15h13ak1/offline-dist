"""プロファイル定義 (YAML) の読み込みと検証。

docmold の設定は「どんな表現があるか」の一覧に徹する。判定ロジックは持たず、
``profiles`` (構造 × 意味づけ × 見た目の組み合わせ) と ``themes`` (CSS 変数) だけを持つ。

読み込み順:
  1. 同梱の ``profiles.yaml``  : 既定のプロファイル定義 (常に読む)
  2. ユーザ設定 ``config.yaml`` : 1 に再帰マージ。差分だけ書けばよい

ユーザ設定は ``--config`` で指したもの、無ければ ``docmold.py と同じフォルダ/config.yaml``。
作業フォルダは見ない（別のフォルダから動かしたときに、そのフォルダの設定を拾わないため）。

知らない項目は、似た項目を添えて、すべてまとめて示して止める（ほかのツールと同じ形）。
"""
from __future__ import annotations

import copy
import difflib
import re
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, Dict, List, Mapping, Optional, Sequence, Tuple

try:
    import yaml
except ImportError as e:  # pragma: no cover - 依存が無い環境向けの案内
    raise ImportError("PyYAML is required. Install with: pip install pyyaml") from e

SCRIPT_DIR = Path(__file__).resolve().parent

#: 同梱の既定プロファイル定義。ユーザ設定はこの上に重なる。
BUNDLED_PROFILES_PATH = SCRIPT_DIR / "profiles.yaml"

#: すべてのプロファイルに共通で入れる Markdown 拡張。
BASE_EXTENSIONS = [
    "extra",        # tables / fenced_code / def_list / attr_list など
    "admonition",   # !!! note 形式の注意ボックス
    "sane_lists",
    "toc",
    "codehilite",
]

#: 既定プロファイル名 (front matter に type が無いときに使う)。
DEFAULT_PROFILE = "default"

#: 取り込み専用の断片。ディレクトリをまとめて変換するとき、単独では変換しない。
FRAGMENT_PROFILE = "fragment"

#: 本文の生 HTML の扱い。"strict" = 許可リストで絞る / "none" = 素通し。
SANITIZE_MODES = ("strict", "none")

#: トップレベルで指定が無いときの既定。安全側に倒す。
DEFAULT_SANITIZE = "strict"


def suggest_key(key: Any, candidates: Any) -> Optional[str]:
    """書き間違いと思われる項目に、似た項目を 1 つ返す。無ければ None。

    大文字・小文字だけの違いを先に見る。候補は名前順に並べてから比べるので、同じ書き間違いには毎回同じ項目を示す。
    """
    names = sorted(str(c) for c in candidates)
    lowered = str(key).lower()
    for name in names:
        if name.lower() == lowered:
            return name
    close = difflib.get_close_matches(str(key), names, n=1, cutoff=0.6)
    return close[0] if close else None


def unknown_keys(section: Any, allowed: Any, path: str = "") -> List[str]:
    """``section`` の中の、``allowed`` に無い項目の文の一覧。マッピングでなければ空。

    文は「profiles.default.tocc は知らない項目です（toc の書き間違いでは？）」の形。path は節の名前（最上位なら ""）。
    """
    if not isinstance(section, Mapping):
        return []
    problems = []
    for key in section:
        if key in allowed:
            continue
        name = f"{path}.{key}" if path else str(key)
        near = suggest_key(key, allowed)
        hint = f"（{near} の書き間違いでは？）" if near else ""
        problems.append(f"{name} は知らない項目です{hint}")
    return problems


def problems_text(problems: List[str]) -> str:
    """誤りが 1 つならその文、複数なら 1 行に 1 つずつ並べた文。"""
    if len(problems) == 1:
        return problems[0]
    return "知らない項目があります:\n  " + "\n  ".join(problems)


def _raise_unknown(section: Any, allowed: Any, path: str) -> None:
    problems = unknown_keys(section, allowed, path)
    if problems:
        raise ConfigError(problems_text(problems))


def parse_bool(value: Any, where: str) -> bool:
    """真偽値の項目。"false"（文字列）は真になってしまうので、true / false 以外は止める。"""
    if value is None:
        return False
    if not isinstance(value, bool):
        raise ConfigError(f"{where}: true か false で指定してください（実際: {value!r}）")
    return value


def parse_allow_schemes(value: Any, where: str) -> List[str]:
    """``allow_schemes`` を検証して小文字の並びにする。

    通せるのは ``sanitize.CONFIGURABLE_SCHEMES`` だけ。``javascript`` のように
    script が動くものは、書かれていてもエラーにする（意図が危ういため黙って捨てない）。
    """
    from sanitize import CONFIGURABLE_SCHEMES

    if value is None:
        return []
    if isinstance(value, str) or not isinstance(value, Sequence):
        raise ConfigError(f"{where}.allow_schemes: リストで指定してください（実際: {value!r}）")

    names = []
    for item in value:
        name = str(item).strip().lower().rstrip(":")
        if name not in CONFIGURABLE_SCHEMES:
            raise ConfigError(
                f"{where}.allow_schemes: {name!r} は通せません"
                f"（指定できるのは {' / '.join(CONFIGURABLE_SCHEMES)}）"
            )
        if name not in names:
            names.append(name)
    return names


def parse_sanitize(value: Any, where: str) -> str:
    """``sanitize`` の指定を "strict" / "none" に正規化する。"""
    if value is None:
        return DEFAULT_SANITIZE
    if value is True:
        return "strict"
    if value is False:
        return "none"
    text = str(value).strip().lower()
    if text in SANITIZE_MODES:
        return text
    if text in ("off", "false", "no"):
        return "none"
    raise ConfigError(
        f"{where}.sanitize: {' / '.join(SANITIZE_MODES)} か true / false で指定してください"
        f"（実際: {value!r}）"
    )


class ConfigError(ValueError):
    """設定ファイルに問題があるときに送出。"""


@dataclass(frozen=True)
class TocSettings:
    """目次の設定。``toc: false`` / ``toc: true`` / ``toc: {depth, numbering}``。"""

    enabled: bool = False
    depth: int = 3
    numbering: bool = False

    _KNOWN = ("depth", "numbering")

    @classmethod
    def parse(cls, value: Any, where: str) -> "TocSettings":
        if value is None or value is False:
            return cls(enabled=False)
        if value is True:
            return cls(enabled=True)
        if isinstance(value, Mapping):
            _raise_unknown(value, cls._KNOWN, f"{where}.toc")
            depth = value.get("depth", 3)
            # 真偽値は int の仲間で、true が 1 になる。2.7 や .inf を int() に通すと 2 やトレースバックになる
            if isinstance(depth, bool) or not isinstance(depth, int):
                raise ConfigError(f"{where}.toc.depth: 整数で指定してください（実際: {depth!r}）")
            if not 1 <= depth <= 6:
                raise ConfigError(f"{where}.toc.depth: 1〜6 で指定してください（実際: {depth}）")
            return cls(enabled=True, depth=depth,
                       numbering=parse_bool(value.get("numbering"), f"{where}.toc.numbering"))
        raise ConfigError(f"{where}.toc: bool かマッピングで指定してください")


@dataclass(frozen=True)
class PrintSettings:
    """印刷 (PDF 化) 前提の設定。``@media print`` に効く。"""

    page_break_per_h1: bool = False
    page_break_per_h2: bool = False
    cover_page: bool = False
    # 用紙の大きさと向き。空なら themes/print.css の既定（A4 縦）
    page_size: str = ""
    page_orientation: str = ""

    _KNOWN = ("page_break_per_h1", "page_break_per_h2", "cover_page")
    _PAGE_KEYS = ("size", "orientation")
    # CSS の @page の size に書ける名前。CSS にそのまま埋め込むため、ここに無いものは通さない
    _PAGE_SIZES = ("A3", "A4", "A5", "B4", "B5", "JIS-B4", "JIS-B5", "letter", "legal", "ledger")
    _ORIENTATIONS = ("portrait", "landscape")

    @classmethod
    def parse(cls, value: Any, where: str) -> "PrintSettings":
        if not value:
            return cls()
        if not isinstance(value, Mapping):
            raise ConfigError(f"{where}.print: マッピングで指定してください")
        _raise_unknown(value, (*cls._KNOWN, "page"), f"{where}.print")
        size, orientation = cls._parse_page(value.get("page"), f"{where}.print.page")
        return cls(**{key: parse_bool(value.get(key), f"{where}.print.{key}") for key in cls._KNOWN},
                   page_size=size, page_orientation=orientation)

    @classmethod
    def _parse_page(cls, value: Any, where: str) -> Tuple[str, str]:
        if value is None:
            return "", ""
        if not isinstance(value, Mapping):
            raise ConfigError(f"{where}: マッピングで指定してください（例: {{size: A4, orientation: landscape}}）")
        _raise_unknown(value, cls._PAGE_KEYS, where)
        size = str(value.get("size") or "")
        if size:
            matched = [name for name in cls._PAGE_SIZES if name.lower() == size.lower()]
            if not matched:
                raise ConfigError(f"{where}.size: {', '.join(cls._PAGE_SIZES)} のどれかを指定してください"
                                  f"（実際: {size}）")
            size = matched[0]
        orientation = str(value.get("orientation") or "")
        if orientation and orientation not in cls._ORIENTATIONS:
            raise ConfigError(f"{where}.orientation: portrait か landscape を指定してください"
                              f"（実際: {orientation}）")
        return size, orientation

    def page_css(self) -> str:
        """``@page`` の size。用紙を指定していなければ空文字。"""
        if not (self.page_size or self.page_orientation):
            return ""
        size = " ".join(v for v in (self.page_size, self.page_orientation) if v)
        return f"@media print {{\n  @page {{ size: {size}; }}\n}}"


#: CDN 参照の既定 URL。再現性のためメジャーバージョンを固定する。
DEFAULT_MERMAID_URL = "https://cdn.jsdelivr.net/npm/mermaid@11/dist/mermaid.min.js"


@dataclass(frozen=True)
class MermaidSettings:
    """図の描画に使う mermaid.js の入手先。

    ``false``            無効（既定）
    ``true`` / bundled   同梱の assets/mermaid.min.js を埋め込む（外部参照ゼロを保つ）
    ``cdn``              既定の CDN を参照する（HTML は軽いが、閲覧時にインターネットが要る）
    ``{url: ...}``       指定した URL を参照する（社内にホスティングした場合など）
    """

    enabled: bool = False
    bundled: bool = True
    url: str = ""
    integrity: str = ""

    _KNOWN = ("source", "url", "integrity")

    @classmethod
    def parse(cls, value: Any, where: str) -> "MermaidSettings":
        if value is None or value is False:
            return cls()
        if value is True:
            return cls(enabled=True, bundled=True)

        if isinstance(value, str):
            keyword = value.strip().lower()
            if keyword in ("bundled", "embed", "local"):
                return cls(enabled=True, bundled=True)
            if keyword == "cdn":
                return cls(enabled=True, bundled=False, url=DEFAULT_MERMAID_URL)
            if keyword.startswith(("http://", "https://")):
                return cls(enabled=True, bundled=False, url=value.strip())
            raise ConfigError(
                f"{where}.mermaid: 'bundled' / 'cdn' / URL / true / false で指定してください"
                f"（実際: {value!r}）"
            )

        if isinstance(value, Mapping):
            _raise_unknown(value, cls._KNOWN, f"{where}.mermaid")
            source = str(value.get("source", "cdn")).lower()
            url = str(value.get("url", "") or "")
            if source in ("bundled", "embed", "local"):
                if url:
                    raise ConfigError(f"{where}.mermaid: source: bundled に url は指定できません")
                return cls(enabled=True, bundled=True)
            if url and not url.startswith(("http://", "https://")):
                raise ConfigError(f"{where}.mermaid.url: http(s) の URL で指定してください")
            return cls(
                enabled=True,
                bundled=False,
                url=url or DEFAULT_MERMAID_URL,
                integrity=str(value.get("integrity", "") or ""),
            )

        raise ConfigError(f"{where}.mermaid: bool / 文字列 / マッピングで指定してください")


@dataclass(frozen=True)
class Theme:
    """見た目。CSS 変数として ``:root`` に流し込む。"""

    name: str
    variables: Dict[str, str] = field(default_factory=dict)

    def css_variables(self) -> str:
        """``--accent: #00529b;`` の形に展開する (キーの ``_`` は ``-`` に統一)。"""
        return "\n".join(
            f"  --{key.replace('_', '-')}: {value};"
            for key, value in self.variables.items()
        )


@dataclass(frozen=True)
class Profile:
    """テンプレート (構造) × ルール (意味づけ) × テーマ (見た目) の組み合わせ。"""

    name: str
    template: str = "article.html"
    theme: str = "corporate"
    toc: TocSettings = field(default_factory=TocSettings)
    rules: List[str] = field(default_factory=list)
    extensions: List[str] = field(default_factory=list)
    meta_header: List[str] = field(default_factory=list)
    print: PrintSettings = field(default_factory=PrintSettings)
    watermark: Optional[str] = None
    mermaid: MermaidSettings = field(default_factory=MermaidSettings)
    sanitize: str = DEFAULT_SANITIZE
    allow_schemes: List[str] = field(default_factory=list)
    description: str = ""
    #: 文書の front matter の既定値。文書に書いたものが勝つ（マッピングは 1 段だけ重ねる）。
    front_matter: Dict[str, Any] = field(default_factory=dict)

    _KNOWN_KEYS = frozenset({
        "template", "theme", "toc", "rules", "extensions",
        "meta_header", "print", "watermark", "mermaid", "sanitize",
        "allow_schemes", "description", "front_matter",
    })

    @classmethod
    def parse(cls, name: str, value: Any,
              default_sanitize: str = DEFAULT_SANITIZE) -> "Profile":
        where = f"profiles.{name}"
        if value is None:
            value = {}
        if not isinstance(value, Mapping):
            raise ConfigError(f"{where}: マッピングで指定してください")
        _raise_unknown(value, cls._KNOWN_KEYS, where)

        template = str(value.get("template", "article.html"))
        if "/" in template or "\\" in template or template.startswith("."):
            raise ConfigError(
                f"{where}.template: templates/（か template_dirs: のフォルダ）直下のファイル名で指定してください")

        return cls(
            name=name,
            template=template,
            theme=str(value.get("theme", "corporate")),
            toc=TocSettings.parse(value.get("toc"), where),
            rules=_as_str_list(value.get("rules"), f"{where}.rules"),
            extensions=_as_str_list(value.get("extensions"), f"{where}.extensions"),
            meta_header=_as_str_list(value.get("meta_header"), f"{where}.meta_header"),
            print=PrintSettings.parse(value.get("print"), where),
            watermark=_optional_str(value.get("watermark")),
            mermaid=MermaidSettings.parse(value.get("mermaid"), where),
            sanitize=(
                parse_sanitize(value["sanitize"], where)
                if "sanitize" in value else default_sanitize
            ),
            allow_schemes=parse_allow_schemes(value.get("allow_schemes"), where),
            description=str(value.get("description", "")),
            front_matter=_parse_front_matter(value.get("front_matter"), where),
        )

    def with_front_matter(self, meta: Dict[str, Any]) -> Dict[str, Any]:
        """``front_matter`` の既定値に文書の ``meta`` を重ねたもの。

        両方がマッピングのキーは 1 段だけ重ねる（文書のタグの定義で、共通の定義に分類を足したり
        同じ名前の分類を置き換えたりできるように）。それ以外は文書に書いたものが勝つ。
        """
        if not self.front_matter:
            return meta
        merged: Dict[str, Any] = {}
        for key, value in self.front_matter.items():
            mine = meta.get(key)
            if isinstance(value, Mapping) and isinstance(mine, Mapping):
                merged[key] = {**value, **mine}
            elif key in meta:
                merged[key] = mine
            else:
                merged[key] = copy.deepcopy(value)
        for key, value in meta.items():
            if key not in merged:
                merged[key] = value
        return merged

    @property
    def markdown_extensions(self) -> List[str]:
        """基本拡張 + プロファイル固有拡張。重複は除き、記述順を維持する。"""
        result: List[str] = []
        for ext in [*BASE_EXTENSIONS, *self.extensions]:
            if ext not in result:
                result.append(ext)
        return result


@dataclass(frozen=True)
class MenuOutput:
    """``menu_outputs:`` の 1 件。メニューで、ファイル名が ``pattern`` に当たる .md の出力先を決める。"""

    #: 書いたままの正規表現（画面に出す）
    source: str
    pattern: "re.Pattern[str]"
    #: 出力先のフォルダ（設定ファイルから見た相対パスを解決したもの）
    output: Path

    _KNOWN = ("input", "output")

    def matches(self, path: Path) -> bool:
        """ファイル名（フォルダを除く）が、正規表現にまるごと当たるか。"""
        return self.pattern.fullmatch(path.name) is not None


def parse_menu_outputs(value: Any, config_path: Optional[Path]) -> List[MenuOutput]:
    """``menu_outputs:`` を検証する。出力先は設定ファイルから見た相対パスで書く。

    ファイル名の大小は区別しない（Windows のファイル名が区別しないため）。フォルダの有無は見ない
    （無ければ変換のときに作る）。
    """
    if value is None:
        return []
    if not isinstance(value, list):
        raise ConfigError("menu_outputs: リストで指定してください（- input: ... / output: ... を並べます）")
    base = config_path.parent if config_path is not None else Path.cwd()
    entries: List[MenuOutput] = []
    for number, item in enumerate(value, 1):
        where = f"menu_outputs[{number}]"
        if not isinstance(item, Mapping):
            raise ConfigError(f"{where}: input と output を書いてください")
        _raise_unknown(item, MenuOutput._KNOWN, where)
        source, output = item.get("input"), item.get("output")
        for key, text in (("input", source), ("output", output)):
            if not isinstance(text, str) or not text.strip():
                raise ConfigError(f"{where}: {key} を文字列で書いてください")
        try:
            pattern = re.compile(source, re.IGNORECASE)
        except re.error as e:
            raise ConfigError(
                f"{where}: input の正規表現を読めません: {e}\n"
                "  → 「\\」を含む正規表現は '' で囲んで書いてください"
            ) from None
        path = Path(output).expanduser()
        if not path.is_absolute():
            path = base / path
        entries.append(MenuOutput(source=source, pattern=pattern, output=path))
    return entries


@dataclass(frozen=True)
class Config:
    """設定ファイル全体。"""

    profiles: Dict[str, Profile]
    themes: Dict[str, Theme]
    keywords: Dict[str, List[str]] = field(default_factory=dict)
    # template_dirs: / theme_dirs: に並べた、ツールの外のフォルダ（解決済みの絶対パス）
    template_dirs: List[Path] = field(default_factory=list)
    theme_dirs: List[Path] = field(default_factory=list)
    config_path: Optional[Path] = None
    # menu_outputs: メニューで使う、ファイル名ごとの出力先（並べた順に見る）
    menu_outputs: List[MenuOutput] = field(default_factory=list)

    def menu_output_for(self, path: Path) -> Optional[MenuOutput]:
        """``path`` のファイル名に当たる、最初の ``menu_outputs:`` の定義。無ければ None。"""
        return next((entry for entry in self.menu_outputs if entry.matches(path)), None)

    def profile(self, name: str) -> Profile:
        """名前でプロファイルを引く。未定義なら ``KeyError``。"""
        return self.profiles[name]

    def theme_for(self, profile: Profile) -> Theme:
        try:
            return self.themes[profile.theme]
        except KeyError:
            raise ConfigError(
                f"profiles.{profile.name}: 未定義のテーマ '{profile.theme}'"
                f"（定義済み: {', '.join(sorted(self.themes)) or 'なし'}）"
            ) from None

    @property
    def type_names(self) -> List[str]:
        """front matter の ``type:`` に書ける名前の一覧。"""
        return sorted(self.profiles)


def _as_str_list(value: Any, where: str) -> List[str]:
    if value is None:
        return []
    if isinstance(value, str):
        return [value]
    if isinstance(value, list):
        return [str(item) for item in value]
    raise ConfigError(f"{where}: リストで指定してください")


def _parse_front_matter(value: Any, where: str) -> Dict[str, Any]:
    """``front_matter:`` を検証する。種類を決める ``type`` は書けない（種類はもう決まっているため）。"""
    if value is None:
        return {}
    if not isinstance(value, Mapping):
        raise ConfigError(f"{where}.front_matter: マッピングで指定してください（実際: {value!r}）")
    if "type" in value:
        raise ConfigError(f"{where}.front_matter: type は書けません（種類は profiles のキーで決まります）")
    return {str(key): item for key, item in value.items()}


def _optional_str(value: Any) -> Optional[str]:
    if value is None or value is False or value == "":
        return None
    return str(value)


def _deep_merge(base: Dict[str, Any], override: Mapping[str, Any]) -> Dict[str, Any]:
    """``override`` を ``base`` に再帰的に重ねる (``base`` は破壊しない)。

    マッピング同士はキー単位でマージし、それ以外 (リスト・スカラ) は置き換える。
    ``rules`` を差分ではなく丸ごと指定できるようにするため、リストは追記しない。
    """
    result = copy.deepcopy(dict(base))
    for key, value in override.items():
        if isinstance(value, Mapping) and isinstance(result.get(key), Mapping):
            result[key] = _deep_merge(dict(result[key]), value)
        else:
            result[key] = copy.deepcopy(value)
    return result


def _load_yaml(path: Path) -> Dict[str, Any]:
    """設定ファイルを読む。UTF-8 で、BOM 付き（メモ帳の「UTF-8 (BOM 付き)」）でもよい。

    メモ帳の ANSI（CP932）で保存したものは、トレースバックにせず、保存し直す手順を示して止める。
    """
    try:
        raw = yaml.safe_load(path.read_text(encoding="utf-8-sig"))
    except UnicodeDecodeError:
        raise ConfigError(
            f"{path}: UTF-8 として読めません\n"
            "  → メモ帳で開き、「名前を付けて保存」で文字コードを「UTF-8」にして保存し直してください"
        ) from None
    except yaml.YAMLError as e:
        raise ConfigError(
            f"{path}: YAML として読めません\n  {e}\n"
            "  → 示された行の字下げ（空白の数）と、「:」の後の空白を確かめてください。"
            "値に「:」や「#」を含むときは \"\" で囲みます"
        ) from e
    except OSError as e:
        raise ConfigError(f"{path}: 読み込めません: {e}") from e
    if raw is None:
        return {}
    if not isinstance(raw, dict):
        raise ConfigError(
            f"{path}: 形が不正です（「profiles:」などの節を並べる形で書いてください。"
            "config.example.yaml を参考にしてください）"
        )
    return raw


def _load_rule_modules(value: Any, config_path: Optional[Path]) -> None:
    """``rule_modules:`` に並べたルールのファイルを読み込む。パスは設定ファイルから見た相対。"""
    if value is None:
        return
    base = config_path.parent if config_path is not None else Path.cwd()
    from rules import RuleError, load_rule_file  # 循環 import 回避のため遅延 import

    for entry in _as_str_list(value, "rule_modules"):
        path = Path(entry).expanduser()
        if not path.is_absolute():
            path = base / path
        try:
            load_rule_file(path)
        except RuleError as e:
            raise ConfigError(f"rule_modules: {e}") from e


def _resolve_dirs(value: Any, key: str, config_path: Optional[Path]) -> List[Path]:
    """``template_dirs:`` / ``theme_dirs:`` のフォルダを解決する。パスは設定ファイルから見た相対。

    無いフォルダは設定エラーにする。打ち間違いで、黙って同梱のものに戻らないように。
    """
    base = config_path.parent if config_path is not None else Path.cwd()
    dirs: List[Path] = []
    for entry in _as_str_list(value, key):
        path = Path(entry).expanduser()
        if not path.is_absolute():
            path = base / path
        if not path.is_dir():
            raise ConfigError(f"{key}: フォルダが見つかりません: {path}")
        dirs.append(path.resolve())
    return dirs


TOP_LEVEL_KEYS = frozenset({
    "profiles", "themes", "keywords", "sanitize", "rule_modules", "template_dirs", "theme_dirs",
    "menu_outputs",
})


def build_config(raw: Mapping[str, Any], config_path: Optional[Path] = None) -> Config:
    """マージ済みの dict を検証して ``Config`` にする。

    検証のエラーには ``config_path`` を前に付ける。別のツールの ``config.yaml`` を拾ったときに、
    どのファイルが原因かを分かるようにするため。
    """
    from rules import RuleError, check_bundled  # 循環 import 回避のため遅延 import

    try:
        check_bundled()
    except RuleError as e:
        raise ConfigError(str(e)) from e

    try:
        return _build_config(raw, config_path)
    except ConfigError as e:
        if config_path is None or str(e).startswith(f"{config_path}: "):
            raise
        raise ConfigError(f"{config_path}: {e}") from e


def _all_unknown_keys(raw: Mapping[str, Any]) -> List[str]:
    """設定全体の知らない項目を、節をまたいですべて集める。最初の 1 つで止めると、直しては動かすを繰り返すため。

    形の誤り（マッピングでないなど）は見ない。後の検証が節ごとに止める。
    """
    from rules import keywords as keyword_registry  # 循環 import 回避のため遅延 import

    problems = unknown_keys(raw, TOP_LEVEL_KEYS)
    problems += unknown_keys(raw.get("keywords"), keyword_registry.GROUPS, "keywords")
    menu_outputs = raw.get("menu_outputs")
    if isinstance(menu_outputs, list):
        for number, item in enumerate(menu_outputs, 1):
            problems += unknown_keys(item, MenuOutput._KNOWN, f"menu_outputs[{number}]")
    profiles = raw.get("profiles")
    if isinstance(profiles, Mapping):
        for name, value in profiles.items():
            where = f"profiles.{name}"
            problems += unknown_keys(value, Profile._KNOWN_KEYS, where)
            if not isinstance(value, Mapping):
                continue
            problems += unknown_keys(value.get("toc"), TocSettings._KNOWN, f"{where}.toc")
            problems += unknown_keys(value.get("mermaid"), MermaidSettings._KNOWN, f"{where}.mermaid")
            print_section = value.get("print")
            problems += unknown_keys(print_section, (*PrintSettings._KNOWN, "page"), f"{where}.print")
            if isinstance(print_section, Mapping):
                problems += unknown_keys(print_section.get("page"), PrintSettings._PAGE_KEYS, f"{where}.print.page")
    return problems


def _build_config(raw: Mapping[str, Any], config_path: Optional[Path]) -> Config:
    problems = _all_unknown_keys(raw)
    if problems:
        raise ConfigError(problems_text(problems))

    # 未登録のルール名の検査より先に読む。ここで登録したルールを profiles から使えるようにするため。
    _load_rule_modules(raw.get("rule_modules"), config_path)

    # トップレベルの sanitize は全プロファイルの既定。種類ごとの指定が優先する。
    default_sanitize = parse_sanitize(raw.get("sanitize"), "")

    themes_raw = raw.get("themes") or {}
    if not isinstance(themes_raw, Mapping):
        raise ConfigError("themes: マッピングで指定してください")
    themes: Dict[str, Theme] = {}
    for name, value in themes_raw.items():
        if value is None:
            value = {}
        if not isinstance(value, Mapping):
            raise ConfigError(f"themes.{name}: マッピングで指定してください")
        themes[str(name)] = Theme(
            name=str(name),
            variables={str(k): str(v) for k, v in value.items()},
        )

    keywords_raw = raw.get("keywords") or {}
    if not isinstance(keywords_raw, Mapping):
        raise ConfigError("keywords: マッピングで指定してください")
    from rules import keywords as keyword_registry  # 循環 import 回避のため遅延 import

    _raise_unknown(keywords_raw, keyword_registry.GROUPS, "keywords")
    keyword_overrides = {
        str(group): _as_str_list(words, f"keywords.{group}")
        for group, words in keywords_raw.items()
    }
    for group, words in keyword_overrides.items():
        if not words:
            raise ConfigError(f"keywords.{group}: 空にはできません（検出できなくなります）")

    profiles_raw = raw.get("profiles") or {}
    if not isinstance(profiles_raw, Mapping):
        raise ConfigError("profiles: マッピングで指定してください")
    profiles = {
        str(name): Profile.parse(str(name), value, default_sanitize)
        for name, value in profiles_raw.items()
    }

    if DEFAULT_PROFILE not in profiles:
        raise ConfigError(f"profiles に '{DEFAULT_PROFILE}' が必要です（type 未指定時に使います）")

    config = Config(profiles=profiles, themes=themes,
                    keywords=keyword_overrides,
                    template_dirs=_resolve_dirs(raw.get("template_dirs"), "template_dirs", config_path),
                    theme_dirs=_resolve_dirs(raw.get("theme_dirs"), "theme_dirs", config_path),
                    config_path=config_path,
                    menu_outputs=parse_menu_outputs(raw.get("menu_outputs"), config_path))
    # テーマ未定義・ルール未登録は読み込み時点で弾く (変換の途中で落とさない)。
    from rules import unknown_rules  # 循環 import 回避のため遅延 import

    for profile in profiles.values():
        config.theme_for(profile)
        missing = unknown_rules(profile.rules)
        if missing:
            raise ConfigError(
                f"profiles.{profile.name}.rules: 未登録のルール: {sorted(missing)}"
                f"（--list-rules で一覧を確認できます）"
            )
    return config


def find_user_config(explicit: Optional[str], default_search_dir: Path = SCRIPT_DIR) -> Optional[Path]:
    """ユーザ設定 config.yaml の場所を決める。無ければ None。

    ``-c`` で指したもの、無ければツールのフォルダ（``default_search_dir``）の config.yaml。
    作業フォルダは見ない。``~/ws`` のほかのツールも同じ名前を使い、別のフォルダから動かしたときに
    そのフォルダの設定を拾ってしまうため（ほかのツールも 2026-10-14 に同じ形にした）。
    """
    if explicit:
        path = Path(explicit).expanduser()
        if not path.is_file():
            raise ConfigError(f"設定ファイルが見つかりません: {path}")
        return path

    candidate = default_search_dir / "config.yaml"
    return candidate if candidate.is_file() else None


def load_config(explicit: Optional[str] = None,
                default_search_dir: Path = SCRIPT_DIR) -> Config:
    """同梱の profiles.yaml を読み、ユーザ設定があれば重ねて ``Config`` を返す。"""
    if not BUNDLED_PROFILES_PATH.is_file():
        raise ConfigError(f"同梱の既定設定が見つかりません: {BUNDLED_PROFILES_PATH}")

    raw = _load_yaml(BUNDLED_PROFILES_PATH)
    user_path = find_user_config(explicit, default_search_dir)
    if user_path is not None:
        raw = _deep_merge(raw, _load_yaml(user_path))
    return build_config(raw, config_path=user_path or BUNDLED_PROFILES_PATH)
