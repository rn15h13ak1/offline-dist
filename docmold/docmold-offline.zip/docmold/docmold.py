#!/usr/bin/env python3
"""docmold - Markdown を、内容の種類ごとに表現を変えた自己完結 HTML に変換する。

Usage:
    python docmold.py 議事録.md                    # front matter の type で表現が決まる
    python docmold.py docs/ -o out/ --index        # ディレクトリ再帰 + 索引 HTML
    python docmold.py 手順.md --type procedure     # front matter を書き換えずに別表現で出す
    python docmold.py --list-types                 # 指定できる種類の一覧
"""
from __future__ import annotations

import sys
from pathlib import Path

SCRIPT_DIR = Path(__file__).resolve().parent
# フルパス実行 (python /abs/path/docmold.py) でも sibling モジュールを解決できるようにする。
if str(SCRIPT_DIR) not in sys.path:
    sys.path.insert(0, str(SCRIPT_DIR))

from deps import ensure, make_console_safe, require_python, stop_on_sigterm  # noqa: E402

# CP932 のコンソールで、ファイル名などに CP932 に無い文字があっても落ちないようにする。
# 依存が足りないときの案内にも効くよう、ensure より先に呼ぶ。
make_console_safe()
# 外から止められたとき（SIGTERM）も、Ctrl+C と同じく「中断しました。」と 130 で終える
stop_on_sigterm()
require_python()

# 依存の確認は cli を import する前に行う。インタプリタを取り違えたときに
# トレースバックではなく、入れ方の案内を出すため。
ensure()

from cli import main  # noqa: E402

if __name__ == "__main__":
    sys.exit(main())
