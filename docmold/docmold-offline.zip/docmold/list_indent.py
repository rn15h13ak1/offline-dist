"""箇条書きの字下げを、2 文字でも 4 文字でも入れ子にする Markdown 拡張。

python-markdown は、入れ子の箇条書きと項目の 2 段落目を、半角スペース 4 文字の字下げで
読む。エディタの整形（Prettier など）は 2 文字（番号付きの項目の下は 3 文字）に直すため、
そのままでは入れ子にならず、同じ階層の項目として並んでしまう。

python-markdown が読む前に、箇条書きの中の行の字下げを「階層 × 4 文字」に書き直す。
親の記号の位置より 2 文字以上深ければ子とみなすので、2・3・4 文字（とタブ）のどれでも
同じ入れ子になる。4 文字で書いた文書は、ほぼそのままの字下げになる。

- 項目の下の段落は、項目の本文の位置からの深さが 4 文字未満なら段落、4 文字以上なら
  コードブロックとして扱う（CommonMark と同じ）
- 引用（``>``）の中の箇条書きも、引用の印を除いた残りで同じように直す
- 行頭のコードブロックの囲み（`````` ``` ``````・``~~~``）の中は触らない。項目の中の囲みは、
  中の行の字下げの差を保ったまま、囲みの行と同じだけずらす
- 箇条書きの外で 4 文字以上字下げした行（コードブロック・admonition の中身）は触らない

タブは、前段の空白の正規化（優先度 30）が 4 文字のスペースに展開してから渡ってくる。
"""
from __future__ import annotations

import re
from dataclasses import dataclass
from typing import List, Optional

try:
    from markdown.extensions import Extension
    from markdown.preprocessors import Preprocessor
except ImportError as e:  # pragma: no cover - 依存が無い環境向けの案内
    raise ImportError("Markdown is required. Install with: pip install markdown") from e

#: 空白の正規化（タブの展開）の後、fenced_code（25）と mermaid（26）の前に走らせる。
PRIORITY = 28

#: python-markdown が 1 階層に求める字下げ。
STEP = 4

#: 子とみなす、親の記号の位置からの深さ。
CHILD_DEPTH = 2

#: 項目の行。字下げ・記号・記号の後の空白・本文に分ける。
_ITEM_RE = re.compile(r"^(?P<indent> *)(?P<marker>[-*+]|\d+\.)(?P<gap> +|$)(?P<rest>.*)$")

#: 引用の印（入れ子も含む）。
_QUOTE_RE = re.compile(r"^((?: {0,3}> ?)*)")

#: 囲みの開始行（字下げは問わない。項目の中の囲みもずらすため）。
_FENCE_RE = re.compile(r"^(?P<indent> *)(?P<fence>`{3,}|~{3,})")


@dataclass
class _Item:
    marker_at: int   # 記号の位置（元の字下げ）
    body_at: int     # 本文の始まる位置（元の文書での桁）
    depth: int       # 0 が最上位


def _closes(text: str, fence: str) -> bool:
    stripped = text.strip()
    return stripped.startswith(fence[0] * len(fence)) and not stripped.strip(fence[0])


class _Block:
    """引用の深さが同じ行の並び 1 つぶんの状態。"""

    def __init__(self) -> None:
        self.items: List[_Item] = []
        self.blank_before = False
        self.top_fence = ""          # 行頭の囲みの中（触らない）
        self.item_fence = ""         # 項目の中の囲み
        self.item_fence_shift = 0

    def line(self, text: str) -> str:
        if self.top_fence:
            if _closes(text, self.top_fence):
                self.top_fence = ""
            return text

        if self.item_fence:
            if _closes(text, self.item_fence):
                self.item_fence = ""
            return self._shift(text, self.item_fence_shift)

        if not text.strip():
            self.blank_before = True
            return text

        blank_before, self.blank_before = self.blank_before, False
        indent = len(text) - len(text.lstrip(" "))

        fence = _FENCE_RE.match(text)
        if fence and (indent == 0 or not self.items):
            if indent <= 3:
                self.items = []
                self.top_fence = fence.group("fence")
            return text

        item = _ITEM_RE.match(text)
        if item and (self.items or indent < STEP):
            return self._item(text, indent, item)

        if not self.items:
            return text

        if indent == 0:
            # 字下げの無い行は、空行の後なら箇条書きの終わり、続けて書いたなら前の段落の続き。
            if blank_before:
                self.items = []
            return text

        owner = self._owner(indent)
        if owner is None or not (blank_before or fence):
            # 空行を挟まずに続けた行は、字下げに依らず前の段落の続きになるので触らない。
            return text
        if blank_before:
            # 空行を挟んで浅い位置に戻ったら、それより深い項目は閉じている。
            self.items = self.items[: self.items.index(owner) + 1]
        extra = indent - owner.body_at
        new_indent = (owner.depth + 1) * STEP + (extra if extra >= STEP else 0)
        if fence:
            self.item_fence = fence.group("fence")
            self.item_fence_shift = new_indent - indent
        return " " * new_indent + text[indent:]

    def _item(self, text: str, indent: int, match: "re.Match[str]") -> str:
        while self.items and indent < self.items[-1].marker_at + CHILD_DEPTH:
            self.items.pop()
        depth = len(self.items)
        body_at = indent + len(match.group("marker")) + len(match.group("gap") or " ")
        self.items.append(_Item(marker_at=indent, body_at=body_at, depth=depth))
        return " " * (depth * STEP) + text[indent:]

    def _owner(self, indent: int) -> Optional[_Item]:
        """字下げした行が属する、いちばん深い項目。"""
        for item in reversed(self.items):
            if indent >= item.marker_at + CHILD_DEPTH:
                return item
        return None

    @staticmethod
    def _shift(text: str, shift: int) -> str:
        if not text.strip():
            return text
        indent = len(text) - len(text.lstrip(" "))
        return " " * max(0, indent + shift) + text[indent:]


def normalize(lines: List[str]) -> List[str]:
    """箇条書きの中の行の字下げを、階層 × 4 文字に書き直す。"""
    out: List[str] = []
    blocks = {}
    quote_depth = 0
    for text in lines:
        prefix = _QUOTE_RE.match(text).group(1)
        depth = prefix.count(">")
        if depth != quote_depth:
            # 引用の深さが変わったら、内側の状態を捨てる（引用を出たら箇条書きも終わる）。
            for key in [k for k in blocks if k > depth]:
                del blocks[key]
            quote_depth = depth
        block = blocks.setdefault(depth, _Block())
        out.append(prefix + block.line(text[len(prefix):]))
    return out


class ListIndentPreprocessor(Preprocessor):
    def run(self, lines: List[str]) -> List[str]:
        return normalize(lines)


class ListIndentExtension(Extension):
    def extendMarkdown(self, md) -> None:  # noqa: N802 - python-markdown の名前
        md.preprocessors.register(ListIndentPreprocessor(md), "docmold_list_indent", PRIORITY)
