---
type: wiki
title: docmold 実行例 ― メニュー・コマンドラインで動かしたときの画面
---

同梱の見本（`examples/`）を実際に変換したときの出力です。種類（type）ごとの書き方と出力は、[種類ごとのページ](#種類の一覧)に分けて載せています。

使い方の説明は `README.md` を参照してください。

画面の取得日：2026年10月15日

メニューの見出しの版は `x.y.z` と伏せています。手元のメニューには、そのときの版が出ます。

## はじめに

動かし方は 2 つあります。中で動く変換は同じで、できる HTML も同じです。

| 動かし方 | 向いている場面 | 載せている章 |
|---|---|---|
| メニュー | 番号を選ぶだけで変換したいとき。`menu.bat` に `.md` やフォルダを落としても起動できます | [1](#1-フォルダをまとめて変換するメニュー) |
| コマンドライン | バッチやタスクスケジューラから呼ぶとき、引数で動きを決めたいとき | [2〜8](#2-種類とルールの一覧を見る) |

どの例も、次の流れです。

1. `.md` の先頭の front matter に `type:` を書く
2. 種類ごとの組み合わせ（構造 = テンプレート・意味づけ = ルール・見た目 = テーマ）で変換する。組み合わせは種類ごとに `profiles.yaml` に書いてある
3. CSS・画像も埋め込んだ HTML を 1 ファイルで書き出す。フォルダを渡すとまとめて変換し、`--index` で索引も作る

### 画面の読み方

- 画面の出力は、入力した値も含めてそのまま載せています。入力は `番号を入力してください [Enter=1]: 1` のように行の末尾に、Enter だけを押したところは `(Enter)` と書いています。省いた部分は `…` の行で示します
- ツールは `C:\tools\docmold` に置いたものとし、そのフォルダでコマンドプロンプトを開いて打ち込んだ形（`> python …`）で載せています。終了コードは `echo %ERRORLEVEL%` で確かめます
- 出力は開発機で実際に動かしたものです。ツールの場所を `C:\tools\docmold` に、パスの区切りを `\` に置き換えています
- 変換するのは同梱の見本 `examples\` です。どの種類の見本も入っています

## 種類の一覧

種類は `.md` の先頭の front matter に `type: minutes` のように書きます。書かなければ `default` です。種類ごとのページに、書き方・変換したときの画面・何がどう変わるかを載せています。

| 種類（type） | 向いている文書 | 見本 | 実行例 |
|---|---|---|---|
| `default` | 種類を書いていないメモ。目次なしの素直な 1 ページ | [メモ](../examples/html/メモ.html) | [default](examples/default.md) |
| `minutes` | 議事録。出席者・決定事項・ToDo を目立たせる | [議事録](../examples/html/議事録.html) | [minutes](examples/minutes.md) |
| `procedure` | 作業手順書。手順をカードにし、コマンドにコピーボタンを付ける | [作業手順書](../examples/html/作業手順書.html) | [procedure](examples/procedure.md) |
| `incident` | 障害報告。冒頭にサマリカード、時系列をタイムラインに | [障害報告](../examples/html/障害報告.html) | [incident](examples/incident.md) |
| `spec` | 設計書。表紙・章番号・図表の通し番号 | [設計書](../examples/html/設計書.html) | [spec](examples/spec.md) |
| `wiki` | 知識ベースのノート。コールアウト（`> [!warning]`） | [ノート](../examples/html/ノート.html) | [wiki](examples/wiki.md) |
| `weekly` | 週次報告。状態のバッジと進捗バー | [週次報告](../examples/html/週次報告.html) | [weekly](examples/weekly.md) |
| `weekly3` | 週次の 3 列（前週・今週・来週）。`fragment`（取り込み用の断片）もここで扱う | [課題サマリー](../examples/html/課題サマリー.html) | [weekly3](examples/weekly3.md) |
| `catalog` | まとまり・段階・項目で引くリンク集。見方の切り替えと絞り込み | [作成物一覧](../examples/html/作成物一覧.html) | [catalog](examples/catalog.md) |
| `process` | 複数の担当が関わる業務の手順。担当での絞り込み・チェック・台帳の更新表 | [取引先登録の手順](../examples/html/取引先登録の手順.html) | [process](examples/process.md) |

出力した HTML の見本は、まとめて [examples/html/index.html](../examples/html/index.html) から開けます。

## 1. フォルダをまとめて変換する（メニュー）

`menu.bat` をダブルクリックし、**変換する → フォルダ → 種類 → 出力先 → 索引 → 実行モード** の順に答えます。Enter だけで答えると、`←既定` や `←前回` の付いたものを選びます。

```text
> menu.bat
============================================================
  Markdown → 自己完結 HTML（docmold x.y.z）
============================================================
  設定: C:\tools\docmold\profiles.yaml（11 種類）

============================================================
  操作を選択
============================================================
  1. 変換する ― Markdown を自己完結 HTML に変換する
  2. 種類の一覧 ― front matter の type に書ける名前を表示する
  3. ルールの一覧 ― 種類ごとの意味づけ（後処理）を表示する
------------------------------------------------------------
  0. 終了
============================================================
番号を入力してください: 1
============================================================
  変換する
============================================================
  変換する .md またはディレクトリ（空 Enter で戻る）: examples
    → examples（11 ファイル）

============================================================
  種類（type）
============================================================
  1. front matter に従う（.md の指定をそのまま使う） ←既定
  2. catalog ― まとまり・段階・項目で引くリンク集
  3. default ― 汎用（type 未指定時）
  4. fragment ― 取り込み用の断片（単独では索引に並べない）
  5. incident ― 障害報告
  6. minutes ― 議事録
  7. procedure ― 作業手順書
  8. process ― 複数の担当が関わる業務の手順
  9. spec ― 設計書
  10. weekly ― 週次報告
  11. weekly3 ― 週次の 3 列（前週・今週・来週）
  12. wiki ― 知識ベースのノート
------------------------------------------------------------
  0. 戻る
============================================================
番号を入力してください [Enter=1]: (Enter)
============================================================
  出力先
============================================================
  1. 既定（C:\tools\docmold\out\<日時>\） ←既定
  2. 場所を指定する
------------------------------------------------------------
  0. 戻る
============================================================
番号を入力してください [Enter=1]: (Enter)
  索引 HTML（index.html）も作りますか？ [Y/n]: (Enter)
============================================================
  実行モード
============================================================
  1. 変換して書き出す ←既定
  2. 検証のみ（--dry-run・HTML を書き出しません）
------------------------------------------------------------
  0. 戻る
============================================================
番号を入力してください [Enter=1]: (Enter)
設定ファイル: C:\tools\docmold\profiles.yaml
対象: 11 ファイル
出力先: C:\tools\docmold\out\20261014-154841
  [wiki] examples\ノート.md → C:\tools\docmold\out\20261014-154841\ノート.html (出力)
  [default] examples\メモ.md → C:\tools\docmold\out\20261014-154841\メモ.html (出力)
  [catalog] examples\作成物一覧.md → C:\tools\docmold\out\20261014-154841\作成物一覧.html (出力)
  … 8 行を省略 …
索引: C:\tools\docmold\out\20261014-154841\index.html
完了: 成功 11 件 / 失敗 0 件
出力先: C:\tools\docmold\out\20261014-154841

------------------------------------------------------------
  出力先を開きますか？ [y/N]: (Enter)
------------------------------------------------------------
  終了コード: 0（すべて変換した）

  Enter キーでメニューに戻ります...
```

> [!note] 数えるのは単独で変換するファイルだけ
> `examples\parts\` の中は `type: fragment`（取り込み用の断片）なので、フォルダを渡したときは単独では変換せず、「11 ファイル」にも数えません。親の `分割した課題サマリー.md` と `作成物一覧.md` が取り込みます（[weekly3 のページ](examples/weekly3.md#6-ファイルを分けて書く取り込み-と-fragment)・[catalog のページ](examples/catalog.md)）。

> [!tip] 出力先は実行ごとに分かれる
> 既定の出力先は、実行した日時のフォルダです。前回の出力を上書きしません。古いものは自動では消えないので、要らなくなったらフォルダごと消してください。

> [!note] ポイント
> - 選んだ値は次回の既定になります（`←前回`。変換対象は `[Enter=examples]` の形で出ます）。初めて開いたときは、最初のメニューに既定が付きません
> - 終わると、終了コードとその意味が出ます
> - `y` と答えると、出力先をエクスプローラで開きます
> - 「検証のみ」を選ぶと、警告だけを出して HTML を書きません（[5 章](#5-書き出す前に確かめる--dry-run)と同じ）

## 2. 種類とルールの一覧を見る

書ける種類は `--list-types`、種類ごとの意味づけ（ルール）は `--list-rules` で出ます。どちらも何も書き出しません。

```text
> python docmold.py --list-types
front matter に 'type: <名前>' で指定します。

  名前         テンプレート           テーマ          説明
  ---------  ---------------- ------------ --------------------
  catalog    catalog.html     corporate    まとまり・段階・項目で引くリンク集
  default    article.html     corporate    汎用（type 未指定時）
  fragment   article.html     corporate    取り込み用の断片（単独では索引に並べない）
  incident   report.html      alert        障害報告
  minutes    article.html     corporate    議事録
  procedure  stepped.html     corporate    作業手順書
  process    process.html     corporate    複数の担当が関わる業務の手順
  spec       document.html    corporate    設計書
  weekly     dashboard.html   corporate    週次報告
  weekly3    columns.html     corporate    週次の 3 列（前週・今週・来週）
  wiki       article.html     corporate    知識ベースのノート

設定ファイル: C:\tools\docmold\profiles.yaml
```

```text
> python docmold.py --list-rules
profiles.<type>.rules に並べると、その順で DOM 後処理が走ります。

  attendee_table      「出席者」節の氏名をバッジ化する（リスト・表のどちらでも）。
  callout_blockquote  ``> [!warning] 見出し`` で始まる引用を、枠付きのコールアウトにする。
  catalog             段階の見出しと項目の箇条書きを読み取り、まとまり・段階・項目の一覧にする。
  … 20 行を省略 …
  todo_checklist      「ToDo」節のリストをチェックボックス化し、担当者をバッジにする。
  topic_cards         1 列にした節を、小見出しごとの枠に分ける。
  topic_index         1 列にした節の先頭に、枠への目次を置く。
```

`config.yaml` で種類を足したり変えたりすると、その内容が一覧に出ます。最後の行の `設定ファイル:` に、どの設定を読んだかが出ます。

## 3. 1 ファイルを変換する

ファイルを 1 つ渡します。`-o` に `.html` の名前を渡すとそのファイルに、フォルダを渡すとその中に出します。

```text
> python docmold.py examples\議事録.md -o out
設定ファイル: C:\tools\docmold\profiles.yaml
対象: 1 ファイル
出力先: out
完了: 成功 1 件 / 失敗 0 件
出力先: out

> dir /b out
議事録.html
```

`-o` を省くと、ツールのフォルダの `out\<日時>\` に出します（[1 章](#1-フォルダをまとめて変換するメニュー)と同じ）。どこから動かしても同じ場所です。

### 別の種類で出す（`-t`）

`.md` を書き換えずに、別の種類の表現で出せます。front matter の `type` より優先します。

```text
> python docmold.py examples\議事録.md -t procedure -o out5
設定ファイル: C:\tools\docmold\profiles.yaml
対象: 1 ファイル
出力先: out5
完了: 成功 1 件 / 失敗 0 件
出力先: out5
```

## 4. まとめて変換して索引を作る

フォルダを渡すと、中の `.md` をまとめて変換し、階層を保って出力します。`--index` で索引の `index.html` も作ります。`-v` を付けると、1 件ごとに種類と出力先が出ます。

```text
> python docmold.py examples -o dist --index -v
設定ファイル: C:\tools\docmold\profiles.yaml
対象: 11 ファイル
出力先: dist
  [wiki] examples\ノート.md → dist\ノート.html (出力)
  [default] examples\メモ.md → dist\メモ.html (出力)
  [catalog] examples\作成物一覧.md → dist\作成物一覧.html (出力)
  [procedure] examples\作業手順書.md → dist\作業手順書.html (出力)
  [weekly3] examples\分割した課題サマリー.md → dist\分割した課題サマリー.html (出力)
  [process] examples\取引先登録の手順.md → dist\取引先登録の手順.html (出力)
  [spec] examples\設計書.md → dist\設計書.html (出力)
  [weekly3] examples\課題サマリー.md → dist\課題サマリー.html (出力)
  [minutes] examples\議事録.md → dist\議事録.html (出力)
  [weekly] examples\週次報告.md → dist\週次報告.html (出力)
  [incident] examples\障害報告.md → dist\障害報告.html (出力)
索引: dist\index.html
完了: 成功 11 件 / 失敗 0 件
出力先: dist
```

こうして作った索引が [examples/html/index.html](../examples/html/index.html) です（生成時刻を入れない `--reproducible` で作っています）。

> [!note] 索引の並び
> front matter の日付（`日時`・`実施日`・`発生日時`・`作成日`・`期間` など）の新しい順に並び、日付の無い文書は最後にまとまります。「元ファイル」の列は渡したフォルダからの相対パスで出るので、索引を配っても変換した端末のフォルダの構成は残りません。

> [!warning] 文書どうしのリンクを保つには
> `[設計書](設計書.md)` のようなリンクは `.html` に書き換わります。リンク先も変換されるよう、共通の親のフォルダを渡してください。

## 5. 書き出す前に確かめる（`--dry-run`）

変換して警告を出しますが、HTML は書き出しません。出力先のフォルダも作りません。

```text
> python docmold.py ng\定例.md --dry-run
設定ファイル: C:\tools\docmold\profiles.yaml
対象: 1 ファイル
出力先: C:\tools\docmold\out\20261014-154832
警告: ng\定例.md: 未知の type 'minuets': default で処理します (指定できる type: catalog, default, fragment, incident, minutes, procedure, process, spec, weekly, weekly3, wiki)
警告: ng\定例.md: front matter の 'titel' は 'title' の打ち間違いではありませんか
警告: ng\定例.md: 画像が見つかりません: 構成図.png
完了: 成功 1 件 / 失敗 0 件 / 警告 3 件
```

ここで変換した `ng\定例.md` は、わざと誤りを 3 つ入れたものです（次の 6 章）。

## 6. 警告が出るとき

書き方の誤りは、変換を止めずに `警告:` の行で知らせます。既定では **終了コードは 0** のままです。

次の `.md` を変換します。種類の打ち間違い・`title` の打ち間違い・無い画像の 3 つを入れてあります。

```text
---
type: minuets
titel: 定例会
---

## 決定事項

- 切替は 10/18

![構成図](構成図.png)
```

```text
> python docmold.py ng\定例.md -o out2
設定ファイル: C:\tools\docmold\profiles.yaml
対象: 1 ファイル
出力先: out2
警告: ng\定例.md: 未知の type 'minuets': default で処理します (指定できる type: catalog, default, fragment, incident, minutes, procedure, process, spec, weekly, weekly3, wiki)
警告: ng\定例.md: front matter の 'titel' は 'title' の打ち間違いではありませんか
警告: ng\定例.md: 画像が見つかりません: 構成図.png
完了: 成功 1 件 / 失敗 0 件 / 警告 3 件
出力先: out2

> echo %ERRORLEVEL%
0
```

### 警告を失敗として扱う（`--strict`）

バッチやタスクスケジューラでは警告を誰も読みません。`--strict` を付けると、警告があれば終了コード 1 にします。

```text
> python docmold.py ng\定例.md -o out3 --strict
設定ファイル: C:\tools\docmold\profiles.yaml
対象: 1 ファイル
出力先: out3
警告: ng\定例.md: 未知の type 'minuets': default で処理します (指定できる type: catalog, default, fragment, incident, minutes, procedure, process, spec, weekly, weekly3, wiki)
警告: ng\定例.md: front matter の 'titel' は 'title' の打ち間違いではありませんか
警告: ng\定例.md: 画像が見つかりません: 構成図.png
完了: 成功 1 件 / 失敗 0 件 / 警告 3 件
出力先: out3
--strict: 警告が 3 件あるため失敗として扱います。

> echo %ERRORLEVEL%
1
```

> [!note] 失敗扱いでも書き出す
> `--strict` で失敗になっても、HTML は書き出します。何が起きたかを出力で確かめられるようにするためです。

種類ごとに出る警告（`weekly3` の見出しの数、`weekly` の期間など）は、それぞれの種類のページに載せています。

## 7. 生の HTML を落としたとき

`.md` に直接書いた HTML は、既定（`sanitize: strict`）では許可したものだけを残します。落とした箇所は件数と内訳を警告します。

```text
<script>alert(1)</script>

[押す](javascript:alert(1))
```

```text
> python docmold.py ng\html.md -o out7
設定ファイル: C:\tools\docmold\profiles.yaml
対象: 1 ファイル
出力先: out7
警告: ng\html.md: 本文の HTML を 2 箇所ほど除きました（sanitize: strict。素通しにするには sanitize: false）。内訳: script が動くリンク 1・script などの要素 1
完了: 成功 1 件 / 失敗 0 件 / 警告 1 件
出力先: out7
```

`<br>` や `<details>`、表の桁揃えなどは残ります。何が残り何が落ちるかは README の「生の HTML を扱う」にあります。

## 8. 止まるとき

変換を始める前に止まるものは終了コード 2、変換したうえで失敗したものは 1 です。終了コードの一覧と意味は、README の「終了コード」にあります。

### 設定ファイルの誤り（終了コード 2）

`config.yaml` に docmold が知らない項目を書いた例です。どのファイルの誤りかが先頭に出て、似た項目を示します。
知らない項目がいくつもあれば、すべてまとめて示します。

```text
> python docmold.py examples\議事録.md -c bad2.yaml -o out4
エラー: bad2.yaml: profile は知らない項目です（profiles の書き間違いでは？）

> echo %ERRORLEVEL%
2
```

### 無いテンプレートを指した（終了コード 1）

種類の設定の誤りは、その種類のファイルを変換するときに分かります。そのファイルだけが失敗になり、ほかのファイルは変換を続けます。

```text
> python docmold.py examples\議事録.md -c bad.yaml -o out4
設定ファイル: bad.yaml
対象: 1 ファイル
出力先: out4
エラー: examples\議事録.md: profiles.minutes.template: テンプレートが見つかりません: 無い.html (同梱: article.html, base.html, columns.html, dashboard.html, document.html, index.html, report.html, stepped.html)
完了: 成功 0 件 / 失敗 1 件

> echo %ERRORLEVEL%
1
```

### 変換するファイルが無い（終了コード 1）

```text
> python docmold.py 無い.md
警告: 見つかりません: 無い.md
エラー: 変換対象の .md が見つかりませんでした。

> echo %ERRORLEVEL%
1
```

### 依存が足りない Python で動かした（終了コード 2）

別のツールの仮想環境など、依存を入れていない Python で動かすと、どの Python で動いているかと入れ方を出して止まります。

```text
> C:\tools\other\.venv\Scripts\python.exe docmold.py examples\議事録.md
必要なライブラリ Markdown, Jinja2, PyYAML, beautifulsoup4 が入っていません。
  実行中の Python: C:\tools\other\.venv\Scripts\python.exe
  次のコマンドで、この Python に入れてください:
      "C:\tools\other\.venv\Scripts\python.exe" -m pip install -r "C:\tools\docmold\requirements.txt"
  ライブラリが入っている別の Python（Anaconda など）があれば、そちらで動かしても構いません。
```

この例だけは、Python の場所を別のツールの仮想環境の形に置き換えています。
