---
type: wiki
title: incident ― 障害報告
---

冒頭にサマリカードを置き、時系列の表をタイムラインにし、重要度をバッジにします。警告色のテーマで、DRAFT の透かしが入ります。

見本: `examples/障害報告.md` → [examples/html/障害報告.html](../../examples/html/障害報告.html)。ほかの種類と共通の実行例は [実行例の入口](../EXAMPLES.md)にあります。

## 1. 向いている文書

障害の第一報や報告書。いつ起きて、いつ戻り、どこまで影響したかを最初の数行で伝える文書です。

| 層 | この種類の組み合わせ |
|---|---|
| 構造 | `report.html`。冒頭にサマリカード（発生 / 復旧 / 影響範囲 / 重要度）、目次あり |
| 意味づけ | `severity_badge`・`impact_summary`・`timeline_table` |
| 見た目 | `alert`（警告色の赤）。`watermark: DRAFT` で全ページに透かし |

## 2. 書き方

```text
---
type: incident
title: サンプルシステム 応答遅延に関する障害報告
発生日時: 2026-09-10 14:22
復旧日時: 2026-09-10 16:05
影響範囲: 登録画面（利用者 約 100 名）
重要度: 高
---

## 概要

登録画面の応答が最大 40 秒まで悪化し、約 1 時間 40 分にわたり実質的に利用できない状態となった。

## 時系列

| 時刻 | 対応内容 | 担当 |
| --- | --- | --- |
| 14:22 | 監視アラート検知（応答時間 閾値超過） | 運用 |
| 14:30 | 一次切り分け開始。DB の待機セッション増加を確認 | インフラ |
… 3 行を省略 …

## 影響

| 機能 | 影響 | 重要度 |
| --- | --- | --- |
| 登録画面 | 画面応答遅延 | 高 |
| 参照画面 | 影響なし | 低 |
```

> [!note] タイムラインになる表
> 「時刻」（日時・時間・タイムスタンプ）の列を持つ表がタイムラインになります。時刻の列が無ければ、「時系列」（経過・タイムライン・対応経過）の節の中の最初の表を使います。後ろの「影響」の表のように、時刻の列が無く「時系列」の節の外にある表は、そのまま表で残ります。

## 3. 変換する

```text
> python docmold.py examples\障害報告.md -o out -v
設定ファイル: C:\tools\docmold\profiles.yaml
対象: 1 ファイル
出力先: out
  [incident] examples\障害報告.md → out\障害報告.html (出力)
完了: 成功 1 件 / 失敗 0 件
出力先: out
```

## 4. 何がどう変わるか

| 入力 | 出力 | ルール |
|---|---|---|
| front matter の `発生日時`・`復旧日時`・`影響範囲`・`重要度` | 冒頭に 4 枚のサマリカード | `impact_summary` |
| front matter の `重要度` | 見出しの下の重要度のバッジ | `severity_badge` |
| 表の「重要度」の列 | セルごとのバッジ | `severity_badge` |
| 時系列の表 | 縦の線に時刻と内容を並べたタイムライン | `timeline_table` |

### 重要度の色

| 書いた語の例 | 色 |
|---|---|
| `高`・`重大`・`緊急`・`critical` | 赤 |
| `中`・`注意` | 黄 |
| 上に無い語（`低` など） | 灰色 |

色を決める語は状態のバッジと共通で、`config.yaml` の `keywords` の `status_ok`・`status_warn`・`status_danger` で変えられます。

> [!warning] 確定版では透かしを消す
> DRAFT の透かしは既定で入ります。確定版として配るときは、`config.yaml` に `profiles: {incident: {watermark: false}}` を書きます。

## 5. 出力の見本と印刷

同梱の見本を変換したものが [examples/html/障害報告.html](../../examples/html/障害報告.html) です。

印刷すると、DRAFT の透かしが全ページの中央に薄く入ります。サマリカードと表の行は、ページの境目で分かれません。

ほかの種類: [default](default.md)・[minutes](minutes.md)・[procedure](procedure.md)・[spec](spec.md)・[wiki](wiki.md)・[weekly](weekly.md)・[weekly3](weekly3.md)
