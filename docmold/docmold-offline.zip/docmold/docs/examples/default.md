---
type: wiki
title: default ― 汎用
---

種類を書いていない `.md` に使う、目次なしの素直な 1 ページです。意味づけ（ルール）は何もしません。

見本: `examples/メモ.md` → [examples/html/メモ.html](../../examples/html/メモ.html)。ほかの種類と共通の実行例は [実行例の入口](../EXAMPLES.md)にあります。

## 1. 向いている文書

メモや連絡のように、決まった形の無い文書。front matter が無い `.md` は、すべてこの種類で変換します。

| 層 | この種類の組み合わせ |
|---|---|
| 構造 | `article.html`。目次なし |
| 意味づけ | なし |
| 見た目 | `corporate` |

意味づけはしませんが、どの種類にも共通の処理（表の列幅の配分、文書間リンクの書き換え、画像の埋め込み、生の HTML の絞り込み）は行います。

## 2. 書き方

front matter は要りません。書くなら `title` だけでも使えます。

```text
# 種類を指定していないメモ

front matter が無い場合は default プロファイルで変換される。

- 目次なし
- 汎用テンプレート
```

タイトルは front matter の `title`、無ければ最初の見出し、それも無ければファイル名で決まります。

## 3. 変換する

```text
> python docmold.py examples\メモ.md -o out -v
設定ファイル: C:\tools\docmold\profiles.yaml
対象: 1 ファイル
出力先: out
  [default] examples\メモ.md → out\メモ.html (出力)
完了: 成功 1 件 / 失敗 0 件
出力先: out
```

front matter を書き換えずに別の種類で出すときは `-t` を付けます（[入口の 3 章](../EXAMPLES.md#3-1-ファイルを変換する)）。

## 4. 種類を打ち間違えたとき

知らない種類が書いてあると、黙って変換せず、警告してからこの種類で変換します。打ち間違いに気付かないまま配らないためです。

```text
> python docmold.py ng\定例.md -o out2 -v
設定ファイル: C:\tools\docmold\profiles.yaml
対象: 1 ファイル
出力先: out2
警告: ng\定例.md: 未知の type 'minuets': default で処理します (指定できる type: default, fragment, incident, minutes, procedure, spec, weekly, weekly3, wiki)
… ほかの警告を省略 …
  [default] ng\定例.md → out2\定例.html (出力)
完了: 成功 1 件 / 失敗 0 件 / 警告 3 件
出力先: out2
```

バッチで動かすときは `--strict` を付けると、この警告で終了コード 1 になります（[入口の 6 章](../EXAMPLES.md#6-警告が出るとき)）。

## 5. 出力の見本

同梱の見本を変換したものが [examples/html/メモ.html](../../examples/html/メモ.html) です。

ほかの種類: [minutes](minutes.md)・[procedure](procedure.md)・[incident](incident.md)・[spec](spec.md)・[wiki](wiki.md)・[weekly](weekly.md)・[weekly3](weekly3.md)
