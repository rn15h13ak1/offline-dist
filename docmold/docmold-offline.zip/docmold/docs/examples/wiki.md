---
type: wiki
title: wiki ― 知識ベースのノート
---

引用の記法で書いたコールアウト（`> [!warning] 見出し`）を枠にし、章番号を振らない目次を付けます。

見本: `examples/ノート.md` → [examples/html/ノート.html](../../examples/html/ノート.html)。ほかの種類と共通の実行例は [実行例の入口](../EXAMPLES.md)にあります。

## 1. 向いている文書

独立したノートの集まり（知識ベース）を、フォルダごとまとめて HTML にする用途です。GitHub の Alerts や Obsidian のコールアウトと同じ書き方が使えます。

| 層 | この種類の組み合わせ |
|---|---|
| 構造 | `article.html`。冒頭に `tags`・`updated` のメタ表、3 階層までの目次（章番号なし） |
| 意味づけ | `callout_blockquote` |
| 見た目 | `corporate` |
| 図 | `mermaid: cdn`（Mermaid の図を CDN から読み込む） |

## 2. 書き方

```text
---
type: wiki
title: 切替作業の進め方
tags: [手順, サーバ移行]
updated: 2026-09-20
---

# 1. 概要

サーバの切替作業を、毎回同じ進め方で行うためのノート。手順そのものは
[作業手順書](作業手順書.md)、構成は [設計書](設計書.md) にある。

> [!info] このノートの位置づけ
> 手順書を書く前に読む、考え方のまとめ。個別の作業の記録は残さない。
…

> [!note]- 「DNS を切り替えればすぐ反映される」（開くと説明）
> キャッシュが残る端末がある。切替の後もしばらくは、旧サーバへの接続を受けられるようにしておく。
```

見出しに「1. 概要」と章番号を書くノートが多いため、この種類は目次に番号を振りません（振ると「1.1 1. 概要」と二重になります）。

## 3. 変換する

```text
> python docmold.py examples\ノート.md -o out -v
設定ファイル: C:\tools\docmold\profiles.yaml
対象: 1 ファイル
出力先: out
  [wiki] examples\ノート.md → out\ノート.html (出力)
完了: 成功 1 件 / 失敗 0 件
出力先: out
```

ノートの中の `[作業手順書](作業手順書.md)` は `作業手順書.html` へのリンクに変わります。リンク先も変換されるよう、知識ベースはフォルダごと渡します（[入口の 4 章](../EXAMPLES.md#4-まとめて変換して索引を作る)）。日付で並べる前提ではないので、`--index` の索引はフォルダごとに区切られます。

## 4. 何がどう変わるか

| 入力 | 出力 |
|---|---|
| `> [!info] 見出し` | 枠と見出しの行 |
| `> [!info]` | 枠だけ（見出しの行なし） |
| `> [!note]- 見出し` | 閉じた折りたたみ（押すと開く） |
| `> [!note]+ 見出し` | 開いた折りたたみ |

### 枠の色

| 系統 | 種別 |
|---|---|
| 既定（青） | `info`・`note`・`abstract`・`example`・`question`・`quote` など、下に無いものすべて |
| 成功（緑） | `tip`・`success`・`check`・`done` |
| 注意（黄） | `warning`・`important`・`caution`・`attention` |
| 危険（赤） | `danger`・`error`・`bug`・`failure`・`fail`・`missing` |

知らない種別も既定の系統で通し、警告しません。

> [!warning] コールアウトの直後の引用
> コールアウトの直後に、空行だけを挟んで普通の引用を書くと、コールアウトの中に入ります。間に本文を 1 行挟めば分かれます。

> [!warning] 図はインターネットから読み込む
> この種類は、本文に図があると、図の描画の仕組みを CDN から読み込みます。見本のように図の無いノートには読み込みの行が入らず、自己完結のままです。閉域で配るなら、`config.yaml` で `mermaid: true`（同梱を埋め込む）か `false` に変えます。

## 5. 出力の見本

同梱の見本を変換したものが [examples/html/ノート.html](../../examples/html/ノート.html) です。4 つの系統の枠と、閉じた折りたたみが入っています。

> [!note] ポイント
> - コールアウトは `weekly3` でも使えます。ほかの種類でも、`rules:` に `callout_blockquote` を足せば使えます
> - `> [!warning]` は Markdown のまま読んでも意味が通るので、同じ `.md` を GitHub で読んでも困りません

ほかの種類: [default](default.md)・[minutes](minutes.md)・[procedure](procedure.md)・[incident](incident.md)・[spec](spec.md)・[weekly](weekly.md)・[weekly3](weekly3.md)
