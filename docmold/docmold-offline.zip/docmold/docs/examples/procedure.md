---
type: wiki
title: procedure ― 作業手順書
---

手順を番号付きのカードにし、コマンドにコピーボタンを付け、切戻し手順を目立たせます。

見本: `examples/作業手順書.md` → [examples/html/作業手順書.html](../../examples/html/作業手順書.html)。ほかの種類と共通の実行例は [実行例の入口](../EXAMPLES.md)にあります。

## 1. 向いている文書

サーバの切替や定例の作業など、上から順に進めて、各手順を終えたか確かめながら使う文書です。

| 層 | この種類の組み合わせ |
|---|---|
| 構造 | `stepped.html`。冒頭に対象システム・実施日・実施者・所要時間のメタ表、目次あり |
| 意味づけ | `step_numbering`・`command_block_copy`・`rollback_callout` |
| 見た目 | `corporate`。印刷では手順（見出し 2）ごとに改ページ |

## 2. 書き方

~~~~text
---
type: procedure
title: サンプルシステム サーバ切替手順書
対象システム: サンプルシステム
実施日: 2026-10-18
実施者: 鈴木 / 田中
所要時間: 4 時間
---

## 手順 1: 事前確認

現行サーバの稼働状態とバックアップの取得状況を確認する。

```bash
systemctl status app-server
ls -lh /backup/latest
```

!!! warning "確認事項"
    バックアップが当日分でない場合は、この時点で中止し責任者に連絡する。

## 手順 2: サービス停止
… 手順 3・4 を省略 …

## 切戻し手順

疎通確認で異常が出た場合は、以下を実施して現行サーバに戻す。

```bash
sudo /opt/tools/switch-target.sh --to current-cluster
sudo systemctl start app-server
```
~~~~

> [!note] どの見出しが手順になるか
> 「手順」「Step」を含む見出しがあれば、それが手順です。無ければ、本文のいちばん上の段より 1 つ下の見出し（多くは見出し 2）を手順とみなします。「切戻し」（切り戻し・ロールバック・復旧手順・リカバリ）を含む見出しは手順に数えず、警告の枠にします。

`!!! warning "題"` は Markdown の注意の枠（admonition）で、どの種類でも使えます。

## 3. 変換する

```text
> python docmold.py examples\作業手順書.md -o out -v
設定ファイル: C:\tools\docmold\profiles.yaml
対象: 1 ファイル
出力先: out
  [procedure] examples\作業手順書.md → out\作業手順書.html (出力)
完了: 成功 1 件 / 失敗 0 件
出力先: out
```

手順に番号を書いていない `.md` でも、`-t procedure` を付けると見出し 2 を手順にして出せます（[入口の 3 章](../EXAMPLES.md#3-1-ファイルを変換する)）。

## 4. 何がどう変わるか

| 入力 | 出力 | ルール |
|---|---|---|
| 手順の見出しとその節 | 1 つずつのカード。見出しの頭に通し番号、右に「完了」のチェック欄 | `step_numbering` |
| コードブロック（`` ```bash `` など） | 右上にコピーボタン | `command_block_copy` |
| 「切戻し手順」の節 | 警告色の枠（題は「切戻し手順」） | `rollback_callout` |
| front matter の `対象システム`・`実施日`・`実施者`・`所要時間` | 冒頭のメタ表 | `meta_header` |

> [!warning] 番号が二重に見えるとき
> 番号は自動で振ります。見出しに「手順 1:」と書いてあると、自動の番号と並んで出ます。気になるなら見出しの番号を外し、「手順: 事前確認」のように書きます。

> [!tip] コピーボタンはファイルを直接開いても動く
> ファイルサーバーの HTML をそのまま開いたとき（`file://`）でもコピーできるよう、ブラウザの古い仕組みに切り替えて動きます。

## 5. 出力の見本と印刷

同梱の見本を変換したものが [examples/html/作業手順書.html](../../examples/html/作業手順書.html) です。

- 印刷では手順ごとに改ページします。コピーボタンと画面用の注記は印刷されません
- チェック欄はブラウザ上の作業用で、保存されません。記録には印刷か PDF への保存を使います

ほかの種類: [default](default.md)・[minutes](minutes.md)・[incident](incident.md)・[spec](spec.md)・[wiki](wiki.md)・[weekly](weekly.md)・[weekly3](weekly3.md)
