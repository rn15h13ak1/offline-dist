---
type: wiki
title: minutes ― 議事録
---

出席者・決定事項・ToDo を見分けて、議事録として読みやすい形にします。

見本: `examples/議事録.md` → [examples/html/議事録.html](../../examples/html/議事録.html)。ほかの種類と共通の実行例は [実行例の入口](../EXAMPLES.md)にあります。

## 1. 向いている文書

定例会や打ち合わせの議事録。決まったことと、誰が何をするかを読み落とさせない文書です。

| 層 | この種類の組み合わせ |
|---|---|
| 構造 | `article.html`。冒頭に日時・場所・出席者・次回のメタ表、目次あり |
| 意味づけ | `attendee_table`・`todo_checklist`・`decision_highlight` |
| 見た目 | `corporate`（標準の青） |

## 2. 書き方

front matter に `type: minutes` と、メタ表に出す項目を書きます。本文は見出しの名前でルールが節を見分けます。

```text
---
type: minutes
title: サーバ移行プロジェクト 定例会 議事録
日時: 2026-09-14 10:00-11:00
場所: 会議室A / オンライン
出席者: [山田太郎, 鈴木花子, 佐藤一郎, 田中二郎]
次回: 2026-09-21 10:00
---

## 出席者

- 山田太郎（プロジェクトリーダー）
- 鈴木花子（インフラ担当）
…

## 決定事項

- 本番切替は 10/18(土) 22:00 開始とする。
- 切戻し判断は 10/19(日) 02:00 時点で行う。

## 議論

現行サーバの保守期限が 11 月末のため、10 月中の切替が必要。

## ToDo

- [x] 切替手順書の初版作成 担当: 鈴木
- [ ] 性能試験の結果まとめ 担当: 佐藤
- [ ] 利用部門への周知文面 @山田
```

> [!note] 見分ける見出しの名前
> 「出席者」（参加者・参加メンバー）、「決定事項」（決定・合意事項）、「ToDo」（アクション・宿題・持ち帰り）を見出しに含む節が対象です。別の名前を使うなら、`config.yaml` の `keywords` の `attendee`・`decision`・`todo` で変えられます。

## 3. 変換する

```text
> python docmold.py examples\議事録.md -o out -v
設定ファイル: C:\tools\docmold\profiles.yaml
対象: 1 ファイル
出力先: out
  [minutes] examples\議事録.md → out\議事録.html (出力)
完了: 成功 1 件 / 失敗 0 件
出力先: out
```

行頭の `[minutes]` が、実際に使った種類です。front matter の `type` を打ち間違えると `[default]` になり、警告が出ます（[入口の 6 章](../EXAMPLES.md#6-警告が出るとき)）。

## 4. 何がどう変わるか

| 入力 | 出力 | ルール |
|---|---|---|
| front matter の `日時`・`場所`・`出席者`・`次回` | 冒頭のメタ表（リストは並べて表示） | `meta_header` |
| 「出席者」の節のリスト | 1 人ずつの札を横に並べた形 | `attendee_table` |
| 「出席者」の節の表の「氏名」（名前・出席者）の列 | 氏名のバッジ | `attendee_table` |
| 「決定事項」の節 | 枠で囲んだコールアウト | `decision_highlight` |
| 「ToDo」の節の `- [ ]` / `- [x]` | チェックボックス（`[x]` は済み） | `todo_checklist` |
| ToDo の行の `担当: 鈴木` / `@山田` | 担当者のバッジ | `todo_checklist` |
| 見出し 2・3 | 冒頭の目次 | `toc` |

> [!warning] チェックは保存されない
> 出力のチェックボックスはブラウザ上の表示です。押しても HTML は変わりません。済みにするなら `.md` の `[ ]` を `[x]` に直して変換し直します。

## 5. 出力の見本

同梱の見本を変換したものが [examples/html/議事録.html](../../examples/html/議事録.html) です。ブラウザで開いて、上の表の変わり方を確かめられます。

> [!note] ポイント
> - 見出しの名前だけで節を見分けます。本文の書き方を変える必要はありません
> - 同じ `.md` を GitHub で開いても、ふつうの Markdown として読めます

ほかの種類: [default](default.md)・[procedure](procedure.md)・[incident](incident.md)・[spec](spec.md)・[wiki](wiki.md)・[weekly](weekly.md)・[weekly3](weekly3.md)
