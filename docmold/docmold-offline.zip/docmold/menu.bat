@echo off
rem ===========================================================
rem  docmold - interactive menu launcher
rem  Double-click this file to start the menu.
rem
rem  Messages here are ASCII on purpose: this file must stay
rem  readable in any console code page.
rem ===========================================================

rem Move to this file's folder. pushd (not cd) so that a UNC
rem path on a shared drive also works.
pushd "%~dp0" || (
    echo [ERROR] Cannot enter the folder of this script.
    pause
    exit /b 1
)

rem Pick the Python to run the menu with. Candidates, in order: a .venv in
rem this folder, python on PATH, then the py launcher. The first one
rem that can import the libraries docmold needs is used: on a PC with
rem both Anaconda and the python.org Python, only one may have them.
rem If none can, the first one that runs is used, and docmold itself
rem says what is missing.
set PYTHON=
set FALLBACK=
if exist ".venv\Scripts\python.exe" call :try ".venv\Scripts\python.exe"
if not defined PYTHON call :try python
if not defined PYTHON call :try py -3
if not defined PYTHON set PYTHON=%FALLBACK%
if not defined PYTHON (
    echo [ERROR] Python 3 was not found.
    echo         Install Python 3.9 or later from https://www.python.org/
    echo         and make sure it is added to PATH.
    popd
    pause
    exit /b 1
)

rem "call" lets a python.cmd (such as the pyenv-win shim) return here,
rem so that the exit code is shown and pause runs.
call %PYTHON% menu.py %*
set RC=%ERRORLEVEL%

popd
if not "%RC%"=="0" echo.& echo [exit code %RC%]

rem Pause even with arguments. Files dropped on this file come in as
rem arguments, and the window should stay open to read the result.
rem To run unattended, call docmold.py directly instead of this file.
pause
exit /b %RC%

rem Use the given command as the Python if it runs. "call" lets a python.cmd
rem return here. Prefer the first one that can import the libraries.
:try
call %* --version >nul 2>&1 || exit /b 0
if not defined FALLBACK set FALLBACK=%*
call %* -c "import markdown, jinja2, yaml, bs4" >nul 2>&1 && set PYTHON=%*
exit /b 0
