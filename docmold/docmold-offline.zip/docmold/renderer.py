"""テンプレート描画 (Jinja2) と、テーマ CSS の埋め込み。

出力は 1 ファイル完結の HTML。CSS・JS・画像はすべて埋め込み、外部参照を持たない。
"""
from __future__ import annotations

from pathlib import Path
from typing import Any, Dict, List, Optional, Sequence, Tuple

try:
    from jinja2 import Environment, FileSystemLoader, StrictUndefined, TemplateNotFound
    from jinja2 import TemplateError, select_autoescape
except ImportError as e:  # pragma: no cover - 依存が無い環境向けの案内
    raise ImportError("Jinja2 is required. Install with: pip install jinja2") from e

from assets import read_mermaid_js, read_theme_css
from config import Config, Profile
from version import __version__

SCRIPT_DIR = Path(__file__).resolve().parent
TEMPLATES_DIR = SCRIPT_DIR / "templates"

#: 探すフォルダの並び → テンプレート環境。設定ごとに template_dirs: が違いうるため、並びごとに持つ。
_envs: Dict[Tuple[str, ...], Environment] = {}


class RenderError(RuntimeError):
    """テンプレートの描画に失敗したときに送出。"""


def get_environment(template_dirs: Sequence[Path] = ()) -> Environment:
    """テンプレート環境を返す (フォルダの並びごとに 1 度だけ構築)。

    ``template_dirs`` (config.yaml の ``template_dirs:``) を同梱の ``templates/`` より先に探す。
    同じ名前なら利用者のものが勝ち、利用者のテンプレートから同梱の ``base.html`` を継承できる。
    """
    search = tuple(str(d) for d in (*template_dirs, TEMPLATES_DIR))
    env = _envs.get(search)
    if env is None:
        env = Environment(
            loader=FileSystemLoader(list(search), encoding="utf-8"),
            autoescape=select_autoescape(default_for_string=False, default=True),
            undefined=StrictUndefined,
            trim_blocks=True,
            lstrip_blocks=True,
        )
        # 配った先で版を知るため、すべての HTML の <head> に出す
        env.globals["docmold_version"] = __version__
        _envs[search] = env
    return env


#: 表紙のあるプロファイルで、1 ページ目（表紙）のページ番号を消す。
_COVER_PAGE_CSS = """@media print {
  @page :first { @bottom-center { content: ""; } }
}"""


def build_css(config: Config, profile: Profile) -> str:
    """テーマ変数 + 共通 CSS + 印刷用 CSS を 1 本にまとめる。"""
    theme = config.theme_for(profile)
    parts = [
        f":root {{\n{theme.css_variables()}\n}}",
        read_theme_css("base", config.theme_dirs),
        read_theme_css(theme.name, config.theme_dirs),
        read_theme_css("print", config.theme_dirs),
    ]
    if profile.print.cover_page:
        parts.append(_COVER_PAGE_CSS)
    # print.css の @page より後に置き、用紙の指定で上書きする
    parts.append(profile.print.page_css())
    return "\n\n".join(part for part in parts if part.strip())


def build_pygments_css() -> str:
    """コードハイライト用 CSS。Pygments が無い環境では空文字。"""
    try:
        from pygments.formatters import HtmlFormatter
    except ImportError:  # pragma: no cover - Pygments 無しでも変換自体は通す
        return ""
    return HtmlFormatter(style="friendly").get_style_defs(".codehilite")


def render(*, config: Config, profile: Profile, content: str, title: str,
           meta: Dict[str, Any], derived: Dict[str, Any],
           toc: List[Dict[str, Any]], meta_header: List[Dict[str, str]],
           warnings: Optional[List[str]] = None, has_diagrams: bool = False) -> str:
    """プロファイルのテンプレートを描画して HTML 文字列を返す。

    ``has_diagrams`` は本文に描画対象の図があるか。無ければ mermaid.js を読み込まない
    （図の無い出力まで外部参照や 3.4 MB の埋め込みを持たないように）。
    """
    env = get_environment(config.template_dirs)
    try:
        template = env.get_template(profile.template)
    except TemplateNotFound:
        available = sorted(p.name for p in TEMPLATES_DIR.glob("*.html"))
        own = sorted({p.name for d in config.template_dirs for p in Path(d).glob("*.html")})
        raise RenderError(
            f"profiles.{profile.name}.template: テンプレートが見つかりません:"
            f" {profile.template} (同梱: {', '.join(available)}"
            + (f" / template_dirs: {', '.join(own)}" if own else "") + ")"
        ) from None

    load_mermaid = profile.mermaid.enabled and has_diagrams
    mermaid_js = ""
    if load_mermaid and profile.mermaid.bundled:
        mermaid_js, warning = read_mermaid_js()
        if warning and warnings is not None:
            warnings.append(warning)

    try:
        return template.render(
            content=content,
            title=title,
            meta=meta,
            derived=derived,
            toc=toc,
            toc_numbering=profile.toc.numbering,
            meta_header=meta_header,
            profile=profile,
            theme=config.theme_for(profile),
            watermark=profile.watermark,
            print_settings=profile.print,
            css=build_css(config, profile),
            pygments_css=build_pygments_css(),
            mermaid_js=mermaid_js,
            mermaid=profile.mermaid,
            load_mermaid=load_mermaid,
        )
    except TemplateError as e:
        # テンプレートの変数名間違いなどを、スタックトレースではなく 1 行で伝える。
        raise RenderError(f"{profile.template}: 描画に失敗しました: {e}") from e
