# docmold

Markdown を、**内容の種類ごとに表現を変えた自己完結 HTML** に変換する CLI ツール。

議事録・作業手順書・障害報告・設計書・週次報告を、それぞれに合った構造 / 意味づけ / 見た目で出力します。
出力は CSS・JS・画像を埋め込んだ 1 ファイルで、外部参照を持ちません（閉域ネットワーク / CDN 不可の前提）。

## 主要機能

- **種類ごとの表現切り替え**: front matter の `type:` 1 行で、テンプレート・ルール・テーマがまとめて切り替わる
- **3 層分離**: 構造（テンプレート）/ 意味づけ（ルール）/ 見た目（テーマ）を独立に組み合わせる
- **YAML 駆動**: 種類の追加は「YAML 数行 + 必要ならルール関数 1 つ」。判定ロジックは設定に持たない
- **完全自己完結 HTML**: CSS / JS / 画像（base64）を 1 ファイルに埋め込み、外部参照ゼロ
- **本文の生 HTML を既定で絞る**: 配布物に `<script>` が紛れ込まない（種類ごとに解除可）
- **印刷（PDF 化）前提**: 手順書は見出しごとに改ページ、設計書は表紙を 1 ページ目に
- **一括変換 + 索引**: ディレクトリ再帰と索引 HTML の生成
- **スマートフォン・タブレットでも読める**: 狭い画面では余白を詰め、長い URL は折り返し、広い表だけを横スクロールにする

---

## 目次

**入門**
1. [クイックスタート](#クイックスタート)
2. [動作要件](#動作要件)
3. [ファイルサーバーから使う](#ファイルサーバーから使う)

**使い方ガイド**
4. [メニューから実行する](#1-メニューから実行する)
5. [種類を指定する](#2-種類を指定する)
6. [一括変換する](#3-一括変換する)
7. [表現を調整する](#4-表現を調整する)
8. [種類を追加する](#5-種類を追加する)
9. [PDF 化する](#6-pdf-化する)
10. [図を使う](#7-図を使う)
11. [生の HTML を扱う](#8-生の-html-を扱う)
12. [節を横に並べる](#9-節を横に並べる)
13. [リンクを書く](#10-リンクを書く)
14. [まとまりを横断して引く](#11-まとまりを横断して引く)
15. [実行例](docs/EXAMPLES.html)（種類ごとの書き方と出力も）

**リファレンス**
16. [同梱の種類](#同梱の種類)
17. [CLI オプション一覧](#cli-オプション一覧)
18. [出力先](#出力先)
19. [設定ファイル](#設定ファイル)
20. [ルール一覧](#ルール一覧)
21. [front matter のキー](#front-matter-のキー)
22. [終了コード](#終了コード)
23. [既知の制約](#既知の制約)
24. [ファイル構成](#ファイル構成)

---

## クイックスタート

**メニューから使う**（CLI オプションを覚えなくてよい）:

```cmd
:: menu.bat をダブルクリック、またはコマンドから
cd C:/tools/docmold
menu.bat
```

**CLI から使う**:

```cmd
:: 1. Anaconda Prompt（通常権限）で展開先に移動
cd C:/tools/docmold

:: 2. 指定できる種類を確認
python docmold.py --list-types

:: 3. .md の先頭に種類を書いて変換
python docmold.py 議事録.md
:: → C:/tools/docmold/out/20260914-213045/議事録.html
```

出力先は **docmold 自身の `out/` 配下に、実行日時のフォルダを作って** その中に出します
（詳しくは [出力先](#出力先)）。

変換対象の `.md`：

```markdown
---
type: minutes
title: 定例会 議事録
日時: 2026-09-14 10:00-11:00
出席者: [山田太郎, 鈴木花子]
---

## 決定事項

- 本番切替は 10/18 に実施する。

## ToDo

- [ ] 手順書の作成 担当: 鈴木
```

`examples/` に 8 種類のサンプルがあります。まとめて出力して見比べられます：

```cmd
python docmold.py examples -o out --index
```

実際に動かしたときの画面と、種類ごとの書き方・出力は [実行例](docs/EXAMPLES.html) にまとめています。

---

## 動作要件

- **Python 3.9 以上**
- 依存パッケージはすべて **Anaconda 同梱**

| パッケージ | 用途 |
| --- | --- |
| `markdown` | Markdown → HTML |
| `jinja2` | テンプレート描画 |
| `pyyaml` | front matter / 設定ファイル |
| `beautifulsoup4` | ルール層の DOM 後処理 |
| `pygments` | コードハイライト（無い場合は色なしで動作） |

Anaconda 以外の環境では:

```bash
pip install -r requirements.txt
```

**依存は「実行に使う Python」に入っている必要があります。** 別のツールの仮想環境や、
依存を入れていない Python で起動すると、次の案内が出て終了コード 2 で止まります。

```
必要なライブラリが入っていません: Markdown, Jinja2, beautifulsoup4

  実行中の Python: /path/to/other-tool/.venv/bin/python

次のいずれかで解決できます。
  1) この Python に入れる
     "/path/to/other-tool/.venv/bin/python" -m pip install -r "/path/to/docmold/requirements.txt"
  2) 依存が入っている Python で実行する
```

どの Python で動いているかが表示されるので、取り違えていないか確認してください。

`menu.bat` は、このフォルダの `.venv` → `python` → `py -3` の順に Python を探し、依存を import できる最初のものを使います。
Anaconda と python.org の Python が両方入っていても、依存の入っている方で動きます。

---

## ファイルサーバーから使う

インターネットに接続できない環境では、ファイルサーバーに置いた Git のリポジトリから取得します。
Git for Windows が要ります。

**初めて使うとき** は、手元のフォルダに clone します（`\\fileserver\share\git` は置き場に読み替えてください）。

```cmd
git clone -b main \\fileserver\share\git\docmold.git C:\tools\docmold
```

その後は、上の「クイックスタート」と「動作要件」のとおりに使います。

**新しい版に更新する** ときは、clone したフォルダの `update.bat` をダブルクリックします。
中で `git pull --ff-only` を実行します。

- `config.yaml` や `local\`（自分で足した種類のルール・テンプレート・テーマ）、`out\` など、Git が扱わないファイルには触れません
- ツールのファイルを手元で書き換えていると、更新せずに止まり、変えたファイルを示します。
  `undo_changes.bat` をダブルクリックすると、変えたファイルを `backup\<日時>\` に退避してから元に戻します
  （一覧を見て `Y` を入力したときだけ）。その後、もう一度 `update.bat` を実行してください。
  退避したものには、変えたファイルと、変更の一覧（`CHANGES.txt`）・差分（`changes.diff`）が入ります

**`config.example.yaml` は、この環境に合わせて直してかまいません**（テーマの色や、種類ごとの設定など）。
clone したフォルダで直して commit・push すると、使う人は `update.bat` で受け取れます。
新しい版を取り込んでも、直した `config.example.yaml` は残ります。

clone や更新で `detected dubious ownership` と出たら、Git が示す
`git config --global --add safe.directory …` のコマンドを実行してから、やり直してください。

---

## 使い方ガイド

### 1. メニューから実行する

CLI オプションを覚えなくても、番号を選ぶだけで実行できます。

```cmd
:: Windows はこれをダブルクリック
menu.bat

:: コマンドから起動する場合
python menu.py
```

```
============================================================
  Markdown → 自己完結 HTML（docmold x.y.z）
============================================================
  設定: C:/tools/docmold/profiles.yaml（10 種類）

============================================================
  操作を選択
============================================================
  1. 変換する ― Markdown を自己完結 HTML に変換する ←前回
  2. 種類の一覧 ― front matter の type に書ける名前を表示する
  3. ルールの一覧 ― 種類ごとの意味づけ（後処理）を表示する
------------------------------------------------------------
  0. 終了
============================================================
```

「変換する」を選ぶと、変換対象 → 種類 → 出力先 → 索引の有無 → 実行モードの順に尋ねます。

- **変換対象** は `.md` かディレクトリ。Windows のドラッグ＆ドロップで付く引用符は自動で外します。
  `.md` やフォルダを `menu.bat` のアイコンに落として起動すると、それが変換対象の既定値になり、
  Enter だけで選べます（複数落としたときは最初の 1 つだけを使います）
- **種類** は前回選んだものが既定。初回は「front matter に従う」で、
  別の表現で出したいときだけ上書きを選びます
- **出力先** は既定（`docmold/out/<日時>/`）か、場所の指定かを選びます
- **索引** はディレクトリを指定したときだけ尋ねます
- **実行モード** で「検証のみ」を選ぶと `--dry-run` 相当（HTML を書き出しません）
- 変換後に出力先をエクスプローラ / Finder で開けます

選んだ値は `~/.docmold_menu.json` に記憶され、次回の既定値になります
（`←前回` と表示され、Enter でそのまま選べます。初めて開いたときは、最初のメニューに既定が付きません）。
終わると `終了コード: 0（すべて変換した）` のように、終了コードとその意味を出します（[終了コード](#終了コード)）。

ランチャーから起動する運用にも、この `menu.py` をそのまま呼び出せます。

> 無人実行（バッチ・タスクスケジューラ）ではメニューではなく `docmold.py` を直接呼んでください。
> その際は `--strict` を付けると、警告を取りこぼしません（下記）。

### 2. 種類を指定する

種類は **書き手が明示したものだけ** を見ます。パス名や本文からの自動判定は行いません
（誤判定で事故るうえ、ルールの保守コストが乗るため）。

**front matter に書く**（基本）:

```markdown
---
type: incident
---
```

**CLI で上書きする**（既存の `.md` を書き換えずに別表現で出したいとき）:

```cmd
python docmold.py 手順.md --type procedure
```

**指定しない場合**は `default`（汎用テンプレート・目次なし）で変換されます。

> 未知の `type` が書かれていた場合は、黙って `default` に落とさず **警告を出したうえで `default` で処理** します。
> タイプミスに気づけないまま変換されるのを防ぐためです。

### 3. 一括変換する

フォルダを渡すと、中の `.md` / `.markdown` をまとめて変換し、階層を保って出力します。
`--index` を付けると、索引の `index.html` も作ります。

```cmd
python docmold.py docs --index
```

```
docs/                          out/20260914-213045/
├── 定例.md          →         ├── 定例.html
├── 障害/                      ├── 障害/
│   └── 0910.md      →         │   └── 0910.html
└── 設計.md          →         ├── 設計.html
                               └── index.html   ← --index で生成
```

- **文書どうしのリンクはそのまま繋がります。** `[設計書](設計書.md)` は `.html` に書き換わります。
  リンク先も変換されるよう、**共通の親のフォルダを渡してください**（渡したフォルダの外へ出る `../` のリンクは切れます）
- ディレクトリへのリンク（`[ADR](adr/)`）は HTML に向け先が無いため、警告して変換します
- `.` で始まるフォルダ（`.git/`・`.obsidian/` など）の中は変換しません。名指しで渡せば変換します
- 索引は front matter の日付の新しい順に並びます。日付として拾うキーは `keywords` の `index_date` で変えられます。
  生成時刻を入れたくないときは `--reproducible` を付けます

実際の画面と索引の見本は [実行例](docs/EXAMPLES.html#4-まとめて変換して索引を作る) にあります。

### 4. 表現を調整する

同梱の定義を変えたいときは `config.yaml` に **差分だけ** 書きます。

```cmd
copy config.example.yaml config.yaml
```

```yaml
profiles:
  incident:
    watermark: false      # 確定版なので DRAFT 透かしを消す
  spec:
    toc:
      depth: 4            # 目次を 4 階層まで

themes:
  corporate:
    accent: "#006c4b"     # 自社色に差し替え
```

同梱の `profiles.yaml` に再帰マージされるため、書かなかったキーは既定のまま残ります。
`profiles.yaml` は直接編集しないでください（ツール更新で上書きされます）。

### 5. 種類を追加する

自分で足すものは、**Git が扱わない `config.yaml` と `local/` に置きます。** ツールのファイル
（`profiles.yaml`・`rules/`・`templates/`・`themes/`）は直しません。こうしておくと、
[`update.bat` で更新](#ファイルサーバーから使う)しても止まらず、足したものも残ります。
`local/` とその下の `templates/`・`themes/` は、clone した時点で空のフォルダとしてあります
（中の `.gitkeep` は、フォルダを Git に残すための空のファイルです。消さないでください）。

| 足すもの | 置く所 | `config.yaml` に書くこと |
| --- | --- | --- |
| 種類・テーマの色 | `config.yaml` | `profiles:`・`themes:` |
| ルール（意味づけ） | `local/` の `.py` | `rule_modules:` |
| テンプレート（構造） | `local/templates/` の `.html` | `template_dirs:` |
| テーマの CSS（見た目） | `local/themes/` の `.css` | `theme_dirs:` |

パスはどれも `config.yaml` から見た相対です。**表現の組み合わせを変えるだけなら YAML 数行** で済みます。

```yaml
profiles:
  review:
    description: レビュー記録
    template: article.html        # 既存テンプレートを再利用
    theme: corporate
    toc: true
    rules: [todo_checklist, status_badge]
    meta_header: [対象, レビュー日, 参加者]
```

**新しい意味づけが要るとき** は、ルール関数を `local/` の `.py` に書き、`rule_modules: [local/review.py]` のように並べます。
`--list-rules` に出て、`rules:` から使えます。

```python
# local/review.py
from rules import rule
from rules.common import add_class, find_headings

@rule("review_severity")
def review_severity(soup, meta):
    """「指摘」節の見出しに重要度クラスを付ける。"""
    for heading in find_headings(soup, ["指摘"]):
        add_class(heading, "dm-review-finding")
```

**構造や見た目を変えるとき** は、`template_dirs: [local/templates]`・`theme_dirs: [local/themes]` を書きます。

- **テンプレート** は同梱の `templates/` より先に探します。`{% extends "base.html" %}` で継承し、変えたいブロックだけを書けます。
  同梱と同じ名前にすると新しい版の直しを受け取れなくなるので、別の名前にしてください
- **テーマの CSS** は同梱の `themes/<name>.css` の後ろに足します。同じ名前なら後勝ちで上書き、新しい名前なら新しいテーマです
- ルールの名前がツールのものと重なったとき、書いたフォルダが無いときは、設定の誤りとして止まります

### 6. PDF 化する

記録として残す場合は、ブラウザの印刷 → PDF 保存を使います。`@media print` を用意済みです。

| 種類 | 印刷時の挙動 |
| --- | --- |
| `procedure` | 見出し（手順）ごとに改ページ。コピーボタン・画面用の注記は印刷されない |
| `spec` | 表紙が単独で 1 ページ目。章ごとに改ページ |
| `incident` | DRAFT 透かしを全ページ中央に薄く配置 |
| `weekly3` | A4 横で印刷する（3 列が折り返されずに並ぶ） |
| `catalog` | A4 横。絞り込みの帯は印刷せず、画面の見方と絞り込みのまま、畳んだ見出しも開いて印刷する |
| 共通 | A4 縦。ページ番号（`1 / 5`）が下端に入る。手順カード・サマリカード・表の行がページ境界で分断されない |

ブラウザの印刷設定で「背景のグラフィック」を有効にしてください（バッジや見出しの色が出ます）。

ページ番号は CSS で入れています。**Chrome / Edge でのみ表示されます**（Firefox / Safari は
CSS のマージンボックスに未対応）。それ以外のブラウザでは、印刷ダイアログの
「ヘッダーとフッター」を有効にすると、ブラウザ自身がページ番号を付けます。
表紙のある `spec` では、表紙（1 ページ目）に番号を出しません。

用紙の大きさと向きは、種類ごとに `config.yaml` の `print.page` で変えられます。
印刷ダイアログの既定の用紙がこれになります。

```yaml
profiles:
  minutes:
    print:
      page: {size: A3, orientation: landscape}   # size: A3 / A4 / A5 / B4 / B5 / JIS-B4 / JIS-B5 / letter / legal / ledger
```

### 7. 図を使う

Mermaid の図を書けます。同梱の設定では **`spec`（設計書）と `wiki`（ノート）で有効**で、
`mermaid: cdn`（CDN から読み込む）になっています。mermaid.js を読み込むのは、本文に図があるファイルだけです。
他の種類で使う場合や、読み込み方を変える場合は `config.yaml` に書きます。

```yaml
profiles:
  minutes:
    mermaid: cdn          # 議事録でも図を使う
  spec:
    mermaid: false        # 設計書では図を使わない（外部参照をなくす）
```

Markdown 側は `mermaid` を指定したコードブロックとして書きます。

````markdown
```mermaid
graph TD
  A[申請受付] --> B{内容確認}
  B -->|不備なし| C[承認]
  B -->|不備あり| D[差戻し]
```
````

`mermaid` が無効な種類では、ただのコードブロックとして表示されます。

#### 図に番号を付ける

`spec` では図にも表と同じように通し番号が付きます。図の直前に「図: 説明」の行を置くと、
キャプションになります。

````markdown
図: 全体構成

```mermaid
graph TD
  U[利用者] --> LB[ロードバランサ]
```
````

「図 1: 全体構成」として採番され、本文中の「図 1」がその図へのリンクになります。
`examples/設計書.md` が実例です。

#### 読み込み方の選択

| 設定 | 動作 | ファイルサイズ | 閲覧条件 |
| --- | --- | --- | --- |
| `mermaid: cdn` | CDN から読み込む | そのまま（数十 KB） | **インターネット接続が必要** |
| `mermaid: true` | `assets/mermaid.min.js` を埋め込む | **図を含むファイル 1 つにつき +約 3.4 MB** | 接続不要 |
| `mermaid: "https://..."` | 指定 URL から読み込む | そのまま | その URL に到達できること |
| 省略 / `false` | 無効 | — | — |

> **`cdn` にすると、その種類で図を含む HTML は自己完結ではなくなります**（図の無いファイルには読み込みが入りません）。閉域ネットワークや
> オフラインで開くと、図の部分は定義テキストのまま表示されます（本文とレイアウトは
> 影響を受けません）。図が出ないと困る配布先がある場合は `mermaid: true` を選び、
> ファイルサイズを許容してください。

社内にホスティングした mermaid.js を使う場合は URL を直接指定できます。
改ざん検知を付けるなら `integrity` も指定できます。

```yaml
profiles:
  spec:
    mermaid:
      url: "https://intra.example.com/lib/mermaid@11/mermaid.min.js"
      integrity: "sha384-..."     # 任意
```

### 8. 生の HTML を扱う

Markdown の仕様では、`.md` に直接書いた HTML はそのまま出力されます。docmold の出力は
ファイルサーバーやメールで配布されるため、**既定では許可リストで絞ります**。

| `.md` の記述 | 既定（`strict`） |
| --- | --- |
| `<script>alert(1)</script>` | 中身ごと削除 |
| `<img src="図.png" onerror="alert(1)">` | `onerror` だけ削除（画像は残る） |
| `<a href="javascript:...">押す</a>` | リンクを無効化（文字は残る） |
| `<iframe>` `<form>` `<svg>` | 削除 |
| `<a href="file:///…">` | リンクを無効化（`allow_schemes` で通せる） |
| `<div style="color:red">` | `style` を削除（文字は残る） |
| `<br>` `<details>` `<abbr>` | **そのまま残る** |
| `**強調**` `[リンク](設計書.md)` などの Markdown 記法 | **影響なし** |
| 表の桁揃え（`\| ---: \|`）| **影響なし** |

落とした箇所があると警告が出ます。末尾の内訳で、何を落としたかが分かります。
「script が動く」と付いたものは、開いた人の端末で script が動く書き方だったものです。

```
警告: 定例.md: 本文の HTML を 3 箇所ほど除きました（sanitize: strict。素通しにするには sanitize: false）。内訳: script が動くリンク 1・script が動く属性 1・script などの要素 1
```

#### 素通しに戻す

自分で書いた `.md` しか変換せず、HTML を自由に使いたい場合は解除できます。

```yaml
# 全体の既定を変える
sanitize: false

# 種類ごとに変える（設計書だけ HTML を自由に使う）
profiles:
  spec:
    sanitize: false
```

種類ごとの指定が、全体の既定より優先されます。

#### ファイルサーバーへのリンクを通す（`allow_schemes`）

`file:` のリンクは既定で無効化されます（配った先の手元のファイルを指さないため）。
**閉域で配る前提の種類だけ通す**こともできます。

```yaml
profiles:
  weekly3:
    allow_schemes: [file]
```

```markdown
- [手順書](file:///C:/docs/手順.xlsx)
```

同梱の `weekly3` と `catalog` は既定で `file` を通します。ほかの種類は落とします。

- 通せるのは `file` / `about` だけです。`javascript` などは書いてもエラーになります。
- `<file:///…>` の書き方は**使えません**。python-markdown が `file:` を自動リンクの
  対象にしておらず、HTML のタグとして読まれて消えます。角括弧で書いてください。
- リンク先が HTML と同じ場所にあるなら、相対パス（`[手順書](手順.xlsx)`）や
  UNC（`[共有](//server/share/手順.xlsx)`）の方が確実です。

> 許可リストは `sanitize.py` にあります。ルール層やテンプレートが作る要素
> （チェックボックス、コピーボタン、Mermaid の読み込み）はサニタイズの後に
> 組み立てるため、影響を受けません。

---

### 9. 節を横に並べる

`type: weekly3` は、見出し 2（`##`）を 4 つ書くと、1 つ目を横幅いっぱいのトピックス、残りの 3 つを横に並べた列にします。
「前週 / 今週 / 来週の予定」のように、同じ形のものを並べて見比べる用途向けです。
小見出しごとのまとめ直し・1 行 1 件のカード・週ごとのファイルに分けて書く方法は、
[weekly3 のページ](docs/examples/weekly3.html) にあります。

---

### 10. リンクを書く

種類によらず共通の書き方です。

| 書きたいもの | 書き方 |
| --- | --- |
| Web ページ | `[社内ポータル](https://example.com/portal)` |
| URL をそのまま見せる | `<https://example.com/portal>` |
| 別の文書 | `[設計書](設計書.md)` → `.html` に書き換わる |
| 同じ場所のファイル | `[手順書](手順.xlsx)` |
| ファイルサーバー | `[共有](//server/share/手順.xlsx)` |
| ローカルの絶対パス | `[手順書](file:///C:/docs/手順.xlsx)`（`allow_schemes` の指定が要る） |

#### 文書内リンク（見出しの id）

見出しの id は GitHub と同じ規則で作るので、`[概要](#概要)` のような文書内リンクは GitHub でも HTML でも成立します。

| 見出し | id |
| --- | --- |
| `## 概要 (説明)` | `#概要-説明` |
| `## A-6 世代管理　実装仕様書` | `#a-6-世代管理実装仕様書`（**全角空白は区切りにならず消えます**） |
| `## 概要` が 2 つ目 | `#概要-1` |

#### 素の URL はリンクになりません

```markdown
https://example.com/portal        ← ただの文字列
<https://example.com/portal>      ← リンク
```

山括弧で囲めばリンクになります。ただし**自動リンクになるのは
`http` / `https` / `ftp` / `mailto` だけ**です。`<file:///…>` は Markdown が
リンクと判断せず、HTML のタグとして読まれて**表示が消えます**（警告は出ます）。
`file:` は必ず角括弧で書いてください。

#### `\`（円記号）は消えることがあります

`\` は Markdown のエスケープ文字です。**次が記号のときだけ**、その `\` が消えます。

| 書いたもの | 結果 |
| --- | --- |
| `C:\docs\手順.xlsx` | `C:\docs\手順.xlsx`（無事） |
| `C:\docs\_下書き\*案.xlsx` | **`C:\docs_下書き*案.xlsx`** |
| `\\server\share\手順.xlsx` | **`\server\share\手順.xlsx`** |
| `[C:\docs\](…)` | **リンクにならない**（`\]` と読まれる） |

リンク先でも表示文字でも本文でも同じように起こり、**警告は出ません**。
「普通のパスは平気なのに、特定のパスだけ崩れる」ため気付きにくい箇所です。

##### 対処

**基本は `/` で書くこと**です。Windows は `/` 区切りのパスも受け付けるので、
エスケープを気にせずに済みます。

```markdown
- [手順書](file:///C:/docs/_下書き/案.xlsx)
- [共有フォルダ](//server/share/手順.xlsx)
```

`\` をどうしても使いたい場合は、**場所によって対処が変わります**。

| 使いたい場所 | 対処 | 例 |
| --- | --- | --- |
| 本文・表示文字 | バッククォートで囲む | `` `C:\docs\_下書き\*案.xlsx` `` |
| 本文・表示文字（囲みたくない） | `\` を 2 本重ねる | `C:\\docs\\_下書き\\*案.xlsx` |
| リンク先（`( )` の中） | `\` を 2 本重ねる | `[共有](\\\\server\\share\\案.xlsx)` |

**バッククォートの中ではエスケープが働きません。** 打ち間違いの余地が無いので、
見た目に `\` を残したいときはこれが確実です。等幅で表示されます。

> **表の中だけは例外で、パイプにエスケープが要ります。** 表はセルの区切りを
> バッククォートより先に判定するため、`` `| ---: |` `` と書くとその行が余分な列に割れます。
> `` `\| ---: \|` `` と書いてください。**表示は `| ---: |` になります**（GitHub と同じく、
> 表の中のパイプに限ってエスケープを外します）。

```markdown
- 保存先は `C:\docs\_下書き\*案.xlsx` です
- [`C:\docs\_下書き\*案.xlsx`](file:///C:/docs/_下書き/案.xlsx)
```

最後の例は、**表示だけ `\` のまま見せ、リンク先は `/` で書く**形です。見た目と動作の
両方を満たせるので、Windows のパスを載せるときはこれを勧めます。

リンク先はバッククォートで囲めないため、`\` を使うなら 2 本重ねるしかありません。
**書き換えのたびに数え間違いが起きる**ので、リンク先は `/` に統一してください。

#### 無効化されるリンク

`sanitize: strict`（既定）では、`javascript:` などのスキームを持つリンクは
**無効化されます**（文字は残ります）。落とした箇所は警告に出ます。

---

### 11. まとまりを横断して引く

`type: catalog` は、**まとまり（案件・コースなど）ごとに書いたリンク集を、段階や項目で横断して引ける 1 枚の HTML** にします。
まとまりごとの `.md` に、段階を見出し 2、項目を箇条書き（`名前｜[パス](リンク先)｜補足`）で書きます。

```markdown
## 要件定義

- 要件定義書｜[\\fileserver\projects\sales\要件定義書.xlsx](file://fileserver/projects/sales/要件定義書.xlsx)
- 業務フロー｜来月から着手
```

画面には項目の名前の下に、リンク先のフルパス（`\\fileserver\projects\…`）が出ます。パスはリンク先から作るので、
`[]` の中の `\` が Markdown で減っても崩れません。

- 名前とリンクを分ける `名前｜[パス](リンク先)｜補足` は 0.16.0 からの書き方です。それより前の版は、前からの `[名前](リンク先)｜補足` だけを読み、
  新しい書き方ではリンクが黙って消えます。書く側と、持ち込む docmold の版をそろえてください
- リンクの `[]` の中の縦棒（`｜` `|`）で欄が切れないのは 0.16.1 からです（Windows のファイル名に使える全角の `｜` を、パスのまま書けます）。
  それより前の版では、リンクが消えてパスの残りが補足に入ります

親の `.md` が `取り込み:` でまとまりの `.md` を束ねます。`呼び名:` で画面に出す名前（既定は「まとまり」「段階」「項目」）を、
`段階:` で段階の並び順を決めます。

```yaml
---
type: catalog
title: 作成物一覧
呼び名:
  まとまり: 案件
  段階: 局面
  項目: 作成物
段階: [要件定義, 基本設計, 詳細設計, 製造, テスト, 移行]
取り込み:
  販売管理刷新: 案件/販売管理刷新.md
  在庫連携: 案件/在庫連携.md
---
```

開いた HTML では、上の帯で「まとまりごと・段階ごと・項目ごと・一覧表」の見方を切り替え、まとまり・段階・名前で絞り込めます。
絞り込んだ見え方は URL に入るので、そのリンクを渡せば同じ見え方で開けます。
書き方の細部・一覧表・警告の出る書き方は、[catalog のページ](docs/examples/catalog.html) にあります。

---

## 同梱の種類

| type | 向いている文書 |
| --- | --- |
| [`default`](docs/examples/default.html) | 種類を決めない文書（意味づけなし） |
| [`minutes`](docs/examples/minutes.html) | 議事録。ToDo・担当者・決定事項を目立たせる |
| [`procedure`](docs/examples/procedure.html) | 作業手順書。手順を採番し、見出しごとに改ページ |
| [`incident`](docs/examples/incident.html) | 障害報告。冒頭のサマリカードと時系列 |
| [`spec`](docs/examples/spec.html) | 設計書。表紙・章番号・図表番号 |
| [`weekly`](docs/examples/weekly.html) | 週次報告。状態のバッジと進捗バー |
| [`weekly3`](docs/examples/weekly3.html) | 前週・今週・来週を 3 列に並べる週次の資料 |
| [`wiki`](docs/examples/wiki.html) | 知識ベースのノート。コールアウトと章番号なしの目次 |
| [`catalog`](docs/examples/catalog.html) | まとまり・段階・項目で引くリンク集。見方の切り替えと絞り込み |
| `fragment` | 取り込み用の断片。単独では変換しない（[weekly3 のページ](docs/examples/weekly3.html)） |

種類ごとの書き方と、変換すると何がどう変わるかは、表のリンク先のページにあります。
一覧は `python docmold.py --list-types` でも確認できます。

---

## CLI オプション一覧

```
python docmold.py [入力...] [オプション]
```

| オプション | 説明 |
| --- | --- |
| `入力` | `.md` ファイル、またはそれを含むディレクトリ（複数可、ディレクトリは再帰） |
| `-o`, `--output` | 出力先。入力が 1 ファイルで `.html` を指定したときだけファイル扱い（省略時は [出力先](#出力先) を参照） |
| `-t`, `--type` | front matter の `type` を上書き |
| `-c`, `--config` | 設定ファイルのパス（省略時: ツールのフォルダの `config.yaml` → 同梱の `profiles.yaml`。作業フォルダは見ない） |
| `--index` | 出力ディレクトリに索引 HTML を生成 |
| `--list-types` | 指定できる種類の一覧を表示して終了 |
| `--list-rules` | 登録済みルールの一覧を表示して終了 |
| `--dry-run` | 変換の検証のみ。HTML は書き出さない |
| `--reproducible` | 出力に生成時刻を埋め込まない（索引を差分管理したいとき） |
| `--strict` | 警告があれば失敗扱いにする（終了コード 1） |
| `-v`, `--verbose` | 1 件ごとの変換結果を出力 |
| `-q`, `--quiet` | 警告以外の進捗を抑制 |
| `--version` | 版を表示して終了。出力した HTML の `<meta name="docmold-version">` にも同じ版が入る |
| `-h`, `--help` | 引数の説明を表示して終了 |

オプションは省略せずに書きます（`--list-t` のような省略形は通らず、終了コード 2 で止まります）。

### 警告を取りこぼさない（`--strict`）

`type` のタイプミスや画像の欠落は警告として表示されますが、既定では**終了コードは 0** です。
バッチやタスクスケジューラで回すと誰も気づきません。`--strict` を付けると失敗扱いになります。

```
$ docmold.py docs -o out --strict
警告: docs/定例.md: 未知の type 'minuets': default で処理します (指定できる type: ...)
--strict: 警告が 1 件あるため失敗として扱います。
$ echo $?
1
```

失敗扱いでも**変換結果は書き出します**。何が起きたかを出力で確認できるようにするためです。

---

## 出力先

### 既定（`-o` を付けない場合）

**docmold.py と同じディレクトリの `out/` 配下に、実行日時のフォルダを作って** その中に出力します。

```
C:/tools/docmold/out/
├── 20260914-213045/      ← 1 回目の実行
│   ├── 定例.html
│   └── index.html
└── 20260914-224512/      ← 2 回目の実行
    └── 障害報告.html
```

- **起動位置に依存しません。** メニューをどこから起動しても、バッチをどのフォルダで実行しても同じ `out/` に出ます
- **実行ごとにフォルダが分かれます。** 複数回実行しても結果が混ざらず、前回の出力が上書きされることもありません。
  同じ秒に複数のプロセスが走った場合は連番が付きます（`20260914-213045-2`）
- フォルダ名は `YYYYMMDD-HHMMSS`
- 古い実行結果は自動では消えません。不要になったらフォルダごと削除してください

### `-o` を指定した場合

指定したパスを**そのまま**使います。タイムスタンプのフォルダは作りません。
バッチやタスクスケジューラから決まった場所に出す用途を想定しています。

| 実行 | 出力 |
| --- | --- |
| `docmold.py docs -o dist` | `dist/` 配下（`docs/` の階層を維持） |
| `docmold.py memo.md -o report.html` | `report.html` |
| `docmold.py docs -o //server/share/html --index` | 共有フォルダ直下に索引ごと出力 |

相対パスは**実行時のカレントディレクトリ基準**です。ファイル扱いになるのは
「入力が 1 ファイル」かつ「拡張子が `.html` / `.htm`」のときだけで、
それ以外はディレクトリ名として扱われます。

複数のファイルを 1 つの HTML にはまとめられないため、入力が複数のときに `.html` を
指定すると、その名前のディレクトリを作ったうえで警告します。

```
$ docmold.py docs -o out.html
警告: -o 'out.html' はディレクトリ名として扱います（入力が複数のため、1 つの HTML にはまとめられません）
```

ディレクトリを渡した場合は入力の階層を保ちます（`docs/sub/b.md` → `<出力先>/sub/b.html`）。
索引 HTML（`--index`）は出力ディレクトリ直下の `index.html` です。

### 出力先が重なる場合

別々のディレクトリにある同名ファイルを個別に指定すると、出力先がぶつかります。
この場合は名前をずらして**両方残し**、警告を出します。

```
$ docmold.py a/doc.md b/doc.md -o out
警告: 出力先が重なるため名前を変えました: b/doc.md → doc-b.html（doc.html は先に変換したファイルが使用）

$ ls out
doc.html  doc-b.html
```

2 番目以降に親ディレクトリ名を付けます。それでも重なる場合は連番になります。
ディレクトリを渡した場合は階層を保つため、元から衝突しません。

---

## 設定ファイル

読み込み順は **同梱 `profiles.yaml` → ユーザ `config.yaml`（再帰マージ）**。

ユーザ `config.yaml` は、`-c` で指したもの、無ければツールのフォルダ（`docmold.py` と同じフォルダ）のものを使います。
**作業フォルダの `config.yaml` は見ません。** 別のフォルダから動かしたときに、そのフォルダにあるほかのツールの設定を拾わないためです。
作業フォルダの設定を使うときは `-c config.yaml` と指します（0.13.0 で変えました）。

設定の誤りには、誤りのあるファイルのパスが付きます。知らない項目は、似た項目を添えて、すべてまとめて示します。

```text
エラー: C:\tools\docmold\config.yaml: 知らない項目があります:
  profiles.minutes.tocc は知らない項目です（toc の書き間違いでは？）
  profiles.minutes.print.cover は知らない項目です（cover_page の書き間違いでは？）
```

トップレベルに書けるのは `profiles` / `themes` / `keywords` / `sanitize` / `rule_modules` / `template_dirs` / `theme_dirs` の 7 つだけです。
`sanitize` は全プロファイルの既定で、`profiles.<type>.sanitize` が優先します。
`rule_modules` は自分で書いたルールのファイルの一覧で、`config.yaml` から見た相対パスで書きます
（[種類を追加する](#5-種類を追加する)）。無いファイルを書くと設定の誤りとして止まります。
`template_dirs` / `theme_dirs` は自分で書いたテンプレートとテーマの CSS を置いたフォルダの一覧で、同じく
`config.yaml` から見た相対パスで書きます。無いフォルダを書くと設定の誤りとして止まります。

`profiles.<type>` に書けるキー:

| キー | 型 | 説明 |
| --- | --- | --- |
| `sanitize` | 文字列 / bool | `strict`（既定）/ `false`。本文の生 HTML を絞るか |
| `template` | 文字列 | `templates/`（か `template_dirs` のフォルダ）直下の HTML ファイル名（構造） |
| `theme` | 文字列 | `themes.<name>`（見た目 = CSS 変数） |
| `toc` | bool / マッピング | `false` / `true` / `{depth: 1-6, numbering: true / false}` |
| `rules` | リスト | 意味づけの後処理。**並べた順に適用される** |
| `extensions` | リスト | 基本拡張に追加する Markdown 拡張 |
| `meta_header` | リスト | 冒頭のメタ表に出す front matter のキーと順序 |
| `print` | マッピング | `page_break_per_h1` / `page_break_per_h2` / `cover_page` / `page: {size, orientation}`（用紙。[PDF 化する](#6-pdf-化する)） |
| `watermark` | 文字列 / `false` | 透かし文字列（例: `DRAFT`） |
| `mermaid` | bool / 文字列 / マッピング | `false` / `true`（`assets/mermaid.min.js` を埋め込む）/ `cdn` / URL / `{url, integrity}`（[図を使う](#7-図を使う)） |
| `allow_schemes` | リスト | 既定で落とすリンクのうち通すスキーム。`file` / `about`（[ファイルサーバーへのリンクを通す](#ファイルサーバーへのリンクを通すallow_schemes)） |
| `description` | 文字列 | `--list-types` に出す説明 |

`toc.numbering` は見出しに通し番号を振ります。**見出しの文言が元資料の章番号を含む文書**
（`## 1. 概要`）では `numbering: false` にしてください。付けたままだと `1.1 1. 概要` と二重になります。
文言が数字で始まるかどうかで自動的に切り替えることはしません（「2026年の方針」と区別できないため）。

`themes.<name>` の各キーは CSS 変数として `:root` に流し込まれます（`accent_weak` → `--accent-weak`）。
テーマの色を増やしたい場合は、キーを足して `themes/*.css` から参照してください。

設定ファイルに置くのは **プロファイルの定義と、ルールのファイルの場所だけ** です。判定ロジックを持たないため、
YAML は「どんな表現があるか」の一覧として読める状態に保たれます。

---

## ルール一覧

`python docmold.py --list-rules` で確認できます。

| ルール | 対象 | 内容 |
| --- | --- | --- |
| `attendee_table` | minutes | 「出席者」節の氏名をバッジ化 |
| `todo_checklist` | minutes | 「ToDo」節をチェックボックス化、`担当: X` / `@X` をバッジ化 |
| `decision_highlight` | minutes | 「決定事項」節をコールアウトで強調 |
| `step_numbering` | procedure | 手順見出しをカード化し自動採番、完了チェック欄を追加 |
| `command_block_copy` | procedure | コードブロックにコピーボタンを追加 |
| `rollback_callout` | procedure | 「切戻し手順」節を警告コールアウト化 |
| `severity_badge` | incident | 重要度をバッジ化（front matter と表の両方） |
| `impact_summary` | incident | 冒頭サマリカードを front matter から組み立て |
| `timeline_table` | incident | 時刻列を持つ表をタイムライン表示に変換（時刻列が無ければ「時系列」の節の中の最初の表） |
| `figure_caption` | spec | 画像を `<figure>` 化し「図 N」を自動採番 |
| `table_caption` | spec | 表に「表 N」のキャプションを付与 |
| `cross_reference` | spec | 本文中の「図 N」「表 N」を図表へのリンク化（「地図 1」のように語の一部なら除く） |
| `status_badge` | weekly | 表の「状態」列をバッジ化 |
| `progress_bar` | weekly | 表の「進捗」列の `80%` を進捗バー化 |
| `period_range` | weekly / weekly3 | front matter の「開始日」から「期間」を組み立てる |
| `list_table` | weekly / weekly3 | `表:` の行に続く箇条書きを表に変換 |
| `column_periods` | weekly3 | 列の見出しに `（m/d(曜)〜m/d(曜)）` を補う |
| `column_dates` | weekly3 | 取り込み先のファイル名の日付が、列の週と合っているか確かめる |
| `count_summary` | weekly3 | `残:3 / 新規:1` だけの段落を件数の並びに変換 |
| `entry_card` | weekly3 | `｜` 区切りのリスト項目を 1 件のカードに変換（字下げした内容はコメント） |
| `group_columns` | weekly3 | 見出し 2 の 1 つ目を 1 列、2 つ目以降を列にする。列の中は小見出し 2 段でまとめ直す |
| `topic_cards` | weekly3 | 1 列にした節を、小見出しごとの枠に分ける（縦に積む） |
| `topic_index` | weekly3 | 1 列にした節の先頭に、枠への目次を置く |
| `callout_blockquote` | wiki / weekly3 | `> [!warning] 見出し` で始まる引用を枠付きのコールアウトに変換 |
| `catalog` | catalog | 段階の見出しと項目の箇条書きを読み取り、見方の切り替えと絞り込みの元にする |

ルールは **どの種類からでも使えます**。`rules:` に並べた順に適用されるため、
`cross_reference` は採番ルール（`figure_caption` / `table_caption`）より後に置いてください。

種類に固有のルールの書き方は、[同梱の種類](#同梱の種類) のリンク先のページにあります。

### 検出語を調整する（`keywords`）

ルールは見出しや表のヘッダ名で対象を見分けます。その語は `config.yaml` で変えられます。

```yaml
keywords:
  status_column: [状態, ステータス, status, 進行, 対応状況, 進捗状況]
  status_ok:     [完了, 済, 対応済, クローズ, done, closed, 検収済]
```

グループ単位の**置き換え**なので、語を足したい場合も既定値ごと書いてください。
書かなかったグループは既定のままです。

| グループ | 用途 |
| --- | --- |
| `attendee` / `todo` / `decision` | 議事録の各節の見出し |
| `index_date` | 索引に出す日付として front matter から拾うキー |
| `step` / `rollback` | 手順の見出し / 切戻しの見出し |
| `severity` / `time_column` / `timeline` | 重要度 / 時刻列 / 時系列の見出し |
| `status_column` / `progress_column` | 状態列 / 進捗列のヘッダ名 |
| `status_ok` / `status_warn` / `status_danger` | 状態バッジの色分け |
| `table_marker` | 箇条書きを表にする目印の語 |
| `include` | 別の `.md` を差し込む front matter のキー |
| `period` / `period_start` | 期間 / 開始日として front matter から拾うキー |

状態バッジは、状態の語と完全に一致するものを先に見ます。一致が無ければ、含まれている語のうち**最も長いもの**で色を決めます（`停止中` は `中` より長い `停止` で赤）。
長さが同じなら `status_ok` → `status_warn` → `status_danger` の順に先のものを採ります。

既定値の全文は [config.example.yaml](config.example.yaml) に載せてあります。

---

## front matter のキー

| キー | 説明 |
| --- | --- |
| `type` | 種類。省略すると `default` |
| `title` | 文書タイトル。省略時は最初の見出し → ファイル名の順で決まる |
| `取り込み` | 別の `.md` を `## 見出し` として差し込む（`見出し: パス` の並び） |
| `呼び名` | `catalog` の画面に出す名前（`まとまり: 案件` / `段階: 局面` / `項目: 作成物`） |
| `段階` | `catalog` の段階の並び順（`[要件定義, 基本設計]`）。呼び名を付けたなら、そのキー（`局面:`）でも書ける |
| その他 | `meta_header` に並べたキーが冒頭のメタ表に出る（`出席者: [山田太郎, 鈴木花子]` のようなリストも可） |

意味を持つキーによく似た打ち間違いは警告します。

```
$ docmold.py 定例.md
警告: 定例.md: front matter の 'titel' は 'title' の打ち間違いではありませんか
```

覚え書きとして自由に書いた項目（`備考` など）は指摘しません。判定は類似度によるため、
**日本語の短いキーの 1 文字違いは拾えません**（`作成日` と `作成者` のように、
1 文字違いでも別物として使い分けるキーが多く、下げると誤検知が増えるためです）。

`incident` では `発生日時` / `復旧日時` / `影響範囲` / `重要度` がサマリカードになります。
`_` で始まるキーはツールの内部用に予約されています。

`weekly` / `weekly3` では、`開始日` だけを書けば 1 週間分の `期間` を組み立てます
（[weekly のページ](docs/examples/weekly.html)）。

---

## 終了コード

| コード | 意味 |
| --- | --- |
| `0` | 全件成功（警告のみの場合も含む） |
| `1` | 1 件以上の変換に失敗、または対象が見つからない。`--strict` 時は警告があった場合も |
| `2` | 設定の誤り / 引数の誤り / 出力フォルダを作れない / 依存が足りない |
| `130` | 中断（Ctrl+C か、外から止められた） |

---

## 既知の制約

- **ルールの検出は見出し文字列と表のヘッダ名に依存** します。「出席者」「ToDo」「時刻」「状態」「進捗」など、
  想定の語を含まない見出し / 列名は対象になりません（`config.yaml` の `keywords:` で調整できます）。
- **`spec`（設計書）と `wiki`（ノート）は `mermaid: cdn` を使うため、その出力のうち図を含むものだけ外部参照を持ちます**。
  閉域環境で図を出すなら `mermaid: true`（同梱を埋め込む）に変えてください。
  他の種類では既定で無効です。有効にする場合、`cdn` なら閲覧時にインターネット接続が要り、
  `true`（同梱）なら `assets/mermaid.min.js` の配置が必要です（無ければ警告のうえ図は描画されません。
  自動ダウンロードはしません）。
- 画像のパスは `%20` のような URL エンコードのままでも探します（Obsidian や VS Code の貼り付けの形）。
- **画像は 8 MB まで** 埋め込みます。それを超えるものは警告のうえスキップします（base64 でファイルが肥大するため）。
- **手順書のチェック欄は保存されません**。ブラウザ上の作業用です。記録には印刷 / PDF 保存を使ってください。
- **パスに含まれる `\` は消えることがあります**（Markdown のエスケープ文字のため）。
  区切りは `/` で書いてください。詳しくは [リンクを書く](#10-リンクを書く) を参照。
- 文字コードは **UTF-8 → CP932** の順で読み込みます。それ以外は変換エラーになります。
- **`catalog` の見方の切り替えと絞り込みは JavaScript で動きます**。JavaScript が動かない環境では、まとまり → 段階 → 項目の並びで全件を出します。

---

## ファイル構成

使うときに要るファイルです。開発に使うファイル（テストなど）は含めていません。

```text
docmold/
├── menu.bat               メニューの起動用（Windows でダブルクリック。.md やフォルダを落としてもよい）
├── update.bat             ファイルサーバーから更新する（Windows でダブルクリック）
├── undo_changes.bat       手元の変更を backup\ に退避して元に戻す（Windows でダブルクリック）
├── undo_changes.py        その本体
├── docmold.py             コマンドラインの入口
├── menu.py                対話メニュー
├── deps.py                依存の確認と案内（サードパーティを import しない）
├── cli.py                 引数の解釈・入出力の解決・索引の生成
├── config.py              種類の定義と設定ファイルの読み込み・検証
├── converter.py           変換の流れ（種類の決定 → Markdown → ルール → 描画）
├── frontmatter.py         front matter の分離
├── include.py             取り込み（front matter に並べた .md を差し込む）
├── mermaid_ext.py         mermaid のコードブロックを図にする Markdown の拡張
├── sanitize.py            本文の生 HTML を許可リストで絞る
├── renderer.py            テンプレートの描画とテーマ CSS の組み立て
├── assets.py              画像の埋め込み・同梱の資材の読み込み
├── version.py             版
├── rules/                 ② ルール層（意味づけ）。rules/ の .py は全部読み込む
│   ├── __init__.py        ルールの登録（@rule）
│   ├── common.py          DOM を扱う共通の部品
│   ├── callout.py  incident.py  keywords.py  minutes.py  period.py
│   └── catalog.py  procedure.py  spec.py  tables.py  weekly.py  weekly3.py
├── templates/             ① テンプレート層（構造）
│   ├── base.html          共通の骨格
│   ├── article.html  catalog.html  columns.html  dashboard.html  document.html
│   ├── report.html  stepped.html
│   └── index.html         一括変換の索引
├── themes/                ③ テーマ層（見た目）
│   ├── base.css           共通のスタイル（色は CSS 変数で受ける）
│   ├── alert.css  corporate.css
│   └── print.css          印刷のとき（@media print）
├── assets/                同梱の資材（mermaid.min.js を置く場所。CDN から読むなら不要）
├── local/                 自分で足すテンプレート・テーマの置き場（Git が扱わない。中身は空）
├── profiles.yaml          同梱の種類の定義
├── config.example.yaml    設定ファイルの雛形（写して config.yaml にする）
├── requirements.txt       依存のパッケージ（Anaconda 以外の環境で入れる）
├── README.md              この文書
├── README.html            この文書をブラウザで読む形にしたもの
├── AGENTS.md              コマンドを動かせる AI が最初に読む、使い方の手引き
├── AGENTS.html            AGENTS.md をブラウザで読む形にしたもの
├── docs/
│   ├── EXAMPLES.md        実行例（メニューとコマンドラインで動かしたときの画面）
│   ├── EXAMPLES.html      その HTML
│   └── examples/          種類ごとの実行例（<type>.md と、その HTML）
├── examples/              種類ごとのサンプル
│   ├── *.md               入力
│   ├── parts/             取り込みの見本（週次の断片・案件ごとの作成物）
│   └── html/              変換結果
├── .gitignore             Git で扱わないファイル（config.yaml・local/ の中身・out/ など）
└── .gitattributes         .bat の改行を CRLF に固定する
```

---

