"""Python の版と依存パッケージの確認と、足りないときの案内。

インタプリタを取り違えたときに、トレースバックではなく
「どの Python で動いていて、何を入れればよいか」を出すためのモジュール。
そのため **サードパーティを import しない**（このモジュール自体が落ちては意味がない）。
案内の形はほかのツールと同じにする（入れるものだけが違う。docmold は requirements.txt をまとめて入れる）。
"""
from __future__ import annotations

import importlib.util
import sys
from pathlib import Path
from typing import List

SCRIPT_DIR = Path(__file__).resolve().parent

#: 動かせる最も古い Python。macOS 標準の python3 が 3.9 のため
MIN_PYTHON = (3, 9)

#: 依存や版が足りないときの終了コード（設定の誤りと同じ 2）
EXIT_ENVIRONMENT = 2

#: import 名 → requirements.txt 上の名前。無いと変換できない。
REQUIRED = {
    "markdown": "Markdown",
    "jinja2": "Jinja2",
    "yaml": "PyYAML",
    "bs4": "beautifulsoup4",
}

#: 無くても動くもの（コードハイライトが無効になるだけ）。
OPTIONAL = {
    "pygments": "Pygments",
}


def missing(names: dict = None) -> List[str]:
    """入っていないパッケージを requirements.txt 上の名前で返す。"""
    targets = REQUIRED if names is None else names
    return [
        package for module, package in targets.items()
        if importlib.util.find_spec(module) is None
    ]


def explain(packages: List[str]) -> str:
    """不足しているときの案内文を組み立てる。

    入れる先は、実行中の Python を名指しする（"<python>" -m pip install）。Windows では Python が複数入っていることが
    あり、ただの pip install だと別の Python に入って「入れたのに直らない」が起きる。
    """
    requirements = SCRIPT_DIR / "requirements.txt"
    lines = [
        f"必要なライブラリ {', '.join(packages)} が入っていません。",
        f"  実行中の Python: {sys.executable}",
        "  次のコマンドで、この Python に入れてください:",
        f'      "{sys.executable}" -m pip install -r "{requirements}"',
        "  ライブラリが入っている別の Python（Anaconda など）があれば、そちらで動かしても構いません。",
    ]
    return "\n".join(lines)


def require_python(version_info=None) -> None:
    """Python が古ければ、入れ方の案内を出して止める。

    古い Python では、新しい書き方のところで構文の誤りやトレースバックになり、何をすればよいか分からないため。
    依存の確認（ensure）より先に呼ぶ。
    """
    version = tuple(version_info or sys.version_info)[:2]
    if version >= MIN_PYTHON:
        return
    need = ".".join(str(n) for n in MIN_PYTHON)
    sys.stderr.write(
        f"Python {need} 以上を入れてください。\n"
        f"  実行中の Python: {'.'.join(str(n) for n in version)}（{sys.executable}）\n"
        "  https://www.python.org/ から入れ、README の手順で依存も入れてください。\n"
    )
    raise SystemExit(EXIT_ENVIRONMENT)


def make_console_safe(streams=None) -> None:
    """UTF-8 でないコンソールで、表せない文字を「?」に置き換えて出すようにする。

    Windows の日本語コンソールは既定で CP932 で、CP932 に無い文字を print すると
    UnicodeEncodeError で落ちる。ソースの文字はテストで CP932 に収めているが、
    ファイル名や config.yaml に書いた説明など、外から来る文字（絵文字など）は防げない。
    落ちるよりは、その文字だけ「?」になる方がよい。

    - コードページ（chcp）は変えない。同じ窓で次に動かすものに影響するため
    - 置き換えるのは画面の表示だけ。書き出す HTML とファイル名は変わらない
    - UTF-8 のコンソール（macOS など）では何もしない
    """
    for stream in (sys.stdout, sys.stderr) if streams is None else streams:
        encoding = (getattr(stream, "encoding", None) or "").lower().replace("-", "").replace("_", "")
        if encoding in ("", "utf8") or not hasattr(stream, "reconfigure"):
            continue
        try:
            stream.reconfigure(errors="replace")
        except (ValueError, OSError):
            pass


def stop_on_sigterm() -> None:
    """外から止める合図（SIGTERM）を、Ctrl+C と同じ KeyboardInterrupt にする。

    コマンドを動かす道具は、時間の上限を超えると SIGTERM で止めることがある。何もしないと
    Python はその場で終わり、「中断しました。」も出ず、終了コードも表に無い値（143）になる。
    入口で呼び、Ctrl+C のときと同じく「中断しました。」と 130 で終わらせる。

    - 呼べるのはメインのスレッドだけ。呼べない環境（SIGTERM が無いなど）では何もしない
    - Windows では、捕まえられない止め方（プロセスを強制終了する）がある。そのときは今までどおり
    """
    import signal

    def _interrupt(signum, frame):
        raise KeyboardInterrupt

    try:
        signal.signal(signal.SIGTERM, _interrupt)
    except (AttributeError, ValueError, OSError):
        pass


def ensure(exit_code: int = EXIT_ENVIRONMENT) -> None:
    """不足していれば案内を出して終了する。足りていれば何もしない。"""
    packages = missing()
    if packages:
        sys.stderr.write(explain(packages) + "\n")
        raise SystemExit(exit_code)
