"""
Backlog API クライアント。取得結果のキャッシュと、エラーの表示。

通信（送る・再送する・待つ・エラーにする）と、どのツールでも使う取得は、共通の部品 backlog_common/client.py にある。
ここには、レポートで使う取得（コメントの履歴）とキャッシュだけを足す。
"""
import sys
import threading

from backlog_common import client as _common
from backlog_common.client import BacklogAPIError
from backlog_common.config import api_key_source_line

from backlog_report.core import API_PAGE_SIZE

__all__ = ["BacklogAPIError", "BacklogClient", "ProjectInfoCache", "format_api_error"]


def format_api_error(err: BacklogAPIError) -> str:
    """BacklogAPIError を利用者向けの日本語メッセージに整形する"""
    if err.status is None:
        # 通信の失敗。理由と確かめることは、共通の部品がエラーの文に入れている（API キーを含む URL は出さない）
        return f"エラー: {err}"

    lines = [f"エラー: API呼び出しに失敗しました（HTTP {err.status}）: {err.endpoint}"]
    if err.detail:
        lines.append(f"  詳細: {err.detail}")
    elif err.raw_body:
        # detailが取れない場合はボディをそのまま表示（デバッグ用）
        lines.append(f"  レスポンス: {err.raw_body[:500]}")

    if err.status == 400:
        lines.append("  → リクエストパラメータを確認してください。")
        lines.append("    フィルターの field_name / field_id や values の値が正しいか確認してください。")
    elif err.status == 401:
        lines.append("  → API キーを確認してください。")
    elif err.status == 403:
        lines.append("  → API キーの権限を確認してください。")
    elif err.status == 404:
        lines.append("  → space_host または project_key を確認してください。")
    elif err.status == 429 or 500 <= err.status < 600:
        lines.append(f"  → リトライ({BacklogClient.MAX_RETRIES}回)しても回復しませんでした。時間をおいて再実行してください。")
    if err.status in (401, 403) and err.api_key_source:
        # API キーは環境変数・設定ファイル・.env のどれからも読むので、直す場所が分かるように
        lines.append(api_key_source_line(err.api_key_source))
    return "\n".join(lines)


class BacklogClient(_common.BacklogClient):
    def __init__(self, space_host: str, api_key: str, ssl_verify: bool = True, base_path: str = "", debug: bool = False,
                 api_key_source: str = ""):
        super().__init__(space_host, api_key, ssl_verify=ssl_verify, base_path=base_path, debug=debug,
                         api_key_source=api_key_source)
        # 課題ページの URL（レポートのリンクに使う）。API ではなく画面側のパス。
        base_path = "/" + base_path.strip("/") if base_path.strip("/") else ""
        self.web_url = f"https://{space_host}{base_path}"

        # 実行中のコメントキャッシュ（フィルター間で課題が重複しても取得は1回）
        self._comment_cache: dict[int, list] = {}
        self._comment_lock = threading.Lock()
        # ステータス一覧のキャッシュ（同一プロジェクトのフィルターが複数あっても取得は1回）
        self._status_cache: dict[str | int, list] = {}
        # コメント取得に失敗した課題ID（集計後に警告表示する）
        self.comment_failures: set[int] = set()

    def get_statuses(self, project_id_or_key: str | int) -> list:
        """プロジェクトのステータス一覧を取得（実行中はキャッシュする）"""
        if project_id_or_key not in self._status_cache:
            self._status_cache[project_id_or_key] = super().get_statuses(project_id_or_key)
        return self._status_cache[project_id_or_key]

    def get_issue_comments(self, issue_id: int) -> list:
        """
        課題のコメントを全件取得（ページネーション対応）。
        コメントの changeLog にステータス変化履歴が含まれる。

        取得に失敗した場合は comment_failures に課題IDを記録し、
        その時点までに取得できた分を返す（1課題の失敗で全体を止めない）。
        """
        with self._comment_lock:
            cached = self._comment_cache.get(issue_id)
        if cached is not None:
            return cached

        all_comments: list = []
        min_id = None
        failed = False

        while True:
            params: dict = {"count": API_PAGE_SIZE, "order": "asc"}
            if min_id is not None:
                params["minId"] = min_id
            try:
                comments = self._get(f"/issues/{issue_id}/comments", params)
            except BacklogAPIError as e:
                failed = True
                if self.debug:
                    print(f"  [DEBUG] get_issue_comments({issue_id}) 失敗: {e}", file=sys.stderr)
                break
            if not comments:
                break
            all_comments.extend(comments)
            if len(comments) < API_PAGE_SIZE:
                break
            min_id = max(c["id"] for c in comments) + 1

        if failed:
            with self._comment_lock:
                self.comment_failures.add(issue_id)
            # 不完全な結果はキャッシュしない
            return all_comments

        with self._comment_lock:
            self._comment_cache[issue_id] = all_comments
        return all_comments


class ProjectInfoCache:
    """
    同一 project_key に対する API 呼び出しを1回に抑えるキャッシュ。

    保持する情報: {id, name, issue_type_map, custom_field_map, master_loaded}
    """

    def __init__(self, client: BacklogClient, debug: bool = False):
        self.client = client
        self.debug = debug
        self._cache: dict = {}

    def get(self, project_key: str, need_master: bool = False) -> dict:
        """プロジェクト情報をキャッシュ付きで取得する。"""
        if project_key not in self._cache:
            print(f"プロジェクト情報を取得中... ({project_key})")
            try:
                proj = self.client.get_project(project_key)
            except BacklogAPIError as e:
                print(f"エラー: プロジェクト情報の取得に失敗しました ({project_key})", file=sys.stderr)
                print(format_api_error(e), file=sys.stderr)
                sys.exit(1)
            self._cache[project_key] = {
                "id":               proj["id"],
                "name":             proj["name"],
                "issue_type_map":   {},
                "custom_field_map": {},
                "master_loaded":    False,
            }
            info = self._cache[project_key]
            print(f"プロジェクト名: {info['name']} (ID: {info['id']})")

        info = self._cache[project_key]
        if need_master and not info["master_loaded"]:
            self._load_master(project_key, info)
        return info

    def _load_master(self, project_key: str, info: dict) -> None:
        """種別・カスタム属性のマスターを取得して info に格納する"""
        print(f"種別・カスタム属性マスターを取得中... ({project_key})")
        try:
            issue_types = self.client.get_issue_types(project_key)
            info["issue_type_map"] = {it["name"]: it["id"] for it in issue_types}
            if self.debug:
                print(f"  [DEBUG] 種別マップ（名前→ID）: {info['issue_type_map']}", file=sys.stderr)
            else:
                print(f"  種別: {list(info['issue_type_map'].keys())}")
        except BacklogAPIError as e:
            print(f"  警告: 種別マスターの取得に失敗: {e}", file=sys.stderr)

        try:
            custom_fields = self.client.get_custom_fields(project_key)
            info["custom_field_map"] = {
                cf["name"]: {
                    "id":     cf["id"],
                    "typeId": cf.get("typeId"),
                    # リスト型（typeId 5/6/7/8）の選択肢を {名前: ID} で保持
                    "items":  {item["name"]: item["id"] for item in cf.get("items", [])},
                }
                for cf in custom_fields
            }
            if self.debug:
                for fname, finfo in info["custom_field_map"].items():
                    print(f"  [DEBUG] カスタム属性「{fname}」: id={finfo['id']}, "
                          f"typeId={finfo['typeId']}, items={finfo['items']}", file=sys.stderr)
            else:
                print(f"  カスタム属性: {list(info['custom_field_map'].keys())}")
        except BacklogAPIError as e:
            print(f"  警告: カスタム属性マスターの取得に失敗: {e}", file=sys.stderr)

        info["master_loaded"] = True
