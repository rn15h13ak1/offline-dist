"""
Backlog API クライアント。取得結果のキャッシュと、エラーの表示。

通信（送る・再送する・待つ・エラーにする）と、どのツールでも使う取得は、共通の部品 backlog_common/client.py にある。
ここには、レポートで使う取得（コメントの履歴）とキャッシュだけを足す。
"""
import sys
import threading

from backlog_common import client as _common
from backlog_common.client import BacklogAPIError

from backlog_report.core import API_PAGE_SIZE

__all__ = ["BacklogAPIError", "BacklogClient", "ProjectInfoCache", "format_api_error"]


def format_api_error(err: BacklogAPIError) -> str:
    """BacklogAPIError を利用者向けの日本語メッセージに整形する（API キーを含む URL は出さない）"""
    return _common.format_api_error(err)


class BacklogClient(_common.BacklogClient):
    # 400 のときは、フィルターの書き方も確かめるよう案内する。ほかの案内は共通の部品のもの
    HTTP_ERROR_HINTS = {
        **_common.BacklogClient.HTTP_ERROR_HINTS,
        400: "リクエストパラメータを確認してください。"
                "\n    フィルターの field_name・field_id・values の値が正しいか確認してください。",
    }

    def __init__(self, space_host: str, api_key: str, ssl_verify: bool = True, base_path: str = "", debug: bool = False,
                 api_key_source: str = "", **client_settings):
        # client_settings は設定ファイルの通信の設定（timeout など。共通の部品の client_settings が確かめたもの）
        super().__init__(space_host, api_key, ssl_verify=ssl_verify, base_path=base_path, debug=debug,
                         api_key_source=api_key_source, **client_settings)
        # 課題ページの URL（レポートのリンクに使う）。API ではなく画面側のパス。
        base_path = "/" + base_path.strip("/") if base_path.strip("/") else ""
        self.web_url = f"https://{space_host}{base_path}"

        # 実行中のコメントキャッシュ（フィルター間で課題が重複しても取得は1回）
        self._comment_cache: dict[int, list] = {}
        self._comment_lock = threading.Lock()
        # ステータス一覧のキャッシュ（同一プロジェクトのフィルターが複数あっても取得は1回）
        self._status_cache: dict[str | int, list] = {}
        # コメント取得に失敗した課題ID（集計後に警告表示する）
        self.comment_failures: set[int] = set()

    def get_statuses(self, project_id_or_key: str | int) -> list:
        """プロジェクトのステータス一覧を取得（実行中はキャッシュする）"""
        if project_id_or_key not in self._status_cache:
            self._status_cache[project_id_or_key] = super().get_statuses(project_id_or_key)
        return self._status_cache[project_id_or_key]

    def get_issue_comments(self, issue_id: int) -> list:
        """
        課題のコメントを全件取得（ページネーション対応）。
        コメントの changeLog にステータス変化履歴が含まれる。

        取得に失敗した場合は comment_failures に課題IDを記録し、
        その時点までに取得できた分を返す（1課題の失敗で全体を止めない）。
        """
        with self._comment_lock:
            cached = self._comment_cache.get(issue_id)
        if cached is not None:
            return cached

        all_comments: list = []
        min_id = None
        failed = False

        while True:
            params: dict = {"count": API_PAGE_SIZE, "order": "asc"}
            if min_id is not None:
                params["minId"] = min_id
            try:
                comments = self._get(f"/issues/{issue_id}/comments", params)
            except BacklogAPIError as e:
                failed = True
                if self.debug:
                    print(f"  [DEBUG] get_issue_comments({issue_id}) 失敗: {e}", file=sys.stderr)
                break
            if not comments:
                break
            all_comments.extend(comments)
            if len(comments) < API_PAGE_SIZE:
                break
            min_id = max(c["id"] for c in comments) + 1

        if failed:
            with self._comment_lock:
                self.comment_failures.add(issue_id)
            # 不完全な結果はキャッシュしない
            return all_comments

        with self._comment_lock:
            self._comment_cache[issue_id] = all_comments
        return all_comments


class ProjectInfoCache:
    """
    同一 project_key に対する API 呼び出しを1回に抑えるキャッシュ。

    保持する情報: {id, name, issue_type_map, custom_field_map, master_loaded}
    """

    def __init__(self, client: BacklogClient, debug: bool = False):
        self.client = client
        self.debug = debug
        self._cache: dict = {}

    def get(self, project_key: str, need_master: bool = False) -> dict:
        """プロジェクト情報をキャッシュ付きで取得する。"""
        if project_key not in self._cache:
            print(f"プロジェクト情報を取得中... ({project_key})")
            try:
                proj = self.client.get_project(project_key)
            except BacklogAPIError as e:
                # 「エラー:」は 1 回だけ（文の形は共通の部品）。どのプロジェクトで止まったかを続けて示す
                print(format_api_error(e), file=sys.stderr)
                print(f"  プロジェクト情報（{project_key}）を取得できなかったため、止めます。", file=sys.stderr)
                sys.exit(1)
            self._cache[project_key] = {
                "id":               proj["id"],
                "name":             proj["name"],
                "issue_type_map":   {},
                "custom_field_map": {},
                "master_loaded":    False,
            }
            info = self._cache[project_key]
            print(f"プロジェクト名: {info['name']} (ID: {info['id']})")

        info = self._cache[project_key]
        if need_master and not info["master_loaded"]:
            self._load_master(project_key, info)
        return info

    def _load_master(self, project_key: str, info: dict) -> None:
        """種別・カスタム属性のマスターを取得して info に格納する"""
        print(f"種別・カスタム属性マスターを取得中... ({project_key})")
        try:
            issue_types = self.client.get_issue_types(project_key)
            info["issue_type_map"] = {it["name"]: it["id"] for it in issue_types}
            if self.debug:
                print(f"  [DEBUG] 種別マップ（名前→ID）: {info['issue_type_map']}", file=sys.stderr)
            else:
                print(f"  種別: {list(info['issue_type_map'].keys())}")
        except BacklogAPIError as e:
            print(f"  警告: 種別マスターの取得に失敗: {e}", file=sys.stderr)

        try:
            custom_fields = self.client.get_custom_fields(project_key)
            info["custom_field_map"] = {
                cf["name"]: {
                    "id":     cf["id"],
                    "typeId": cf.get("typeId"),
                    # リスト型（typeId 5/6/7/8）の選択肢を {名前: ID} で保持
                    "items":  {item["name"]: item["id"] for item in cf.get("items", [])},
                }
                for cf in custom_fields
            }
            if self.debug:
                for fname, finfo in info["custom_field_map"].items():
                    print(f"  [DEBUG] カスタム属性「{fname}」: id={finfo['id']}, "
                          f"typeId={finfo['typeId']}, items={finfo['items']}", file=sys.stderr)
            else:
                print(f"  カスタム属性: {list(info['custom_field_map'].keys())}")
        except BacklogAPIError as e:
            print(f"  警告: カスタム属性マスターの取得に失敗: {e}", file=sys.stderr)

        info["master_loaded"] = True
