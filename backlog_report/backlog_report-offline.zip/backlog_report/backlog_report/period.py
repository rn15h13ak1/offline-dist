"""集計期間の決定と、設定・コマンドライン引数の読み取り。"""
import argparse
import sys
from datetime import date, datetime, timedelta

import yaml  # noqa: F401  （設定ファイルを読む共通の部品が使う。無ければ入口が案内する）
from backlog_common import cli
from backlog_common import config as config_files
from backlog_common.config import ConfigError
from backlog_common.runtime import exit_on_error

from backlog_report.core import DEFAULT_MAX_WORKERS, JST, MAX_WORKERS_LIMIT, REPO_ROOT
from version import TOOL_NAME, __version__

WEEK_START_MAP = {
    "monday":    0,
    "tuesday":   1,
    "wednesday": 2,
    "thursday":  3,
    "friday":    4,
    "saturday":  5,
    "sunday":    6,
    # 日本語でも指定可能
    "月曜": 0, "月": 0,
    "火曜": 1, "火": 1,
    "水曜": 2, "水": 2,
    "木曜": 3, "木": 3,
    "金曜": 4, "金": 4,
    "土曜": 5, "土": 5,
    "日曜": 6, "日": 6,
}


def get_week_range(target_week: str, week_start: str, today: date | None = None) -> tuple[date, date]:
    """
    対象週の開始日と終了日を返す（date型）

    target_week: "previous" or "current"
    week_start:  曜日名（"monday"〜"sunday" または "月"〜"日"）
    today:       基準日（省略時は JST の今日）
    """
    if today is None:
        today = datetime.now(JST).date()

    start_weekday = WEEK_START_MAP.get(week_start.lower())
    if start_weekday is None:
        print(
            f"エラー: 設定ファイルの report.week_start に無効な値 '{week_start}' が指定されています。\n"
            "  有効な値: monday, tuesday, wednesday, thursday, friday, saturday, sunday\n"
            "  （日本語も可: 月, 火, 水, 木, 金, 土, 日）",
            file=sys.stderr,
        )
        sys.exit(1)

    # 今日から直近の week_start 曜日までの日数
    days_since_start = (today.weekday() - start_weekday) % 7
    this_week_start = today - timedelta(days=days_since_start)

    if target_week == "previous":
        period_start = this_week_start - timedelta(weeks=1)
        period_end = this_week_start - timedelta(days=1)
    else:  # current
        period_start = this_week_start
        period_end = today

    return period_start, period_end


# 設定の誤りの終了コード（README の「終了コード」）
EXIT_CONFIG = 1


# 書ける項目（知らない項目は止める。5 つのツールで同じ）。backlog: の節は共通の部品の項目に project_key を足したもの
# （timeout・max_retries・retry_backoff・retry_max_delay の通信の設定も、共通の部品が確かめて BacklogClient に渡す）
TOP_KEYS = {"backlog", "report", "filters"}
BACKLOG_KEYS = set(config_files.BACKLOG_KEYS) | {"project_key"}
REPORT_KEYS = {"period", "target_week", "week_start", "output_dir", "closed_status_ids", "max_workers"}
PERIOD_KEYS = {"from", "to"}
FILTER_KEYS = {"name", "description", "project_key", "keyword", "issue_types", "custom_fields"}
CUSTOM_FIELD_KEYS = {"field_name", "field_id", "values"}  # field_name の代わりに field_id（数値）でもよい


def _list_problems(value, path: str, what: str) -> list[str]:
    """書いてあって一覧（- で並べる形）でなければ文。値を空にした（None）ものは、書いていないものとして通す"""
    if value is None or isinstance(value, list):
        return []
    return [f"{path} は{what}の一覧（- で並べる形）で書いてください: {value!r}"]


def _filter_problems(filters) -> list[str]:
    """filters: の誤りの文。形が違うと、集計の途中（通信の後）でトレースバックや見当違いの結果になる"""
    unknown = config_files.unknown_keys
    problems = _list_problems(filters, "filters", "フィルター")
    for i, raw in enumerate(filters if isinstance(filters, list) else []):
        path = f"filters[{i}]"
        flt, shape = config_files.section_problems({"f": raw}, "f")
        if shape or raw is None:
            problems.append(f"{path} の形が不正です（「name: ...」などを字下げして並べます）: {raw!r}")
            continue
        problems += unknown(flt, FILTER_KEYS, path)
        problems += config_files.text_problems(flt, ["name", "description", "project_key", "keyword"], path)
        types = flt.get("issue_types")
        problems += _list_problems(types, f"{path}.issue_types", "種別の名前")
        if isinstance(types, list) and not all(isinstance(name, str) for name in types):
            problems.append(f"{path}.issue_types は種別の名前の一覧で書いてください: {types!r}")
        fields = flt.get("custom_fields")
        problems += _list_problems(fields, f"{path}.custom_fields", "カスタム属性")
        for j, cf in enumerate(fields if isinstance(fields, list) else []):
            cf_path = f"{path}.custom_fields[{j}]"
            if not isinstance(cf, dict):
                problems.append(f"{cf_path} の形が不正です（「field_name: ...」などを字下げして並べます）: {cf!r}")
                continue
            problems += unknown(cf, CUSTOM_FIELD_KEYS, cf_path)
            problems += config_files.text_problems(cf, ["field_name"], cf_path)
            problems += config_files.int_problems(cf, ["field_id"], cf_path, minimum=1)
            problems += _list_problems(cf.get("values"), f"{cf_path}.values", "値")
    return problems


def config_problems(config: dict, required: tuple | list = ()) -> list[str]:
    """
    知らない項目と、値の形の誤りの文の一覧。以前は知らない項目を黙って無視しており、書き間違いに気付けなかった。

    値の形（節が辞書でない・数でない・一覧でないなど）も、通信の前にここでまとめて示す。以前は report: の子の行を
    すべてコメントにする（None）・report: [] と書くとトレースバックになり、closed_status_ids: 4 は通信の後で
    トレースバック、["3", "4"] は黙って一致しなかった。確かめ方と文は 5 つのツールで共通の部品。
    """
    unknown = config_files.unknown_keys
    # required は書いていなければ止める backlog: の項目（load_config は space_host と project_key）
    problems = config_files.backlog_problems(config, required, BACKLOG_KEYS)[1]
    problems = unknown(config, TOP_KEYS) + problems
    report, report_problems = config_files.section_problems(config, "report")
    problems += report_problems
    problems += unknown(report, REPORT_KEYS, "report")
    period, period_problems = config_files.section_problems(report, "report.period")
    problems += period_problems + unknown(period, PERIOD_KEYS, "report.period")
    problems += config_files.text_problems(report, ["output_dir"], "report")
    week_start = report.get("week_start")
    if week_start is not None and not (isinstance(week_start, str) and week_start.lower() in WEEK_START_MAP):
        problems.append("report.week_start は monday〜sunday（日本語なら 月〜日）で書いてください: "
                        f"{week_start!r}")
    target_week = report.get("target_week")
    if target_week is not None and not (isinstance(target_week, str)
                                        and target_week.strip().lower() in TARGET_WEEKS):
        problems.append(f"report.target_week は previous（前週）か current（今週）で書いてください: {target_week!r}")
    ids = report.get("closed_status_ids")
    if ids is not None and not (isinstance(ids, list) and all(config_files.is_int(i) for i in ids)):
        problems.append(f"report.closed_status_ids はステータスの ID（整数）の一覧で書いてください（例: [3, 4]）: {ids!r}")
    # 範囲の外も丸めずに止める（以前は警告して丸め、小数・真偽値・文字列も黙って通していた）
    problems += config_files.int_problems(report, ["max_workers"], "report", 1, MAX_WORKERS_LIMIT)
    return problems + _filter_problems(config.get("filters"))


def load_config(config_path: str) -> dict:
    """
    設定ファイルを読み込む。無い・UTF-8 でない・YAML の書き損じ・空・形が不正・知らない項目があるなら、
    直し方を示して終了コード 1 で止める。
    """
    config = exit_on_error(ConfigError, EXIT_CONFIG, config_files.load_config, config_path)
    # 知らない項目と、空・例のままの必須の項目を、1 つの一覧で示す（1 つ直すと次が出る、にしない。5 つのツールで同じ形）
    problems = config_problems(config, ["space_host", "project_key"])
    if problems:
        print("エラー: " + config_files.problems_text(config_path, problems), file=sys.stderr)
        sys.exit(EXIT_CONFIG)
    return config


def client_settings(backlog_cfg: dict) -> dict:
    """backlog: の節の通信の設定（BacklogClient に渡す引数）。誤りは load_config が先に止めている"""
    return config_files.client_settings(backlog_cfg)


def backlog_section(config: dict) -> dict:
    """backlog: の節（無ければ空）。形が不正なら案内して終了コード 1"""
    return exit_on_error(ConfigError, EXIT_CONFIG, config_files.backlog_section, config)


def build_arg_parser() -> argparse.ArgumentParser:
    """コマンドライン引数パーサーを構築する"""
    # --help の日本語と、同じ意味の引数の説明は、5 つのツールで共通の部品
    parser = cli.make_parser(
        str(REPO_ROOT / "backlog_weekly_report.py"),
        description="Backlog の課題を期間で集計して、レポートを書き出す",
        epilog="""
期間指定の優先順位:
  1. --from / --to             （最優先）
  2. --week                    （前週 or 今週の自動計算）
  3. 設定ファイルの report.period（from と to を両方書いたとき）
  4. 設定ファイルの report.target_week（前週 or 今週の自動計算）

使い方の例:
  python backlog_weekly_report.py --from 2026-03-01 --to 2026-03-31
  python backlog_weekly_report.py --week current
  python backlog_weekly_report.py
""",
    )
    cli.add_version(parser, TOOL_NAME, __version__)
    cli.add_config(parser, default=str(REPO_ROOT / "config.yaml"))
    parser.add_argument("--week", choices=["previous", "current"],
                        help="対象週の指定（設定ファイルの値を上書き）")
    parser.add_argument("--from", dest="date_from", metavar="YYYY-MM-DD",
                        help="集計開始日（例: 2026-03-01）。--to と併用。")
    parser.add_argument("--to", dest="date_to", metavar="YYYY-MM-DD",
                        help="集計終了日（例: 2026-03-31）。--from と併用。")
    cli.add_output_dir(parser, "report.output_dir", "reports")
    parser.add_argument("--overwrite", action="store_true",
                        help="同じ期間のレポートが既にあっても、確かめずに上書きする")
    cli.add_debug(parser)
    return parser


def validate_backlog_config(backlog_cfg: dict, config_path: str | None = None) -> tuple[str, str, str, str]:
    """
    backlog 設定を検証して (space_host, api_key, project_key, API キーをどこから読んだか) を返す。

    API キーは 環境変数 BACKLOG_API_KEY → 設定ファイルの backlog.api_key → .env
    （設定ファイルの隣 → このツールのフォルダ → 作業フォルダ）の順に探す。例の値のままのものは、
    書いていないものとして扱う。
    """
    problems = config_files.missing_problems(backlog_cfg, ["space_host", "project_key"])
    if problems:
        # 読んだ設定ファイルのパスと、誤りを並べる（5 つのツールで同じ形）
        print("エラー: " + config_files.problems_text(config_path or "config.yaml", problems), file=sys.stderr)
        sys.exit(EXIT_CONFIG)
    api_key, source = exit_on_error(ConfigError, EXIT_CONFIG, config_files.locate_api_key,
                                    config_path, backlog_cfg.get("api_key"), tool_dir=REPO_ROOT)
    return (config_files.setting(backlog_cfg, "space_host"), api_key,
            config_files.setting(backlog_cfg, "project_key"), source)


def resolve_max_workers(report_cfg: dict) -> int:
    """
    コメント取得の並列数。書いていなければ既定値。

    設定ミスで API を叩きすぎないよう 1〜MAX_WORKERS_LIMIT の整数に限る。外れたものは load_config が先に止めている。
    """
    return report_cfg.get("max_workers", DEFAULT_MAX_WORKERS)


TARGET_WEEKS = ("previous", "current")


def _target_week(report_cfg: dict) -> str:
    """
    config の report.target_week を返す。書いていなければ previous。

    以前は previous 以外の値（書き損じを含む）をすべて今週として扱い、
    エラーも出さずに意図と違う週のレポートを作っていた。
    """
    value = report_cfg.get("target_week")
    if value is None:
        return "previous"
    if isinstance(value, str) and value.strip().lower() in TARGET_WEEKS:
        return value.strip().lower()
    print(
        f"エラー: 設定ファイルの report.target_week に無効な値 '{value}' が指定されています。\n"
        "  有効な値: previous（前週）, current（今週）",
        file=sys.stderr,
    )
    sys.exit(1)


def resolve_period(args, report_cfg: dict, parser: argparse.ArgumentParser) -> tuple[date, date, str]:
    """
    集計期間を決定する。

    優先順位: --from/--to > --week > config.report.period > config.report.target_week
    """
    cfg_period = report_cfg.get("period") or {}

    if args.date_from:
        # 最優先: コマンドライン引数
        try:
            period_start = datetime.strptime(args.date_from, "%Y-%m-%d").date()
            period_end   = datetime.strptime(args.date_to,   "%Y-%m-%d").date()
        except ValueError:
            parser.error("日付は YYYY-MM-DD 形式で入力してください（例: 2026-03-01）")
        if period_start > period_end:
            parser.error("--from は --to より前の日付を指定してください。")
        return period_start, period_end, "指定期間（引数）"

    if args.week:
        # 2番目: --week オプション
        week_start_day = report_cfg.get("week_start", "monday")
        period_start, period_end = get_week_range(args.week, week_start_day)
        return period_start, period_end, "前週" if args.week == "previous" else "今週"

    if cfg_period.get("from") and cfg_period.get("to"):
        # 3番目: config.yaml の period 設定
        try:
            period_start = datetime.strptime(str(cfg_period["from"]), "%Y-%m-%d").date()
            period_end   = datetime.strptime(str(cfg_period["to"]),   "%Y-%m-%d").date()
        except ValueError:
            print("エラー: 設定ファイルの report.period.from / to は YYYY-MM-DD 形式で書いてください",
                  file=sys.stderr)
            sys.exit(1)
        if period_start > period_end:
            print("エラー: 設定ファイルの report.period.from は to より前の日付にしてください",
                  file=sys.stderr)
            sys.exit(1)
        return period_start, period_end, "指定期間（config）"

    # 最終フォールバック: target_week の自動計算
    target_week    = _target_week(report_cfg)
    week_start_day = report_cfg.get("week_start", "monday")
    period_start, period_end = get_week_range(target_week, week_start_day)
    return period_start, period_end, "前週" if target_week == "previous" else "今週"
