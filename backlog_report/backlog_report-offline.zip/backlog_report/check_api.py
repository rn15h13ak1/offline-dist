#!/usr/bin/env python3
"""
Backlog API の応答の確かめ（接続を確かめる）
config.yaml の設定を読み込んで実際にリクエストを送信し、
週次レポート生成に必要なエンドポイントが利用できるかを確認します。

  python check_api.py
  python check_api.py --config path/to/config.yaml
"""
import argparse
import sys
from pathlib import Path

from backlog_common import cli
from backlog_common.runtime import exit_on_interrupt, make_console_safe, require_python, stop_on_sigterm

# 3.9 だと、下の定義や import の途中で原因の分からないトレースバックになるため、先に確かめる。
# 本体（backlog_weekly_report.py）と同じく 2 で止める
require_python(code=2)


from backlog_weekly_report import (
    DEFAULT_CLOSED_STATUS_IDS,
    BacklogAPIError,
    BacklogClient,
    backlog_section,
    client_settings,
    format_api_error,
    load_config,
    to_local_date,
    validate_backlog_config,
)
from version import TOOL_NAME, __version__


def build_parser() -> argparse.ArgumentParser:
    parser = cli.make_parser(__file__, description="Backlog API の応答が、本ツールの前提どおりかを確かめる（レポートは書き出さない）")
    cli.add_version(parser, TOOL_NAME, __version__)
    cli.add_config(parser, default=str(Path(__file__).parent / "config.yaml"))
    cli.add_debug(parser, read_only=True)
    return parser


def main() -> None:
    # Windows の日本語コンソール（CP932）で、課題の件名など Backlog から来る文字で落ちないように（ほかより先に）
    make_console_safe()
    # 外から止められたときも、Ctrl+C と同じく「中断しました。」を出して 130 で終える（本体と同じ終了コードの表を使うため）
    stop_on_sigterm()
    args = build_parser().parse_args()

    config = load_config(args.config)
    backlog_cfg = backlog_section(config)
    report_cfg = config.get("report") or {}

    space_host, api_key, project_key, api_key_source = validate_backlog_config(backlog_cfg, args.config)
    closed_status_ids = report_cfg.get("closed_status_ids", DEFAULT_CLOSED_STATUS_IDS)

    client = BacklogClient(
        space_host,
        api_key,
        ssl_verify=backlog_cfg.get("ssl_verify", True),
        base_path=backlog_cfg.get("base_path", ""),
        debug=args.debug,
        api_key_source=api_key_source,
        **client_settings(backlog_cfg),
    )

    print(f"接続先: {client.base_url}")
    print(f"プロジェクト: {project_key}")
    print(f"完了系ステータスID: {closed_status_ids}（これ以外はすべてオープン系）")
    print()
    # 止めずに続ける NG の数。最後の「結果:」の行と終了コード（あれば 1）に使う（backlog_change_log の診断と同じ）
    problems = 0

    # 取得に失敗したときの「NG」の行と案内は、エラーの文と同じく標準エラーに出す（パイプにつないでも順が崩れない）。
    # 応答が前提と違うときの「NG」（取得はできた）は、確かめた結果として画面の出力に出す
    # ---- Step1: 接続・認証確認（/space は最もシンプルなエンドポイント）----
    print("=== Step1: 接続・認証確認 ===")
    try:
        space = client._get("/space")
        print(f"OK 接続: {space.get('name', space)}")
    except BacklogAPIError as e:
        print("NG 接続失敗", file=sys.stderr)
        print(format_api_error(e), file=sys.stderr)
        print("  → space_host / base_path / API キー / ssl_verify を確認してください", file=sys.stderr)
        sys.exit(1)
    print()

    # ---- Step2: プロジェクト情報とステータス一覧 ----
    print("=== Step2: プロジェクト情報・ステータス一覧 ===")
    try:
        project = client.get_project(project_key)
        print(f"OK プロジェクト取得: {project.get('name')} (id={project.get('id')})")
    except BacklogAPIError as e:
        print("NG プロジェクト取得失敗", file=sys.stderr)
        print(format_api_error(e), file=sys.stderr)
        print("  → project_key を確認してください", file=sys.stderr)
        sys.exit(1)
    project_id = project.get("id")

    try:
        statuses = client.get_statuses(project_key)
        for idx, st in enumerate(statuses):
            label = "完了系" if st["id"] in closed_status_ids else "オープン系"
            initial = "  ← 新規作成時のステータス" if idx == 0 else ""
            print(f"   id={st['id']}: {st['name']}  → {label}{initial}")
        if statuses and statuses[0]["id"] in closed_status_ids:
            print("   NG 新規作成時のステータスが完了系に登録されています。"
                  "closed_status_ids から取り除いてください。")
            problems += 1
    except BacklogAPIError as e:
        print("NG ステータス一覧の取得に失敗", file=sys.stderr)
        print(format_api_error(e), file=sys.stderr)
        problems += 1
    print()

    # ---- Step3: 課題を 1 件取得 ----
    print("=== Step3: 課題を 1 件取得 ===")
    # ステータス変化を確認しやすいよう完了済み課題を優先して取得
    try:
        issues = client._get("/issues", {"projectId": [project_id], "statusId": closed_status_ids, "count": 1})
        if not issues:
            # 完了済みがなければ全ステータスで取得
            issues = client._get("/issues", {"projectId": [project_id], "count": 1})
    except BacklogAPIError as e:
        print("NG 課題の取得に失敗", file=sys.stderr)
        print(format_api_error(e), file=sys.stderr)
        sys.exit(1)
    if not issues:
        print("NG 課題が 1 件も見つかりませんでした。")
        sys.exit(1)

    issue = issues[0]
    issue_id = issue["id"]
    print(f"取得した課題: {issue['issueKey']} (id={issue_id}, "
          f"status={issue.get('status', {}).get('name')}, "
          f"created={to_local_date(issue.get('created', ''))} JST)")
    print()

    # ---- Step4: コメントの changeLog にステータス変化が記録されているか ----
    print("=== Step4: /issues/{id}/comments の changeLog 確認 ===")
    try:
        comments = client._get(f"/issues/{issue_id}/comments", {"count": 20, "order": "desc"})
    except BacklogAPIError as e:
        print("NG エンドポイント無効またはエラー", file=sys.stderr)
        print(format_api_error(e), file=sys.stderr)
        sys.exit(1)

    print(f"OK エンドポイント有効。取得件数: {len(comments)}")
    status_changes = [
        {
            "date": to_local_date(c.get("created", "")),
            "from": cl.get("originalValue"),
            "to":   cl.get("newValue"),
        }
        for c in comments
        for cl in c.get("changeLog", [])
        if cl.get("field") == "status"
    ]
    if status_changes:
        print(f"   ステータス変化の記録あり（直近 {len(status_changes)} 件・日付は JST）:")
        for sc in status_changes:
            print(f"     {sc['date']}: {sc['from']} → {sc['to']}")
    else:
        print("   直近 20 件のコメントにステータス変化なし")
        print("   ※ changeLog フィールドの有無を確認します")
        has_changelog = any("changeLog" in c for c in comments)
        print(f"   changeLog フィールド: {'あり' if has_changelog else 'なし（コメント構造が異なる可能性）'}")
        if comments:
            print(f"   コメント構造サンプル: {list(comments[0].keys())}")
    print()
    print("結果: " + ("前提と違う応答があります（上の NG の行）" if problems else "前提と違う応答はありませんでした"))
    if problems:
        sys.exit(1)


if __name__ == "__main__":
    try:
        # Ctrl+C・外からの SIGTERM で止めたら、トレースバックを出さずに終了コード 130 で終える
        exit_on_interrupt(main)
    except BacklogAPIError as e:
        print(format_api_error(e), file=sys.stderr)
        sys.exit(1)
