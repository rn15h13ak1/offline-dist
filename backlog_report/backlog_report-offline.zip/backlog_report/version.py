"""backlog_report の版。CHANGELOG.md の最新の版と同じにする（版を切ったら上げる）。"""

TOOL_NAME = "backlog_report"
__version__ = "0.22.6"
