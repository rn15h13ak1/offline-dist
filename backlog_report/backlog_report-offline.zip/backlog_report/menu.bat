@echo off
rem ===========================================================
rem  backlog_report - interactive menu launcher
rem  Double-click this file to start the menu.
rem
rem  Messages here are ASCII on purpose: this file must stay
rem  readable in any console code page.
rem ===========================================================

rem Move to this file's folder. pushd (not cd) so that a UNC
rem path on a shared drive also works.
pushd "%~dp0" || (
    echo [ERROR] Cannot enter the folder of this script.
    pause
    exit /b 1
)

rem Prefer the virtual environment (.venv) if this folder has one.
rem Otherwise the py launcher, then python on PATH.
set PYTHON=
if exist ".venv\Scripts\python.exe" set PYTHON=".venv\Scripts\python.exe"
if not defined PYTHON (
    py -3 --version >nul 2>&1 && set PYTHON=py -3
)
if not defined PYTHON (
    python --version >nul 2>&1 && set PYTHON=python
)
if not defined PYTHON (
    echo [ERROR] Python 3 was not found.
    echo         Install Python 3.10 or later from https://www.python.org/
    echo         and make sure it is added to PATH.
    popd
    pause
    exit /b 1
)

%PYTHON% menu.py %*
set RC=%ERRORLEVEL%

popd
if not "%RC%"=="0" echo.& echo [exit code %RC%]

rem Pause only when double-clicked, so the window stays open to read errors.
rem With arguments (e.g. --config from a shortcut or Task Scheduler) the caller
rem owns the console, and pause would wait forever when nobody is watching.
if "%~1"=="" pause
exit /b %RC%
