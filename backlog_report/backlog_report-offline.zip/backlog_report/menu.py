#!/usr/bin/env python3
"""
Backlog レポート 対話メニュー
=============================
集計する週を選ぶだけで、レポートを書き出す。日付を入力して期間を決めることもできる。
作りは同じ種類のツールのメニューに揃えている。

  python menu.py                  # メニューを表示
  python menu.py --config my.yaml # 設定ファイルを指定

本体（backlog_weekly_report.py / check_api.py）は別のプロセスとして呼ぶ。
無人実行にはメニューではなく本体を使うこと:
  python backlog_weekly_report.py --week previous
"""

from __future__ import annotations

import argparse
from datetime import date, timedelta
from pathlib import Path

from backlog_common import cli
from backlog_common.menu import (
    EXIT_EOF,  # noqa: F401  （終了コード。ツールを起動する側と、同じ種類のツールのメニューに揃える）
    EXIT_INTERRUPTED,  # noqa: F401
    EXIT_OK,  # noqa: F401
    EXIT_SETUP,  # noqa: F401
    check_runtime,
    describe_config,  # noqa: F401  （テストが使う）
    describe_exit,
    exit_menu,
    input_text,
    print_config_header,
    print_menu,
    run_loop,
    run_script,
    show_result,
    wait_enter,
)
from backlog_common.menu import load_history as _load_history
from backlog_common.menu import save_history as _save_history
from backlog_common.runtime import make_console_safe

from version import TOOL_NAME, __version__

# 本体を選んだところで止まる前に、メニューを開くときに確かめる（足りなければ 2。5 つのメニューで同じ）
check_runtime([("yaml", "pyyaml")])

TOOL_DIR = Path(__file__).resolve().parent
MAIN_SCRIPT = TOOL_DIR / "backlog_weekly_report.py"
CHECK_SCRIPT = TOOL_DIR / "check_api.py"
HISTORY_PATH = Path.home() / ".backlog_report_menu.json"

#: 本体と check_api.py の終了コードの意味（README の「終了コード」と揃える。127・130 は共通の部品が足す）
EXIT_MEANINGS = {
    0: "レポートを書き出しました",
    1: "設定の誤り、API キーが無い、API・通信のエラー、または想定外のエラー",
    2: "コマンドライン引数の誤り、または Python の版・PyYAML の不足",
    20: "同じ期間のレポートが既にあり、端末でない所から動かしたため上書きしてよいか確かめられず、何も書いていません",
}
CHECK_EXIT_MEANINGS = {
    0: "前提と違う応答はありませんでした",
    1: "前提と違う応答があります（または設定の誤り、API・通信のエラー、想定外のエラー）",
    2: "Python の版・PyYAML の不足",
}

#: 選べる週の数（今週・先週・2 週間前・3 週間前）
WEEK_PRESET_COUNT = 4
WEEK_NAMES = ["今週", "先週", "2 週間前", "3 週間前"]


def load_history() -> dict:
    """前回の選択を読む。壊れていても既定値で続行する。"""
    return _load_history(HISTORY_PATH)


def save_history(data: dict) -> None:
    """選択を保存する。書けなくても実行は妨げない。"""
    _save_history(HISTORY_PATH, data)


def sat_to_fri(weeks_ago: int, today: date | None = None) -> tuple[date, date]:
    """
    土曜から金曜までの週を (始まり, 終わり) で返す。weeks_ago=0 は今日を含む週、1 は先週。
    メニューを並べるランチャーがこのツールに渡している週と同じ区切りにしている。
    """
    today = today or date.today()
    saturday = today - timedelta(days=(today.weekday() - 5) % 7)   # weekday(): 月=0 … 土=5
    start = saturday - timedelta(weeks=weeks_ago)
    return start, start + timedelta(days=6)


def menu_items(today: date | None = None) -> list[str]:
    """番号の並びは、ランチャーがこのツールに渡している選択肢と揃える。新しい項目は末尾に足す"""
    items = []
    for i in range(WEEK_PRESET_COUNT):
        start, end = sat_to_fri(i, today)
        items.append(f"{WEEK_NAMES[i]}（土 {start} 〜 金 {end}）")
    items.append("日付を入力して期間を決める（YYYY-MM-DD）")
    items.append("接続を確かめる ― 設定と API の応答を確かめる（レポートは書き出さない）")
    return items


MANUAL_CHOICE = WEEK_PRESET_COUNT + 1
CHECK_CHOICE = WEEK_PRESET_COUNT + 2


def _is_date(value: str) -> bool:
    try:
        date.fromisoformat(value)
        return True
    except ValueError:
        return False


def ask_period() -> tuple[str, str] | None:
    """期間を入力させる。戻る場合は None。"""
    hint = "YYYY-MM-DD の形で入力してください（例: 2026-03-01）"
    date_from = input_text("始まりの日 (YYYY-MM-DD)", validate=_is_date, hint=hint)
    if not date_from:
        return None
    while True:
        date_to = input_text("終わりの日 (YYYY-MM-DD)", validate=_is_date, hint=hint)
        if not date_to:
            return None
        if date_to >= date_from:
            return date_from, date_to
        print("  ※ 終わりの日は、始まりの日と同じか後にしてください。")


def build_args(choice: int, config: str | None, period: tuple[str, str] | None = None,
               today: date | None = None) -> list[str]:
    """本体に渡すコマンドライン引数を組み立てる。"""
    args = ["--config", config] if config else []
    if choice == CHECK_CHOICE:
        return args
    if choice == MANUAL_CHOICE:
        assert period is not None
        date_from, date_to = period
    else:
        start, end = sat_to_fri(choice - 1, today)
        date_from, date_to = str(start), str(end)
    return args + ["--from", date_from, "--to", date_to]


def script_for(choice: int) -> Path:
    return CHECK_SCRIPT if choice == CHECK_CHOICE else MAIN_SCRIPT


def run_choice(choice: int, config: str | None, history: dict) -> int | None:
    """1 つの操作を実行する。戻る場合は None。"""
    period = None
    if choice == MANUAL_CHOICE:
        print()
        period = ask_period()
        if period is None:
            return None
    history["choice"] = choice
    save_history(history)
    return run_script(script_for(choice), build_args(choice, config, period), TOOL_DIR)


def build_parser() -> argparse.ArgumentParser:
    parser = cli.make_parser(__file__, description="Backlog レポート 対話メニュー",
                             epilog="無人実行には backlog_weekly_report.py を直接使ってください。")
    cli.add_version(parser, TOOL_NAME, __version__)
    cli.add_config(parser)
    return parser


def main() -> None:
    # 入力されたパスなどに CP932 に無い文字があっても、Windows のコンソールが落ちないように
    make_console_safe()
    config = build_parser().parse_args().config
    if config:
        # 本体はツールのフォルダで動かすため、相対パスは起動した場所を基準に絶対パスにしておく
        config = str(Path(config).resolve())
    history = load_history()
    last = history.get("choice")
    default_choice = last if isinstance(last, int) and 1 <= last <= CHECK_CHOICE else None

    def loop() -> None:
        nonlocal default_choice
        while True:
            items = menu_items()   # 日をまたいで開いたままでも、週がずれないように毎回作る
            print_config_header("Backlog レポート", config or TOOL_DIR / "config.yaml", version=TOOL_NAME + " " + __version__)
            choice = print_menu("集計する期間を選択", items, back_label="終了",
                                default=default_choice, default_mark="前回")
            if choice == 0:
                exit_menu()
            rc = run_choice(choice, config, history)
            if rc is not None:
                show_result(describe_exit(rc, CHECK_EXIT_MEANINGS if choice == CHECK_CHOICE else EXIT_MEANINGS))
                default_choice = choice
                wait_enter()

    run_loop(loop)


if __name__ == "__main__":
    main()
