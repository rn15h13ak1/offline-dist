"""
path_lister 対話メニュー
========================
引数を覚えなくても、番号を選んで答えるだけで、一覧 (CSV)・Excel・下書き (.md) を作れる。

  python menu.py                   # メニューを表示
  python menu.py --config my.yaml   # 設定ファイルを指定

AI や定期実行からは、このメニューではなく本体 (path_lister.py) を直接呼ぶこと。
"""
# 注釈の `str | None` を Python 3.9 でも書けるようにする (PEP 563)
from __future__ import annotations

import json
import os
import subprocess
import sys
from pathlib import Path

from utils import DEPENDENCY_MODULES, missing_library_lines, make_console_safe, make_parser, require_python, stop_on_sigterm

require_python()

TOOL_DIR = Path(__file__).resolve().parent

try:
    import config as pl_config  # noqa: E402
except ModuleNotFoundError as e:
    # menu.bat のダブルクリックで依存が入っていないとき、トレースバックでなく入れ方を示す
    if e.name not in DEPENDENCY_MODULES:
        raise
    make_console_safe()
    for line in missing_library_lines(e.name, TOOL_DIR):
        print(line, file=sys.stderr)
    sys.exit(2)
from version import __version__  # noqa: E402

WIDTH = 60
SCRIPT = TOOL_DIR / "path_lister.py"
HISTORY_PATH = Path.home() / ".path_lister_menu.json"

MODE_SCAN = "scan"
MODE_SHEET = "sheet"
MODE_DRAFT = "draft"
MODE_SHOW = "show"
MODE_OPEN = "open"

MODES = [
    (MODE_SCAN, "一覧を作る", "起点の下を辿って、フルパスの一覧 (CSV) を書き出す"),
    (MODE_SHEET, "Excel を作る", "一覧 (CSV) から、組み立ての列を付けた Excel を作る"),
    (MODE_DRAFT, "下書きを作る", "Excel で選んだ行から、catalog の .md を作る"),
    (MODE_SHOW, "設定を確認", "設定ファイルの起点・除外の型・段の名前を表示する"),
    (MODE_OPEN, "出力フォルダを開く", "CSV・Excel・下書きを書き出すフォルダを開く"),
]

# 本体の終了コード (README の「終了コード」と対応)。127 はメニューが自分で返す (本体が見つからない)
EXIT_MEANINGS = {
    0: "済み",
    1: "読めない所があった（CSV は書き出した）",
    2: "引数・設定・出力先の誤り",
    3: "予期しないエラー",
    127: "本体（path_lister.py）が見つからない",
    130: "中断",
}

# 表に無い番号の説明 (同じ種類のツールと同じ文)
UNKNOWN_EXIT = "想定外の終了コードです"

# メニュー自身の終了コード (同じ種類のツールと揃える)
EXIT_OK = 0
EXIT_EOF = 1
EXIT_NOT_FOUND = 127
EXIT_INTERRUPTED = 130


# ===========================================================================
# 表示・入力
# ===========================================================================


def hr(char="="):
    print(char * WIDTH)


def print_menu(title: str, items: list, back_label: str = "戻る",
               default: int | None = None, default_mark: str = "既定") -> int:
    """メニューを表示して選んだ番号を返す。0 = 戻る / 終了。"""
    while True:
        print()
        hr()
        print(f"  {title}")
        hr()
        for i, item in enumerate(items, 1):
            mark = f" ←{default_mark}" if default == i else ""
            print(f"  {i}. {item}{mark}")
        hr("-")
        print(f"  0. {back_label}")
        hr()
        prompt = ("番号を入力してください"
                  + (f" [Enter={default}]: " if default else ": "))
        choice = input(prompt).strip()
        if not choice and default:
            return default
        if choice == "0":
            return 0
        if choice.isdigit() and 1 <= int(choice) <= len(items):
            return int(choice)
        print("  ※ 無効な入力です。もう一度入力してください。")


def input_text(prompt: str, default: str = "", validate=None, hint: str = "",
               empty: str = "戻る") -> str | None:
    """文字列を入力させる。空 Enter は default を採用し、default が無ければ None を返す。

    empty は、default が無いときの空 Enter の意味 (既定は「戻る」)。
    """
    suffix = f" [Enter={default}]" if default else f"（空 Enter で{empty}）"
    while True:
        answer = input(f"  {prompt}{suffix}: ").strip().strip('"')
        if not answer:
            return default or None
        if validate is None or validate(answer):
            return answer
        print(f"  ※ {hint}")


def input_roots(defaults: list) -> list | None:
    """起点を 1 行に 1 つ入力させる。最初に空 Enter なら defaults を使う (無ければ戻る)。"""
    if defaults:
        print("  前回の起点:")
        for root in defaults:
            print(f"    {root}")
        print("  そのまま使うなら Enter、変えるなら新しい起点を入力してください。")
    roots = []
    while True:
        label = "起点" if not roots else "次の起点（空 Enter で入力を終える）"
        answer = input(f"  {label}: ").strip().strip('"')
        if not answer:
            break
        if not os.path.isdir(answer):
            print(f"  ※ フォルダが見つかりません: {answer}")
            continue
        roots.append(answer)
    return roots or (list(defaults) if defaults else None)


# 一覧を作るときの起点の決め方 (履歴の scan_how に覚える)
SCAN_INPUT = "input"
SCAN_SET = "set"
SCAN_HOWS = [
    (SCAN_INPUT, "起点を入力する", "設定と関係なく、辿る起点をその都度入力する"),
    (SCAN_SET, "設定から選ぶ", "設定に名前を付けて書いた起点の組を選ぶ"),
]

def choose_root_group(settings, history: dict) -> str | None:
    """設定の起点の組を選ばせる。組が 1 つなら選ばせない。組の名前、戻るか組が無ければ None。"""
    names = list(settings.roots)
    if not names:
        print("  ※ 設定に起点の組がありません。config.yaml の scan.roots に名前を付けて書くか、")
        print("     「起点を入力する」を使ってください。")
        return None
    if len(names) == 1:
        return names[0]
    items = [f"{name} ― {', '.join(settings.roots[name].roots)}" for name in names]
    last = history.get("root_name")
    choice = print_menu("起点の組を選択", items, default=names.index(last) + 1 if last in names else None,
                        default_mark="前回")
    return None if choice == 0 else names[choice - 1]


def depth_target(labels) -> str:
    """深さで決める段の言葉。2 段には間の段が無いので、最上段の下の境目を指す。"""
    return labels[1] if len(labels) > 2 else f"{labels[0]}の下"


def is_depth(value: str) -> bool:
    return value.isdigit() and int(value) >= 1


# ===========================================================================
# 前回値の記憶
# ===========================================================================


def load_history() -> dict:
    """前回の入力値を読む。壊れていても既定値で続ける。"""
    try:
        with open(HISTORY_PATH, encoding="utf-8") as f:
            data = json.load(f)
        return data if isinstance(data, dict) else {}
    except (OSError, ValueError):
        return {}


def save_history(data: dict) -> None:
    """入力値を保存する。書けなくても実行は妨げない。"""
    try:
        with open(HISTORY_PATH, "w", encoding="utf-8") as f:
            json.dump(data, f, ensure_ascii=False, indent=2)
    except OSError:
        pass


# ===========================================================================
# 設定と出力先
# ===========================================================================


def load_settings(config_path: str):
    """設定を読む。読めなければ (既定の設定, 理由) を返す。ファイルが無いのは誤りにしない。"""
    path = Path(config_path)
    if not path.is_file():
        return pl_config.Settings(), ""
    try:
        return pl_config.load_config(path), ""
    except pl_config.ConfigError as e:
        return pl_config.Settings(), str(e)


def output_dir(settings) -> Path:
    return settings.scan_output_dir or TOOL_DIR / "out"


def latest(settings, suffix: str = ".csv") -> Path | None:
    """出力フォルダにある最新の一覧 (paths-*.csv か paths-*.xlsx)。無ければ None。"""
    folder = output_dir(settings)
    if not folder.is_dir():
        return None
    found = sorted(folder.glob("paths-*" + suffix), key=lambda p: p.stat().st_mtime)
    return found[-1] if found else None


def root_line(root: str, depths: dict, onlys: dict) -> str:
    """起点の 1 行。起点ごとの深さ・書き出すものがあれば添える。"""
    key = pl_config.root_key(root)
    notes = []
    if depths.get(key):
        notes.append(f"深さの上限 {depths[key]}")
    if onlys.get(key):
        notes.append(f"書き出すもの {onlys[key]}")
    return f"    {root}" + (f"（{'・'.join(notes)}）" if notes else "")


def print_config(config_path: str) -> None:
    settings, problem = load_settings(config_path)
    print(f"  設定ファイル: {config_path}" + ("" if Path(config_path).is_file() else "（無い。既定で動く）"))
    if problem:
        print(f"  ※ 設定を読めません: {problem}")
        return
    if not settings.roots:
        print("  起点: （書いていない。実行のときに入力する）")
    for name, group in settings.roots.items():
        print(f"  起点の組「{name}」:")
        for root in group.roots:
            print(root_line(root, group.depths, group.onlys))
    print(f"  深さの上限: {settings.max_depth or '無し'}")
    print(f"  書き出すもの: {settings.only}")
    print(f"  拡張子: {', '.join(settings.extensions) or 'すべて'}")
    print(f"  除外の型: {', '.join(settings.excludes) or '無し'}")
    print(f"  出力フォルダ: {output_dir(settings)}")
    labels = settings.labels
    if labels != pl_config.DEFAULT_LABELS:
        print(f"  段の名前: {'・'.join(labels)}")
    print(f"  {depth_target(labels)}のフォルダの深さ: {settings.stage_depth}")
    print(f"  リンクのスキーム: {settings.link_scheme}")
    if settings.stages:
        print(f"  {depth_target(labels)}の名前:")
        for folder, name in settings.stages.items():
            print(f"    {folder} → {name}")


# ===========================================================================
# 実行
# ===========================================================================


def run_script(args: list) -> int:
    """本体を実行して終了コードを返す。

    Ctrl+C は本体も同じものを受け、書きかけの CSV を閉じてから止まる。subprocess.run は
    本体をすぐ止めてしまうため、終わるまで待つ (もう一度押せば止める)。
    """
    if not SCRIPT.is_file():
        print(f"\n  ※ 本体が見つかりません: {SCRIPT}")
        return EXIT_NOT_FOUND
    print()
    hr("-")
    process = subprocess.Popen([sys.executable, str(SCRIPT), *args], cwd=TOOL_DIR)
    try:
        return process.wait()
    except KeyboardInterrupt:
        try:
            process.wait()
        except KeyboardInterrupt:
            process.kill()
            process.wait()
        print("\n  中断しました。")
        return EXIT_INTERRUPTED


def build_scan_args(config_path: str, roots: list, max_depth: str = "", name: str = "") -> list:
    """本体の scan の引数。name があれば、起点の代わりに --roots で組の名前を渡す。"""
    args = ["scan", *(["--roots", name] if name else roots)]
    if Path(config_path).is_file():
        args += ["--config", config_path]
    if max_depth:
        args += ["--max-depth", max_depth]
    return args


def build_sheet_args(config_path: str, csv_path: str, stage_depth: str = "") -> list:
    args = ["sheet", csv_path]
    if Path(config_path).is_file():
        args += ["--config", config_path]
    if stage_depth:
        args += ["--stage-depth", stage_depth]
    return args


def build_draft_args(config_path: str, xlsx_path: str) -> list:
    args = ["draft", xlsx_path]
    if Path(config_path).is_file():
        args += ["--config", config_path]
    return args


def input_depth(settings, has_root_depths: bool) -> str:
    """深さの上限を入力させる。空なら --max-depth を渡さない。"""
    if has_root_depths:
        # 既定を出すと --max-depth で渡り、起点ごとの深さを上書きしてしまう。空 Enter は渡さない
        return input_text("深さの上限（起点の直下が 1。すべての起点に効く）", "", is_depth,
                          "1 以上の数を入力してください。", empty="設定のとおり") or ""
    return input_text("深さの上限（起点の直下が 1）", str(settings.max_depth or ""), is_depth,
                      "1 以上の数を入力してください。", empty="下まで辿る") or ""


def run_scan(config_path: str, history: dict) -> int | None:
    """起点の決め方 (入力するか、設定から選ぶか) を選ばせて辿る。"""
    last = history.get("scan_how")
    keys = [key for key, _, _ in SCAN_HOWS]
    choice = print_menu("起点の決め方を選択", [f"{label} ― {desc}" for _, label, desc in SCAN_HOWS],
                        default=keys.index(last) + 1 if last in keys else None, default_mark="前回")
    if choice == 0:
        return None
    how = keys[choice - 1]
    history["scan_how"] = how
    return run_scan_input(config_path, history) if how == SCAN_INPUT else run_scan_set(config_path, history)


def run_scan_input(config_path: str, history: dict) -> int | None:
    """起点をその都度入力して辿る。設定の起点と、その起点ごとの深さは使わない。"""
    settings, problem = load_settings(config_path)
    if problem:
        print(f"  ※ 設定を読めません: {problem}")
        return None
    roots = input_roots(history.get("roots") or [])
    if not roots:
        return None
    depth = input_depth(settings, False)
    history["roots"] = roots
    save_history(history)
    return run_script(build_scan_args(config_path, roots, depth))


def run_scan_set(config_path: str, history: dict) -> int | None:
    """設定の起点の組 (scan.roots) を選んで辿る。"""
    settings, problem = load_settings(config_path)
    if problem:
        print(f"  ※ 設定を読めません: {problem}")
        return None
    name = choose_root_group(settings, history)
    if name is None:
        return None
    group = settings.roots[name]
    print(f"  起点の組「{name}」の起点:")
    for root in group.roots:
        print(root_line(root, group.depths, group.onlys))
    depth = input_depth(settings, bool(group.depths))
    history["root_name"] = name
    save_history(history)
    # 起点は渡さず --roots で組の名前を渡し、深さなどの決め方を本体に任せる
    return run_script(build_scan_args(config_path, [], depth, name))


def run_sheet(config_path: str, history: dict) -> int | None:
    settings, problem = load_settings(config_path)
    if problem:
        print(f"  ※ 設定を読めません: {problem}")
        return None
    found = latest(settings, ".csv")
    print("  一覧 (CSV) の隣に、同じ名前の Excel を作ります。")
    labels = settings.labels
    uppers = "".join(f"「{name}」" for name in labels[:-1])
    target = depth_target(labels)
    print(f"  {uppers}「補足」は、下の深さのフォルダを{target}として埋めます。")
    csv_path = input_text("CSV のパス", str(found) if found else "",
                          lambda p: Path(p).is_file(), "ファイルが見つかりません。")
    if not csv_path:
        return None
    depth = input_text(f"{target}にするフォルダの深さ（起点の直下が 1）", str(settings.stage_depth),
                       is_depth, "1 以上の数を入力してください。")
    if depth is None:
        return None
    return run_script(build_sheet_args(config_path, csv_path, depth))


def run_draft(config_path: str, history: dict) -> int | None:
    settings, problem = load_settings(config_path)
    if problem:
        print(f"  ※ 設定を読めません: {problem}")
        return None
    found = latest(settings, ".xlsx")
    print("  Excel で「採用」の列に印を付けた行（印が無ければ、残したファイルの行）から作ります。")
    uppers = "".join(f"「{name}」" for name in settings.labels[:-1])
    print(f"  {uppers}が空の行は使いません。Excel は保存してから選んでください。")
    xlsx_path = input_text("Excel のパス", str(found) if found else "",
                           lambda p: Path(p).is_file(), "ファイルが見つかりません。")
    if not xlsx_path:
        return None
    return run_script(build_draft_args(config_path, xlsx_path))


def open_folder(path: Path) -> None:
    path.mkdir(parents=True, exist_ok=True)
    try:
        if sys.platform == "win32":
            os.startfile(str(path))  # type: ignore[attr-defined]
        elif sys.platform == "darwin":
            subprocess.run(["open", str(path)], check=False)
        else:
            subprocess.run(["xdg-open", str(path)], check=False)
    except OSError as e:
        print(f"  ※ 開けません: {path}（{e}）")
        return
    print(f"  開きました: {path}")


def run_mode(mode: str, label: str, config_path: str, history: dict) -> int | None:
    print()
    hr()
    print(f"  {label}")
    hr()
    if mode == MODE_SCAN:
        return run_scan(config_path, history)
    if mode == MODE_SHEET:
        return run_sheet(config_path, history)
    if mode == MODE_DRAFT:
        return run_draft(config_path, history)
    if mode == MODE_SHOW:
        print_config(config_path)
        return None
    open_folder(output_dir(load_settings(config_path)[0]))
    return None


# ===========================================================================
# エントリポイント
# ===========================================================================


def build_parser():
    parser = make_parser(
        __file__, "path_lister 対話メニュー",
        epilog="AI や定期実行からは path_lister.py を直接使ってください。",
    )
    parser.add_argument(
        "--config", default=str(TOOL_DIR / pl_config.CONFIG_NAME), metavar="PATH",
        help="設定ファイルのパス（既定: ツールのフォルダの config.yaml）",
    )
    parser.add_argument(
        "--version", action="version", version=f"path_lister {__version__}",
        help="版を出して終わる",
    )
    return parser


def main() -> None:
    # 外からの SIGTERM も Ctrl+C と同じに扱う。本体を待っている間に受けたら、
    # Ctrl+C の 1 回目と同じく本体の終わりを待つ
    stop_on_sigterm()
    make_console_safe()
    args = build_parser().parse_args()
    # 本体はツールのフォルダで動かすため、相対パスは起動した場所を基準に絶対パスにしておく
    args.config = str(Path(args.config).resolve())
    history = load_history()
    last_mode = history.get("mode")
    default_choice = next((i for i, (key, _, _) in enumerate(MODES, 1) if key == last_mode), None)
    items = [f"{label} ― {desc}" for _, label, desc in MODES]

    try:
        while True:
            print()
            hr()
            print(f"  フルパスの一覧（path_lister {__version__}）")
            hr()
            choice = print_menu("実行内容を選択", items, back_label="終了",
                                default=default_choice, default_mark="前回")
            if choice == 0:
                print("  終了します。")
                sys.exit(EXIT_OK)
            mode, label, _ = MODES[choice - 1]
            rc = run_mode(mode, label, args.config, history)
            history["mode"] = mode
            save_history(history)
            default_choice = choice
            if rc is not None:
                print()
                hr("-")
                print(f"  終了コード: {rc}（{EXIT_MEANINGS.get(rc, UNKNOWN_EXIT)}）")
            input("\n  Enter キーでメニューに戻ります...")
    except EOFError:
        print("\n  入力が終了しました。")
        sys.exit(EXIT_EOF)
    except KeyboardInterrupt:
        print("\n  中断しました。")
        sys.exit(EXIT_INTERRUPTED)


if __name__ == "__main__":
    main()
