"""sheet で作り、Excel で選んだ一覧 (.xlsx) から、catalog の下書き (.md) を作る。

1 つのまとまりを 1 つの子 (`type: fragment`) にし、親 (`type: catalog`) が `取り込み:` で束ねる。

- 「採用」に印のある行だけを使う (ファイル・フォルダ・リンク)。印が 1 つも無ければ、ファイルの行をすべて使う
- 「まとまり」「段階」「項目」「補足」の列の値を使う。まとまり・段階はフォルダの位置から sheet が埋めてある。
  どちらかが空の行は飛ばす
- 段階は先頭の番号の順に並べ、番号を外した名前を出す。設定の stages で名前を付け替えられる
- 項目の名前は「項目」の列。sheet が埋めたまま (直していない) なら、同じ段階で重なると拡張子付きにする
- まとまり・段階・項目の見出しは、設定の labels で変えられる。読むときに既定の名前へ戻し、中では既定の名前で扱う。
  変えたものは親の `呼び名:` に書く (catalog の画面に出る)
"""
from __future__ import annotations

import re
import zipfile
from dataclasses import dataclass, field
from pathlib import Path
from typing import Dict, List, Optional, Tuple

from openpyxl import load_workbook
from openpyxl.utils.exceptions import InvalidFileException

from config import Labels
from scanner import KIND_DIR, KIND_FILE, KIND_LINK, stem, to_url
from sheet import SHEET_TITLE, split_path

ADOPT_COLUMN = "採用"
GROUP_COLUMN = "まとまり"
STAGE_COLUMN = "段階"
ITEM_COLUMN = "項目"
NOTE_COLUMN = "補足"
# 「採用」に印を付ければ項目にできる種別。印が 1 つも無ければファイルの行だけを使う
ADOPTABLE_KINDS = (KIND_FILE, KIND_DIR, KIND_LINK)
REQUIRED_COLUMNS = ("種別", "フルパス", GROUP_COLUMN, STAGE_COLUMN)

_NUMBER_RE = re.compile(r"^(\d+)[\s._\-]*(.*)$")
# リンクの文字の中で意味を持つ記号。前に \ を置いて文字として出す
_MD_SPECIAL_RE = re.compile(r"([\\`*_\[\]()!{}#])")
_SEPARATOR_RE = re.compile(r"[|｜]")
_BAD_FILENAME_RE = re.compile(r'[\\/:*?"<>|\x00-\x1f]')


class DraftError(Exception):
    """入力・出力先の誤り。入口は終了コード 2 で止まる。"""


@dataclass
class Item:
    stem: str
    name: str
    sub: str
    url: str
    path: str = ""  # [] に書くフルパス (人が .md で読む目印。docmold は画面のパスをリンク先から作る)
    label: str = ""
    fixed: bool = False  # 人が「項目」に書いた名前。重なっても付け替えない


@dataclass
class Draft:
    """書き出すもの。groups はまとまりの名前 → 段階の名前 (フォルダ名か「段階」の列の値) → 項目。"""

    groups: Dict[str, Dict[str, List[Item]]] = field(default_factory=dict)
    warnings: List[str] = field(default_factory=list)
    notes: List[str] = field(default_factory=list)
    used_rows: int = 0


# --------------------------------------------------------------------------- Excel を読む


def _text(value) -> str:
    """セルの値を文字にする。Excel が数にした値 (`1.0`) は整数の形にする。"""
    if value is None:
        return ""
    if isinstance(value, float) and value.is_integer():
        return str(int(value))
    return str(value)


def _column(heading: str, labels: Labels) -> str:
    """Excel の見出しを、中で使う既定の名前にする。

    呼び名を変えたのに既定の名前の列があれば読まない (呼び名を入れ替えても、別の列を読まないように)。
    """
    default = Labels()
    names = (default.group, default.stage, default.item)
    for name in names:
        if heading == labels.heading(name):
            return name
    return "" if heading in names else heading


def read_xlsx(path: Path, labels: Labels = Labels()) -> List[Dict[str, str]]:
    """sheet で作った Excel の「一覧」のシート (無ければ最初のシート) を読む。"""
    if path.suffix.lower() == ".csv":
        raise DraftError(f"CSV でなく、sheet で作った Excel（.xlsx）を渡してください: {path}")
    try:
        wb = load_workbook(path, read_only=True, data_only=True)
    except FileNotFoundError:
        raise DraftError(f"Excel がありません: {path}") from None
    except (zipfile.BadZipFile, InvalidFileException, KeyError, ValueError):
        raise DraftError(f"Excel（.xlsx）として読めません: {path}（sheet で作った Excel を、"
                         "「Excel ブック」の形のまま保存して渡してください）") from None
    except OSError as e:
        raise DraftError(f"Excel を読めません: {path}（{e.strerror or e}）") from None
    try:
        ws = wb[SHEET_TITLE] if SHEET_TITLE in wb.sheetnames else wb.worksheets[0]
        ws.reset_dimensions()
        lines = ws.iter_rows(values_only=True)
        header = [_column(_text(v).strip(), labels) for v in next(lines, ())]
        missing = [c for c in REQUIRED_COLUMNS if c not in header]
        if missing:
            raise DraftError(f"Excel に {', '.join(labels.heading(c) for c in missing)} の列がありません: {path}"
                             "（path_lister.py sheet で作った Excel を使ってください。"
                             "設定の labels を変えたなら、sheet と draft を同じ設定で動かします）")
        rows = []
        for values in lines:
            if all(v is None or v == "" for v in values):
                continue
            rows.append({h: _text(v) for h, v in zip(header, values) if h})
        return rows
    finally:
        wb.close()


# --------------------------------------------------------------------------- 名前


def stage_key(folder: str) -> Tuple[int, int, str, str]:
    """段階の並び。番号の付いたものを番号の順に先に、無いものを名前の順に後に並べる。"""
    m = _NUMBER_RE.match(folder)
    if m:
        return (0, int(m.group(1)), folder.casefold(), folder)
    return (1, 0, folder.casefold(), folder)


def stage_title(folder: str, names: Dict[str, str]) -> str:
    """段階の見出し。設定の stages にあればその名前、無ければ先頭の番号を外した名前。"""
    if folder in names:
        return names[folder]
    folded = {k.casefold(): v for k, v in names.items()}
    if folder.casefold() in folded:
        return folded[folder.casefold()]
    m = _NUMBER_RE.match(folder)
    if m and m.group(2).strip():
        return m.group(2).strip()
    return folder


def clean_text(text: str) -> str:
    """catalog の欄に書く文字。縦棒は区切りと読まれるので「／」に、空白はまとめる。"""
    return " ".join(_SEPARATOR_RE.sub("／", text).split())


def md_escape(text: str) -> str:
    return _MD_SPECIAL_RE.sub(r"\\\1", text)


def file_name(text: str, fallback: str = Labels.group) -> str:
    """まとまりの名前を、子の .md のファイル名に使える形にする。"""
    name = _BAD_FILENAME_RE.sub("_", text).strip(" .")
    return name or _BAD_FILENAME_RE.sub("_", fallback).strip(" .") or Labels.group


# --------------------------------------------------------------------------- 組み立て


def build(rows: List[Dict[str, str]], *, scheme: str = "file", labels: Labels = Labels()) -> Draft:
    """Excel の行から、まとまり → 段階 → 項目の並びを組み立てる。まとまり・段階が空の行は飛ばす。"""
    draft = Draft()
    adopt = any((r.get(ADOPT_COLUMN) or "").strip() for r in rows)
    if not adopt and rows and ADOPT_COLUMN in rows[0]:
        draft.notes.append("「採用」に印が無いので、すべてのファイルの行を使いました")
    blank: List[str] = []
    for row in rows:
        kind = (row.get("種別") or "").strip()
        path = (row.get("フルパス") or "").strip()
        if adopt:
            if not (row.get(ADOPT_COLUMN) or "").strip():
                continue
            if kind not in ADOPTABLE_KINDS:
                draft.warnings.append(f"種別が「{kind}」の行は{labels.item}にできないので飛ばしました: {path}")
                continue
        elif kind != KIND_FILE:
            continue
        if not path:
            continue
        given = {c: clean_text(row.get(c) or "") for c in (GROUP_COLUMN, STAGE_COLUMN, ITEM_COLUMN, NOTE_COLUMN)}
        group, stage = given[GROUP_COLUMN], given[STAGE_COLUMN]
        if not (group and stage):
            blank.append(path)
            continue
        name = split_path(path)[-1]
        base = stem(name) if kind == KIND_FILE else name
        label = given[ITEM_COLUMN]
        draft.groups.setdefault(group, {}).setdefault(stage, []).append(
            Item(stem=base, name=name, sub=given[NOTE_COLUMN], url=to_url(path, scheme), path=path,
                 label=label, fixed=bool(label) and label != clean_text(base)))
        draft.used_rows += 1
    if blank:
        sample = "、".join(blank[:3]) + (f" ほか {len(blank) - 3} 件" if len(blank) > 3 else "")
        draft.warnings.append(f"「{labels.group}」「{labels.stage}」が空の行を飛ばしました: {sample}"
                              f"（{labels.stage}のフォルダの外の行です。Excel で書けば使えます）")
    for group, stages in draft.groups.items():
        for stage, items in stages.items():
            _label(items)
            seen: Dict[str, int] = {}
            for item in items:
                seen[item.label.casefold()] = seen.get(item.label.casefold(), 0) + 1
            twice = [item.label for item in items if seen.pop(item.label.casefold(), 0) > 1]
            if twice:
                draft.warnings.append(f"同じ名前の{labels.item}があります（{group} の {stage}: {'、'.join(twice)}）。"
                                      f"catalog は 2 つ目から捨てるので、「{labels.item}」の列で名前を変えてください")
    return draft


def _label(items: List[Item]) -> None:
    """同じ段階の中で重ならない名前を付ける。人が「項目」に書いた名前 (fixed) はそのまま使う。

    拡張子を除いた名前で重ならなければそれを、拡張子付きで重ならなければそれを使う。
    どちらでも重なる (下のフォルダに同じ名前がある) ときは、拡張子を除いた名前に下のフォルダを添える。
    """
    def counts(labels):
        seen: Dict[str, int] = {}
        for label in labels:
            seen[label.casefold()] = seen.get(label.casefold(), 0) + 1
        return seen

    items = [i for i in items if not i.fixed]
    stems = counts(clean_text(i.stem) for i in items)
    names = counts(clean_text(i.name) for i in items)
    for item in items:
        stem, name = clean_text(item.stem), clean_text(item.name)
        if stems[stem.casefold()] == 1:
            item.label = stem
        elif names[name.casefold()] == 1:
            item.label = name
        elif item.sub:
            item.label = f"{stem}（{clean_text(item.sub)}）"
        else:
            item.label = stem


def order_stages(draft: Draft) -> List[str]:
    """すべてのまとまりに出てくる段階のフォルダ名を、並べる順にする。"""
    folders = {stage for stages in draft.groups.values() for stage in stages}
    return sorted(folders, key=stage_key)


# --------------------------------------------------------------------------- 書き出し


def _yaml_str(text: str) -> str:
    return '"' + text.replace("\\", "\\\\").replace('"', '\\"') + '"'


def render_link(item: Item) -> str:
    """項目の名前とリンク。`名前｜[フルパス](リンク先)` と書く。

    フルパスに縦棒があっても同じに書く (docmold 0.16.1 から、リンクの中の縦棒を欄の区切りと読まない)。
    """
    if not item.path:
        return f"[{md_escape(item.label)}]({item.url})"
    return f"{md_escape(item.label)}｜[{md_escape(item.path)}]({item.url})"


def render_fragment(group: str, stages: Dict[str, List[Item]], order: List[str],
                    names: Dict[str, str]) -> str:
    lines = ["---", "type: fragment", f"title: {_yaml_str(group)}", "---", ""]
    for folder in order:
        items = stages.get(folder)
        if not items:
            continue
        lines += [f"## {md_escape(clean_text(stage_title(folder, names)))}", ""]
        for item in items:
            line = f"- {render_link(item)}"
            if item.sub:
                line += "｜" + md_escape(clean_text(item.sub))
            lines.append(line)
        lines.append("")
    return "\n".join(lines)


def render_parent(title: str, includes: List[Tuple[str, str]], stage_titles: List[str],
                  labels: Labels = Labels()) -> str:
    lines = ["---", "type: catalog", f"title: {_yaml_str(title)}",
             "段階: [" + ", ".join(_yaml_str(s) for s in stage_titles) + "]"]
    changed = labels.changed()
    if changed:
        lines.append("呼び名:")
        lines += [f"  {name}: {_yaml_str(label)}" for name, label in changed.items()]
    lines.append("取り込み:")
    for group, rel in includes:
        lines.append(f"  {_yaml_str(group)}: {_yaml_str(rel)}")
    lines += ["---", "", f"path_lister で作った下書き。{labels.item}の名前・補足・{labels.stage}は、見ながら直してください。", ""]
    return "\n".join(lines)


def plan_files(draft: Draft, out_dir: Path, title: str, names: Dict[str, str],
               labels: Labels = Labels()) -> List[Tuple[Path, str]]:
    """書くファイルとその中身。親は out_dir/<title>.md、子は out_dir/parts/<まとまり>.md。"""
    order = order_stages(draft)
    stage_titles: List[str] = []
    for folder in order:
        t = clean_text(stage_title(folder, names))
        if t not in stage_titles:
            stage_titles.append(t)
    files: List[Tuple[Path, str]] = []
    includes: List[Tuple[str, str]] = []
    used: Dict[str, int] = {}
    for group in sorted(draft.groups, key=lambda g: (g.casefold(), g)):
        base = file_name(group, labels.group)
        n = used.get(base.casefold(), 0) + 1
        used[base.casefold()] = n
        fname = base + (f"_{n}" if n > 1 else "") + ".md"
        files.append((out_dir / "parts" / fname,
                      render_fragment(group, draft.groups[group], order, names)))
        includes.append((group, "parts/" + fname))
    files.insert(0, (out_dir / (file_name(title) + ".md"), render_parent(title, includes, stage_titles, labels)))
    return files


def write_files(files: List[Tuple[Path, str]]) -> None:
    """書く前に、どれも既に無いことを確かめる。1 つでもあれば何も書かずに止める。"""
    existing = [str(p) for p, _ in files if p.exists()]
    if existing:
        raise DraftError("既にあるファイルは上書きしません。別の書き出し先を指定してください: "
                         + "、".join(existing))
    for path, text in files:
        path.parent.mkdir(parents=True, exist_ok=True)
        with open(path, "x", encoding="utf-8", newline="\n") as f:
            f.write(text)


def draft_from_xlsx(xlsx_path: Path, out_dir: Path, *, title: str,
                    names: Optional[Dict[str, str]] = None, scheme: str = "file",
                    labels: Labels = Labels()) -> Tuple[Draft, List[Path]]:
    draft = build(read_xlsx(xlsx_path, labels), scheme=scheme, labels=labels)
    if not draft.groups:
        raise DraftError("下書きにする行がありません（「採用」に印の付いた行、印が無ければファイルの行のうち、"
                         f"「{labels.group}」「{labels.stage}」が書いてあるものを使います）: {xlsx_path}")
    files = plan_files(draft, out_dir, title, names or {}, labels)
    write_files(files)
    return draft, [p for p, _ in files]
