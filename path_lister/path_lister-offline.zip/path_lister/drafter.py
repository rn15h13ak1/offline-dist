"""sheet で作り、Excel で選んだ一覧 (.xlsx) から、catalog の下書き (.md) を作る。

1 つのまとまりを 1 つの子 (`type: fragment`) にし、親 (`type: catalog`) が `取り込み:` で束ねる。

- 「採用」に印のある行だけを使う (ファイル・フォルダ・リンク)。印が 1 つも無ければ、ファイルの行をすべて使う
- 「まとまり」「段階」「項目」「補足」の列の値を使う。まとまり・段階はフォルダの位置から sheet が埋めてある。
  どちらかが空の行は飛ばす
- 段階は先頭の番号の順に並べ、番号を外した名前を出す。設定の stages で名前を付け替えられる
- 項目の名前は「項目」の列。sheet が埋めたまま (直していない) なら、同じ段階で重なると拡張子付きにする
- 段の並びは Excel のシート「組み立て」から読む。段の数は 2 から 5 で、親に `段:` と段ごとの並びを書き、
  子は 2 段目を `##`、3 段目を `###` と深くする
"""
from __future__ import annotations

import re
import zipfile
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, Dict, Iterator, List, Optional, Tuple

from openpyxl import load_workbook
from openpyxl.utils.exceptions import InvalidFileException

from config import DEFAULT_LABELS, MAX_LEVELS, MIN_LEVELS
from scanner import KIND_DIR, KIND_FILE, KIND_LINK, stem, to_url
from sheet import LEVELS_SHEET, SHEET_TITLE, split_path

ADOPT_COLUMN = "採用"
NOTE_COLUMN = "補足"
# 「採用」に印を付ければ項目にできる種別。印が 1 つも無ければファイルの行だけを使う
ADOPTABLE_KINDS = (KIND_FILE, KIND_DIR, KIND_LINK)
REQUIRED_COLUMNS = ("種別", "フルパス")

_NUMBER_RE = re.compile(r"^(\d+)[\s._\-]*(.*)$")
# リンクの文字の中で意味を持つ記号。前に \ を置いて文字として出す
_MD_SPECIAL_RE = re.compile(r"([\\`*_\[\]()!{}#])")
_SEPARATOR_RE = re.compile(r"[|｜]")
_BAD_FILENAME_RE = re.compile(r'[\\/:*?"<>|\x00-\x1f]')


class DraftError(Exception):
    """入力・出力先の誤り。入口は終了コード 2 で止まる。"""


@dataclass
class Item:
    stem: str
    name: str
    sub: str
    url: str
    path: str = ""  # [] に書くフルパス (人が .md で読む目印。docmold は画面のパスをリンク先から作る)
    label: str = ""
    fixed: bool = False  # 人が「項目」に書いた名前。重なっても付け替えない


@dataclass
class Draft:
    """書き出すもの。groups は段の木で、最上段の名前 → 間の段の名前 (フォルダ名か列の値) → … → 項目の並び。

    3 段ならまとまり → 段階 → 項目、2 段ならまとまり → 項目。
    """

    groups: Dict[str, Any] = field(default_factory=dict)
    # 上から順の段の名前 (シート「組み立て」の並び)
    labels: Tuple[str, ...] = DEFAULT_LABELS
    warnings: List[str] = field(default_factory=list)
    notes: List[str] = field(default_factory=list)
    used_rows: int = 0


# --------------------------------------------------------------------------- Excel を読む


def _text(value) -> str:
    """セルの値を文字にする。Excel が数にした値 (`1.0`) は整数の形にする。"""
    if value is None:
        return ""
    if isinstance(value, float) and value.is_integer():
        return str(int(value))
    return str(value)


def _read_labels(wb, path: Path) -> Tuple[str, ...]:
    """シート「組み立て」の段の並び。"""
    if LEVELS_SHEET not in wb.sheetnames:
        raise DraftError(f"Excel にシート「{LEVELS_SHEET}」がありません: {path}"
                         "（path_lister.py sheet で作った Excel を使ってください）")
    ws = wb[LEVELS_SHEET]
    ws.reset_dimensions()
    cells = [_text(line[0]).strip() for line in ws.iter_rows(values_only=True, max_col=1) if line]
    labels = tuple(c for c in cells[1:] if c)
    if not MIN_LEVELS <= len(labels) <= MAX_LEVELS:
        raise DraftError(f"シート「{LEVELS_SHEET}」の段は {MIN_LEVELS} から {MAX_LEVELS} 個で書きます"
                         f"（{len(labels)} 個あります）: {path}")
    twice = [label for i, label in enumerate(labels) if label in labels[:i]]
    if twice:
        raise DraftError(f"シート「{LEVELS_SHEET}」に同じ名前の段が 2 つあります: {twice[0]}: {path}")
    return labels


def read_book(path: Path) -> Tuple[List[Dict[str, str]], Tuple[str, ...]]:
    """sheet で作った Excel を読む。戻り値は (「一覧」のシートの行, シート「組み立て」の段の並び)。

    「一覧」が無ければ、「組み立て」以外の最初のシートを読む。行のキーは列の見出しのまま。
    """
    if path.suffix.lower() == ".csv":
        raise DraftError(f"CSV でなく、sheet で作った Excel（.xlsx）を渡してください: {path}")
    try:
        wb = load_workbook(path, read_only=True, data_only=True)
    except FileNotFoundError:
        raise DraftError(f"Excel がありません: {path}") from None
    except (zipfile.BadZipFile, InvalidFileException, KeyError, ValueError):
        raise DraftError(f"Excel（.xlsx）として読めません: {path}（sheet で作った Excel を、"
                         "「Excel ブック」の形のまま保存して渡してください）") from None
    except OSError as e:
        raise DraftError(f"Excel を読めません: {path}（{e.strerror or e}）") from None
    try:
        labels = _read_labels(wb, path)
        others = [ws for ws in wb.worksheets if ws.title != LEVELS_SHEET]
        if not others:
            raise DraftError(f"Excel に「{SHEET_TITLE}」のシートがありません: {path}")
        ws = wb[SHEET_TITLE] if SHEET_TITLE in wb.sheetnames else others[0]
        ws.reset_dimensions()
        lines = ws.iter_rows(values_only=True)
        header = [_text(v).strip() for v in next(lines, ())]
        missing = [c for c in (*REQUIRED_COLUMNS, *labels[:-1]) if c not in header]
        if missing:
            raise DraftError(f"Excel に {', '.join(missing)} の列がありません: {path}"
                             f"（シート「{LEVELS_SHEET}」の段の名前と、列の見出しを同じにします。"
                             "path_lister.py sheet で作った Excel を使ってください）")
        rows = []
        for values in lines:
            if all(v is None or v == "" for v in values):
                continue
            rows.append({h: _text(v) for h, v in zip(header, values) if h})
        return rows, labels
    finally:
        wb.close()


# --------------------------------------------------------------------------- 名前


def stage_key(folder: str) -> Tuple[int, int, str, str]:
    """段階の並び。番号の付いたものを番号の順に先に、無いものを名前の順に後に並べる。"""
    m = _NUMBER_RE.match(folder)
    if m:
        return (0, int(m.group(1)), folder.casefold(), folder)
    return (1, 0, folder.casefold(), folder)


def stage_title(folder: str, names: Dict[str, str]) -> str:
    """段階の見出し。設定の stages にあればその名前、無ければ先頭の番号を外した名前。"""
    if folder in names:
        return names[folder]
    folded = {k.casefold(): v for k, v in names.items()}
    if folder.casefold() in folded:
        return folded[folder.casefold()]
    m = _NUMBER_RE.match(folder)
    if m and m.group(2).strip():
        return m.group(2).strip()
    return folder


def clean_text(text: str) -> str:
    """catalog の欄に書く文字。縦棒は区切りと読まれるので「／」に、空白はまとめる。"""
    return " ".join(_SEPARATOR_RE.sub("／", text).split())


def md_escape(text: str) -> str:
    return _MD_SPECIAL_RE.sub(r"\\\1", text)


def file_name(text: str, fallback: str = DEFAULT_LABELS[0]) -> str:
    """まとまりの名前を、子の .md のファイル名に使える形にする。"""
    name = _BAD_FILENAME_RE.sub("_", text).strip(" .")
    return name or _BAD_FILENAME_RE.sub("_", fallback).strip(" .") or DEFAULT_LABELS[0]


# --------------------------------------------------------------------------- 組み立て


def leaves(tree: Any, path: Tuple[str, ...] = ()) -> Iterator[Tuple[Tuple[str, ...], List[Item]]]:
    """段の木の、一番下の段の並びを (段の名前の並び, 項目) で順に返す。"""
    if isinstance(tree, list):
        yield path, tree
        return
    for key, value in tree.items():
        yield from leaves(value, (*path, key))


def build(rows: List[Dict[str, str]], *, scheme: str = "file",
          labels: Tuple[str, ...] = DEFAULT_LABELS) -> Draft:
    """Excel の行から、段の木を組み立てる。項目より上の段が 1 つでも空の行は飛ばす。"""
    draft = Draft(labels=labels)
    adopt = any((r.get(ADOPT_COLUMN) or "").strip() for r in rows)
    if not adopt and rows and ADOPT_COLUMN in rows[0]:
        draft.notes.append("「採用」に印が無いので、すべてのファイルの行を使いました")
    blank: List[str] = []
    for row in rows:
        kind = (row.get("種別") or "").strip()
        path = (row.get("フルパス") or "").strip()
        if adopt:
            if not (row.get(ADOPT_COLUMN) or "").strip():
                continue
            if kind not in ADOPTABLE_KINDS:
                draft.warnings.append(f"種別が「{kind}」の行は{labels[-1]}にできないので飛ばしました: {path}")
                continue
        elif kind != KIND_FILE:
            continue
        if not path:
            continue
        uppers = [clean_text(row.get(c) or "") for c in labels[:-1]]
        if not all(uppers):
            blank.append(path)
            continue
        name = split_path(path)[-1]
        base = stem(name) if kind == KIND_FILE else name
        label = clean_text(row.get(labels[-1]) or "")
        node = draft.groups
        for key in uppers[:-1]:
            node = node.setdefault(key, {})
        node.setdefault(uppers[-1], []).append(
            Item(stem=base, name=name, sub=clean_text(row.get(NOTE_COLUMN) or ""), url=to_url(path, scheme), path=path,
                 label=label, fixed=bool(label) and label != clean_text(base)))
        draft.used_rows += 1
    if blank:
        sample = "、".join(blank[:3]) + (f" ほか {len(blank) - 3} 件" if len(blank) > 3 else "")
        quoted = "".join(f"「{name}」" for name in labels[:-1])
        draft.warnings.append(f"{quoted}が空の行を飛ばしました: {sample}"
                              f"（{labels[-2]}のフォルダの外の行です。Excel で書けば使えます）")
    for where, items in leaves(draft.groups):
        _label(items)
        seen: Dict[str, int] = {}
        for item in items:
            seen[item.label.casefold()] = seen.get(item.label.casefold(), 0) + 1
        twice = [item.label for item in items if seen.pop(item.label.casefold(), 0) > 1]
        if twice:
            draft.warnings.append(f"同じ名前の{labels[-1]}があります（{' の '.join(where)}: {'、'.join(twice)}）。"
                                  f"catalog は 2 つ目から捨てるので、「{labels[-1]}」の列で名前を変えてください")
    return draft


def _label(items: List[Item]) -> None:
    """同じ段階の中で重ならない名前を付ける。人が「項目」に書いた名前 (fixed) はそのまま使う。

    拡張子を除いた名前で重ならなければそれを、拡張子付きで重ならなければそれを使う。
    どちらでも重なる (下のフォルダに同じ名前がある) ときは、拡張子を除いた名前に下のフォルダを添える。
    """
    def counts(labels):
        seen: Dict[str, int] = {}
        for label in labels:
            seen[label.casefold()] = seen.get(label.casefold(), 0) + 1
        return seen

    items = [i for i in items if not i.fixed]
    stems = counts(clean_text(i.stem) for i in items)
    names = counts(clean_text(i.name) for i in items)
    for item in items:
        stem, name = clean_text(item.stem), clean_text(item.name)
        if stems[stem.casefold()] == 1:
            item.label = stem
        elif names[name.casefold()] == 1:
            item.label = name
        elif item.sub:
            item.label = f"{stem}（{clean_text(item.sub)}）"
        else:
            item.label = stem


def order_level(draft: Draft, index: int) -> List[str]:
    """間の段 (index は 2 段目が 0) に出てくる名前を、並べる順にする。段ごとに先頭の番号で並べる。"""
    nodes = list(draft.groups.values())
    for _ in range(index):
        nodes = [child for node in nodes if isinstance(node, dict) for child in node.values()]
    return sorted({key for node in nodes if isinstance(node, dict) for key in node}, key=stage_key)


def order_stages(draft: Draft) -> List[str]:
    """すべてのまとまりに出てくる段階のフォルダ名を、並べる順にする。"""
    return order_level(draft, 0)


def order_levels(draft: Draft) -> List[List[str]]:
    """間の段ごとの並び。"""
    return [order_level(draft, i) for i in range(len(draft.labels) - 2)]


def summary(draft: Draft) -> str:
    """段ごとの数。「まとまり 2・段階 3・項目 9」の形。"""
    items = sum(len(found) for _, found in leaves(draft.groups))
    counts = [len(draft.groups), *(len(order) for order in order_levels(draft)), items]
    return "・".join(f"{name} {count}" for name, count in zip(draft.labels, counts))


# --------------------------------------------------------------------------- 書き出し


def _yaml_str(text: str) -> str:
    return '"' + text.replace("\\", "\\\\").replace('"', '\\"') + '"'


def render_link(item: Item) -> str:
    """項目の名前とリンク。`名前｜[フルパス](リンク先)` と書く。

    フルパスに縦棒があっても同じに書く (docmold 0.16.1 から、リンクの中の縦棒を欄の区切りと読まない)。
    """
    if not item.path:
        return f"[{md_escape(item.label)}]({item.url})"
    return f"{md_escape(item.label)}｜[{md_escape(item.path)}]({item.url})"


def _render_tree(lines: List[str], tree: Any, orders: List[List[str]], names: Dict[str, str], depth: int) -> None:
    """段の木の中身を書く。間の段は深さの順に見出しにし、一番下に項目を並べる。"""
    if isinstance(tree, list):
        for item in tree:
            line = f"- {render_link(item)}"
            if item.sub:
                line += "｜" + md_escape(clean_text(item.sub))
            lines.append(line)
        lines.append("")
        return
    for folder in orders[0]:
        child = tree.get(folder)
        if not child:
            continue
        lines += [f"{'#' * depth} {md_escape(clean_text(stage_title(folder, names)))}", ""]
        _render_tree(lines, child, orders[1:], names, depth + 1)


def render_fragment(group: str, tree: Any, orders: List[List[str]], names: Dict[str, str]) -> str:
    lines = ["---", "type: fragment", f"title: {_yaml_str(group)}", "---", ""]
    _render_tree(lines, tree, orders, names, 2)
    return "\n".join(lines)


def _yaml_list(values: List[str]) -> str:
    return "[" + ", ".join(_yaml_str(v) for v in values) + "]"


def render_parent(title: str, includes: List[Tuple[str, str]], level_titles: List[List[str]],
                  labels: Tuple[str, ...] = DEFAULT_LABELS) -> str:
    """親。`段:` と、間の段ごとの並びと、`取り込み:` を書く。"""
    lines = ["---", "type: catalog", f"title: {_yaml_str(title)}", f"段: {_yaml_list(list(labels))}"]
    lines += [f"{_yaml_str(name)}: {_yaml_list(titles)}" for name, titles in zip(labels[1:-1], level_titles)]
    lines.append("取り込み:")
    for group, rel in includes:
        lines.append(f"  {_yaml_str(group)}: {_yaml_str(rel)}")
    fixable = "・".join([f"{labels[-1]}の名前", "補足", *labels[1:-1]])
    lines += ["---", "", f"path_lister で作った下書き。{fixable}は、見ながら直してください。", ""]
    return "\n".join(lines)


def plan_files(draft: Draft, out_dir: Path, title: str, names: Dict[str, str]) -> List[Tuple[Path, str]]:
    """書くファイルとその中身。親は out_dir/<title>.md、子は out_dir/parts/<まとまり>.md。"""
    orders = order_levels(draft)
    level_titles: List[List[str]] = []
    for order in orders:
        titles: List[str] = []
        for folder in order:
            t = clean_text(stage_title(folder, names))
            if t not in titles:
                titles.append(t)
        level_titles.append(titles)
    files: List[Tuple[Path, str]] = []
    includes: List[Tuple[str, str]] = []
    used: Dict[str, int] = {}
    for group in sorted(draft.groups, key=lambda g: (g.casefold(), g)):
        base = file_name(group, draft.labels[0])
        n = used.get(base.casefold(), 0) + 1
        used[base.casefold()] = n
        fname = base + (f"_{n}" if n > 1 else "") + ".md"
        files.append((out_dir / "parts" / fname,
                      render_fragment(group, draft.groups[group], orders, names)))
        includes.append((group, "parts/" + fname))
    files.insert(0, (out_dir / (file_name(title) + ".md"), render_parent(title, includes, level_titles, draft.labels)))
    return files


def write_files(files: List[Tuple[Path, str]]) -> None:
    """書く前に、どれも既に無いことを確かめる。1 つでもあれば何も書かずに止める。"""
    existing = [str(p) for p, _ in files if p.exists()]
    if existing:
        raise DraftError("既にあるファイルは上書きしません。別の書き出し先を指定してください: "
                         + "、".join(existing))
    for path, text in files:
        path.parent.mkdir(parents=True, exist_ok=True)
        with open(path, "x", encoding="utf-8", newline="\n") as f:
            f.write(text)


def draft_from_xlsx(xlsx_path: Path, out_dir: Path, *, title: str,
                    names: Optional[Dict[str, str]] = None, scheme: str = "file") -> Tuple[Draft, List[Path]]:
    rows, labels = read_book(xlsx_path)
    draft = build(rows, scheme=scheme, labels=labels)
    if not draft.groups:
        quoted = "".join(f"「{name}」" for name in labels[:-1])
        raise DraftError("下書きにする行がありません（「採用」に印の付いた行、印が無ければファイルの行のうち、"
                         f"{quoted}が書いてあるものを使います）: {xlsx_path}")
    files = plan_files(draft, out_dir, title, names or {})
    write_files(files)
    return draft, [p for p, _ in files]
