"""ファイルサーバーを辿ってフルパスの一覧 (CSV) を作り、Excel で選んだ行から catalog の下書き (.md) を作る。

  python path_lister.py scan \\\\server\\share\\projects         # 一覧 (CSV) を作る
  python path_lister.py sheet out\\paths-20261015-120000.csv     # CSV から組み立ての列を付けた Excel を作る
  python path_lister.py draft out\\paths-20261015-120000.xlsx    # Excel で選んだ行から下書きを作る
"""
# 注釈の `str | None` を Python 3.9 でも書けるようにする (PEP 563)
from __future__ import annotations

import os
import sys
import time
import traceback
from datetime import datetime
from pathlib import Path

from utils import DEPENDENCY_MODULES, missing_library_lines, add_subparser, make_console_safe, make_parser, require_python, stop_on_sigterm

require_python()

TOOL_DIR = Path(__file__).resolve().parent

try:
    import config as pl_config  # noqa: E402
    import drafter  # noqa: E402
    import sheet  # noqa: E402
except ModuleNotFoundError as e:
    # menu.bat のダブルクリックで依存が入っていないとき、トレースバックでなく入れ方を示す
    if e.name not in DEPENDENCY_MODULES:
        raise
    make_console_safe()
    for line in missing_library_lines(e.name, TOOL_DIR):
        print(line, file=sys.stderr)
    sys.exit(2)
import scanner  # noqa: E402
from version import __version__  # noqa: E402

# 終了コード (README と AGENTS.md の「終了コード」と同じ。tests/test_docs.py が見る)
EXIT_OK = 0
EXIT_UNREADABLE = 1
EXIT_USAGE = 2
EXIT_UNEXPECTED = 3
EXIT_INTERRUPTED = 130

# 画面に出す読めない所の数。残りは CSV の「エラー」の列で見る
ERROR_SAMPLES = 20


class UsageError(Exception):
    """引数・出力先の誤り (終了コード 2)。"""


def build_parser():
    parser = make_parser(
        __file__,
        "ファイルサーバーを辿ってフルパスの一覧 (CSV) を作り、Excel で選んだ行から catalog の下書き (.md) を作る。",
        epilog="小コマンドごとの説明: python path_lister.py scan --help / sheet --help / draft --help",
    )
    parser.add_argument("--version", action="version", version=f"path_lister {__version__}",
                        help="版を出して終わる")
    sub = parser.add_subparsers(dest="command", title="小コマンド", metavar="{scan,sheet,draft}")

    scan = add_subparser(
        sub, "scan", "起点の下を辿って、フルパスの一覧 (CSV) を書き出す",
        "起点の下を辿って、フルパスの一覧を UTF-8 (BOM 付き) の CSV に 1 行ずつ書き出す。",
        epilog="例: python path_lister.py scan \\\\server\\share\\projects S:\\projects --max-depth 3",
    )
    scan.add_argument("roots", nargs="*", metavar="起点",
                      help="辿り始めるフォルダ。複数書ける (省くと設定の scan.roots)")
    scan.add_argument("--root-set", metavar="NAME",
                      help="設定の scan.root_sets に名前を付けて書いた起点の組を辿る (起点と一緒には書けない)")
    scan.add_argument("-c", "--config", metavar="PATH",
                      help="設定ファイル (既定: ツールのフォルダの config.yaml。無ければ設定なし)")
    scan.add_argument("-o", "--output", metavar="PATH",
                      help="書き出す CSV (既定: out\\paths-YYYYMMDD-HHMMSS.csv)。フォルダならその中に既定の名前で書く")
    scan.add_argument("--max-depth", type=int, metavar="N", help="深さの上限 (起点の直下が 1)")
    scan.add_argument("--only", choices=pl_config.ONLY_CHOICES,
                      help="書き出すもの: both (両方。既定)・files (ファイルだけ)・dirs (フォルダとリンクだけ)")
    scan.add_argument("--ext", metavar="LIST",
                      help="拡張子で絞る (例 .xlsx,.docx)。ファイルにだけ効く")
    scan.add_argument("--exclude", action="append", default=[], metavar="PATTERN",
                      help="除外の型を足す (例 *.bak・作業中/*)。何度も書ける")
    scan.add_argument("--no-default-excludes", action="store_true",
                      help="既定の除外の型 (~$*・Thumbs.db・.git など) を使わない")
    scan.add_argument("--no-progress", action="store_true", help="進み具合を出さない")

    sheet_ = add_subparser(
        sub, "sheet", "CSV から、組み立ての列を付けた Excel (.xlsx) を作る",
        "scan の CSV の左に「採用・まとまり・段階・項目・補足」の列を付けた Excel を作る。\n"
        "まとまり・段階・補足はフォルダの位置で、項目は名前で埋める。",
        epilog="例: python path_lister.py sheet out\\paths-20261015-120000.csv --stage-depth 2",
    )
    sheet_.add_argument("csv", metavar="CSV", help="scan で作った CSV")
    sheet_.add_argument("-c", "--config", metavar="PATH",
                        help="設定ファイル (既定: ツールのフォルダの config.yaml。無ければ設定なし)")
    sheet_.add_argument("-o", "--output", metavar="PATH",
                        help="書き出す Excel (既定: CSV の隣に同じ名前の .xlsx)。フォルダならその中に書く")
    sheet_.add_argument("--stage-depth", type=int, metavar="N",
                        help="段階にするフォルダの深さ (起点の直下が 1。既定 1)")

    draft = add_subparser(
        sub, "draft", "Excel で選んだ行から catalog の下書き (.md) を作る",
        "Excel で行を選んだ一覧から、まとまりごとの子 (type: fragment) と、それを束ねる親 (type: catalog) を作る。",
        epilog="例: python path_lister.py draft out\\paths-20261015-120000.xlsx --title 資料一覧",
    )
    draft.add_argument("xlsx", metavar="EXCEL", help="sheet で作り、Excel で行を選んで保存した .xlsx")
    draft.add_argument("-c", "--config", metavar="PATH",
                       help="設定ファイル (既定: ツールのフォルダの config.yaml。無ければ設定なし)")
    draft.add_argument("-o", "--out-dir", metavar="DIR",
                       help="書き出すフォルダ (既定: out\\draft-YYYYMMDD-HHMMSS)。既にあるファイルは上書きしない")
    draft.add_argument("--title", help="親の題とファイル名 (既定: 資料一覧)")
    draft.add_argument("--link-scheme", metavar="NAME",
                       help="リンクのスキーム。file の所だけを変える (例: lw。既定: 設定、無ければ file)")
    return parser


def load_settings(config_path: str | None) -> pl_config.Settings:
    """-c があればそれを、無ければツールのフォルダの config.yaml を読む。どちらも無ければ設定なし。"""
    if config_path:
        return pl_config.load_config(Path(config_path))
    default = TOOL_DIR / pl_config.CONFIG_NAME
    return pl_config.load_config(default if default.is_file() else None)


def _err(message: str) -> None:
    print(message, file=sys.stderr, flush=True)


# --------------------------------------------------------------------------- scan


def scan_output_path(arg: str | None, settings: pl_config.Settings, now: datetime | None = None) -> Path:
    name = scanner.default_csv_name(now)
    if arg:
        path = Path(arg)
        return path / name if path.is_dir() else path
    return (settings.scan_output_dir or TOOL_DIR / "out") / name


def run_scan(args) -> int:
    settings = load_settings(args.config)
    root_set = args.root_set
    if root_set is not None:
        if args.roots:
            raise UsageError("起点と --root-set は一緒に書けません。どちらかにしてください")
        if root_set not in settings.root_sets:
            names = ", ".join(settings.root_sets) or "無し（設定の scan.root_sets に書きます）"
            raise UsageError(f"起点の組 {root_set} が設定にありません（書いてある組: {names}）")
    roots = args.roots or settings.roots_of(root_set)
    if not roots:
        raise UsageError("起点を指定してください（例 python path_lister.py scan \\\\server\\share\\projects）。"
                         "設定の scan.roots にも書けます")
    for root in roots:
        if not os.path.isdir(root):
            raise UsageError(f"起点のフォルダがありません（読めません）: {root}")
    if args.max_depth is not None and args.max_depth < 1:
        raise UsageError("--max-depth は 1 以上にします")
    # --max-depth はすべての起点に効く。無ければ設定の起点ごとの深さ、それも無ければ scan.max_depth。
    # 引数の起点は設定の起点と関係なく辿るので、起点ごとの深さを見ない
    max_depth = args.max_depth if args.max_depth is not None else settings.max_depth
    from_config = args.max_depth is None and not args.roots
    max_depths = {root: settings.depth_for(root, root_set) for root in roots} if from_config else {}
    excludes = (list(pl_config.DEFAULT_EXCLUDES)
                if settings.default_excludes and not args.no_default_excludes else [])
    excludes += settings.exclude + args.exclude
    options = scanner.ScanOptions(
        max_depth=max_depth,
        only=args.only or settings.only,
        extensions=pl_config.parse_extensions(args.ext) if args.ext else settings.extensions,
        excludes=excludes,
    )

    out = scan_output_path(args.output, settings)
    try:
        out.parent.mkdir(parents=True, exist_ok=True)
        stream = scanner.open_csv(str(out))
    except FileExistsError:
        raise UsageError(f"既にあるファイルは上書きしません。別の名前を指定してください: {out}") from None
    except OSError as e:
        raise UsageError(f"CSV を書けません（Excel で開いていませんか）: {out}（{e.strerror or e}）") from None

    shown = []

    def on_error(row):
        if len(shown) < ERROR_SAMPLES:
            shown.append(row)
            _err(f"警告: 読めません: {row[2]}（{row[9]}）")

    def on_progress(stats):
        if not args.no_progress:
            _err(f"  {stats.rows:,} 行（エラー {stats.errors:,}）")

    start = time.monotonic()
    print(f"走査します{f'（{root_set}）' if root_set else ''}: {', '.join(roots)}", flush=True)
    try:
        with stream:
            stats = scanner.write_csv(stream, roots, options, on_progress=on_progress, on_error=on_error,
                                      max_depths=max_depths)
    except KeyboardInterrupt:
        _err(f"ここまでの一覧: {out}")
        raise
    seconds = time.monotonic() - start
    if stats.errors > len(shown):
        _err(f"警告: ほか {stats.errors - len(shown):,} 件の読めない所は、CSV の「エラー」の列を見てください。")
    print(f"済み: {stats.rows:,} 行（ファイル {stats.files:,}・フォルダ {stats.dirs:,}・リンク {stats.links:,}）"
          f"・エラー {stats.errors:,}・{seconds:.1f} 秒")
    print(f"出力: {out}")
    return EXIT_UNREADABLE if stats.errors else EXIT_OK


# --------------------------------------------------------------------------- draft


# --------------------------------------------------------------------------- sheet


def run_sheet(args) -> int:
    settings = load_settings(args.config)
    stage_depth = args.stage_depth if args.stage_depth is not None else settings.stage_depth
    if stage_depth < 1:
        raise UsageError("--stage-depth は 1 以上にします")
    csv_path = Path(args.csv)
    out = sheet.default_xlsx_path(csv_path, args.output)
    stats, warnings = sheet.sheet_from_csv(csv_path, out, stage_depth=stage_depth)
    for warning in warnings:
        _err(f"警告: {warning}")
    if stats.outside:
        sample = "、".join(stats.outside[:3]) + (f" ほか {len(stats.outside) - 3:,} 件" if len(stats.outside) > 3 else "")
        where = "起点の直下" if stage_depth == 1 else f"深さ {stage_depth} までのフォルダの直下"
        print(f"段階のフォルダの外のファイル（{where}）は、「まとまり」「段階」を空にしました: {sample}"
              "（載せるなら Excel で書きます）")
    print(f"済み: {stats.rows:,} 行（まとまり・段階を埋めた行 {stats.placed:,}）")
    print(f"出力: {out}")
    return EXIT_OK


# --------------------------------------------------------------------------- draft


def run_draft(args) -> int:
    settings = load_settings(args.config)
    if args.out_dir:
        out_dir = Path(args.out_dir)
    else:
        base = settings.draft_output_dir or TOOL_DIR / "out"
        out_dir = base / ("draft-" + datetime.now().strftime("%Y%m%d-%H%M%S"))
    title = (args.title or settings.title).strip() or "資料一覧"
    try:
        scheme = (pl_config.parse_scheme(args.link_scheme, "--link-scheme") if args.link_scheme is not None
                  else settings.link_scheme)
    except pl_config.ConfigError as e:
        raise UsageError(str(e)) from None
    draft, paths = drafter.draft_from_xlsx(Path(args.xlsx), out_dir, title=title,
                                           names=settings.stages, scheme=scheme)
    for warning in draft.warnings:
        _err(f"警告: {warning}")
    for note in draft.notes:
        print(note)
    items = sum(len(v) for stages in draft.groups.values() for v in stages.values())
    stages = len(drafter.order_stages(draft))
    print(f"済み: まとまり {len(draft.groups)}・段階 {stages}・項目 {items}")
    print(f"出力: {paths[0]}")
    for path in paths[1:]:
        print(f"  子: {path}")
    return EXIT_OK


# --------------------------------------------------------------------------- 入口


def main(argv=None) -> int:
    stop_on_sigterm()
    make_console_safe()
    parser = build_parser()
    try:
        args = parser.parse_args(argv)
        if not args.command:
            parser.print_help()
            return EXIT_USAGE
        if args.command == "scan":
            return run_scan(args)
        if args.command == "sheet":
            return run_sheet(args)
        return run_draft(args)
    except KeyboardInterrupt:
        _err("中断しました。")
        return EXIT_INTERRUPTED
    except (UsageError, pl_config.ConfigError, sheet.SheetError, drafter.DraftError) as e:
        _err(f"エラー: {e}")
        return EXIT_USAGE
    except SystemExit:
        raise
    except Exception:
        _err("エラー: 予期しないエラーで止まりました。次の内容を添えて知らせてください。")
        _err(traceback.format_exc())
        return EXIT_UNEXPECTED


if __name__ == "__main__":
    sys.exit(main())
