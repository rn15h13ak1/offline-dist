"""共通の小物。標準ライブラリだけで書き、入口 (path_lister.py・menu.py) が依存より先に読む。"""
from __future__ import annotations

import argparse
import importlib.util
import os
import sys
from pathlib import Path


def make_console_safe(streams=None) -> None:
    """UTF-8 でないコンソールで、表せない文字を「?」に置き換えて出すようにする。

    Windows の日本語コンソールは既定で CP932 で、CP932 に無い文字を print すると
    UnicodeEncodeError で落ちる。ソースの文字は tests/test_windows.py で CP932 に収めているが、
    共有フォルダのファイル名 (絵文字など) は防げない。落ちるよりは、その文字だけ「?」になる方がよい。

    - コードページ (chcp) は変えない。同じ窓で次に動かすものに影響するため
    - 置き換えるのは画面の表示だけ。CSV と .md に書く内容は変わらない
    - UTF-8 のコンソール (macOS など) では何もしない
    """
    for stream in (sys.stdout, sys.stderr) if streams is None else streams:
        encoding = (getattr(stream, "encoding", None) or "").lower().replace("-", "").replace("_", "")
        if encoding in ("", "utf8") or not hasattr(stream, "reconfigure"):
            continue
        try:
            stream.reconfigure(errors="replace")
        except (ValueError, OSError):
            pass


def stop_on_sigterm() -> None:
    """外から止める合図 (SIGTERM) を、Ctrl+C と同じ KeyboardInterrupt にする。

    コマンドを動かす道具は、時間の上限を超えると SIGTERM で止めることがある。何もしないと
    Python はその場で終わり、「中断しました。」が出ず、終了コードも README の表に無い値
    (POSIX では 143) になる。入口で呼び、Ctrl+C の扱い (終了コード 130) をそのまま効かせる。

    - 呼べるのはメインのスレッドだけ。呼べない環境 (SIGTERM が無いなど) では何もしない
    - Windows では、捕まえられない止め方 (プロセスを強制終了する) がある。そのときは今までどおり
    """
    import signal

    def _interrupt(signum, frame):
        raise KeyboardInterrupt

    try:
        signal.signal(signal.SIGTERM, _interrupt)
    except (AttributeError, ValueError, OSError):
        pass


# 動作要件 (README の「動作要件」・.bat の案内・scripts/export_offline.py と同じ。テストが見る)
MIN_PYTHON = (3, 9)


def require_python(version_info=None, stream=None) -> None:
    """Python が古ければ、入れ直す案内を出して終了コード 2 で止める。"""
    version = tuple(version_info or sys.version_info)[:2]
    if version >= MIN_PYTHON:
        return
    out = stream or sys.stderr
    need = ".".join(str(n) for n in MIN_PYTHON)
    print(f"Python {need} 以上を入れてください。", file=out)
    print(f"  実行中の Python: {'.'.join(str(n) for n in version)}（{sys.executable}）", file=out)
    print("  https://www.python.org/ から入れ、README の手順で依存も入れてください。", file=out)
    sys.exit(2)


# 依存の (import する名前, pip に渡す名前)。2 つは一致しないことがある (yaml と PyYAML)。
# 案内に import の名前を出すと、入らない名前を示すことになる
DEPENDENCIES = (("yaml", "PyYAML"), ("openpyxl", "openpyxl"))
DEPENDENCY_MODULES = tuple(module for module, _ in DEPENDENCIES)


def missing_packages() -> list:
    """入っていない依存の、pip に渡す名前の一覧。最初の 1 つだけでなく全部を示すために使う。"""
    missing = []
    for module, package in DEPENDENCIES:
        try:
            found = importlib.util.find_spec(module) is not None
        except (ImportError, ValueError):
            found = False
        if not found:
            missing.append(package)
    return missing


def missing_library_lines(name: str, tool_dir: Path) -> list:
    """依存が入っていないときの案内の行。入口は標準エラーに出し、終了コード 2 で止まる。

    name は ModuleNotFoundError の import の名前。欠けているものを調べ直し、pip に渡す名前で全部を示す。
    入れる先は実行中の Python を名指しする (`"<python>" -m pip install`)。Windows では Python が
    複数入っていることがあり、ただの `pip install` だと別の Python に入って「入れたのに直らない」が起きる。
    """
    packages = missing_packages() or [dict(DEPENDENCIES).get(name, name)]
    return [
        f"必要なライブラリ {', '.join(packages)} が入っていません。",
        f"  実行中の Python: {sys.executable}",
        "  次のコマンドで、この Python に入れてください:",
        f'      "{sys.executable}" -m pip install -r "{tool_dir / "requirements.txt"}"',
        "  ライブラリが入っている別の Python (Anaconda など) があれば、そちらで動かしても構いません。",
    ]


class _HelpFormatter(argparse.RawDescriptionHelpFormatter):
    """「usage:」を「使い方:」にする。説明と使い方の例 (epilog) は改行をそのまま出す。"""

    def add_usage(self, usage, actions, groups, prefix=None):
        return super().add_usage(usage, actions, groups,
                                 prefix="使い方: " if prefix is None else prefix)


def localize(parser: argparse.ArgumentParser) -> argparse.ArgumentParser:
    """見出しを「引数」「オプション」にし、日本語の -h を足す。"""
    parser._positionals.title = "引数"
    parser._optionals.title = "オプション"
    parser.add_argument("-h", "--help", action="help", help="この説明を出して終わる")
    return parser


def make_parser(script: str, description: str, epilog: str | None = None) -> argparse.ArgumentParser:
    """入口の ArgumentParser。`--help` を日本語で出し、オプションの省略形を受け付けない。"""
    parser = argparse.ArgumentParser(
        prog="python " + os.path.basename(script), description=description, epilog=epilog,
        formatter_class=_HelpFormatter, add_help=False, allow_abbrev=False,
    )
    return localize(parser)


def add_subparser(subparsers, name: str, help_text: str, description: str,
                  epilog: str | None = None) -> argparse.ArgumentParser:
    """小コマンドの ArgumentParser。入口と同じく日本語にする。"""
    parser = subparsers.add_parser(
        name, help=help_text, description=description, epilog=epilog,
        formatter_class=_HelpFormatter, add_help=False, allow_abbrev=False,
    )
    return localize(parser)
