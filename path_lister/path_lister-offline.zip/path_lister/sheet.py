"""一覧 (CSV) から、下書きの組み立てを書き込む Excel (.xlsx) を作る。

    起点/01_要件定義/要件定義書.xlsx           → まとまり「起点」・段階「01_要件定義」・項目「要件定義書」
    起点/01_要件定義/旧版/要件定義書_v1.xlsx   → 補足に「旧版」

- 左端に人が書き込む列 (SELECT_COLUMNS) を置き、右に CSV の列を並べる
- 親フォルダとリンク (ADDED_COLUMNS) は CSV に無く、フルパスから作って CSV の列の間に入れる
- まとまり・段階・補足は、フルパスの中の位置で埋める。段階は起点から stage_depth 番目のフォルダ。
  その上のフォルダ (無ければ起点) をまとまりにし、段階と名前の間のフォルダを補足にする。
  段階のフォルダの外の行 (起点の直下など) は空のままにする
- 項目は、ファイルなら拡張子を除いた名前、フォルダ・リンクなら名前。「採用」は空にする
- 段の数と名前は設定の labels (2 から 5 個)。最初の段がまとまり、最後の段が項目で、間の段は段階のフォルダから
  順に 1 つずつのフォルダ。段の並びはシート「組み立て」に書く (draft がどの列を段として読むかを Excel が持つ)
- 文字は文字のセルに書く (`=` で始まる名前を式にしない)。書き込む列は書式を文字にし、Excel で `01` と
  書いても `1` にならないようにする
"""
from __future__ import annotations

import csv
import io
from dataclasses import dataclass, field
from pathlib import Path
from typing import Dict, List, Optional, Tuple

from openpyxl import Workbook
from openpyxl.cell import WriteOnlyCell
from openpyxl.cell.cell import ILLEGAL_CHARACTERS_RE
from openpyxl.styles import Font, PatternFill
from openpyxl.utils import get_column_letter

from config import DEFAULT_LABELS
from scanner import KIND_DIR, KIND_FILE, KIND_LINK, stem, to_url

# 人が Excel で書き込む列。下書きはこれと「種別」「フルパス」だけを読む
SELECT_COLUMNS = ("採用", *DEFAULT_LABELS, "補足")
# CSV に無く、Excel を作るときにフルパスから作る列
ADDED_COLUMNS = ("親フォルダ", "リンク")
# 書き込む列の右に並べる列。ADDED_COLUMNS を除くと scanner.COLUMNS になる
LIST_COLUMNS = ("種別", "深さ", "フルパス", "親フォルダ", "名前", "拡張子", "サイズ", "更新日時", "リンク", "エラー")
COLUMNS = SELECT_COLUMNS + LIST_COLUMNS
REQUIRED_COLUMNS = ("種別", "深さ", "フルパス")
SHEET_TITLE = "一覧"
# 段の並びを書くシート。人が見て分かるように、隠さない
LEVELS_SHEET = "組み立て"
LEVELS_HEADING = "段の並び（上から順。最後が名前の段）"
# 1 枚のシートに入る行 (見出しを除く)
MAX_ROWS = 1_048_575
NUMBER_COLUMNS = ("深さ", "サイズ")
UPPER_WIDTH = 18
ITEM_WIDTH = 30
WIDTHS = {"採用": 6, "補足": 16, "種別": 8, "深さ": 6,
          "フルパス": 60, "親フォルダ": 40, "名前": 30, "拡張子": 8, "サイズ": 12, "更新日時": 20,
          "リンク": 40, "エラー": 30}
# 書き込む列の見出しの色。どこに書けばよいかを目で分かるようにする
SELECT_FILL = PatternFill("solid", fgColor="FFF2CC")
PLACEABLE_KINDS = (KIND_FILE, KIND_DIR, KIND_LINK)


class SheetError(Exception):
    """入力・出力先の誤り。入口は終了コード 2 で止まる。"""


@dataclass
class SheetStats:
    rows: int = 0
    placed: int = 0
    # 段階のフォルダの外で、まとまり・段階を空にしたファイルの行。段階より上のフォルダは外にあって当たり前なので数えない
    outside: List[str] = field(default_factory=list)


# --------------------------------------------------------------------------- CSV を読む


def read_csv(path: Path) -> Tuple[List[Dict[str, str]], List[str]]:
    """CSV を読む。UTF-8 で読めなければ CP932 (Excel の「CSV (コンマ区切り)」) で読む。

    戻り値は (行, 警告)。
    """
    if path.suffix.lower() in (".xlsx", ".xlsm"):
        raise SheetError(f"Excel でなく、scan で作った CSV を渡してください: {path}")
    try:
        data = path.read_bytes()
    except FileNotFoundError:
        raise SheetError(f"CSV がありません: {path}") from None
    except OSError as e:
        raise SheetError(f"CSV を読めません: {path}（{e}）") from None
    warnings = []
    try:
        text = data.decode("utf-8-sig")
    except UnicodeDecodeError:
        text = data.decode("cp932", errors="replace")
        warnings.append("CSV を CP932 で読みました。CP932 に無い文字は「?」になり、そのファイルのリンクは開けません"
                        "（scan で作り直した CSV を使ってください）")
    reader = csv.DictReader(io.StringIO(text, newline=""))
    header = [h.strip() for h in (reader.fieldnames or [])]
    missing = [c for c in REQUIRED_COLUMNS if c not in header]
    if missing:
        raise SheetError(f"CSV に {', '.join(missing)} の列がありません: {path}"
                         "（path_lister.py scan で作った CSV を使ってください）")
    reader.fieldnames = header
    return list(reader), warnings


# --------------------------------------------------------------------------- 書き込む列を埋める


def split_path(path: str) -> List[str]:
    """フルパスを部品に分ける。`\\` があれば Windows の区切り、無ければ `/`。"""
    sep = "\\" if "\\" in path else "/"
    return path.split(sep)


def place(path: str, depth: int, stage_depth: int, fallback: str = DEFAULT_LABELS[0],
          count: int = 3) -> Optional[Tuple[str, ...]]:
    """フルパスの中の位置から (最上段, 間の段…, 補足) を決める。count は項目まで含めた段の数。

    3 段なら (まとまり, 段階, 補足)。段のフォルダの外か、深さが合わなければ None。
    """
    parts = split_path(path)
    last = stage_depth - 1 + count - 2  # 間の段に使う一番深いフォルダの深さ
    if depth <= last or depth >= len(parts):
        return None
    root, rel = parts[:-depth], parts[-depth:]
    group_parts = rel[:stage_depth - 1] or [p for p in root if p][-1:]
    group = " ／ ".join(group_parts) or fallback
    return (group, *rel[stage_depth - 1:last], "/".join(rel[last:-1]))


def select_cells(row: Dict[str, str], stage_depth: int, fallback: str = DEFAULT_LABELS[0],
                 count: int = 3) -> Tuple[List[str], bool]:
    """書き込む列の初めの値と、位置で埋められたか。count は項目まで含めた段の数。"""
    empty = [""] * (count - 1)
    kind = (row.get("種別") or "").strip()
    name = row.get("名前") or split_path(row.get("フルパス") or "")[-1]
    if kind not in PLACEABLE_KINDS:
        return ["", *empty, "", ""], False
    item = stem(name) if kind == KIND_FILE else name
    try:
        depth = int((row.get("深さ") or "").strip())
    except ValueError:
        return ["", *empty, item, ""], False
    placed = place((row.get("フルパス") or "").strip(), depth, stage_depth, fallback, count)
    if placed is None:
        return ["", *empty, item, ""], False
    return ["", *placed[:-1], item, placed[-1]], True


# --------------------------------------------------------------------------- フルパスから作る列


def parent_folder(path: str, name: str) -> str:
    """フルパスのフォルダの部分。起点そのものの行 (名前がフルパスと同じ) は空。"""
    if not name or not path.endswith(name):
        name = split_path(path)[-1]
    base = path[:-len(name)] if name else path
    stripped = base.rstrip("\\/")
    # `/` や `S:\` は、区切りを外すとフォルダでなくなる
    return base if not stripped or stripped.endswith(":") else stripped


def added_cells(row: Dict[str, str], scheme: str = "file") -> Dict[str, str]:
    path = (row.get("フルパス") or "").strip()
    return {"親フォルダ": parent_folder(path, (row.get("名前") or "").strip()),
            "リンク": to_url(path, scheme) if path else ""}


# --------------------------------------------------------------------------- 書き出し


def _text_cell(ws, value: str, number_format: Optional[str] = None) -> WriteOnlyCell:
    cell = WriteOnlyCell(ws, value=ILLEGAL_CHARACTERS_RE.sub("?", value))
    cell.data_type = "s"  # `=` で始まっても式にしない
    if number_format:
        cell.number_format = number_format
    return cell


def _value(ws, column: str, value: str, select: Tuple[str, ...]):
    if column in NUMBER_COLUMNS and value.strip().isdigit():
        return int(value)
    if column in select:
        return _text_cell(ws, value, "@")
    if value.startswith("=") or ILLEGAL_CHARACTERS_RE.search(value):
        return _text_cell(ws, value)
    return value


def check_size(rows: List[Dict[str, str]]) -> None:
    if len(rows) > MAX_ROWS:
        raise SheetError(f"行が多すぎて 1 枚のシートに入りません（{len(rows):,} 行。上限 {MAX_ROWS:,} 行）。"
                         "scan の起点を分けるか、--max-depth・--ext で絞ってください")


def _width(column: str, labels: Tuple[str, ...]) -> int:
    if column == labels[-1]:
        return ITEM_WIDTH
    return UPPER_WIDTH if column in labels else WIDTHS.get(column, 12)


def build_workbook(rows: List[Dict[str, str]], stage_depth: int,
                   labels: Tuple[str, ...] = DEFAULT_LABELS, scheme: str = "file") -> Tuple[Workbook, SheetStats]:
    check_size(rows)
    select = ("採用", *labels, "補足")
    columns = select + LIST_COLUMNS
    wb = Workbook(write_only=True)
    ws = wb.create_sheet(SHEET_TITLE)
    for i, column in enumerate(columns, 1):
        ws.column_dimensions[get_column_letter(i)].width = _width(column, labels)
    ws.freeze_panes = "A2"
    ws.auto_filter.ref = f"A1:{get_column_letter(len(columns))}{len(rows) + 1}"
    header = []
    for column in columns:
        cell = _text_cell(ws, column)
        cell.font = Font(bold=True)
        if column in select:
            cell.fill = SELECT_FILL
        header.append(cell)
    ws.append(header)
    stats = SheetStats()
    for row in rows:
        cells, placed = select_cells(row, stage_depth, labels[0], len(labels))
        listed = {**row, **added_cells(row, scheme)}
        values = cells + [(listed.get(c) or "") for c in LIST_COLUMNS]
        ws.append([_value(ws, c, v, select) for c, v in zip(columns, values)])
        stats.rows += 1
        if placed:
            stats.placed += 1
        elif (row.get("種別") or "").strip() == KIND_FILE:
            stats.outside.append((row.get("フルパス") or "").strip())
    _write_labels(wb, labels)
    return wb, stats


def _write_labels(wb: Workbook, labels: Tuple[str, ...]) -> None:
    ws = wb.create_sheet(LEVELS_SHEET)
    ws.column_dimensions["A"].width = 40
    heading = _text_cell(ws, LEVELS_HEADING)
    heading.font = Font(bold=True)
    ws.append([heading])
    for label in labels:
        ws.append([_text_cell(ws, label, "@")])


def default_xlsx_path(csv_path: Path, arg: Optional[str] = None) -> Path:
    """既定は CSV の隣に同じ名前で。-o がフォルダなら、その中に同じ名前で。"""
    name = csv_path.with_suffix(".xlsx").name
    if arg:
        path = Path(arg)
        return path / name if path.is_dir() else path
    return csv_path.with_suffix(".xlsx")


def _create(out: Path):
    """書き出す先を、既に無いことを確かめて開く。既にあるファイルは上書きしない。"""
    try:
        out.parent.mkdir(parents=True, exist_ok=True)
        return open(out, "xb")
    except FileExistsError:
        raise SheetError(f"既にあるファイルは上書きしません。別の名前を指定してください: {out}") from None
    except OSError as e:
        raise SheetError(f"Excel を書けません: {out}（{e.strerror or e}）") from None


def sheet_from_csv(csv_path: Path, out: Path, *, stage_depth: int = 1,
                   labels: Tuple[str, ...] = DEFAULT_LABELS, scheme: str = "file") -> Tuple[SheetStats, List[str]]:
    """CSV を読み、Excel を書く。書きかけで止まったら、書きかけのファイルを消す。"""
    rows, warnings = read_csv(csv_path)
    check_size(rows)
    f = _create(out)
    try:
        with f:
            wb, stats = build_workbook(rows, stage_depth, labels, scheme)
            wb.save(f)
    except BaseException:
        out.unlink()
        raise
    return stats, warnings
