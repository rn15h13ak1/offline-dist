"""設定ファイル (config.yaml) の読み込みと検証。

同じ種類のツールに揃えて YAML にする。知らない節・項目は、似た名前を示してまとめて止める
(書き間違えた項目が黙って無視されると、効いていない設定に気付けないため)。

Windows のパスは、引用符なしか ' ' で囲めばそのまま書ける (`'\\\\server\\share'`)。
" " で囲むと `\\` が特別な意味になり、別のパスになるか読めなくなる。
"""
from __future__ import annotations

import difflib
import os
import re
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, Dict, List, Optional, Tuple

import yaml

from scanner import COLUMNS as CSV_COLUMNS, compile_pattern

CONFIG_NAME = "config.yaml"
EXAMPLE_NAME = "config.example.yaml"

ONLY_CHOICES = ("both", "files", "dirs")

# 既定の除外の型。Office の一時ファイル・OS が作るもの・版管理のフォルダ
DEFAULT_EXCLUDES = (
    "~$*", "Thumbs.db", "desktop.ini", ".git", ".svn", "$RECYCLE.BIN",
    "System Volume Information", ".DS_Store", "~*.tmp",
)

# 節ごとに書ける項目。stages と labels は名前を自由に書けるので、ここに無い
KNOWN_KEYS = {
    "scan": ("roots", "max_depth", "only", "extensions", "exclude", "default_excludes", "output_dir"),
    "sheet": ("stage_depth",),
    "draft": ("title", "output_dir", "link_scheme"),
    "labels": None,
    "stages": None,
}
# scan.roots の組の起点を「path: 起点」の形で書くときに書ける項目
ROOT_KEYS = ("path", "pattern", "max_depth", "only")
# 別の節へ移した項目。古い設定ファイルに、移った先を示す
MOVED_KEYS = {"draft.stage_depth": "sheet.stage_depth"}
# 段の名前にできない列の名前。Excel の列を見出しで見分けるので、段の名前と重なると読めない
FIXED_COLUMNS = ("採用", "補足", "親フォルダ", "リンク") + CSV_COLUMNS
# 既定の段。上から順で、最後がファイルなどの名前の段
DEFAULT_LABELS = ("まとまり", "段階", "項目")
# 書ける段の数。catalog が読める数に揃える
MIN_LEVELS = 2
MAX_LEVELS = 5
# 段の名前にできない語。段の名前は親の .md の front matter のキーにもなるので、別の意味のキーと重なると読めない
RESERVED_LEVEL_NAMES = ("type", "title", "取り込み", "include", "段", "levels", "呼び名", "names")


@dataclass
class RootGroup:
    """名前を付けた起点の組 (scan.roots の 1 つ)。"""
    roots: List[str] = field(default_factory=list)
    # 起点ごとの深さの上限。キーは root_key で揃えた起点
    depths: Dict[str, int] = field(default_factory=dict)
    # 起点ごとの書き出すもの。キーは root_key で揃えた起点
    onlys: Dict[str, str] = field(default_factory=dict)
    # pattern の起点。キーは roots の起点 (pattern_root の形)、値は (土台, 正規表現)
    patterns: Dict[str, Tuple[str, str]] = field(default_factory=dict)


class ConfigError(Exception):
    """設定の誤り。入口は終了コード 2 で止まる。"""


@dataclass
class Settings:
    # 名前を付けた起点の組。書いた順
    roots: Dict[str, RootGroup] = field(default_factory=dict)
    max_depth: Optional[int] = None
    only: str = "both"
    extensions: List[str] = field(default_factory=list)
    exclude: List[str] = field(default_factory=list)
    default_excludes: bool = True
    scan_output_dir: Optional[Path] = None
    stage_depth: int = 1
    title: str = "資料一覧"
    draft_output_dir: Optional[Path] = None
    link_scheme: str = "file"
    stages: Dict[str, str] = field(default_factory=dict)
    # 名前を付けた段の組。書いた順。値は上から順の段の名前で、最後がファイルなどの名前の段。空なら DEFAULT_LABELS
    label_sets: Dict[str, Tuple[str, ...]] = field(default_factory=dict)
    path: Optional[Path] = None

    def depth_for(self, root: str, name: str) -> Optional[int]:
        """組 name のその起点の深さの上限。起点に書いていなければ scan.max_depth。"""
        return self.roots[name].depths.get(root_key(root), self.max_depth)

    def only_for(self, root: str, name: str) -> str:
        """組 name のその起点の書き出すもの。起点に書いていなければ scan.only。"""
        return self.roots[name].onlys.get(root_key(root), self.only)

    @property
    def excludes(self) -> List[str]:
        return (list(DEFAULT_EXCLUDES) if self.default_excludes else []) + list(self.exclude)


# 下書きのリンクに使えないスキーム。開いたときにスクリプトが動くか、ファイルを開くものでない
BLOCKED_SCHEMES = ("javascript", "vbscript", "data", "about", "http", "https", "mailto")
_SCHEME_RE = re.compile(r"\A[A-Za-z][A-Za-z0-9+.-]*\Z")


def pattern_root(base: str, pattern: str) -> str:
    """pattern の起点を roots に並べるときの文字。画面に出し、起点ごとの深さ・書き出すもののキーにもなる。

    同じ土台に違う pattern を書いて、違う深さで辿れるよう、pattern まで含める。
    """
    folder = base.rstrip("\\/") or base
    return f"{folder} [pattern: {pattern}]"


def root_key(root: str) -> str:
    """起点を比べるための形。末尾の区切りを外し、Windows では大小文字と / \\ の違いを見ない。"""
    return os.path.normcase(root.rstrip("\\/") or root)


def parse_scheme(value: str, where: str) -> str:
    """リンクのスキーム。末尾の `:` や `://` は外す。小文字にそろえる。"""
    scheme = value.strip().rstrip("/").rstrip(":").lower()
    if not _SCHEME_RE.match(scheme) or len(scheme) < 2:
        raise ConfigError(f"{where} はスキームの名前（file・lw など）で書きます: {value}")
    if scheme in BLOCKED_SCHEMES:
        raise ConfigError(f"{where} に {scheme} は使えません（ファイルを開くスキームを書きます）: {value}")
    return scheme


def parse_extensions(value: str) -> List[str]:
    """`.xlsx, docx PDF` を ['.xlsx', '.docx', '.pdf'] にする。"""
    found = []
    for word in value.replace(",", " ").replace("、", " ").split():
        ext = word.lower()
        if not ext.startswith("."):
            ext = "." + ext
        if ext not in found:
            found.append(ext)
    return found


def _suggest(word: str, choices) -> str:
    names = sorted(str(c) for c in choices)
    for name in names:
        if name.lower() == str(word).lower():
            return f"（{name} の書き間違いではありませんか）"
    close = difflib.get_close_matches(str(word), names, n=1, cutoff=0.6)
    return f"（{close[0]} の書き間違いではありませんか）" if close else f"（書ける項目: {', '.join(names)}）"


def _read_yaml(path: Path) -> Dict[str, Any]:
    try:
        text = path.read_text(encoding="utf-8-sig")
    except UnicodeDecodeError:
        raise ConfigError(f"設定ファイルを UTF-8 として読めません: {path}\n"
                          "  → メモ帳で開き、「名前を付けて保存」で文字コードを「UTF-8」にして保存し直してください") from None
    except OSError as e:
        raise ConfigError(f"設定ファイルを読めません: {path}（{e}）") from None
    try:
        raw = yaml.safe_load(text)
    except yaml.YAMLError as e:
        raise ConfigError(f"設定ファイルを YAML として読めません: {path}\n  {e}\n"
                          "  → 示された行の字下げ（空白の数）と、「:」の後の空白を確かめてください。"
                          "Windows のパスは \" \" でなく ' ' で囲みます。* で始まる値（*.bak）も ' ' で囲みます") from None
    if raw is None:
        return {}
    if not isinstance(raw, dict):
        raise ConfigError(f"設定ファイルの形が不正です: {path}（scan: などの節を並べる形で書きます。{EXAMPLE_NAME} を参考にしてください）")
    return raw


def _check_keys(raw: Dict[str, Any]) -> None:
    """知らない節・項目を、まとめて 1 つの ConfigError にする (1 つ直すたびに次が出るより直しやすい)。"""
    problems = []
    for section, value in raw.items():
        if section not in KNOWN_KEYS:
            problems.append(f"{section} は知らない節です{_suggest(section, KNOWN_KEYS)}")
            continue
        if value is None or section == "labels":
            continue
        if not isinstance(value, dict):
            problems.append(f"{section}: の形が不正です（項目を字下げして「項目: 値」で並べます）: {value!r}")
            continue
        keys = KNOWN_KEYS[section]
        if keys is None:
            continue
        for key in value:
            if f"{section}.{key}" in MOVED_KEYS:
                problems.append(f"{section}.{key} は {MOVED_KEYS[section + '.' + key]} に移りました"
                                "（段階をフォルダの位置で埋めるのは、Excel を作るときになりました）")
            elif key not in keys:
                problems.append(f"{section}.{key} は知らない項目です{_suggest(key, keys)}")
    if problems:
        raise ConfigError("\n".join(problems) + f"\n  → 書き間違いなら直し、要らない項目なら消してください（{EXAMPLE_NAME} に書ける項目があります）")


def _text(value: Any, where: str) -> str:
    """文字の値。数や真偽値は書いたとおりの文字にせず止める (01 が 1 になるなど、書いた形と変わるため)。"""
    if not isinstance(value, str):
        raise ConfigError(f"{where} は文字で書きます（数や yes・no に読まれるときは ' ' で囲みます）: {value!r}")
    if any(ord(ch) < 0x20 for ch in value):
        raise ConfigError(f"{where} に改行やタブが入っています: {value!r}\n"
                          "  → \" \" で囲んだ \\ が特別な意味に読まれています。' ' で囲むか、引用符を外してください")
    return value.strip()


def _texts(value: Any, where: str) -> List[str]:
    """文字の並び。1 つだけなら並びにせず書いてもよい。"""
    if value is None:
        return []
    items = value if isinstance(value, list) else [value]
    return [t for t in (_text(v, f"{where}[{i}]" if isinstance(value, list) else where)
                        for i, v in enumerate(items)) if t]


def _positive(value: Any, where: str, *, minimum: int = 1) -> int:
    if isinstance(value, bool) or not isinstance(value, int) or value < minimum:
        raise ConfigError(f"{where} は {minimum} 以上の整数で書きます: {value!r}")
    return value


def _only(value: Any, where: str) -> str:
    only = _text(value, where)
    if only not in ONLY_CHOICES:
        raise ConfigError(f"{where} は {' / '.join(ONLY_CHOICES)} のどれかです: {only!r}")
    return only


def _pattern(value: Any, where: str) -> str:
    """pattern を読む。区切りを \\ で書いた形は、黙って当たらなくなるので止める。"""
    pattern = _text(value, where)
    hint = "（フォルダの区切りは / で書きます。例 '案件\\d+/設計'）"
    if not pattern:
        raise ConfigError(f"{where} が空です{hint}")
    # \設 は re では「設」と同じになり、区切りのつもりの \ が消えて、どのフォルダにも当たらない
    if re.search(r"\\[^\x00-\x7f]", pattern):
        raise ConfigError(f"{where} の \\ に日本語が続いています: {pattern}{hint}")
    try:
        compile_pattern(pattern)
    except (re.error, ValueError) as e:
        raise ConfigError(f"{where} を正規表現として読めません: {pattern}（{e}）{hint}") from None
    return pattern


def _roots(value: Any, name: str) -> tuple:
    """起点の並びを (起点の並び, 起点ごとの深さ, 起点ごとの書き出すもの, pattern の起点) にする。

    1 つは文字か「path: 起点」の形で書き、後者には pattern・max_depth・only を添えられる。
    """
    if value is None:
        return [], {}, {}, {}
    items = value if isinstance(value, list) else [value]
    roots: List[str] = []
    depths: Dict[str, int] = {}
    onlys: Dict[str, str] = {}
    patterns: Dict[str, Tuple[str, str]] = {}
    for i, item in enumerate(items):
        where = f"{name}[{i}]" if isinstance(value, list) else name
        if not isinstance(item, dict):
            root = _text(item, where)
            if root:
                roots.append(root)
            continue
        unknown = [k for k in item if k not in ROOT_KEYS]
        if unknown:
            raise ConfigError(f"{where}.{unknown[0]} は知らない項目です{_suggest(unknown[0], ROOT_KEYS)}")
        root = _text(item.get("path"), f"{where}.path") if item.get("path") is not None else ""
        if not root:
            raise ConfigError(f"{where} に path: が無いか、空です（「- path: 'S:\\projects'」の形で書きます）")
        if item.get("pattern") is not None:
            pattern = _pattern(item["pattern"], f"{where}.pattern")
            base, root = root, pattern_root(root, pattern)
            patterns[root] = (base, pattern)
        roots.append(root)
        key = root_key(root)
        if item.get("max_depth") is not None:
            depth = _positive(item["max_depth"], f"{where}.max_depth")
            if depths.get(key, depth) != depth:
                raise ConfigError(f"{where} の起点に、違う max_depth が 2 つ書かれています: {root}")
            depths[key] = depth
        if item.get("only") is not None:
            only = _only(item["only"], f"{where}.only")
            if onlys.get(key, only) != only:
                raise ConfigError(f"{where} の起点に、違う only が 2 つ書かれています: {root}")
            onlys[key] = only
    return roots, depths, onlys, patterns


def _root_groups(value: Any) -> Dict[str, RootGroup]:
    """scan.roots (名前: 起点の並び) を読む。名前は文字で、組は空にしない。"""
    if value is None:
        return {}
    if not isinstance(value, dict):
        raise ConfigError("scan.roots は「名前:」の下に起点を字下げして並べます"
                          f"（組が 1 つでも名前を書きます）: {value!r}")
    groups: Dict[str, RootGroup] = {}
    for key, roots in value.items():
        if not isinstance(key, str) or not key.strip():
            raise ConfigError(f"scan.roots の名前 {key!r} は文字で書きます（数や yes・no に読まれるときは ' ' で囲みます）")
        name = key.strip()
        found, depths, onlys, patterns = _roots(roots, f"scan.roots.{name}")
        if not found:
            raise ConfigError(f"scan.roots.{name} に起点がありません（「- 」に続けて 1 行に 1 つ書きます）")
        groups[name] = RootGroup(found, depths, onlys, patterns)
    return groups


def _labels(value: Any, where: str) -> Tuple[str, ...]:
    """段の組の 1 つ (上から順の段の名前の並び) を読む。"""
    if not isinstance(value, list):
        raise ConfigError(f"{where} は [案件, 工程, 資料] のように並べます: {value!r}")
    labels = _texts(value, where)
    if not MIN_LEVELS <= len(labels) <= MAX_LEVELS:
        raise ConfigError(f"{where} は {MIN_LEVELS} から {MAX_LEVELS} 個で書きます（{len(labels)} 個あります）")
    for label in labels:
        if labels.count(label) > 1:
            raise ConfigError(f"{where} に同じ名前が 2 つあります: {label}（Excel の列を見分けられないので、すべて違う名前にします）")
        if label in FIXED_COLUMNS:
            raise ConfigError(f"{where} の {label} は使えません（Excel の別の列と同じ名前です）")
        if label.casefold() in RESERVED_LEVEL_NAMES:
            raise ConfigError(f"{where} の {label} は使えません（下書きの親の .md で別の意味を持つ語です）")
    return tuple(labels)


def _label_sets(value: Any) -> Dict[str, Tuple[str, ...]]:
    """labels (名前: 段の名前の並び) を読む。書かなければ空で、既定の 3 段を使う。"""
    if value is None:
        return {}
    if not isinstance(value, dict):
        raise ConfigError("labels は「名前: [案件, 工程, 資料]」のように書きます"
                          f"（組が 1 つでも名前を書きます）: {value!r}")
    sets: Dict[str, Tuple[str, ...]] = {}
    for key, labels in value.items():
        if not isinstance(key, str) or not key.strip():
            raise ConfigError(f"labels の名前 {key!r} は文字で書きます（数や yes・no に読まれるときは ' ' で囲みます）")
        name = key.strip()
        sets[name] = _labels(labels, f"labels.{name}")
    return sets


def load_config(path: Optional[Path]) -> Settings:
    """設定を読む。path が None なら既定 (何も書いていない設定) を返す。"""
    settings = Settings()
    if path is None:
        return settings
    path = Path(path)
    if not path.is_file():
        raise ConfigError(f"設定ファイルがありません: {path}")
    raw = _read_yaml(path)
    _check_keys(raw)

    base = path.resolve().parent
    settings.path = path
    scan = raw.get("scan") or {}
    settings.roots = _root_groups(scan.get("roots"))
    if scan.get("max_depth") is not None:
        settings.max_depth = _positive(scan["max_depth"], "scan.max_depth")
    if scan.get("only") is not None:
        settings.only = _only(scan["only"], "scan.only")
    settings.extensions = parse_extensions(" ".join(_texts(scan.get("extensions"), "scan.extensions")))
    settings.exclude = _texts(scan.get("exclude"), "scan.exclude")
    if scan.get("default_excludes") is not None:
        if not isinstance(scan["default_excludes"], bool):
            raise ConfigError(f"scan.default_excludes は true か false で書きます: {scan['default_excludes']!r}")
        settings.default_excludes = scan["default_excludes"]
    if scan.get("output_dir") is not None and _text(scan["output_dir"], "scan.output_dir"):
        settings.scan_output_dir = base / _text(scan["output_dir"], "scan.output_dir")

    sheet = raw.get("sheet") or {}
    if sheet.get("stage_depth") is not None:
        settings.stage_depth = _positive(sheet["stage_depth"], "sheet.stage_depth")

    draft = raw.get("draft") or {}
    if draft.get("title") is not None and _text(draft["title"], "draft.title"):
        settings.title = _text(draft["title"], "draft.title")
    if draft.get("output_dir") is not None and _text(draft["output_dir"], "draft.output_dir"):
        settings.draft_output_dir = base / _text(draft["output_dir"], "draft.output_dir")
    if draft.get("link_scheme") is not None:
        settings.link_scheme = parse_scheme(_text(draft["link_scheme"], "draft.link_scheme"), "draft.link_scheme")

    settings.label_sets = _label_sets(raw.get("labels"))

    stages = {}
    for key, value in (raw.get("stages") or {}).items():
        if not isinstance(key, str):
            raise ConfigError(f"stages の {key!r} が数に読まれました。'{key}': のように ' ' で囲みます"
                              "（01 は 1 になり、フォルダ名と合わなくなるため）")
        if value is not None and _text(value, f"stages.{key}"):
            stages[key.strip()] = _text(value, f"stages.{key}")
    settings.stages = stages
    return settings
