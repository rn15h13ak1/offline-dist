"""設定ファイル (config.yaml) の読み込みと検証。

同じ種類のツールに揃えて YAML にする。知らない節・項目は、似た名前を示してまとめて止める
(書き間違えた項目が黙って無視されると、効いていない設定に気付けないため)。

Windows のパスは、引用符なしか ' ' で囲めばそのまま書ける (`'\\\\server\\share'`)。
" " で囲むと `\\` が特別な意味になり、別のパスになるか読めなくなる。
"""
from __future__ import annotations

import difflib
import os
import re
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, Dict, List, Optional

import yaml

CONFIG_NAME = "config.yaml"
EXAMPLE_NAME = "config.example.yaml"

ONLY_CHOICES = ("both", "files", "dirs")

# 既定の除外の型。Office の一時ファイル・OS が作るもの・版管理のフォルダ
DEFAULT_EXCLUDES = (
    "~$*", "Thumbs.db", "desktop.ini", ".git", ".svn", "$RECYCLE.BIN",
    "System Volume Information", ".DS_Store", "~*.tmp",
)

# 節ごとに書ける項目。stages は名前を自由に書けるので、ここに無い
KNOWN_KEYS = {
    "scan": ("roots", "root_sets", "max_depth", "only", "extensions", "exclude", "default_excludes", "output_dir"),
    "sheet": ("stage_depth",),
    "draft": ("title", "output_dir", "link_scheme"),
    "stages": None,
}
# scan.roots の 1 つを「path: 起点」の形で書くときに書ける項目
ROOT_KEYS = ("path", "max_depth")
# 別の節へ移した項目。古い設定ファイルに、移った先を示す
MOVED_KEYS = {"draft.stage_depth": "sheet.stage_depth"}


@dataclass
class RootSet:
    """名前を付けた起点の組 (scan.root_sets の 1 つ)。"""
    roots: List[str] = field(default_factory=list)
    # 起点ごとの深さの上限。キーは root_key で揃えた起点
    depths: Dict[str, int] = field(default_factory=dict)


class ConfigError(Exception):
    """設定の誤り。入口は終了コード 2 で止まる。"""


@dataclass
class Settings:
    roots: List[str] = field(default_factory=list)
    max_depth: Optional[int] = None
    # 起点ごとの深さの上限。キーは root_key で揃えた起点
    root_depths: Dict[str, int] = field(default_factory=dict)
    root_sets: Dict[str, RootSet] = field(default_factory=dict)
    only: str = "both"
    extensions: List[str] = field(default_factory=list)
    exclude: List[str] = field(default_factory=list)
    default_excludes: bool = True
    scan_output_dir: Optional[Path] = None
    stage_depth: int = 1
    title: str = "資料一覧"
    draft_output_dir: Optional[Path] = None
    link_scheme: str = "file"
    stages: Dict[str, str] = field(default_factory=dict)
    path: Optional[Path] = None

    def roots_of(self, root_set: Optional[str]) -> List[str]:
        """起点の組の起点。root_set が None なら scan.roots。"""
        return list(self.root_sets[root_set].roots if root_set is not None else self.roots)

    def depth_for(self, root: str, root_set: Optional[str] = None) -> Optional[int]:
        """その起点の深さの上限。起点に書いていなければ scan.max_depth。

        root_set を渡せばその組の、無ければ scan.roots の起点ごとの深さを見る。
        """
        depths = self.root_sets[root_set].depths if root_set is not None else self.root_depths
        return depths.get(root_key(root), self.max_depth)

    @property
    def excludes(self) -> List[str]:
        return (list(DEFAULT_EXCLUDES) if self.default_excludes else []) + list(self.exclude)


# 下書きのリンクに使えないスキーム。開いたときにスクリプトが動くか、ファイルを開くものでない
BLOCKED_SCHEMES = ("javascript", "vbscript", "data", "about", "http", "https", "mailto")
_SCHEME_RE = re.compile(r"\A[A-Za-z][A-Za-z0-9+.-]*\Z")


def root_key(root: str) -> str:
    """起点を比べるための形。末尾の区切りを外し、Windows では大小文字と / \\ の違いを見ない。"""
    return os.path.normcase(root.rstrip("\\/") or root)


def parse_scheme(value: str, where: str) -> str:
    """リンクのスキーム。末尾の `:` や `://` は外す。小文字にそろえる。"""
    scheme = value.strip().rstrip("/").rstrip(":").lower()
    if not _SCHEME_RE.match(scheme) or len(scheme) < 2:
        raise ConfigError(f"{where} はスキームの名前（file・lw など）で書きます: {value}")
    if scheme in BLOCKED_SCHEMES:
        raise ConfigError(f"{where} に {scheme} は使えません（ファイルを開くスキームを書きます）: {value}")
    return scheme


def parse_extensions(value: str) -> List[str]:
    """`.xlsx, docx PDF` を ['.xlsx', '.docx', '.pdf'] にする。"""
    found = []
    for word in value.replace(",", " ").replace("、", " ").split():
        ext = word.lower()
        if not ext.startswith("."):
            ext = "." + ext
        if ext not in found:
            found.append(ext)
    return found


def _suggest(word: str, choices) -> str:
    names = sorted(str(c) for c in choices)
    for name in names:
        if name.lower() == str(word).lower():
            return f"（{name} の書き間違いではありませんか）"
    close = difflib.get_close_matches(str(word), names, n=1, cutoff=0.6)
    return f"（{close[0]} の書き間違いではありませんか）" if close else f"（書ける項目: {', '.join(names)}）"


def _read_yaml(path: Path) -> Dict[str, Any]:
    try:
        text = path.read_text(encoding="utf-8-sig")
    except UnicodeDecodeError:
        raise ConfigError(f"設定ファイルを UTF-8 として読めません: {path}\n"
                          "  → メモ帳で開き、「名前を付けて保存」で文字コードを「UTF-8」にして保存し直してください") from None
    except OSError as e:
        raise ConfigError(f"設定ファイルを読めません: {path}（{e}）") from None
    try:
        raw = yaml.safe_load(text)
    except yaml.YAMLError as e:
        raise ConfigError(f"設定ファイルを YAML として読めません: {path}\n  {e}\n"
                          "  → 示された行の字下げ（空白の数）と、「:」の後の空白を確かめてください。"
                          "Windows のパスは \" \" でなく ' ' で囲みます。* で始まる値（*.bak）も ' ' で囲みます") from None
    if raw is None:
        return {}
    if not isinstance(raw, dict):
        raise ConfigError(f"設定ファイルの形が不正です: {path}（scan: などの節を並べる形で書きます。{EXAMPLE_NAME} を参考にしてください）")
    return raw


def _check_keys(raw: Dict[str, Any]) -> None:
    """知らない節・項目を、まとめて 1 つの ConfigError にする (1 つ直すたびに次が出るより直しやすい)。"""
    problems = []
    for section, value in raw.items():
        if section not in KNOWN_KEYS:
            problems.append(f"{section} は知らない節です{_suggest(section, KNOWN_KEYS)}")
            continue
        if value is None:
            continue
        if not isinstance(value, dict):
            problems.append(f"{section}: の形が不正です（項目を字下げして「項目: 値」で並べます）: {value!r}")
            continue
        keys = KNOWN_KEYS[section]
        if keys is None:
            continue
        for key in value:
            if f"{section}.{key}" in MOVED_KEYS:
                problems.append(f"{section}.{key} は {MOVED_KEYS[section + '.' + key]} に移りました"
                                "（段階をフォルダの位置で埋めるのは、Excel を作るときになりました）")
            elif key not in keys:
                problems.append(f"{section}.{key} は知らない項目です{_suggest(key, keys)}")
    if problems:
        raise ConfigError("\n".join(problems) + f"\n  → 書き間違いなら直し、要らない項目なら消してください（{EXAMPLE_NAME} に書ける項目があります）")


def _text(value: Any, where: str) -> str:
    """文字の値。数や真偽値は書いたとおりの文字にせず止める (01 が 1 になるなど、書いた形と変わるため)。"""
    if not isinstance(value, str):
        raise ConfigError(f"{where} は文字で書きます（数や yes・no に読まれるときは ' ' で囲みます）: {value!r}")
    if any(ord(ch) < 0x20 for ch in value):
        raise ConfigError(f"{where} に改行やタブが入っています: {value!r}\n"
                          "  → \" \" で囲んだ \\ が特別な意味に読まれています。' ' で囲むか、引用符を外してください")
    return value.strip()


def _texts(value: Any, where: str) -> List[str]:
    """文字の並び。1 つだけなら並びにせず書いてもよい。"""
    if value is None:
        return []
    items = value if isinstance(value, list) else [value]
    return [t for t in (_text(v, f"{where}[{i}]" if isinstance(value, list) else where)
                        for i, v in enumerate(items)) if t]


def _positive(value: Any, where: str, *, minimum: int = 1) -> int:
    if isinstance(value, bool) or not isinstance(value, int) or value < minimum:
        raise ConfigError(f"{where} は {minimum} 以上の整数で書きます: {value!r}")
    return value


def _roots(value: Any, name: str = "scan.roots") -> tuple:
    """起点の並びを (起点の並び, 起点ごとの深さ) にする。1 つは文字か「path: 起点」と max_depth の形で書く。"""
    if value is None:
        return [], {}
    items = value if isinstance(value, list) else [value]
    roots: List[str] = []
    depths: Dict[str, int] = {}
    for i, item in enumerate(items):
        where = f"{name}[{i}]" if isinstance(value, list) else name
        if not isinstance(item, dict):
            root = _text(item, where)
            if root:
                roots.append(root)
            continue
        unknown = [k for k in item if k not in ROOT_KEYS]
        if unknown:
            raise ConfigError(f"{where}.{unknown[0]} は知らない項目です{_suggest(unknown[0], ROOT_KEYS)}")
        root = _text(item.get("path"), f"{where}.path") if item.get("path") is not None else ""
        if not root:
            raise ConfigError(f"{where} に path: が無いか、空です（「- path: 'S:\\projects'」の形で書きます）")
        roots.append(root)
        if item.get("max_depth") is None:
            continue
        depth = _positive(item["max_depth"], f"{where}.max_depth")
        key = root_key(root)
        if depths.get(key, depth) != depth:
            raise ConfigError(f"{where} の起点に、違う max_depth が 2 つ書かれています: {root}")
        depths[key] = depth
    return roots, depths


def _root_sets(value: Any) -> Dict[str, RootSet]:
    """scan.root_sets (名前: 起点の並び) を読む。名前は文字で、組は空にしない。"""
    if value is None:
        return {}
    if not isinstance(value, dict):
        raise ConfigError("scan.root_sets は「名前:」の下に起点を字下げして並べます"
                          f"（scan.roots と同じ書き方）: {value!r}")
    sets: Dict[str, RootSet] = {}
    for key, roots in value.items():
        if not isinstance(key, str) or not key.strip():
            raise ConfigError(f"scan.root_sets の名前 {key!r} は文字で書きます（数や yes・no に読まれるときは ' ' で囲みます）")
        name = key.strip()
        found, depths = _roots(roots, f"scan.root_sets.{name}")
        if not found:
            raise ConfigError(f"scan.root_sets.{name} に起点がありません（「- 」に続けて 1 行に 1 つ書きます）")
        sets[name] = RootSet(found, depths)
    return sets


def load_config(path: Optional[Path]) -> Settings:
    """設定を読む。path が None なら既定 (何も書いていない設定) を返す。"""
    settings = Settings()
    if path is None:
        return settings
    path = Path(path)
    if not path.is_file():
        raise ConfigError(f"設定ファイルがありません: {path}")
    raw = _read_yaml(path)
    _check_keys(raw)

    base = path.resolve().parent
    settings.path = path
    scan = raw.get("scan") or {}
    settings.roots, settings.root_depths = _roots(scan.get("roots"))
    settings.root_sets = _root_sets(scan.get("root_sets"))
    if scan.get("max_depth") is not None:
        settings.max_depth = _positive(scan["max_depth"], "scan.max_depth")
    if scan.get("only") is not None:
        only = _text(scan["only"], "scan.only")
        if only not in ONLY_CHOICES:
            raise ConfigError(f"scan.only は {' / '.join(ONLY_CHOICES)} のどれかです: {only!r}")
        settings.only = only
    settings.extensions = parse_extensions(" ".join(_texts(scan.get("extensions"), "scan.extensions")))
    settings.exclude = _texts(scan.get("exclude"), "scan.exclude")
    if scan.get("default_excludes") is not None:
        if not isinstance(scan["default_excludes"], bool):
            raise ConfigError(f"scan.default_excludes は true か false で書きます: {scan['default_excludes']!r}")
        settings.default_excludes = scan["default_excludes"]
    if scan.get("output_dir") is not None and _text(scan["output_dir"], "scan.output_dir"):
        settings.scan_output_dir = base / _text(scan["output_dir"], "scan.output_dir")

    sheet = raw.get("sheet") or {}
    if sheet.get("stage_depth") is not None:
        settings.stage_depth = _positive(sheet["stage_depth"], "sheet.stage_depth")

    draft = raw.get("draft") or {}
    if draft.get("title") is not None and _text(draft["title"], "draft.title"):
        settings.title = _text(draft["title"], "draft.title")
    if draft.get("output_dir") is not None and _text(draft["output_dir"], "draft.output_dir"):
        settings.draft_output_dir = base / _text(draft["output_dir"], "draft.output_dir")
    if draft.get("link_scheme") is not None:
        settings.link_scheme = parse_scheme(_text(draft["link_scheme"], "draft.link_scheme"), "draft.link_scheme")

    stages = {}
    for key, value in (raw.get("stages") or {}).items():
        if not isinstance(key, str):
            raise ConfigError(f"stages の {key!r} が数に読まれました。'{key}': のように ' ' で囲みます"
                              "（01 は 1 になり、フォルダ名と合わなくなるため）")
        if value is not None and _text(value, f"stages.{key}"):
            stages[key.strip()] = _text(value, f"stages.{key}")
    settings.stages = stages
    return settings
