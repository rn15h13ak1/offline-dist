# path_lister を AI が使うときの手引き

ファイルサーバーのフォルダを辿ってフルパスの一覧（CSV）を作り、それを組み立ての列を付けた Excel にし、人が Excel で選んだ行から
リンク集（catalog）の下書き（.md）を作る。
ファイルサーバーは読むだけで、ファイルを作る・変える・消すことは無い。

詳しい説明は [README.md](README.md) にある。

## 動かし方

作業フォルダをこのフォルダ（`AGENTS.md` のあるフォルダ）にして、`path_lister.py` を `python` で直接動かす（`python` が無ければ `py -3`）。

- 小コマンドは 3 つ。`scan`（一覧の CSV を作る）・`sheet`（CSV から Excel を作る）・`draft`（人が選んだ Excel から下書きを作る）
- 設定ファイルは無くても動く。あれば、既定でこのフォルダの `config.yaml` を読む（作業フォルダの `config.yaml` は見ない）。別のファイルは `-c <パス>`
- `config.yaml` を作るときは、ひな形の `config.example.yaml` を写す（ひな形そのものは直さない）。辿る起点は人に聞いて書く。
  Windows のパスは `' '` で囲む（`" "` では `\` が特別な意味になる）
- 設定に知らない項目（書き間違い）があると、終了コード `2` で止まり、似た項目の名前を示す。示された名前に直す
- Python は 3.9 以上と、ライブラリ PyYAML と openpyxl が要る。入っていなければ、入れるコマンドを示して終了コード `2` で止まる。
  入れるのは人に確かめてから（示されたコマンドを人に見せる）
- メニュー（`menu.bat`・`menu.py`）は人が番号を選ぶためのもの。入力を待って止まるので、AI は使わない
- 出力が文字化けして読めないときは、Python を UTF-8 モードで動かす（`python -X utf8 path_lister.py ...`）。ツールの振る舞いは変わらない

## 許可なしで動かしてよいコマンド

どれもファイルサーバーへは書き込まない。

| コマンド | すること |
| --- | --- |
| `python path_lister.py scan <起点> --only dirs --max-depth 2` | フォルダだけを浅く辿る。どこに何があるかを先に見るときに使う |
| `python path_lister.py scan --root-set <名前> --no-progress` | 設定の `scan.root_sets` に名前を付けて書いた起点の組を辿る |
| `python path_lister.py scan <起点> --no-progress` | 起点の下をすべて辿り、`out/` に CSV を書き出す |
| `python path_lister.py scan <起点> --ext .xlsx,.docx --exclude "*.bak"` | 拡張子で絞り、除外の型を足して辿る |
| `python path_lister.py sheet <CSV>` | CSV の隣に、組み立ての列（採用・まとまり・段階・項目・補足）と親フォルダ・リンクの列を付けた Excel を作る |
| `python path_lister.py sheet <CSV> --stage-depth 2` | 段階にするフォルダの深さを変えて Excel を作る（既にあるときは `-o` で別の名前にする） |
| `python path_lister.py draft <Excel>` | 人が選んだ Excel から、`out/draft-YYYYMMDD-HHMMSS/` に下書きを作る |
| `python path_lister.py draft <Excel> --title 資料一覧` | 親の題を変える |
| `python path_lister.py draft <Excel> --link-scheme lw` | リンクのスキームを `file` から変える（独自のスキームを入れた環境で、人に頼まれたとき） |
| `python path_lister.py --version` | 版を `path_lister <版>` の形で出す。不具合を人に伝えるときに添える |

- 大きい共有では時間がかかる。1,000 行ごとに標準エラーに進み具合が出る。`--no-progress` で止められる
- **どの行を下書きにするか、どう組み立てるかは人が決める。** `sheet` の Excel をそのまま `draft` に渡さず、人に Excel で選んでもらう
  （`採用` の列に印を付けるか、要らない行を消す。要れば `まとまり`・`段階`・`項目`・`補足` の列を直す。
  `まとまり`・`段階` が空の行は使われない）。
  人に頼まれて書き込むときは、書き方を人に確かめてから Excel を写して直し、元の Excel は残す
- `まとまり`・`段階`・`項目` の呼び名は、設定の `labels` で変えられる（Excel の列の見出しと画面の言葉が変わる）。
  列が無いと `draft` が止まったら、`sheet` と同じ設定で動かしているかを確かめる

**ただし、手元にファイルを書く。** 出力先のことは下の「できるファイル」にある。

## 終了コード

| コード | 意味 | すること |
|---|---|---|
| `0` | 済み | 出力の「出力」の行のパスを人に伝える |
| `1` | 読めない所があった（`scan`。CSV は最後まで書き出した） | `警告:` の行と、CSV の種別「エラー」の行の数を人に伝える。権限の問題なら直すのは人 |
| `2` | 引数・設定の誤り、起点が無い、CSV・Excel が無い・読めない・列が足りない、出力先に既にファイルがある・書けない、または Python が古い | 出力の `エラー:` で始まる部分をそのまま人に見せる。書き間違いなら直して動かし直してよい。既にあるファイルは消さず、別の出力先を指定する |
| `3` | 予期しないエラー | 出力のトレースバックを人に見せる |
| `130` | 中断した（Ctrl+C か、外から止められた） | そこまでの CSV は残る。人に伝える。動かし直すかは人が決める |

## できるファイル

| ファイル | 中身 |
|---|---|
| `out/paths-YYYYMMDD-HHMMSS.csv` | `scan` の一覧。UTF-8（BOM 付き）。`-o` で場所を変えられる |
| `out/paths-YYYYMMDD-HHMMSS.xlsx` | `sheet` の Excel。CSV の隣に同じ名前で作る。`-o` で場所を変えられる |
| `out/draft-YYYYMMDD-HHMMSS/資料一覧.md` | `draft` の親（`type: catalog`）。`-o` で場所を、`--title` で名前を変えられる |
| `out/draft-YYYYMMDD-HHMMSS/parts/<まとまり>.md` | `draft` の子（`type: fragment`） |

- 下書きは docmold（0.16.1 以上）の `catalog` で HTML にする。それより前の docmold ではリンクが消える
- `out/` は、設定の `output_dir` で変えられる（相対パスは設定ファイルのある所から）
- どれも既にあるファイルは上書きせず、終了コード `2` で止まる

## 気を付けること

- **ツールのファイル（`.py`・`.bat`・この文書）を直さない。** 直してよいのは、ひな形から作った `config.yaml` だけ
- 作られた CSV・Excel・下書きは、人に聞かずに消さない
- 取り消しの道具（`undo_changes.bat`）と更新の道具（`update.bat`）は、AI が動かさない。要りそうなら人に伝える
- CSV・Excel・下書きにはファイルサーバーのパスと名前が並ぶ。外へ送らない
