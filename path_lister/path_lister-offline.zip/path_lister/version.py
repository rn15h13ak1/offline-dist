"""path_lister の版。CHANGELOG の最新の版と同じにする。"""

__version__ = "0.12.0"
