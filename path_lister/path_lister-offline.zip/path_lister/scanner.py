"""フォルダを辿って、フルパスの一覧 (CSV) を 1 行ずつ書き出す。

辿り方:

- `os.walk` でなく `os.scandir` を直接使う。Windows では列挙の時点でサイズと更新日時が返るので、
  ファイルサーバーでも stat を呼び直さずに済む
- 再帰でなく自前のスタックで辿る。深い木でも再帰の上限に当たらない
- スタックには未処理のエントリを積み、フォルダの行の直後にその中身が来る順 (行き順) にする。
  1 つのフォルダの中は名前 (casefold) の順に並べる
- シンボリックリンクとジャンクションは辿らない (循環を防ぐ)。種別を「リンク」として書く
- 読めないフォルダは、種別「エラー」の行を足して先へ進む。全体は止めない

CSV には辿って分かることだけを書く。下書きの組み立てを書き込む列は、CSV から Excel を作るとき
(sheet.py) に足す。
"""
from __future__ import annotations

import csv
import fnmatch
import os
import re
from dataclasses import dataclass, field, replace
from datetime import datetime
from typing import Callable, Dict, Iterable, Iterator, List, Optional, TextIO

# 辿って分かること。walk はこの順の list を返し、CSV の列もこの順にする
COLUMNS = ("種別", "深さ", "フルパス", "親フォルダ", "名前", "拡張子", "サイズ", "更新日時", "リンク", "エラー")

KIND_FILE = "ファイル"
KIND_DIR = "フォルダ"
KIND_LINK = "リンク"
KIND_ERROR = "エラー"

# 進み具合を出す間隔 (行)
PROGRESS_INTERVAL = 1000

# Windows のジャンクション (と、それに類する再解析ポイント)。3.9 には DirEntry.is_junction が無い
FILE_ATTRIBUTE_REPARSE_POINT = 0x400

# Windows でパスの長さの上限 (260) に当たらないよう、\\?\ を付けて読み始める長さ。
# フォルダの上限は 248 (8.3 形式の名前の分を引く)
LONG_PATH = 248

IS_WINDOWS = os.name == "nt"


class ExcludeMatcher:
    """除外の型を事前にコンパイルして繰り返し使う。

    `/` を含まない型はファイル名・フォルダ名に対して照合する (`*.tmp`, `~$*` など)。
    `/` を含む型は起点からの相対パス全体 (`/` 区切り) に対して照合する (`作業中/*` など)。

    `fnmatch.fnmatch` をエントリ×型の回数だけ呼ぶと、内部で `os.path.normcase` が照合のたびに走り、
    列挙の時間の多くを占める。型は走査中に変わらないので、1 本の正規表現にまとめて 1 回だけ組み立てる。
    大小文字の扱いは `fnmatch` と同じ (`normcase` 経由なので Windows では無視、POSIX では区別)。
    """

    __slots__ = ("_name_re", "_path_re")

    def __init__(self, patterns: Iterable[str]) -> None:
        names, paths = [], []
        for p in patterns:
            (paths if "/" in p else names).append(p)
        self._name_re = self._compile(names)
        self._path_re = self._compile(paths)

    @staticmethod
    def _compile(patterns: List[str]):
        if not patterns:
            return None
        return re.compile(
            "|".join(f"(?:{fnmatch.translate(os.path.normcase(p))})" for p in patterns)
        )

    def __bool__(self) -> bool:
        return self._name_re is not None or self._path_re is not None

    def matches(self, name: str, relpath: str) -> bool:
        if self._name_re is not None and self._name_re.match(os.path.normcase(name)):
            return True
        if self._path_re is not None and self._path_re.match(os.path.normcase(relpath)):
            return True
        return False


# --------------------------------------------------------------------------- リンク用の URL

_DRIVE_RE = re.compile(r"^([A-Za-z]):[\\/]?")
_UNSAFE_ASCII = frozenset(
    chr(c) for c in range(128)
    if not (chr(c).isascii() and (chr(c).isalnum() or chr(c) in "-._~/"))
)


def strip_long_prefix(path: str) -> str:
    """`\\\\?\\UNC\\server\\share` を `\\\\server\\share` に、`\\\\?\\S:\\` を `S:\\` に戻す。"""
    if path.startswith("\\\\?\\UNC\\"):
        return "\\\\" + path[8:]
    if path.startswith("\\\\?\\"):
        return path[4:]
    return path


def _quote(text: str) -> str:
    """ASCII の英数字と `-._~/` 以外の ASCII を %XX にする。ASCII でない文字 (日本語) はそのまま。

    日本語まで %XX にすると、catalog の HTML でリンクにかざしたときに読めない。ブラウザは
    ASCII でない文字を自分で符号化して開く。空白・`#`・`%`・`(` などは残すとリンクが壊れる。
    """
    return "".join(f"%{ord(ch):02X}" if ch in _UNSAFE_ASCII else ch for ch in text)


def to_url(path: str, scheme: str = "file") -> str:
    """フルパスを、catalog に書くリンク (`file:` の URL) にする。

    scheme を変えると、`file` の所だけを変えた形にする (`lw://server/share/x`)。
    エクスプローラーで開くための独自のスキームを入れた環境のため。

    - ドライブ `S:\\a b\\c.xlsx` は `file:///S:/a%20b/c.xlsx`
    - UNC `\\\\server\\share\\x` は `file://server/share/x`。スキームの無い `//server/share/x` にしないのは、
      変換する側がスキームの無いリンクを相対リンクとして扱い、書き換えたり警告したりするため
    - POSIX のパス `/a/b` は `file:///a/b` (開発機とテストのため)
    """
    path = strip_long_prefix(path)
    m = _DRIVE_RE.match(path)
    if m:
        rest = path[m.end():].replace("\\", "/")
        return f"{scheme}:///{m.group(1).upper()}:/{_quote(rest)}"
    if path.startswith("\\\\") or (path.startswith("//") and not path.startswith("///")):
        rest = path[2:].replace("\\", "/")
        return f"{scheme}://{_quote(rest)}"
    return f"{scheme}://" + _quote(path if path.startswith("/") else "/" + path)


# --------------------------------------------------------------------------- 走査


@dataclass
class ScanStats:
    files: int = 0
    dirs: int = 0
    links: int = 0
    errors: int = 0
    rows: int = 0
    error_samples: List[str] = field(default_factory=list)


@dataclass
class ScanOptions:
    max_depth: Optional[int] = None
    only: str = "both"          # both / files / dirs
    extensions: List[str] = field(default_factory=list)
    excludes: List[str] = field(default_factory=list)


def _long(path: str) -> str:
    """Windows で長いパスを読むときに \\\\?\\ を付ける。表示と CSV には付けない形を使う。"""
    if not IS_WINDOWS or len(path) < LONG_PATH or path.startswith("\\\\?\\"):
        return path
    path = os.path.abspath(path)
    if path.startswith("\\\\"):
        return "\\\\?\\UNC\\" + path[2:]
    return "\\\\?\\" + path


def _is_reparse_point(de: os.DirEntry) -> bool:
    try:
        attrs = getattr(de.stat(follow_symlinks=False), "st_file_attributes", 0)
    except OSError:
        return False
    return bool(attrs & FILE_ATTRIBUTE_REPARSE_POINT)


def _sorted_entries(path: str) -> List[os.DirEntry]:
    with os.scandir(_long(path)) as it:
        entries = list(it)
    entries.sort(key=lambda de: (de.name.casefold(), de.name))
    return entries


def stem(name: str) -> str:
    """拡張子を除いた名前。先頭の「.」だけのもの (`.gitignore`) はそのまま。"""
    dot = name.rfind(".")
    return name[:dot] if dot > 0 else name


def _extension(name: str) -> str:
    ext = os.path.splitext(name)[1]
    return ext.lower()


def _mtime(st) -> str:
    try:
        return datetime.fromtimestamp(st.st_mtime).strftime("%Y-%m-%d %H:%M:%S")
    except (OverflowError, OSError, ValueError):
        return ""


def walk(root: str, options: ScanOptions) -> Iterator[list]:
    """起点の下を辿り、CSV の 1 行 (COLUMNS の順の list) を順に返す。

    起点そのものの行は出さない (深さ 1 が起点の直下)。
    """
    excluded = ExcludeMatcher(options.excludes)
    kinds_dir = options.only in ("both", "dirs")
    kinds_file = options.only in ("both", "files")
    root = root.rstrip("\\/") or root
    sep = "\\" if ("\\" in root or _DRIVE_RE.match(root)) else os.sep

    def join(parent: str, name: str) -> str:
        return parent + name if parent.endswith(("\\", "/")) else parent + sep + name

    def error_row(path: str, parent: str, name: str, depth: int, message: str) -> list:
        return [KIND_ERROR, depth, path, parent, name, "", "", "", to_url(path), message]

    # スタックの要素: (親のフルパス, 起点からの相対パス (/ 区切り) の親, 深さ, エントリ)
    stack: List[tuple] = []

    def push_children(path: str, rel: str, depth: int) -> Optional[list]:
        try:
            entries = _sorted_entries(path)
        except OSError as e:
            name = os.path.basename(path) if depth else path
            parent = os.path.dirname(path) if depth else ""
            return error_row(path, parent, name, depth, f"フォルダを読めません: {type(e).__name__}: {e.strerror or e}")
        for de in reversed(entries):
            stack.append((path, rel, depth + 1, de))
        return None

    err = push_children(root, "", 0)
    if err is not None:
        yield err
        return

    while stack:
        parent, prel, depth, de = stack.pop()
        name = de.name
        rel = f"{prel}/{name}" if prel else name
        if excluded.matches(name, rel):
            continue
        path = join(parent, name)
        try:
            is_dir = de.is_dir()
            if de.is_symlink() or (IS_WINDOWS and is_dir and _is_reparse_point(de)):
                # リンクとジャンクションは辿らない。リンク先がファイルでも、リンクとして書く
                if kinds_dir:
                    st = de.stat(follow_symlinks=False)
                    yield [KIND_LINK, depth, path, parent, name, "", "", _mtime(st), to_url(path), ""]
                continue
            if is_dir:
                if kinds_dir:
                    yield [KIND_DIR, depth, path, parent, name, "", "", _mtime(de.stat()), to_url(path), ""]
                if options.max_depth is None or depth < options.max_depth:
                    err = push_children(path, rel, depth)
                    if err is not None:
                        yield err
                continue
            if not kinds_file:
                continue
            ext = _extension(name)
            if options.extensions and ext not in options.extensions:
                continue
            st = de.stat()
            yield [KIND_FILE, depth, path, parent, name, ext, st.st_size, _mtime(st), to_url(path), ""]
        except OSError as e:
            yield error_row(path, parent, name, depth, f"{type(e).__name__}: {e.strerror or e}")


def write_csv(stream: TextIO, roots: List[str], options: ScanOptions,
              on_progress: Optional[Callable[[ScanStats], None]] = None,
              on_error: Optional[Callable[[list], None]] = None,
              max_depths: Optional[Dict[str, Optional[int]]] = None) -> ScanStats:
    """起点を順に辿り、見出しの行の後に 1 行ずつ書く。進み具合の間隔で flush する。

    max_depths は起点ごとの深さの上限 (キーは roots に渡した起点)。無い起点は options.max_depth で辿る。

    中断 (KeyboardInterrupt) は呼び出し側へそのまま上げる。それまでに書いた行は stream に残る。
    """
    stats = ScanStats()
    writer = csv.writer(stream, lineterminator="\r\n")
    writer.writerow(COLUMNS)
    for root in roots:
        root_options = options
        if max_depths and root in max_depths:
            root_options = replace(options, max_depth=max_depths[root])
        for row in walk(root, root_options):
            writer.writerow(row)
            stats.rows += 1
            kind = row[0]
            if kind == KIND_FILE:
                stats.files += 1
            elif kind == KIND_DIR:
                stats.dirs += 1
            elif kind == KIND_LINK:
                stats.links += 1
            else:
                stats.errors += 1
                if on_error is not None:
                    on_error(row)
            if stats.rows % PROGRESS_INTERVAL == 0:
                stream.flush()
                if on_progress is not None:
                    on_progress(stats)
    stream.flush()
    return stats


def default_csv_name(now: Optional[datetime] = None) -> str:
    return "paths-" + (now or datetime.now()).strftime("%Y%m%d-%H%M%S") + ".csv"


def open_csv(path: str) -> TextIO:
    """Excel でそのまま開けるよう、UTF-8 (BOM 付き) で書く。既にあるファイルは上書きしない。"""
    return open(path, "x", encoding="utf-8-sig", newline="")

