"""
設定ファイルと API キーの読み込み
=================================
5 つのツールで同じ意味のものだけを置く。設定ファイルの読み込み（UTF-8・BOM・YAML の書き損じを
案内にする）、backlog: の節の取り出しと例の値の扱い、API キーの探し方と、どこから読んだか。

ツールごとの節の確かめ、知らない項目の扱い、設定ファイルを探す場所、止めるときの終了コードは
各ツールに残す。ここでは ConfigError を送出するだけで、表示も終了もしない。

API キーは、環境変数 BACKLOG_API_KEY → 設定ファイルの backlog.api_key → .env の順に探す。
.env は、設定ファイルの隣 → ツールのフォルダ → 作業フォルダの順に探す。

ほかの部品と書き方を揃える（f 文字列・注釈を使わない）。PyYAML は読むときに初めて import する。
入っていないときの案内は、各ツールの入口が出す。
"""

import os
from pathlib import Path

API_KEY_ENV = "BACKLOG_API_KEY"

# 設定ファイルの例（config.example.yaml など）の値。コピーしたまま残っていても、書いていないものとして扱う
PLACEHOLDERS = frozenset((
    "yourcompany.backlog.com",
    "YOUR_API_KEY_HERE",
    "YOUR_PROJECT_KEY",
))


class ConfigError(Exception):
    """設定の誤り。人が直すもの。どう止めるか（終了コード）は各ツールが決める"""


def read_text_utf8(path, what):
    """
    UTF-8 のテキストを読む。BOM 付きでもよい（メモ帳の「UTF-8 (BOM 付き)」）。

    Windows では、メモ帳の ANSI（CP932）や PowerShell 5 の `echo ... > .env`（UTF-16）で
    作ったファイルがありうる。トレースバックにせず、保存し直す手順を示して止める。
    """
    try:
        return Path(path).read_text(encoding="utf-8-sig")
    except UnicodeDecodeError:
        raise ConfigError(
            "{}を UTF-8 として読めません: {}\n"
            "  → メモ帳で開き、「名前を付けて保存」で文字コードを「UTF-8」にして保存し直してください".format(what, path)
        ) from None


def find_config(explicit, candidates, example="config.example.yaml"):
    """
    設定ファイルの場所。explicit（--config）があればそれ、無ければ candidates の最初にあるもの。

    探す場所はツールごとに違う（作業フォルダを先に見るものと、スクリプトの隣だけのもの）ので、
    呼ぶ側が渡す。
    """
    if explicit:
        path = Path(explicit)
        if not path.is_file():
            raise ConfigError("設定ファイルが見つかりません: {}（{} をコピーして作ってください）".format(path, example))
        return path
    for candidate in candidates:
        if Path(candidate).is_file():
            return Path(candidate)
    places = "".join("\n    {}".format(c) for c in candidates)
    raise ConfigError(
        "設定ファイル config.yaml が見つかりません。{} をコピーして作ってください"
        "（--config で場所を指定することもできます）。探した場所:{}".format(example, places)
    )


def load_config(path, example="config.example.yaml"):
    """
    設定ファイルを読み、辞書で返す。中の項目は確かめない（各ツールが確かめる）。

    無い・UTF-8 でない・YAML の書き損じ・空・形が不正（辞書でない）は、ConfigError にする。
    """
    import yaml

    path = Path(path)
    if not path.is_file():
        raise ConfigError("設定ファイルが見つかりません: {}（{} をコピーして作ってください）".format(path, example))
    text = read_text_utf8(path, "設定ファイル")
    try:
        config = yaml.safe_load(text)
    except yaml.YAMLError as e:
        raise ConfigError(
            "設定ファイルを YAML として読めません: {}\n  {}\n"
            "  → 示された行の字下げ（空白の数）と、「:」の後の空白を確かめてください。"
            "値に「:」や「#」を含むときは \"\" で囲みます".format(path, e)
        ) from None
    if config is None:
        raise ConfigError("設定ファイルが空です: {}（{} を参考に書いてください）".format(path, example))
    if not isinstance(config, dict):
        raise ConfigError(
            "設定ファイルの形が不正です: {}（「backlog:」などの節を並べる形で書いてください。"
            "{} を参考にしてください）".format(path, example)
        )
    return config


def backlog_section(config):
    """
    backlog: の節。無ければ空の辞書。辞書でなければ ConfigError。

    節が無いときにどう伝えるか（ほかの誤りとまとめて示すか）は、各ツールが決める。
    """
    section = config.get("backlog")
    if section is None:
        return {}
    if not isinstance(section, dict):
        raise ConfigError("設定ファイルの backlog: の節の形が不正です（「space_host: ...」などを字下げして並べます）")
    return section


def is_placeholder(value):
    return isinstance(value, str) and value.strip() in PLACEHOLDERS


def setting(section, key):
    """
    節の値を文字列で返す。無い・空・例の値のままは ""（書いていないものとして扱う）。
    """
    value = section.get(key)
    if value is None or is_placeholder(value):
        return ""
    return str(value).strip()


def missing_settings(section, keys):
    """keys のうち、書いていない（空・例の値のまま）もの"""
    return [key for key in keys if not setting(section, key)]


def read_dotenv(path):
    """
    .env の KEY=VALUE の行を読む。# で始まる行と空行は飛ばす。無ければ空の辞書。

    書き方の揺れを受け付ける: 先頭の `export `、値の前後の引用符、cmd で `echo 'KEY=値' > .env` と
    打って行全体が引用符に入ったもの、BOM 付き。UTF-8 でなければ ConfigError。
    """
    values = {}  # type: dict
    path = Path(path)
    if not path.is_file():
        return values
    for line in read_text_utf8(path, ".env ファイル").splitlines():
        line = line.strip()
        if len(line) >= 2 and line[0] == line[-1] and line[0] in "\"'":
            line = line[1:-1].strip()
        if not line or line.startswith("#") or "=" not in line:
            continue
        key, _, value = line.partition("=")
        key = key.strip()
        if key.startswith("export "):
            key = key[len("export "):].strip()
        value = value.strip()
        if len(value) >= 2 and value[0] == value[-1] and value[0] in "\"'":
            value = value[1:-1]
        values[key] = value
    return values


def dotenv_candidates(config_path=None, tool_dir=None, cwd=None):
    """
    .env を探す場所（同じ場所は 1 度だけ）。設定ファイルの隣 → ツールのフォルダ → 作業フォルダ。

    設定ファイルを別の場所に置いたとき、その隣の .env が読まれないと気付きにくいため、まずそこを見る。
    """
    places = []
    if config_path is not None:
        places.append(Path(config_path).resolve().parent)
    if tool_dir is not None:
        places.append(Path(tool_dir).resolve())
    places.append(Path(cwd if cwd is not None else os.getcwd()).resolve())
    seen = []
    for place in places:
        candidate = place / ".env"
        if candidate not in seen:
            seen.append(candidate)
    return seen


def locate_api_key(config_path=None, config_value=None, tool_dir=None, env=None, cwd=None):
    """
    (API キー, どこから読んだか)。環境変数 → 設定ファイルの値（config_value）→ .env の順に探す。
    例の値のままのものは、書いていないものとして扱う。

    環境変数を先に見るのは、設定ファイルを書き換えずに差し替えられるようにするため。そのぶん、
    別の用途で設定した BACKLOG_API_KEY が先に使われうる。どこから読んだかは、認証・権限のエラーの
    ときに、どこを直せばよいかを示すのに使う。見つからなければ、探した場所を示して ConfigError。
    """
    source = os.environ if env is None else env
    value = (source.get(API_KEY_ENV) or "").strip()
    if value and not is_placeholder(value):
        return value, "環境変数 {}".format(API_KEY_ENV)
    if isinstance(config_value, str) and config_value.strip() and not is_placeholder(config_value):
        where = "設定ファイル {} の backlog.api_key".format(config_path) if config_path else "設定ファイルの backlog.api_key"
        return config_value.strip(), where
    candidates = dotenv_candidates(config_path, tool_dir, cwd)
    without_key = []
    for path in candidates:
        value = (read_dotenv(path).get(API_KEY_ENV) or "").strip()
        if value and not is_placeholder(value):
            return value, "{} の {}".format(path, API_KEY_ENV)
        if path.is_file():
            without_key.append(path)
    message = (
        "API キーがありません。次のどれかに書いてください（上から順に探します）。\n"
        "  - 環境変数 {key}\n"
        "  - 設定ファイルの backlog.api_key\n"
        "  - 次のどれかの .env（{key}=... の行）".format(key=API_KEY_ENV)
    )
    message += "".join("\n      {}".format(path) for path in candidates)
    for path in without_key:
        # 書いたつもりなのに読めていないことに、気付けるように
        message += "\n  {} はありますが、{}=... の行が見つかりませんでした".format(path, API_KEY_ENV)
    raise ConfigError(message)


def api_key_source_line(source):
    """認証・権限のエラー（401・403）のときに添える 1 行。どこを直せばよいかが分かるように"""
    return "  使った API キー: {}".format(source)
