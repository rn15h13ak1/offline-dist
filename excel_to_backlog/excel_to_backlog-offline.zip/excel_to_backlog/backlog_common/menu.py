"""
対話メニューの部品
==================
各ツールの menu.py が使う、表示・入力・前回値の記憶・本体の起動。どのメニューを並べ、本体にどの引数を渡すかは、
各ツールの menu.py に残す。

- 終了コードはツールを起動する側（メニューを並べるランチャー）が見ているので変えない。
  正常に終了 0、入力の終わり（EOF）1、本体が見つからない 127、中断 130
- 画面の文字は CP932 に収める（Windows の日本語コンソールで落ちないように）
- 入口より先に読まれることがあるので、古い Python でも読める書き方にする（f 文字列・注釈を使わない）
"""

import json
import subprocess
import sys

WIDTH = 60

EXIT_OK = 0
EXIT_EOF = 1
EXIT_NOT_FOUND = 127
EXIT_INTERRUPTED = 130


# ===========================================================================
# 表示・入力
# ===========================================================================


def hr(char="="):
    print(char * WIDTH)


def print_menu(title, items, back_label="戻る", default=None, default_mark="既定"):
    """
    メニューを表示して選択番号を返す。0 = 戻る / 終了。
    default に番号を渡すと、空 Enter でその番号を選べる。default_mark は既定値の由来を示すラベル
    （前回の選択なら「前回」）。
    """
    while True:
        print()
        hr()
        print("  " + title)
        hr()
        for i, item in enumerate(items, 1):
            mark = " ←" + default_mark if default == i else ""
            print("  {}. {}{}".format(i, item, mark))
        hr("-")
        print("  0. " + back_label)
        hr()
        prompt = "番号を入力してください" + (" [Enter={}]: ".format(default) if default else ": ")
        choice = input(prompt).strip()
        if not choice and default:
            return default
        if choice == "0":
            return 0
        if choice.isdigit() and 1 <= int(choice) <= len(items):
            return int(choice)
        print("  ※ 無効な入力です。もう一度入力してください。")


def input_text(prompt, default="", validate=None, hint=""):
    """
    文字列を入力させる。空 Enter は default を採用する。
    default が無い状態で空 Enter を押した場合は None（戻る）を返す。
    validate を渡すと、通るまで hint を示して聞き直す。
    """
    suffix = " [Enter={}]".format(default) if default else "（空 Enter で戻る）"
    while True:
        answer = input("  {}{}: ".format(prompt, suffix)).strip()
        if not answer:
            return default or None
        if validate is None or validate(answer):
            return answer
        print("  ※ " + hint)


def confirm(prompt):
    """y/N で確認する。y / yes 以外はすべて「いいえ」"""
    return input("  {} [y/N]: ".format(prompt)).strip().lower() in ("y", "yes")


def clean_path(text):
    """ドラッグ＆ドロップで付く引用符や前後の空白を除く。"""
    text = text.strip()
    if len(text) >= 2 and text[0] == text[-1] and text[0] in "\"'":
        text = text[1:-1]
    return text.replace("\\ ", " ") if sys.platform != "win32" else text


def wait_enter():
    input("\n  Enter キーでメニューに戻ります...")


def show_result(text):
    """本体を動かした後の結果（終了コードなど）を区切り線の下に出す。"""
    print()
    hr("-")
    print("  " + text)


# ===========================================================================
# 前回値の記憶
# ===========================================================================


def load_history(path):
    """前回の選択を読む。無い・壊れている・形が違うときは空で続ける。"""
    try:
        with open(str(path), encoding="utf-8") as f:
            data = json.load(f)
        return data if isinstance(data, dict) else {}
    except (OSError, ValueError):
        return {}


def save_history(path, data):
    """選択を保存する。書けなくても実行は妨げない。"""
    try:
        with open(str(path), "w", encoding="utf-8") as f:
            json.dump(data, f, ensure_ascii=False, indent=2)
    except OSError:
        pass


# ===========================================================================
# 本体の起動
# ===========================================================================


def run_script(script, args, cwd):
    """
    本体を別のプロセスで動かして終了コードを返す。本体が無ければ 127、中断したら 130。

    Ctrl+C は本体も同じものを受け、書きかけの記録を書き終えてから止まる。subprocess.run は
    本体をすぐ止めてしまうため、終わるまで待つ（もう一度押せば止める）。
    """
    if not script.is_file():
        print("\n  ※ 本体が見つかりません: {}".format(script))
        return EXIT_NOT_FOUND
    print()
    hr("-")
    process = subprocess.Popen([sys.executable, str(script)] + list(args), cwd=str(cwd))
    try:
        return process.wait()
    except KeyboardInterrupt:
        try:
            process.wait()
        except KeyboardInterrupt:
            process.kill()
            process.wait()
        print("\n  中断しました。")
        return EXIT_INTERRUPTED


def run_loop(loop):
    """
    メニューの繰り返し（loop）を動かし、入力の終わりと中断を終了コードにする。
    loop は「終了」を選んだら exit_menu() を呼ぶ。
    """
    try:
        loop()
    except EOFError:
        print("\n  入力が終了しました。")
        sys.exit(EXIT_EOF)
    except KeyboardInterrupt:
        print("\n  中断しました。")
        sys.exit(EXIT_INTERRUPTED)


def exit_menu():
    print("  終了します。")
    sys.exit(EXIT_OK)
