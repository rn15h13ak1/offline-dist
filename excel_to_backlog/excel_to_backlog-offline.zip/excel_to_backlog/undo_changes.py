#!/usr/bin/env python3
"""
手元の変更を退避して元に戻す
============================
clone したフォルダで、ツールのファイルを書き換えたために update.bat が止まったときに使う
（undo_changes.bat をダブルクリック）。

  python undo_changes.py
  python undo_changes.py --yes     確かめずに進める

1. Git が「変わった」とみなすファイル（書き換え・削除・git add したもの）を一覧する
2. backup/<日時>/ に、元の場所の形のまま写す。変更の一覧（CHANGES.txt）と差分（changes.diff）も残す。
   backup/ は .gitignore で外してあり、update.bat も触れない
3. 写し終えたことを確かめてから、git reset と git checkout -- . で元に戻す

config.yaml など、Git が扱わないファイルには触れない。
.bat の for /f で git の出力を読むと日本語のファイル名が化けるため、Python で書く。
古い Python でも動くよう、f 文字列・注釈を使わない。標準ライブラリだけで書く。
"""

import datetime
import os
import shutil
import subprocess
import sys

ROOT = os.path.dirname(os.path.abspath(__file__))
BACKUP_DIR = "backup"


class UndoError(Exception):
    pass


def git(args, root, check=True):
    """git を動かし、標準出力をバイト列で返す。日本語の名前を化けさせないよう -z と UTF-8 で読む"""
    try:
        result = subprocess.run(["git", "-c", "core.quotePath=false"] + args, cwd=root,
                                stdout=subprocess.PIPE, stderr=subprocess.PIPE)
    except OSError:
        raise UndoError("Git が見つかりません。Git for Windows を入れてください。")
    if check and result.returncode != 0:
        raise UndoError("git {} が失敗しました: {}".format(
            " ".join(args), result.stderr.decode("utf-8", "replace").strip()))
    return result.stdout


def changed_files(root):
    """[(状態, 相対パス)]。状態は M（書き換え）・D（削除）・A（git add した新しいファイル）など"""
    out = git(["diff", "--name-status", "-z", "--no-renames", "HEAD", "--"], root)
    parts = [p.decode("utf-8") for p in out.split(b"\0") if p]
    return [(parts[i][0], parts[i + 1]) for i in range(0, len(parts) - 1, 2)]


def backup(root, changes, stamp):
    """backup/<日時>/ に写し、そのフォルダを返す。写せなければ UndoError（元には戻さない）"""
    dest = os.path.join(root, BACKUP_DIR, stamp)
    n = 1
    while os.path.exists(dest):
        n += 1
        dest = os.path.join(root, BACKUP_DIR, "{}-{}".format(stamp, n))
    os.makedirs(dest)
    for status, rel in changes:
        src = os.path.join(root, *rel.split("/"))
        if status == "D" or not os.path.isfile(src):
            continue  # 消したファイルは写すものが無い。一覧と差分に残る
        target = os.path.join(dest, *rel.split("/"))
        if not os.path.isdir(os.path.dirname(target)):
            os.makedirs(os.path.dirname(target))
        shutil.copy2(src, target)
        if os.path.getsize(target) != os.path.getsize(src):
            raise UndoError("写したファイルの大きさが元と違います: " + rel)
    labels = {"M": "書き換え", "D": "削除", "A": "追加"}
    with open(os.path.join(dest, "CHANGES.txt"), "w", encoding="utf-8") as f:
        f.write("退避した日時: {}\n\n".format(stamp))
        for status, rel in changes:
            f.write("{}\t{}\n".format(labels.get(status, status), rel))
    with open(os.path.join(dest, "changes.diff"), "wb") as f:
        f.write(git(["diff", "--binary", "HEAD", "--"], root))
    return dest


def undo(root):
    git(["reset", "--quiet"], root)
    git(["checkout", "--", "."], root)
    if changed_files(root):
        raise UndoError("元に戻しきれないファイルがあります。退避したものは残っています。")


def make_console_safe():
    for stream in (sys.stdout, sys.stderr):
        encoding = (getattr(stream, "encoding", None) or "").lower().replace("-", "").replace("_", "")
        if encoding in ("", "utf8") or not hasattr(stream, "reconfigure"):
            continue
        try:
            stream.reconfigure(errors="replace")
        except (ValueError, OSError):
            pass


def main(argv=None, root=None, ask=input, now=None):
    make_console_safe()
    argv = sys.argv[1:] if argv is None else argv
    root = root or ROOT
    if argv not in ([], ["--yes"]):
        print("使い方: python undo_changes.py [--yes]")
        return 2
    try:
        if not os.path.isdir(os.path.join(root, ".git")):
            raise UndoError("このフォルダは git clone で作ったものではありません。")
        changes = changed_files(root)
        if not changes:
            print("OK: 変えたファイルはありません。何もしていません。")
            return 0
        print("次のファイルを {}\\ に退避してから、元に戻します。".format(BACKUP_DIR))
        for status, rel in changes:
            print("  {} {}".format(status, rel))
        if argv != ["--yes"]:
            answer = ask("よければ Y を入力してください（Enter だけなら何もしません）: ")
            if answer.strip().lower() not in ("y", "yes"):
                print("止めました。何も変えていません。")
                return 1
        stamp = (now or datetime.datetime.now()).strftime("%Y%m%d-%H%M%S")
        dest = backup(root, changes, stamp)
        undo(root)
    except UndoError as e:
        print("NG: " + str(e))
        return 1
    except OSError as e:
        print("NG: 退避できませんでした。何も元に戻していません: {}".format(e))
        return 1
    print("OK: 元に戻しました。退避したもの: " + dest)
    print("  変えた内容が要るときは、退避したファイルを見て、必要な所だけを写し直してください。")
    return 0


if __name__ == "__main__":
    sys.exit(main())
