#!/usr/bin/env python3
"""
Excel から Backlog へ課題を登録
================================
複数の Excel ファイルから特定行を抽出し、Backlog 課題として登録・更新する。

【既定の動作はドライランです】
引数なしで実行すると変換結果の確認のみ行い、Backlog への登録は行いません。
実際に登録・更新するには --execute を付けて実行してください。

使い方:
  # ドライラン（既定。実際には作成・更新せず変換結果を確認）
  python excel_to_backlog.py

  # 実際に課題を作成/更新
  python excel_to_backlog.py --execute

  # 特定のソースのみ処理（ドライラン）
  python excel_to_backlog.py --source "タスク管理表"

  # 特定のソースのみ実際に登録
  python excel_to_backlog.py --source "タスク管理表" --execute

  # 設定ファイルを指定
  python excel_to_backlog.py --config path/to/config.yaml

  # 登録内容をMarkdownファイルに出力して確認（本文の全内容を含む）
  python excel_to_backlog.py --preview

  # API リクエスト詳細を表示（デバッグ）
  python excel_to_backlog.py --execute --debug
"""

import argparse
import io
import sys
import time
from contextlib import ExitStack, redirect_stderr, redirect_stdout
from dataclasses import dataclass, field
from datetime import datetime
from pathlib import Path

# 設定ファイルと API キーの読み込みは、5 つのツールで共通の部品にある（PyYAML は読むときに初めて使う）
from backlog_common import cli
from backlog_common import config as config_files
from backlog_common import plan as plans
from backlog_common.client import (
    BacklogAPIError,
    BacklogClient,
    BacklogNoChangeError,
    estimate_text,
    format_api_error,
)
from backlog_common.config import ConfigError
from backlog_common.console import has_tty, not_tty_text
from backlog_common.files import safe_filename, unique_stamp
from backlog_common.runtime import (
    EXIT_NEEDS_CONFIRMATION,
    exit_on_error,
    exit_on_interrupt,
    make_console_safe,
    require_packages,
    require_python,
    stop_on_sigterm,
)

from version import TOOL_NAME, __version__

# 3.9 だと、下の定義や import の途中で原因の分からないトレースバックになるため、先に確かめる
require_python()

# 依存が無ければ、入れ方を案内して 1 で止める（終了コードは README の対応表の「実行環境・設定の不備」。新しい番号は足さない）。
# PyYAML は設定ファイルを読む共通の部品が、openpyxl は Excel を読む excel_reader が使う
require_packages([("yaml", "pyyaml"), ("openpyxl", "openpyxl")])

from config_validation import validate_config_keys
from excel_reader import ExcelReader, col_letter_to_index
from mapper import BacklogMaster, IssueMapper
from row_merge import (
    continuation_groups,
    merge_by_groups,
    merge_continuation_rows,
    single_value_columns,
)
from run_log import RunLog, completion_key, default_log_path, load_completed
from summary_index import SummaryIndex

# ------------------------------------------------------------------
# 設定ファイル読み込み
# ------------------------------------------------------------------

TOOL_DIR = Path(__file__).resolve().parent


# 設定の誤りの終了コード（README の「終了コード」）
EXIT_CONFIG = 1


def find_config(explicit: str | None) -> str:
    """--config が無ければ、ツールのフォルダの config.yaml（5 つのツールで同じ。以前は作業フォルダを先に探した）。"""
    return str(exit_on_error(ConfigError, EXIT_CONFIG, config_files.find_config,
                             explicit, (TOOL_DIR / "config.yaml",), example="config.minimal.yaml"))


def load_config(config_path: str) -> dict:
    """
    設定ファイルを読む。無い・UTF-8 でない・YAML の書き損じ・空・形が不正なら、
    直し方を示して終了コード 1 で止める。
    """
    return exit_on_error(ConfigError, EXIT_CONFIG, config_files.load_config, config_path, example="config.minimal.yaml")


def backlog_section(config: dict) -> dict:
    """backlog: の節（無ければ空）。形が不正なら案内して終了コード 1"""
    return exit_on_error(ConfigError, EXIT_CONFIG, config_files.backlog_section, config)


def validate_backlog_config(backlog_cfg: dict, config_path: str | None = None) -> str:
    """
    接続設定を確かめ、API キーを探して backlog_cfg["api_key"] に入れる。どこから読んだかを返す。

    API キーは 環境変数 BACKLOG_API_KEY → 設定ファイルの backlog.api_key → .env
    （設定ファイルの隣 → このツールのフォルダ → 作業フォルダ）の順。例の値のままのものは、
    書いていないものとして扱う。
    """
    problems = config_files.missing_problems(backlog_cfg, ["space_host", "project_key"])
    if problems:
        # 読んだ設定ファイルのパスと、誤りを並べる（5 つのツールで同じ形）
        print("エラー: " + config_files.problems_text(config_path or "config.yaml", problems), file=sys.stderr)
        sys.exit(EXIT_CONFIG)
    api_key, source = exit_on_error(ConfigError, EXIT_CONFIG, config_files.locate_api_key,
                                    config_path, backlog_cfg.get("api_key"), tool_dir=TOOL_DIR)
    backlog_cfg["api_key"] = api_key
    return source


# ------------------------------------------------------------------
# 集計
# ------------------------------------------------------------------

def new_counts() -> dict:
    """
    処理結果の集計辞書を返す。

    created       : 新規作成に成功した件数
    updated       : 既存課題の更新に成功した件数
    unchanged     : 既存課題と内容が同一で変更が発生しなかった件数
                    （以前は skipped に混ぜていたが、「処理しなかった」行と
                     「処理したが変わらなかった」行は意味が異なるため分離した）
    partial       : 作成・更新はできたが一部フィールドを設定できなかった件数
                    （created / updated にも計上される）
    skipped       : 必須列が空・確認でキャンセル等で処理しなかった件数
    resumed       : --resume により前回処理済みとして飛ばした件数
    status_failed : 作成には成功したがステータス変更に失敗した件数
                    （created にも計上される。課題は Backlog に存在する）
    error         : 作成・更新に失敗した件数
    status_planned: ドライランで、作成の後にステータスを変える予定の件数
                    （作成と別に API を 1 回呼ぶ。書き込みの回数の目安に使う）
    """
    return {
        "created": 0,
        "updated": 0,
        "unchanged": 0,
        "partial": 0,
        "skipped": 0,
        "resumed": 0,
        "status_failed": 0,
        "error": 0,
        "status_planned": 0,
    }


# ------------------------------------------------------------------
# upsert ロジック
# ------------------------------------------------------------------

def find_existing_issue(
    client: BacklogClient,
    upsert_cfg: dict,
    row: dict,
    params: dict,
    master: BacklogMaster,
    summary_index: SummaryIndex | None = None,
) -> dict | None:
    """
    upsert 設定に従い既存課題を返す（見つからない場合は None）。

    issueKey だけでなく課題そのものを返す。更新前に「本当に変わるのか」を
    比較するために、現在の値が必要なため。

    upsert_cfg キー:
        key_col       : str  Excel の列名（issueKey が記入されている列）
        match_summary : bool 件名で一致する課題を探す
    """
    # ① Excel の key_col に issueKey が記入されている場合
    key_col = upsert_cfg.get("key_col")
    if key_col:
        issue_key = row.get(key_col, "").strip()
        if issue_key:
            existing = client.get_issue(issue_key)
            if existing:
                return existing
            # key_col に値はあるが Backlog に存在しない → 新規作成
            print(
                f"    ※ issueKey「{issue_key}」は Backlog に存在しません → 新規作成",
                file=sys.stderr,
            )
            return None

    # ② 件名で照合
    # params["summary"] は map_row() で normalize_summary() 済み。
    # 索引側にも同じ正規化を適用しているため表記の揺れを吸収できる。
    if upsert_cfg.get("match_summary") and summary_index is not None:
        summary = params.get("summary", "")
        if summary:
            return summary_index.find(summary)

    return None


# ------------------------------------------------------------------
# 更新内容の差分判定
# ------------------------------------------------------------------

def _existing_value(issue: dict, key: str):
    """
    Backlog の課題オブジェクトから、送信パラメータ key に対応する現在値を返す。

    比較できない項目は None ではなく _UNKNOWN を返し、呼び出し元が
    「変更あり」に倒せるようにする。
    """
    if key == "summary":
        return IssueMapper.normalize_summary(issue.get("summary") or "")
    if key == "description":
        return issue.get("description") or ""
    if key in ("dueDate", "startDate"):
        # "2025-01-05T00:00:00Z" のような形式で返ることがあるため日付部分だけ見る
        value = issue.get(key)
        return str(value)[:10] if value else ""
    if key == "assigneeId":
        return (issue.get("assignee") or {}).get("id")
    if key == "statusId":
        return (issue.get("status") or {}).get("id")
    if key == "issueTypeId":
        return (issue.get("issueType") or {}).get("id")
    if key == "priorityId":
        return (issue.get("priority") or {}).get("id")
    if key.startswith("customField_"):
        field_id = int(key.removeprefix("customField_"))
        for cf in issue.get("customFields") or []:
            if cf.get("id") == field_id:
                value = cf.get("value")
                if isinstance(value, dict):
                    return value.get("id")
                if isinstance(value, list):
                    return sorted(
                        v.get("id") if isinstance(v, dict) else v for v in value
                    )
                return value
        return None
    return _UNKNOWN


class _Unknown:
    """比較できないことを表す番兵。None（値なし）と区別する。"""

    def __repr__(self) -> str:
        return "<比較不可>"


_UNKNOWN = _Unknown()


def has_changes(params: dict, issue: dict) -> bool:
    """
    送信予定の params が、既存課題 issue に対して変更をもたらすか判定する。

    Backlog は「変更が無く、コメントも無い」更新に対して
    "No comment content." (code=7) を返す。実際に PATCH を投げるまで
    分からなかったが、既存課題は照合の時点で取得済みのため、
    事前に比較できる。

    判定できない項目が 1 つでもあれば True（変更あり）を返す。
    誤って「変更なし」と判断して更新を飛ばすより、余分に PATCH を
    投げるほうが安全なため。
    """
    for key, new_value in params.items():
        if key == "projectId":
            continue
        current = _existing_value(issue, key)
        if current is _UNKNOWN:
            return True
        if key == "summary":
            if IssueMapper.normalize_summary(str(new_value)) != current:
                return True
            continue
        if isinstance(new_value, list):
            if sorted(new_value) != (sorted(current) if isinstance(current, list) else current):
                return True
            continue
        if str(new_value) != ("" if current is None else str(current)):
            return True
    return False


# ------------------------------------------------------------------
# メタキー注入
# ------------------------------------------------------------------

def inject_meta(row: dict, source_cfg: dict) -> dict:
    """
    行データに Excel ソース由来のメタ情報を注入して返す。

    注入キー（アンダースコア始まりで Excel 列名とは区別できる）:
        _source_name  : sources[i].name の値
        _excel_path   : sources[i].excel.path の値
        _excel_sheet  : sources[i].excel.sheet の値

    これらは summary_template / description_template などの
    {{キー名}} プレースホルダーで参照できる。
    """
    excel_cfg = source_cfg.get("excel", {})
    meta = {
        "_source_name": source_cfg.get("name", ""),
        "_excel_path":  excel_cfg.get("path", ""),
        "_excel_sheet": excel_cfg.get("sheet", ""),
    }
    # 元の row は変更しない（コピーして返す）
    return {**meta, **row}


# ------------------------------------------------------------------
# フィルタリング（filters / filter_groups 共通処理）
# ------------------------------------------------------------------

def apply_filters(
    rows: list,
    source_cfg: dict,
    headers: list,
) -> list:
    """
    source_cfg の filters または filter_groups に従い行を絞り込む。

    filters       : 複数条件を AND 評価（従来通り）
    filter_groups : 各グループを AND 評価し、グループ間を OR 評価
                    同じ行が複数グループにマッチしても重複しない
    両方省略時は全行を返す。filters と filter_groups が両方指定された場合は
    filter_groups を優先する。
    """
    filter_groups_cfg = source_cfg.get("filter_groups") or []
    filters_cfg = source_cfg.get("filters") or []

    if filter_groups_cfg:
        # 列名チェック（全グループ対象）
        for gi, group in enumerate(filter_groups_cfg):
            for cond in group.get("filters") or []:
                col = cond.get("col_name", "")
                if col and col not in headers:
                    print(
                        f"  警告: filter_groups[{gi}] の列「{col}」がヘッダーに存在しません。"
                        f"（ヘッダー: {headers}）",
                        file=sys.stderr,
                    )

        # 各グループを AND 評価 → グループ間を OR（重複除去しつつ順序保持）
        seen_ids: set = set()
        result = []
        for group in filter_groups_cfg:
            group_filters = group.get("filters") or []
            for row in ExcelReader.filter_rows(rows, group_filters):
                rid = id(row)
                if rid not in seen_ids:
                    seen_ids.add(rid)
                    result.append(row)
        return result

    else:
        # 従来の filters（AND 評価）
        for cond in filters_cfg:
            col = cond.get("col_name", "")
            if col and col not in headers:
                print(
                    f"  警告: フィルター列「{col}」がヘッダーに存在しません。"
                    f"（ヘッダー: {headers}）",
                    file=sys.stderr,
                )
        return ExcelReader.filter_rows(rows, filters_cfg)


# ------------------------------------------------------------------
# 列名参照の事前検証
# ------------------------------------------------------------------

# inject_meta() が行データに注入するキー。Excel の列ではないがテンプレートから
# 参照できるため、列名検証では既知の名前として扱う。
# _excel_row は ExcelReader が行データに直接持たせる（inject_meta 経由ではない）
META_KEYS = {"_source_name", "_excel_path", "_excel_sheet", ExcelReader.ROW_NUMBER_KEY}


def collect_referenced_columns(source_cfg: dict) -> list[tuple[str, str]]:
    """
    source_cfg が参照している Excel 列名を (設定パス, 列名) のリストで返す。

    テンプレート項目（summary_template / description_template）は
    IssueMapper.extract_template_columns() でプレースホルダーを展開する。
    due_date_col / start_date_col は map_row() と同じ判定（"{{" を含むか）で
    テンプレートと列名を区別する。
    """
    refs: list[tuple[str, str]] = []
    mapping_cfg = source_cfg.get("issue_mapping") or {}
    upsert_cfg = source_cfg.get("upsert") or {}

    def add(path: str, value) -> None:
        # 列名は strip せずそのまま登録する。
        # filter_rows() や _resolve_*() は設定値を strip せずに row の
        # キーと突き合わせるため、前後の空白の有無まで含めて一致させる必要がある。
        # （テンプレートの {{列名}} だけは _render_template() 側が strip するため、
        #   add_template() 経由で strip 済みの名前が渡る）
        if isinstance(value, str) and value.strip():
            refs.append((path, value))

    def add_template(path: str, template: str) -> None:
        for col in sorted(IssueMapper.extract_template_columns(template)):
            refs.append((path, col))

    # ---- フィルター ----
    # apply_filters() は filter_groups があれば filters を無視するため、
    # 検証も同じ優先順位に合わせる。移行途中で古い filters が残っていても
    # 実行時に読まれない設定でソースを止めない。
    filter_groups_cfg = source_cfg.get("filter_groups") or []
    if filter_groups_cfg:
        for gi, group in enumerate(filter_groups_cfg):
            for i, cond in enumerate(group.get("filters") or []):
                add(f"filter_groups[{gi}].filters[{i}].col_name", cond.get("col_name"))
    else:
        for i, cond in enumerate(source_cfg.get("filters") or []):
            add(f"filters[{i}].col_name", cond.get("col_name"))

    # ---- 件名 ----
    summary_template = mapping_cfg.get("summary_template", "")
    if summary_template:
        add_template("issue_mapping.summary_template", summary_template)
    else:
        add("issue_mapping.summary_col", mapping_cfg.get("summary_col"))

    # ---- 本文 ----
    # description_template は template モードでのみ使われる
    is_auto = mapping_cfg.get("description_format", "template") == "auto"
    description_template = mapping_cfg.get("description_template", "")
    if not is_auto:
        add_template("issue_mapping.description_template", description_template)

    # description_cols を読むのは _render_auto() だけで、それが動くのは
    # auto モードか、テンプレートに {{auto}} がある場合に限られる。
    # どちらでもないときに検証すると、使われない設定でソースを止めてしまう。
    # _render_template() はプレースホルダー名を strip して判定するため、
    # {{ auto }} のような書き方も同じように扱う。
    placeholders = {
        name.strip()
        for name in IssueMapper.TEMPLATE_PLACEHOLDER_RE.findall(description_template)
    }
    uses_auto_body = is_auto or "auto" in placeholders
    if uses_auto_body:
        for i, col in enumerate(mapping_cfg.get("description_cols") or []):
            add(f"issue_mapping.description_cols[{i}]", col)

    # ---- 日付（列名またはテンプレート）----
    for key in ("due_date_col", "start_date_col"):
        value = mapping_cfg.get(key)
        if not value:
            continue
        if "{{" in str(value):
            add_template(f"issue_mapping.{key}", str(value))
        else:
            add(f"issue_mapping.{key}", value)

    # ---- その他の単一列 ----
    add("issue_mapping.assignee_col", mapping_cfg.get("assignee_col"))
    add("issue_mapping.status_col", mapping_cfg.get("status_col"))

    # key_col を読む find_existing_issue() は upsert 有効時しか呼ばれない。
    # 書き戻し列をこれから用意する段階で設定だけ先に書いておけるよう、
    # 無効時は検証しない。
    if upsert_cfg.get("enabled", False):
        add("upsert.key_col", upsert_cfg.get("key_col"))

    # ---- 必須列・カスタム属性 ----
    for i, col in enumerate(mapping_cfg.get("required_cols") or []):
        add(f"issue_mapping.required_cols[{i}]", col)
    for i, cf in enumerate(mapping_cfg.get("custom_fields") or []):
        add(f"issue_mapping.custom_fields[{i}].col_name", cf.get("col_name"))

    return refs


def validate_column_references(source_cfg: dict, headers: list[str]) -> list[str]:
    """
    設定が参照する列名がすべてヘッダーに存在するか検証する。

    存在しない参照が1件でもあれば、その内容を説明する行のリストを返す。
    すべて解決できる場合は空リストを返す。

    列名の不一致は「その条件が無視される」「プレースホルダーが未展開のまま
    件名になる」といった無言の誤動作につながるため、警告ではなく実行前の
    エラーとして扱う（呼び出し元がソースの処理を中止する）。
    """
    known = set(headers) | META_KEYS
    unknown = [(path, col) for path, col in collect_referenced_columns(source_cfg)
               if col not in known]
    if not unknown:
        return []

    lines = [
        f"設定が参照する列名が Excel のヘッダーに存在しません（{len(unknown)} 件）:",
    ]
    for path, col in unknown:
        # 前後の空白は「」で囲んでも見えないため、strip すると一致する場合は明示する
        hint = ""
        if col.strip() != col and col.strip() in known:
            hint = f"  ← 前後の空白を除けば一致します（{col!r}）"
        lines.append(f"    {path}: 「{col}」{hint}")
    lines.append(f"  ヘッダー: {headers}")
    lines.append(
        "  → 列名の綴り・前後の空白・複数行ヘッダーの結合結果（\" / \" 区切り）を確認してください。"
    )
    return lines


# ------------------------------------------------------------------
# ソースの読み込み
# ------------------------------------------------------------------

class SourceLoadError(Exception):
    """ソースの読み込み・検証に失敗した。message は利用者向けの説明。"""

    def __init__(self, message: str, detail: str = ""):
        super().__init__(message)
        self.message = message
        self.detail = detail


@dataclass
class LoadedSource:
    """
    1 ソース分の読み込み結果。

    実処理（process_source）とプレビュー生成（generate_preview_for_source）は
    同じ手順で Excel を読み、列名を検証し、フィルターを適用し、マッパーを
    用意する。以前は両者が同じ流れを別々に実装しており、実際に乖離が
    始まっていた（プレビュー側だけ書式付き行の取得方法が異なる等）。
    """

    headers: list[str]
    rows: list[dict]                    # フィルター適用後
    mapper: IssueMapper
    formatted_by_row: dict[str | None, dict]   # {_excel_row: 書式付き行}

    def formatted_for(self, row: dict) -> dict | None:
        """
        平文行に対応する書式付き行を返す。rich_text 無効時は None。

        対応付けには Excel の行番号を使う。以前は id(dict) を使っており、
        フィルターがコピーを返すようになった瞬間に壊れる作りだった。
        壊れても例外は出ず、本文だけが静かに元テキストへ戻る。
        """
        if not self.formatted_by_row:
            return None
        return self.formatted_by_row.get(row.get(ExcelReader.ROW_NUMBER_KEY))


def load_source(source_cfg: dict, master: BacklogMaster, *, limit: int | None = None) -> LoadedSource:
    """
    ソースを読み込み、列名を検証し、フィルターを適用して返す。

    Raises
    ------
    SourceLoadError : 読み込み失敗・列名不一致・設定不備のいずれか
    """
    import traceback

    excel_cfg = source_cfg.get("excel") or {}
    mapping_cfg = source_cfg.get("issue_mapping") or {}

    # ---- Excel 読み込み ----
    try:
        reader = ExcelReader(excel_cfg)
        if mapping_cfg.get("rich_text"):
            headers, rows, formatted_rows = reader.read_with_format()
        else:
            headers, rows = reader.read()
            formatted_rows = None
    except Exception as e:
        raise SourceLoadError(
            f"Excel の読み込みに失敗しました: {e}\n"
            "  ヒント: Excel ファイルが破損または非標準形式の可能性があります。",
            detail=traceback.format_exc(),
        ) from e

    print(f"  読込行数: {len(rows)} 行（フィルター前）")

    # ---- 継続行の結合 ----
    # 1 件の内容が複数行に分かれている表を 1 件にまとめる。
    # 絞り込みより前に行う。続きの行は絞り込み条件の列も空になっているため、
    # 先に絞ると結合前に失われてしまう。
    if mapping_cfg.get("merge_continuation_rows"):
        required_cols = mapping_cfg.get("required_cols") or []
        single_cols = single_value_columns(source_cfg)
        # 書式付きの行（rich_text）も同じ区切りで結合する。本文はこちらから
        # 作るため、結合しないと続きの行の内容が本文にだけ現れない。
        # 区切りは平文の行で判定する。書式付きは取り消し線が ~~ に変換されて
        # いるため、そちらで判定すると平文と結果がずれる。
        if formatted_rows is not None and required_cols:
            formatted_rows = merge_by_groups(
                formatted_rows,
                continuation_groups(rows, required_cols),
                headers, single_cols, required_cols, warn=False,
            )
        rows = merge_continuation_rows(rows, headers, required_cols, single_cols)

    # ---- 列名参照の検証 ----
    # 列名が1つでも一致しないと、フィルター条件が無視されて全行が対象になる、
    # プレースホルダーが未展開のまま件名になる等の無言の誤動作が起きるため、
    # 行を処理する前に中止する。
    errors = validate_column_references(source_cfg, headers)
    if errors:
        raise SourceLoadError("\n".join(errors))

    # ---- フィルタリング ----
    filtered = apply_filters(rows, source_cfg, headers)
    print(f"  対象行数: {len(filtered)} 行（フィルター後）")

    if limit is not None and len(filtered) > limit:
        print(f"  → --limit {limit} のため先頭 {limit} 行のみ処理します"
              f"（残り {len(filtered) - limit} 行は対象外）")
        filtered = filtered[:limit]

    # ---- マッパー ----
    mapper = IssueMapper(mapping_cfg, master, headers=headers)
    # 種別・優先度は全行に共通の設定のため、行ごとではなくここで一度だけ解決する。
    # 行ごとに判定すると、設定のタイプミスが「全行スキップ」というデータ不備の
    # ような報告になり、原因が設定だと分からない。
    try:
        mapper.resolve_fixed_fields()
    except ValueError as e:
        raise SourceLoadError(f"{e}\n  → issue_mapping の設定を確認してください。") from e

    formatted_by_row = (
        {r.get(ExcelReader.ROW_NUMBER_KEY): r for r in formatted_rows}
        if formatted_rows is not None else {}
    )
    return LoadedSource(headers, filtered, mapper, formatted_by_row)


# ------------------------------------------------------------------
# プレビューファイル生成
# ------------------------------------------------------------------

def build_master_labels(master: BacklogMaster) -> dict:
    """
    ID → 表示名 の逆引き辞書を生成する（プレビュー表示用）。

    種別・優先度・ユーザーは ID 空間が独立しているため、
    フラットにマージせずカテゴリ別のネスト構造で返す。

    Returns
    -------
    dict
        {
          "issue_type": {id: 種別名, ...},
          "priority":   {id: 優先度名, ...},
          "user":       {id: ユーザー名, ...},
          "status":     {id: ステータス名, ...},
        }
    """
    # user_map には同一ユーザーの表示名・ログインIDが両方登録されているため、
    # ID が初出のエントリ（登録順で先に来る表示名）のみを逆引きに採用する
    user_labels: dict[int, str] = {}
    for name, id_ in master.user_map.items():
        if id_ not in user_labels:
            user_labels[id_] = name

    return {
        "issue_type": {id_: name for name, id_ in master.issue_type_map.items()},
        "priority":   {id_: name for name, id_ in master.priority_map.items()},
        "user":       user_labels,
        "status":     {id_: name for name, id_ in master.status_map.items()},
    }


def _safe_filename(name: str) -> str:
    """sources[].name をファイル名として安全な文字列にする（決まりは 5 つのツールで共通の部品）。"""
    return safe_filename(name, "source")


def generate_preview_for_source(
    source_cfg: dict,
    master: BacklogMaster,
    master_labels: dict,
    output_path: Path,
    now: str,
) -> int:
    """
    1ソース分の登録予定内容を Markdown ファイルに書き出す。

    Returns
    -------
    int : プレビュー生成した課題件数
    """
    name = source_cfg.get("name", "（名前なし）")
    excel_cfg = source_cfg.get("excel", {})

    lines = [
        f"# Backlog 課題登録 プレビュー — {name}",
        "",
        f"> 生成日時: {now}  ",
        "> ※ このファイルは登録前の確認用です。実際の登録は `--execute` で行います。",
        "",
        f"- ファイル: `{excel_cfg.get('path', '（未設定）')}`",
        f"- シート: `{excel_cfg.get('sheet', '（最初のシート）')}`",
        "",
        "---",
        "",
    ]

    issue_count = 0
    # ---- 読み込み・検証・フィルタ（実処理と共通）----
    try:
        loaded = load_source(source_cfg, master)
    except SourceLoadError as e:
        lines.append(f"> ⚠ {e.message}")
        lines.append("")
        if e.detail:
            lines.append(f"> 詳細: `{e.detail}`")
            lines.append("")
        output_path.write_text("\n".join(lines) + "\n", encoding="utf-8")   # 末尾は改行で終える
        return 0

    lines.append(f"対象行数: **{len(loaded.rows)} 件**（フィルター後）")
    lines.append("")

    if not loaded.rows:
        lines.append("_対象行がありません。_")
        lines.append("")
        output_path.write_text("\n".join(lines) + "\n", encoding="utf-8")   # 末尾は改行で終える
        return 0

    issue_count = 0
    for row in loaded.rows:
        i = row.get(ExcelReader.ROW_NUMBER_KEY, "?")
        enriched = inject_meta(row, source_cfg)
        fmt_row = loaded.formatted_for(row)
        fmt_enriched = inject_meta(fmt_row, source_cfg) if fmt_row is not None else None
        lines.append(loaded.mapper.format_preview(
            enriched, i, master_labels=master_labels, formatted_row=fmt_enriched
        ))
        lines.append("")
        lines.append("---")
        lines.append("")
        issue_count += 1

    output_path.write_text("\n".join(lines) + "\n", encoding="utf-8")   # 末尾は改行で終える
    return issue_count


def generate_preview_file(
    sources_cfg: list,
    master: BacklogMaster,
    output_dir: Path,
    timestamp: str,
) -> list[tuple[Path, int]]:
    """
    sources[].name の単位で Markdown プレビューファイルを生成する。
    Backlog API のデータ書き込みは行わない。

    Returns
    -------
    list[tuple[Path, int]]
        各ソースの (出力ファイルパス, 課題件数) のリスト
    """
    master_labels = build_master_labels(master)
    now = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    results = []

    for source_cfg in sources_cfg:
        name = source_cfg.get("name", "source")
        safe = _safe_filename(name)
        output_path = output_dir / f"preview_{timestamp}_{safe}.md"
        count = generate_preview_for_source(
            source_cfg, master, master_labels, output_path, now
        )
        results.append((output_path, count))

    return results


# ------------------------------------------------------------------
# 課題新規作成（2段階: 未対応で作成 → statusId を更新）
# ------------------------------------------------------------------

class StatusUpdateFailed(Exception):
    """
    課題の作成には成功したが、その後のステータス変更に失敗した。

    課題は Backlog に存在するため、呼び出し元は「作成成功」として issueKey を
    表示しなければならない。これをエラーとして扱うと、実際には存在する課題が
    「作成 0 件 / エラー 1 件」と報告され、issueKey も表示されないまま
    Backlog 上に取り残される。
    """

    def __init__(self, issue: dict, cause: Exception):
        super().__init__(str(cause))
        self.issue = issue
        self.cause = cause


def create_issue_with_status(client: BacklogClient, params: dict) -> dict:
    """
    課題を新規作成する。

    Backlog API は新規作成時に「完了」などの終了ステータスを直接設定できないため、
    statusId をいったん除いた状態（デフォルト「未対応」）で作成し、
    statusId が指定されていた場合は作成後に update_issue で変更する。

    Raises
    ------
    StatusUpdateFailed
        作成には成功したがステータス変更に失敗した場合。
        作成済みの課題を .issue に保持する。
    """
    status_id = params.pop("statusId", None)
    try:
        issue = client.create_issue(params)
    finally:
        # pop したのでロールバックしておく（呼び出し元の params を汚さない）
        if status_id is not None:
            params["statusId"] = status_id

    if status_id is not None:
        try:
            client.update_issue(issue["issueKey"], {"statusId": status_id})
        except BacklogNoChangeError:
            # 作成時点で既にそのステータスだった場合はそのまま続行
            pass
        except BacklogAPIError as e:
            # 課題は作成済み。呼び出し元が issueKey を表示できるよう課題ごと渡す。
            raise StatusUpdateFailed(issue, e) from e

    return issue


# ------------------------------------------------------------------
# 新規作成の確認
# ------------------------------------------------------------------

class ConfirmationDeclined(Exception):
    """ユーザーが確認で実行を取りやめた。"""


class RowConfirmer:
    """
    新規作成の可否を 1 件ずつ確認する。

    まとめて一気に書き込むと、件数が多いときに何が起きたのか把握しきれない。
    課題が増えるのは新規作成のときだけなので、そこに確認を集約する。

    既存課題の更新は確認せずに実行する。内容が既存と同じ行は
    plan_row() の時点で「変更なし」と判定されており、確認に出てくるのは
    実際に変わる行だけだが、更新は件数が多くなりやすく、都度の確認が
    かえって判断を鈍らせるため。

    選択肢:
        y  この行を作成する
        n  この行を飛ばす（スキップとして計上）
        a  以降はすべて確認せず実行する
        q  ここで実行を中止する

    assume_yes=True（--yes）のときは一切確認しない。cron やパイプ経由で
    使う場合に必要。
    """

    def __init__(self, assume_yes: bool = False, master_labels: dict | None = None):
        self.assume_all = assume_yes
        self.master_labels = master_labels or {}

    def confirm(self, plan, mapper: IssueMapper) -> bool:
        """
        実行してよければ True、飛ばすなら False を返す。

        Raises
        ------
        ConfirmationDeclined : ユーザーが中止（q）を選んだ場合
        """
        if self.assume_all:
            return True

        # 更新は確認しない。課題が増えるのは新規作成のときだけであり、
        # 更新まで都度確認すると件数が多くなって判断が鈍る。
        if plan.action == "update":
            return True

        print(f"\n  [{plan.row_number}] 新規作成")
        print(mapper.format_plan(plan, master_labels=self.master_labels))

        while True:
            try:
                answer = input(
                    "    作成しますか？ [y=作成 / n=スキップ / a=以降すべて / q=中止]: "
                ).strip().lower()
            except (EOFError, OSError):
                # 端末でない所。本来は main() が事前に弾いているが、
                # 途中で標準入力が閉じられた場合に無限ループしないよう中止する。
                raise ConfirmationDeclined(
                    "エラー: 確認の入力を受け取れませんでした。残りの行は送っていません。--yes を付けて実行してください。"
                ) from None

            if answer in ("y", "yes"):
                return True
            if answer in ("n", "no", ""):
                return False
            if answer in ("a", "all"):
                self.assume_all = True
                print("    → 以降は確認せずに実行します。")
                return True
            if answer in ("q", "quit"):
                raise ConfirmationDeclined("実行を中止しました（新規作成の確認で q を選んだ）。残りの行は送っていません。")
            print("    y / n / a / q のいずれかを入力してください。")


# ------------------------------------------------------------------
# 出力先フォルダ
# ------------------------------------------------------------------

DEFAULT_OUTPUT_DIR = "output"


def resolve_output_dir(config: dict, config_path: str, override: str | None) -> Path:
    """
    プレビューと実行ログの出力先を決めて返す。フォルダは、ファイルを書くとき（プレビュー・実行ログ）に作る
    （--show-columns・--list-master・ドライランでは作らない。ほかのツールと同じ）。

    実行のたびに preview_*.md と run_*.csv が増えるため、設定ファイルと
    同じ場所に出すと元のファイルに混ざって見分けがつかなくなる。

    優先順位は --output-dir > 設定ファイルの output_dir > 既定（output）。
    相対パスの基準は、5 つのツールで同じ決まりにしている。設定ファイルに書いたもの（と既定）は設定ファイルのある場所から
    （作業フォルダで出力先が変わると、同じ設定でもどこに出たか分からなくなるため）。コマンドラインで渡した --output-dir は
    作業フォルダから（ふつうのコマンドと同じ。--resume も同じ）。
    """
    if override:
        output_dir = Path(override)
    else:
        output_dir = Path(config.get("output_dir") or DEFAULT_OUTPUT_DIR)
        if not output_dir.is_absolute():
            output_dir = Path(config_path).parent / output_dir
    return output_dir


def confirm_run(
    sources_cfg: list,
    master: BacklogMaster,
    assume_yes: bool,
) -> None:
    """
    Backlog への書き込みを始める前に、対象ソースを表示する。

    件数の内訳を示したうえで、実際の可否は 1 行ずつ RowConfirmer が確認する
    （ここで重ねて聞くと二重の確認になるため、この関数は表示のみ）。

    以前は行ごとに新規作成の確認を出していたが、以下の問題があった:
      - 200 行あれば 200 回の入力が必要で、実質「全部 y」しか選べない
      - 表示が件名と期限日だけで、本文・担当者・ステータス・カスタム属性は
        隠れており、行ごとに判断する材料が無かった
      - 既存課題の「更新」は無確認だった。上書きという破壊的な操作の方が
        確認なしで、追加でしかない作成の方に確認を求めていた
      - 端末でない所では input() が毎回 EOFError になり全行スキップ。
        1 件も作らずに「作成: 0 件」と表示して正常終了していた

    Raises
    ------
    ConfirmationDeclined
        ユーザーが「いいえ」を選んだ場合、または端末でない所で --yes が
        指定されていない場合。
    """
    names = [s.get("name", "（名前なし）") for s in sources_cfg]

    print()
    print("─" * 55)
    print("Backlog への書き込みを開始します")
    print("─" * 55)
    print(f"  対象ソース: {', '.join(names)}")

    # 作成・更新の件数は事前に算出しない。算出には全行を Backlog と照合する
    # 必要があり、行数に比例して「何も起きない待ち時間」が伸びる。
    # 件数を先に知りたい場合は --execute を付けずに実行する（ドライラン）。
    print("  作成・更新の内訳は、--execute を付けずに実行すると事前に確認できます。")
    print("  内容は --preview で詳しく確認できます。")
    print()

    if assume_yes:
        print("  --yes が指定されているため、確認せずに実行します。")
        return

    # pythonw やサービスから動かすと sys.stdin が None になる
    if not has_tty():
        # 端末でない所で黙って進めると、確認を求められないまま
        # 全件スキップして「成功したように見える無処理」になる。
        # 定期実行やほかのプログラムから使う場合は --yes を明示させる。
        raise ConfirmationDeclined(
            not_tty_text("登録してよいか", "何も送っていません", "自動で実行するなら --yes を付けてください。")
        )

    print("  この後、新規作成のみ 1 件ずつ確認します（更新は確認せず実行します）。")


# ------------------------------------------------------------------
# マスターデータの一覧表示
# ------------------------------------------------------------------

# Backlog のカスタム属性の型（typeId → 表示名）
CUSTOM_FIELD_TYPES = {
    1: "文字列", 2: "文章", 3: "数値", 4: "日付",
    5: "単一リスト", 6: "複数リスト", 7: "チェックボックス", 8: "ラジオ",
}


def print_master_data(master: BacklogMaster) -> None:
    """
    設定に書ける名前の一覧を表示する。

    config.yaml を書くには Backlog 側の種別名・優先度名・ステータス名・
    担当者名・カスタム属性名が必要だが、これらは設定を書き終えて実行して
    初めて分かるという順序になっていた。特にカスタム属性名はどこにも
    表示されず、「見つかりません」と言われても正しい名前を知る手段がなかった。
    """
    def section(title: str, values) -> None:
        print(f"\n{title}")
        if not values:
            print("  （取得できませんでした）")
            return
        for v in values:
            print(f"  {v}")

    print("=" * 55)
    print("設定に使える名前の一覧")
    print("=" * 55)

    section("種別（issue_mapping.issue_type）", list(master.issue_type_map))
    section("優先度（issue_mapping.priority）", list(master.priority_map))
    section("ステータス（issue_mapping.status_map の変換先）", list(master.status_map))

    # user_map は表示名とログインIDの両方を持つため、ID ごとにまとめ直す
    by_id: dict[int, list[str]] = {}
    for name, uid in master.user_map.items():
        by_id.setdefault(uid, []).append(name)
    section(
        "担当者（issue_mapping.assignee_col の値 / default_assignee）",
        [" / ".join(names) for names in by_id.values()],
    )

    print("\nカスタム属性（issue_mapping.custom_fields.field_name）")
    if not master.custom_field_map:
        print("  （このプロジェクトには定義されていません）")
    for name, info in master.custom_field_map.items():
        type_id = info.get("typeId")
        # 型の一覧に無い typeId（int でないものを含む）は番号のまま出す
        type_name = f"typeId={type_id}"
        if isinstance(type_id, int):
            type_name = CUSTOM_FIELD_TYPES.get(type_id, type_name)
        print(f"  {name}  [{type_name}]")
        items = list(info.get("items") or {})
        if items:
            print(f"      選択肢: {' / '.join(items)}")

    print()
    print("─" * 55)
    print("  これらの名前を config.yaml にそのまま記述してください。")
    print("  Excel の列名は --show-columns で確認できます。")


# ------------------------------------------------------------------
# Excel の列名一覧
# ------------------------------------------------------------------

def print_source_columns(sources_cfg: list) -> int:
    """
    各ソースの Excel から読み取れる列名を一覧表示する。

    設定に書く列名は、複数行ヘッダーの " / " 結合結果や、重複時に付く
    " (2)" の連番まで含めて正確に一致させる必要がある。これらは実際に
    読み込ませないと分からないため、設定を書く前に確認できるようにする。

    Returns
    -------
    int : 読み込みに失敗したソースの数
    """
    from openpyxl.utils import get_column_letter

    failures = 0
    for source_cfg in sources_cfg:
        name = source_cfg.get("name", "（名前なし）")
        excel_cfg = source_cfg.get("excel") or {}
        print(f"\n{'=' * 55}")
        print(f"[{name}] {excel_cfg.get('path', '（path 未設定）')}")
        sheet = excel_cfg.get("sheet")
        print(f"  シート: {sheet or '（最初のシート）'}")
        print("=" * 55)

        try:
            reader = ExcelReader(excel_cfg)
            headers, rows = reader.read()
        except Exception as e:
            print(f"  エラー: 読み込みに失敗しました: {e}", file=sys.stderr)
            failures += 1
            continue

        start = col_letter_to_index(reader.col_start_str)
        seen: set[str] = set()
        for i, header in enumerate(headers):
            letter = get_column_letter(start + i + 1)
            if header in seen:
                # 同名の列。本文には出力されるが、列名で参照すると左端になる
                print(f"  {letter:>3}: {header}  ← 同名（本文には出力／列名指定は左端）")
                continue
            seen.add(header)
            # その列に値が入っている最初の行を例として添える
            sample = next(
                (r[header] for r in rows if r.get(header)), ""
            )
            sample = f"  例: {sample[:28]}" if sample else ""
            print(f"  {letter:>3}: {header}{sample}")

        print(f"\n  読込 {len(rows)} 行（フィルター前）")

    print()
    print("─" * 55)
    print("  この列名を config.yaml にそのまま記述してください。")
    print("  複数行ヘッダーは \" / \" で結合されます。")
    return failures


# ------------------------------------------------------------------
# 行ごとの処理計画
# ------------------------------------------------------------------

@dataclass
class RowPlan:
    """
    1 行をどう処理するかの決定。

    ドライラン・実行の両方がこれを組み立てるため、ドライランの表示が
    実行結果と食い違わない。以前はドライランが行ループの手前で return して
    おり、upsert の照合を一切行わなかった。このツールで最も影響が大きい
    「作成するのか更新するのか」を事前に確認できなかった。

    action:
        "create"  新規作成する
        "update"  existing_key の課題を更新する
        "skip"      処理しない（必須列が空・件名が空など）
        "resume"    前回の実行で完了済みのため飛ばす
        "unchanged" 既存課題と内容が同じで、更新しても変わらない
    """

    row_number: str                     # Excel シート上の行番号
    action: str
    params: dict = field(default_factory=dict)
    existing: dict | None = None        # 既存課題（更新・変更なしの場合）
    warnings: list[str] = field(default_factory=list)
    reason: str = ""                    # skip の理由

    @property
    def summary(self) -> str:
        return self.params.get("summary", "")

    @property
    def existing_key(self) -> str | None:
        return (self.existing or {}).get("issueKey")


def operation_id(source_name: str, row_number) -> str:
    """計画と結果の JSON で、行を指す名前（実行のたびに同じ）。"""
    return f"{source_name}:{row_number}"


def plan_operation(source_name: str, plan: RowPlan) -> dict:
    """計画ファイルの操作（作成・更新する行だけ）。"""
    op: dict = {"id": operation_id(source_name, plan.row_number), "op": plan.action, "summary": plan.summary,
          "params": plan.params}
    if plan.action == "update":
        op["issue"] = plan.existing_key
    return op


# 実行ログの action → 結果の JSON（--result-out）の op と status
RESULT_OF_ACTION = {
    "created": ("create", "ok"),
    "updated": ("update", "ok"),
    "unchanged": ("update", "no_change"),
    "created_status_failed": ("create", "failed"),
    "skipped": ("", "skipped"),
    "resumed": ("", "skipped"),
    "error": ("", "failed"),
}


def plan_row(
    row: dict,
    source_cfg: dict,
    mapper: IssueMapper,
    *,
    formatted_row: dict | None = None,
    client: BacklogClient | None = None,
    master: BacklogMaster | None = None,
    summary_index: SummaryIndex | None = None,
    completed: set[tuple[str, str, str]] | None = None,
) -> RowPlan:
    """
    1 行分の処理計画を組み立てる。Backlog への書き込みは行わない。

    upsert が有効な場合は既存課題の照合（読み取りのみ）を行うため、
    ドライランでも「作成か更新か」を確定できる。
    """
    name = source_cfg.get("name", "（名前なし）")
    upsert_cfg = source_cfg.get("upsert") or {}
    row_number = row.get(ExcelReader.ROW_NUMBER_KEY, "?")

    enriched = inject_meta(row, source_cfg)
    fmt_enriched = (
        inject_meta(formatted_row, source_cfg) if formatted_row is not None else None
    )

    try:
        params = mapper.map_row(enriched, formatted_row=fmt_enriched)
    except ValueError as e:
        return RowPlan(row_number=row_number, action="skip", reason=str(e))

    # map_row は次の呼び出しでリセットするため、この行の分を控える
    warnings = list(mapper.warnings)
    summary = params.get("summary", "")

    # --resume: 前回の実行で作成・更新まで完了した行は飛ばす
    if completed is not None and completion_key(name, row_number, summary) in completed:
        return RowPlan(row_number=row_number, action="resume", params=params,
                       warnings=warnings)

    existing = None
    if upsert_cfg.get("enabled", False) and client is not None and master is not None:
        existing = find_existing_issue(
            client, upsert_cfg, enriched, params, master, summary_index=summary_index
        )

    if existing is None:
        action = "create"
    elif has_changes(params, existing):
        action = "update"
    else:
        # 既存課題と内容が同じ。PATCH を投げても Backlog が
        # "No comment content." を返すだけなので、送らずに済ませる。
        action = "unchanged"

    return RowPlan(
        row_number=row_number,
        action=action,
        params=params,
        existing=existing,
        warnings=warnings,
    )


# ------------------------------------------------------------------
# 1ソースの処理
# ------------------------------------------------------------------

def process_source(
    source_cfg: dict,
    client: BacklogClient,
    master: BacklogMaster,
    dry_run: bool,
    run_log: RunLog | None = None,
    completed: set[tuple[str, str, str]] | None = None,
    summary_index: SummaryIndex | None = None,
    counts: dict | None = None,
    limit: int | None = None,
    confirmer: RowConfirmer | None = None,
    operations: list[dict] | None = None,
    result: plans.ResultLog | None = None,
) -> dict:
    """
    1つのソース（Excel ファイル）を処理して作成・更新件数を返す。

    Parameters
    ----------
    limit : int | None
        処理する行数の上限。初回に少数だけ試すために使う。
        フィルター適用後の先頭から数える。
    confirmer : RowConfirmer | None
        1 行ずつ書き込みの可否を確認する。省略時は確認しない。
    operations : list | None
        ドライランで、作成・更新する行の操作（計画ファイルの中身）を足していく（--plan-out・--plan）。
    result : ResultLog | None
        実行で、行ごとの結果を JSON に書く（--result-out）。
    counts : dict | None
        集計を積む辞書。呼び出し元が渡した辞書をその場で更新するため、
        途中で例外が送出されてもそこまでの集計が呼び出し元に残る。
        以前は戻り値でのみ返しており、認証エラー等で中断すると
        「3 件作成したのにサマリーは 0 件」と報告していた。
        省略時は新しい辞書を作る。

    Returns
    -------
    dict: new_counts() と同じキーを持つ集計結果（counts と同一オブジェクト）
    """
    name = source_cfg.get("name", "（名前なし）")
    excel_cfg = source_cfg.get("excel", {})
    upsert_cfg = source_cfg.get("upsert") or {}
    upsert_enabled = upsert_cfg.get("enabled", False)

    if counts is None:
        counts = new_counts()

    print(f"\n{'='*55}")
    print(f"ソース: {name}")
    print(f"{'='*55}")
    print(f"  ファイル: {excel_cfg.get('path', '（未設定）')}")
    print(f"  シート : {excel_cfg.get('sheet', '（最初のシート）')}")
    print(f"  upsert : {'有効' if upsert_enabled else '無効（常に新規作成）'}")

    # ---- 読み込み・検証・フィルタ（プレビュー生成と共通）----
    try:
        loaded = load_source(source_cfg, master, limit=limit)
    except SourceLoadError as e:
        print(f"\n  エラー: {e.message}", file=sys.stderr)
        if e.detail:
            print(e.detail, file=sys.stderr)
        counts["error"] += 1
        return counts

    filtered_rows = loaded.rows
    mapper = loaded.mapper

    if not filtered_rows:
        print("  → 対象行がないためスキップします。")
        return counts

    def get_formatted_row(plain_row: dict) -> dict | None:
        """plain_row に対応する書式付き行を返す。rich_text 無効時は None。"""
        return loaded.formatted_for(plain_row)

    # ---- ドライラン ----
    # 実行と同じ plan_row() を通すため、作成か更新かまで確認できる。
    # upsert の照合は読み取りのみで Backlog を変更しない。
    if dry_run:
        print("\n  [ドライラン] 以下の課題を作成・更新します:\n")
        for row in filtered_rows:
            plan = plan_row(
                row, source_cfg, mapper,
                formatted_row=get_formatted_row(row),
                client=client, master=master,
                summary_index=summary_index, completed=completed,
            )
            i = plan.row_number

            if plan.action == "skip":
                print(f"  [{i}] 警告 スキップ: {plan.reason}", file=sys.stderr)
                counts["skipped"] += 1
                continue
            if plan.action == "resume":
                print(f"  [{i}] -- 再開スキップ（前回処理済み）: {plan.summary}")
                counts["resumed"] += 1
                continue

            if plan.action == "unchanged":
                print(f"  [{i}] 変更なし（{plan.existing_key}）")
                counts["unchanged"] += 1
                continue

            if operations is not None:
                operations.append(plan_operation(name, plan))
            if plan.action == "update":
                print(f"  [{i}] 更新 → {plan.existing_key}")
                counts["updated"] += 1
            else:
                print(f"  [{i}] 新規作成")
                counts["created"] += 1
                if plan.params.get("statusId") is not None:
                    # 作成の後に、ステータスを変える更新を送る（create_issue_with_status）
                    counts["status_planned"] += 1
                # 実行時は作成した課題を索引に加えるため、同じ件名の後続行は
                # 「更新」になる。ドライランでも同じ判断になるよう、作成予定の
                # 件名を索引に入れておく（Backlog へは書き込まない）。
                if summary_index is not None:
                    # 実行時と同じく索引へ加える。実在しないことが分かる
                    # issueKey にして、万一表示されても取り違えないようにする。
                    summary_index.add(plan.summary, {
                        "issueKey": "（この実行で作成予定）",
                        "summary": plan.summary,
                    })
            if plan.warnings:
                counts["partial"] += 1

            print(mapper.format_plan(plan))
        return counts

    # ---- 実処理 ----
    def log(*, row: str, action: str, issue_key: str = "", summary: str = "", detail: str = "", op: str = "") -> None:
        """実行ログに1件記録する（--log-file 未指定時は何もしない）。結果の JSON にも書く（--result-out）。"""
        if run_log is not None:
            run_log.record(
                source=name, row=row, action=action,
                issue_key=issue_key, summary=summary, detail=detail,
            )
        if result is not None:
            kind, status = RESULT_OF_ACTION.get(action, ("", "failed"))
            result.add(operation_id(name, row), op or kind or "-", status, issue=issue_key, summary=summary,
                       message=detail)

    for row in filtered_rows:
        # 表示・ログ・再開判定には Excel シート上の行番号を使う。
        # フィルタ後の連番ではシートの何行目か辿れず、失敗した行を特定できない。
        i = row.get(ExcelReader.ROW_NUMBER_KEY, "?")

        # 例外処理で参照するため、計画の組み立て前に初期化しておく。
        # plan_row() は照合のために API を呼ぶため、ここで失敗しうる。
        params: dict = {}
        row_warnings: list[str] = []
        existing_key: str | None = None

        # 実際に通信した行だけレート制限用の待機を入れる
        # （スキップ・再開スキップした行は通信していないため待つ意味がない）
        api_called = False
        try:
            # ドライランと同じ関数で計画を組み立てる（照合は読み取りのみ）
            api_called = upsert_enabled
            plan = plan_row(
                row, source_cfg, mapper,
                formatted_row=get_formatted_row(row),
                client=client, master=master,
                summary_index=summary_index, completed=completed,
            )
            params = plan.params
            row_warnings = plan.warnings
            existing_key = plan.existing_key

            if plan.action == "skip":
                print(f"  [{i}] 警告 スキップ: {plan.reason}", file=sys.stderr)
                counts["skipped"] += 1
                log(row=i, action="skipped", detail=plan.reason)
                api_called = False          # 照合前に確定するため通信していない
                continue

            if plan.action == "resume":
                print(f"  [{i}] -- 再開スキップ（前回処理済み）: {plan.summary}")
                counts["resumed"] += 1
                # 再開スキップもログに残す。残さないと --resume を繰り返した
                # ときにログが痩せ、次の再開で作成済みの行が再作成される。
                log(row=i, action="resumed", summary=plan.summary)
                api_called = False          # 照合より前に判定するため通信していない
                continue

            if plan.action == "unchanged":
                # 内容が同じ。PATCH を投げても Backlog が
                # "No comment content." を返すだけなので送らない。
                # 確認も求めない（判断することが無いため）。
                print(f"  [{i}] -- 変更なし: {plan.existing_key} ― {plan.summary}")
                counts["unchanged"] += 1
                if row_warnings:
                    counts["partial"] += 1
                log(row=i, action="unchanged", issue_key=plan.existing_key or "",
                    summary=plan.summary, detail=" / ".join(row_warnings))
                api_called = False
                continue

            # 書き込む直前に 1 行ずつ確認する。
            # まとめて一気に書き込むと、件数が多いときに何が起きたのか
            # 把握しきれないため、作成・更新のどちらも都度確認する。
            if confirmer is not None and not confirmer.confirm(plan, mapper):
                print(f"  [{i}] -- スキップ（新規作成を見送り）: {plan.summary}")
                counts["skipped"] += 1
                log(row=i, action="skipped", summary=plan.summary,
                    detail="新規作成を見送り", op=plan.action)
                api_called = False
                continue

            if existing_key:
                # projectId は更新時不要なので除去
                update_params = {k: v for k, v in params.items() if k != "projectId"}
                try:
                    client.update_issue(existing_key, update_params)
                    print(f"  [{i}] OK 更新: {existing_key} ― {params.get('summary', '')}")
                    counts["updated"] += 1
                    if row_warnings:
                        counts["partial"] += 1
                    log(row=i, action="updated", issue_key=existing_key,
                        summary=params.get("summary", ""),
                        detail=" / ".join(row_warnings))
                except BacklogNoChangeError as nce:
                    # 実際の Backlog エラーメッセージを表示して誤検出を確認できるようにする
                    print(f"  [{i}] -- 変更なし: {existing_key} ― {params.get('summary', '')}")
                    print(f"    Backlog message: {nce}", file=sys.stderr)
                    counts["unchanged"] += 1
                    if row_warnings:
                        counts["partial"] += 1
                    log(row=i, action="unchanged", issue_key=existing_key,
                        summary=params.get("summary", ""),
                        detail=" / ".join([str(nce), *row_warnings]))
            else:
                try:
                    api_called = True
                    issue = create_issue_with_status(client, params)
                    print(f"  [{i}] OK 作成: {issue['issueKey']} ― {issue['summary']}")
                    counts["created"] += 1
                    if row_warnings:
                        counts["partial"] += 1
                    log(row=i, action="created", issue_key=issue["issueKey"],
                        summary=issue["summary"], detail=" / ".join(row_warnings))
                    if summary_index is not None:
                        summary_index.add(issue["summary"], issue)
                except StatusUpdateFailed as e:
                    # 課題は作成済み。issueKey を必ず表示する（Backlog 上に
                    # 取り残されたことに気づけないと重複作成につながる）
                    issue = e.issue
                    print(
                        f"  [{i}] 警告 作成（ステータス変更は失敗）: "
                        f"{issue['issueKey']} ― {issue['summary']}"
                    )
                    print(f"    {e.cause}", file=sys.stderr)
                    counts["created"] += 1
                    counts["status_failed"] += 1
                    if summary_index is not None:
                        summary_index.add(issue["summary"], issue)
                    if row_warnings:
                        counts["partial"] += 1
                    log(row=i, action="created_status_failed",
                        issue_key=issue["issueKey"], summary=issue["summary"],
                        detail=" / ".join([str(e.cause), *row_warnings]))

        except BacklogAPIError as e:
            print(f"  [{i}] NG 失敗: {params.get('summary', '')}", file=sys.stderr)
            print(f"    {e}", file=sys.stderr)
            counts["error"] += 1
            log(row=i, action="error", summary=params.get("summary", ""), detail=str(e),
                op=("update" if existing_key else "create") if params else "")
            # 認証・権限エラーは以降の行でも必ず失敗するため実行全体を中止する
            if e.fatal:
                raise
        finally:
            # API レート制限対策。以前は成功パスにしか無かったため、
            # エラーが続くと逆に速くリクエストが飛んでいた。
            if api_called:
                time.sleep(0.3)

    return counts


# ------------------------------------------------------------------
# メイン
# ------------------------------------------------------------------

def main():
    # Windows の日本語コンソール（CP932）で、Excel や Backlog から来る文字で落ちないように（ほかより先に）
    make_console_safe()
    # 外から止められたとき（コマンドを動かす道具の時間切れなど）も、Ctrl+C と同じくまとめと再開の案内を出す
    stop_on_sigterm()
    # --help の日本語と、同じ意味の引数の説明は、5 つのツールで共通の部品
    parser = cli.make_parser(
        __file__,
        description="Excel の行から Backlog の課題を作成・更新する",
        epilog="""
使い方の例:
  python excel_to_backlog.py                        # ドライラン（既定）
  python excel_to_backlog.py --preview              # プレビューファイルを生成
  python excel_to_backlog.py --execute              # 実際に登録/更新
  python excel_to_backlog.py --source "タスク管理表"          # ソース指定（ドライラン）
  python excel_to_backlog.py --source "タスク管理表" --execute # ソース指定して実行
  python excel_to_backlog.py --config ./config.yaml --execute
""",
    )
    cli.add_version(parser, TOOL_NAME, __version__)
    # 設定ファイルの既定値は、ツールのフォルダの config.yaml（find_config。5 つのツールで同じ）
    cli.add_config(parser)
    parser.add_argument(
        "--source",
        metavar="NAME",
        help="処理するソース名（省略時: 全ソースを処理）",
    )
    parser.add_argument(
        "--preview",
        action="store_true",
        help="登録予定の課題内容（本文全文含む）を Markdown ファイルに出力して確認する",
    )
    cli.add_execute(parser)
    parser.add_argument(
        "--limit",
        type=cli.positive_int,
        metavar="N",
        help="各ソースで処理する行数を先頭 N 行に制限する（初回に少数だけ試す用）",
    )
    parser.add_argument(
        "--show-columns",
        action="store_true",
        help="Excel から読み取れる列名を一覧表示する（Backlog へは接続しない）",
    )
    parser.add_argument(
        "--list-master",
        action="store_true",
        help="設定に使える名前（種別・優先度・ステータス・担当者・カスタム属性）を一覧表示する",
    )
    cli.add_yes(parser)
    plans.add_plan_options(parser)
    parser.add_argument(
        "--resume",
        metavar="CSV",
        help="過去の実行ログ（run_*.csv）を読み、作成・更新済みの行を飛ばして再開する",
    )
    cli.add_output_dir(parser, "output_dir", "output", what="プレビュー・実行ログの出力先のフォルダ")
    parser.add_argument(
        "--no-log",
        action="store_true",
        help="実行ログ（run_*.csv）を出力しない",
    )
    cli.add_debug(parser)
    # メニュー（menu.py）から動かしたとき。ドライランの最後の案内を、メニューの項目の名前にする（--help には出さない）
    parser.add_argument("--from-menu", action="store_true", help=argparse.SUPPRESS)
    argv = sys.argv[1:]
    args = parser.parse_args(argv)
    # デフォルトはドライラン。--execute が指定された場合のみ実処理を行う。
    dry_run = not args.execute
    if plans.yes_refused(args.yes and args.execute):
        # この端末では、書き込みの許可を --yes で示せない（環境変数で拒んでいる）。設定も読まず、Backlog にもつながない
        print(plans.refused_yes_text(__file__, argv), file=sys.stderr)
        sys.exit(EXIT_NEEDS_CONFIRMATION)
    try:
        plan_request = plans.PlanRequest.from_args(args, TOOL_NAME, __version__, plan_args={
            "source": args.source, "limit": args.limit, "resume": args.resume,
        })
    except plans.PlanError as e:
        print(f"エラー: {e}", file=sys.stderr)
        sys.exit(plans.EXIT_PLAN_MISMATCH)

    if args.preview and args.execute:
        parser.error("--preview と --execute は同時に指定できません。")

    # 設定読み込み
    args.config = find_config(args.config)
    config = load_config(args.config)

    # 設定キーの綴り間違いは dict.get() の既定値で静かに無視され、意図と違う動作になる。読み込み直後に検出する。
    # 知らない項目・値の誤りと、空・例のままの必須の項目を、1 つの一覧で示す（1 つ直すと次が出る、にしない。5 つのツールで同じ形）
    problems = [line.strip() for line in validate_config_keys(config, ["space_host", "project_key"])]
    if problems:
        print("エラー: " + config_files.problems_text(args.config, problems), file=sys.stderr)
        sys.exit(EXIT_CONFIG)
    backlog_cfg = backlog_section(config)
    sources_cfg = config.get("sources") or []

    api_key_source = validate_backlog_config(backlog_cfg, args.config)

    # 設定ファイルに書いた excel.path の相対パスは、設定ファイルのある場所から読む（5 つのツールで同じ決まり）。
    # 書いた値そのもの（本文の {{_excel_path}} に入る）は変えない
    config_dir = Path(args.config).resolve().parent
    for source_cfg in sources_cfg:
        if isinstance(source_cfg.get("excel"), dict):
            source_cfg["excel"][ExcelReader.BASE_DIR_KEY] = str(config_dir)

    # --list-master は設定を書く前に使うため、sources がまだ無くても通す
    if not sources_cfg and not args.list_master:
        print("エラー: " + config_files.problems_text(args.config, ["sources が空です"]), file=sys.stderr)
        sys.exit(1)

    # ソースの絞り込み
    if args.source:
        sources_cfg = [s for s in sources_cfg if s.get("name") == args.source]
        if not sources_cfg:
            names = [s.get("name", "（名前なし）") for s in config.get("sources", [])]
            print(
                f"エラー: ソース「{args.source}」が見つかりません。"
                f"（定義済み: {names}）",
                file=sys.stderr,
            )
            sys.exit(1)

    # プレビューと実行ログの出力先。設定ファイルと同じ場所に出すと
    # 実行のたびにファイルが増えて元のファイルに混ざるため、分けている。
    output_dir = resolve_output_dir(config, args.config, args.output_dir)

    # ヘッダー
    print("=" * 55)
    print("Excel から Backlog へ課題を登録")
    print("=" * 55)
    print(f"接続先      : {backlog_cfg['space_host']}")
    print(f"プロジェクト : {backlog_cfg['project_key']}")
    print(f"ソース数    : {len(sources_cfg)}")
    print(f"出力先      : {output_dir}")
    if args.preview:
        print("モード      : プレビュー（登録内容を Markdown のファイルに書き出します）")
    elif dry_run:
        print("モード      : ドライラン（Backlog には何も送りません）")
    else:
        print("モード      : 実行（Backlog に作成・更新します）")
    print()

    # --show-columns: Excel の列名だけ表示して終了。
    # 設定を書いている途中で使うため、Backlog への接続は行わない。
    if args.show_columns:
        sys.exit(1 if print_source_columns(sources_cfg) else 0)

    # BacklogClient 初期化
    client = BacklogClient(
        space_host=backlog_cfg["space_host"],
        api_key=backlog_cfg["api_key"],
        ssl_verify=backlog_cfg.get("ssl_verify", True),
        base_path=backlog_cfg.get("base_path", ""),
        debug=args.debug,
        **config_files.client_settings(backlog_cfg),
    )

    # マスターデータ取得（ドライランでも接続確認のため取得）
    print("マスターデータを取得中...")
    try:
        master = BacklogMaster.build(client, backlog_cfg["project_key"])
    except BacklogAPIError as e:
        e.api_key_source = e.api_key_source or api_key_source
        print(format_api_error(e), file=sys.stderr)
        sys.exit(1)

    # --list-master: 設定に書ける名前を一覧表示して終了
    if args.list_master:
        print_master_data(master)
        return

    print(
        f"  種別: {list(master.issue_type_map.keys())}\n"
        f"  優先度: {list(master.priority_map.keys())}\n"
        f"  ステータス: {list(master.status_map.keys())}\n"
        f"  メンバー数: {len(master.user_map)} 名"
    )

    # --preview モード: Markdown ファイルを生成して終了
    if args.preview:
        # 秒までの日時なので、同じ秒に続けて動かすと前のプレビューを上書きしていた。重なれば _2 を付ける
        names = [
            "preview_{}_" + _safe_filename(s.get("name", "source")).replace("{", "{{").replace("}", "}}") + ".md"
            for s in sources_cfg
        ]
        timestamp = unique_stamp(output_dir, names)
        print("プレビューファイルを生成中...")
        output_dir.mkdir(parents=True, exist_ok=True)   # 出力先のフォルダは、書くときに作る
        results = generate_preview_file(sources_cfg, master, output_dir, timestamp)
        total_issues = sum(count for _, count in results)
        print(f"\n{'='*55}")
        print("プレビュー生成完了")
        print(f"{'='*55}")
        for path, count in results:
            print(f"  {path.name}  （{count} 件）")
        print(f"{'─'*55}")
        print(f"  合計: {total_issues} 件")
        print()
        print(f"  内容を確かめたら、Backlog に反映するには{execute_hint(args.from_menu)}。")
        return

    # 各ソースを処理
    # 途中で中断・失敗しても、それまでの処理結果を必ず表示する。
    # 以前は通信エラーがトレースバックのまま抜けてサマリーが出ず、
    # 何件作成済みかを知る手段がターミナルのログしか無かった。
    total = new_counts()
    interrupted = ""

    # 実行ログ。ドライランでは書き込みが発生しないため出力しない。
    log_path = None
    if not dry_run and not args.no_log:
        # 秒までの日時なので、同じ秒に続けて動かすと前の実行ログ（--resume に使う）を上書きしていた。重なれば _2 を付ける
        log_path = default_log_path(output_dir, unique_stamp(output_dir, ["run_{}.csv"]))

    completed = load_resume_log(args.resume, output_dir) if args.resume else None

    # 件名索引は遅延構築のため、match_summary を使うソースが無ければ API を呼ばない
    summary_index = SummaryIndex(client, master.project_id)

    # 計画のファイル（--plan-out・--plan）。入力は設定ファイルと、各ソースの Excel と、--resume の実行ログ
    if plan_request.active():
        plan_request.inputs = source_inputs(args.config, sources_cfg, args.resume)
    if not dry_run and plan_request.active():
        # 1 行ずつ書き込むので、書く前に全ソースをドライランと同じ処理で通して計画を立て直し、照らし合わせる
        print("計画を立て直しています（Backlog には何も送りません）…")
        operations = collect_operations(sources_cfg, client, master, completed, args.limit)
        if not plan_request.settle(operations):
            sys.exit(plans.EXIT_PLAN_MISMATCH)

    # 確認は Backlog へ書き込む場合のみ。ドライランは何も変更しないため、
    # 確認を求めると無意味な入力待ちになり、端末でない所では実行すらできなくなる。
    if not dry_run:
        try:
            confirm_run(sources_cfg, master, assume_yes=args.yes)
        except ConfirmationDeclined as e:
            # 何も送っていない。設定の誤り（1）と分け、呼び出した側が人に許可を求めると分かるようにする
            print(f"エラー: {e}", file=sys.stderr)
            sys.exit(EXIT_NEEDS_CONFIRMATION)

    # ドライランで作る計画（--plan-out・--plan）と、実行の結果（--result-out）
    dry_operations: list[dict] | None = [] if dry_run and plan_request.active() else None
    result = plans.ResultLog(None if dry_run else args.result_out, TOOL_NAME, __version__)
    if plan_request.current is not None:
        result.start(plan_request.current)
    with ExitStack() as stack:
        run_log = stack.enter_context(RunLog(log_path)) if log_path else None
        stack.enter_context(result)
        try:
            # 実行時は 1 行ずつ確認する（ドライランでは確認しない）
            confirmer = (
                None if dry_run
                else RowConfirmer(assume_yes=args.yes,
                                  master_labels=build_master_labels(master))
            )
            for source_cfg in sources_cfg:
                # total を直接渡す。ソースの途中で中断しても、それまでの
                # 集計が total に残りサマリーに反映される。
                process_source(
                    source_cfg, client, master, dry_run=dry_run,
                    run_log=run_log, completed=completed,
                    summary_index=summary_index, counts=total,
                    limit=args.limit, confirmer=confirmer,
                    operations=dry_operations, result=result,
                )
        except ConfirmationDeclined as e:
            interrupted = str(e)
        except KeyboardInterrupt:
            result.close("interrupted", 1)
            # 中断の知らせと注意は、ほかのツールと同じ文（送信中だった行の注意は、送るときだけ）
            interrupted = "中断しました（Ctrl+C か、外から止められた）。残りの行は送っていません。"
            if not dry_run:
                interrupted += ("\n  中断したときに送信中だった行は、反映されたか分かりません。"
                                "Backlog の画面で確かめてください。")
        except BacklogAPIError as e:
            # 文の形は共通の部品（5 つのツールで同じ）。クライアントは API キーの出どころを知らないので、ここで渡す
            e.api_key_source = e.api_key_source or api_key_source
            interrupted = format_api_error(e) + "\n  API エラーのため中止しました。残りの行は送っていません。"
        finally:
            print_summary(
                total, dry_run=dry_run, interrupted=interrupted, log_path=log_path, from_menu=args.from_menu
            )

    # 中断だけでなく、1 件でも失敗があれば異常終了とする。
    # 以前は全行が設定ミスで失敗しても終了コード 0 で終わっていた。
    code = 1 if interrupted or total["error"] else 0
    if dry_operations is not None and not interrupted and not plan_request.settle(dry_operations):
        code = plans.EXIT_PLAN_MISMATCH
    result.close("failed" if code else "done", code)
    if code:
        sys.exit(code)


def source_inputs(config_path: str, sources_cfg: list, resume: str | None) -> dict:
    """計画の入力のファイルの指紋。設定ファイル・各ソースの Excel（excel_reader と同じ探し方）・--resume の実行ログ。"""
    inputs = {"config": plans.file_digest(config_path)}
    for source_cfg in sources_cfg:
        excel_cfg = source_cfg.get("excel") or {}
        if not excel_cfg.get("path"):
            continue
        path = Path(str(excel_cfg["path"])).expanduser()
        base_dir = excel_cfg.get(ExcelReader.BASE_DIR_KEY)
        if base_dir and not path.is_absolute():
            path = Path(base_dir) / path
        inputs["excel:" + str(source_cfg.get("name", "（名前なし）"))] = plans.file_digest(str(path))
    if resume:
        inputs["resume"] = plans.file_digest(resume)
    return inputs


def collect_operations(sources_cfg: list, client: BacklogClient, master: BacklogMaster,
                       completed: set[tuple[str, str, str]] | None, limit: int | None) -> list[dict]:
    """
    全ソースをドライランと同じ処理で通し、作成・更新する行の操作を集める（--plan で実行する前の照合）。

    画面の出力は抑える（ドライランの表示は計画を書いたときに見せてある）。件名の索引は、ドライランが作成予定の
    件名を足すので、実行に使うものとは別に作る。
    """
    operations: list[dict] = []
    index = SummaryIndex(client, master.project_id)
    with redirect_stdout(io.StringIO()), redirect_stderr(io.StringIO()):
        for source_cfg in sources_cfg:
            process_source(source_cfg, client, master, dry_run=True, completed=completed, summary_index=index,
                           limit=limit, operations=operations)
    return operations


def load_resume_log(path: str, output_dir: Path) -> set[tuple[str, str, str]]:
    """
    --resume の実行ログを読む。見つからなければ案内して終了コード 1 で終える。

    実行ログは出力先のフォルダに書かれるが、--resume のパスは作業フォルダからの
    相対で開く。ファイル名だけを渡されると見つからないことがあるため、出力先に
    同じ名前のファイルがあればそのパスを示す。
    """
    try:
        return load_completed(path)
    except FileNotFoundError:
        print(f"エラー: 実行ログが見つかりません: {path}", file=sys.stderr)
        candidate = output_dir / Path(path).name
        if candidate.is_file():
            print(f'  出力先のフォルダにあります: --resume "{candidate.resolve()}"', file=sys.stderr)
        else:
            print(f"  実行ログは出力先のフォルダ（{output_dir}）に書かれます。", file=sys.stderr)
            print("  前回のまとめの「実行ログ:」の行のパスを指定してください。", file=sys.stderr)
        sys.exit(1)


def execute_hint(from_menu: bool) -> str:
    """
    ドライラン・プレビューの最後の案内（「Backlog に反映するには〜。」の〜）。メニューから動かしたときは、メニューの項目の名前で示す
    （issue_sheet と同じ。メニューを使う人に --execute を示しても、どうすればよいか分からない）。
    オプション名は前後を空白で区切る（日本語に続けて書くと読みにくい）。メニューの案内は日本語どうしなので詰める
    """
    return "メニューの「実行」を選んでください" if from_menu else " --execute を付けてください"


def print_summary(total: dict, *, dry_run: bool, interrupted: str = "",
                  log_path=None, from_menu: bool = False) -> None:
    """処理結果のサマリーを表示する。"""
    print(f"\n{'='*55}")
    print("処理完了" if not interrupted else "処理中断")
    print(f"{'='*55}")

    if interrupted:
        # 止めた理由はエラーの出力に、件数のまとめは画面の出力に出す（5 つのツールで同じ）
        print(interrupted, file=sys.stderr)
        print()

    if dry_run:
        # ドライランは実行と同じ計画を組み立てているため、作成/更新の内訳まで
        # 予測できる。算出しているのに表示しないと RowPlan を入れた意味がない。
        print("（ドライランのため、Backlog には何も送っていません）")
        print(f"  作成予定: {total['created']} 件")
        print(f"  更新予定: {total['updated']} 件")
        if total["resumed"]:
            print(f"  再開スキップ: {total['resumed']} 件（前回処理済み）")
        if total["skipped"]:
            print(f"  スキップ: {total['skipped']} 件")
        if total["partial"]:
            print(f"  うち一部フィールド未設定: {total['partial']} 件")
        if total["error"]:
            print(f"  エラー: {total['error']} 件  ← 読み込み・設定に問題があります")
        # 書き込みの回数と時間の目安は最後の 1 行（5 つのツールで同じ）。書くものが無ければ出さない
        writes = total["created"] + total["updated"] + total["status_planned"]
        if writes:
            print(f"  Backlog に反映するには{execute_hint(from_menu)}。")
            print("  " + estimate_text(writes))
        return

    print(f"  作成: {total['created']} 件")
    print(f"  更新: {total['updated']} 件")
    print(f"  変更なし: {total['unchanged']} 件")
    print(f"  スキップ: {total['skipped']} 件")
    if total["partial"]:
        print(f"  うち一部フィールド未設定: {total['partial']} 件")
        print("    実行ログの detail 列に、どのフィールドが落ちたか記録しています。")
    if total["resumed"]:
        print(f"  再開スキップ: {total['resumed']} 件（前回処理済み）")
    print(f"  エラー: {total['error']} 件")
    if total["status_failed"]:
        print()
        print(
            f"  警告: うち {total['status_failed']} 件は作成できましたが"
            f"ステータス変更に失敗しています。"
        )
        print("    課題は Backlog に存在します。上のログの issueKey を確認してください。")

    if log_path is not None:
        print()
        print(f"  実行ログ: {log_path}")
        # 作成・更新が済んだ行が無ければ、再開しても最初から動かすのと同じなので案内しない
        # （1 行目の確認で q を選んだときに、何もしていないのに再開を勧めていた）
        done = total["created"] + total["updated"] + total["unchanged"] + total["resumed"]
        if (interrupted or total["error"]) and done:
            # 実行ログは出力先のフォルダにあり、--resume は作業フォルダからの相対で
            # 開く。以前はファイル名だけを示していたため、写して動かすと見つからなかった。
            print(f'  続きから再開するには: --resume "{Path(log_path).resolve()}"')


if __name__ == "__main__":
    # 処理の繰り返しの外（マスターの取得・--preview・--show-columns など）で Ctrl+C を押しても、トレースバックを出さない。
    # 中断の終了コードは、このツールでは 1（README の「終了コード」。繰り返しの中で止めたときと同じ）
    exit_on_interrupt(main, code=1)
