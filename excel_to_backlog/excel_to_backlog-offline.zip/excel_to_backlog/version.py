"""excel_to_backlog の版。CHANGELOG.md の最新の版と同じにする（版を切ったら上げる）。"""

TOOL_NAME = "excel_to_backlog"
__version__ = "0.21.2"
