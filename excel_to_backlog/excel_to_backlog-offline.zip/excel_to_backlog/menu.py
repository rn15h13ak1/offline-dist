"""
Excel → Backlog 課題登録 対話メニュー
=====================================
ドライラン・プレビュー・実行・列名の一覧・使える名前の一覧を、番号を選ぶだけで実行する。
作りは同じ種類のツールのメニューに揃えている。

  python menu.py                  # メニューを表示
  python menu.py --config my.yaml # 設定ファイルを指定

本体（excel_to_backlog.py）は別のプロセスとして呼ぶ。
無人実行にはメニューではなく本体を使うこと:
  python excel_to_backlog.py --execute --yes
"""

from __future__ import annotations

import argparse
from pathlib import Path

from backlog_common.menu import (
    EXIT_EOF,  # noqa: F401  （終了コード。ツールを起動する側と、同じ種類のツールのメニューに揃える）
    EXIT_INTERRUPTED,  # noqa: F401
    EXIT_OK,  # noqa: F401
    confirm,
    exit_menu,
    hr,
    print_menu,
    run_loop,
    run_script,
    show_result,
    wait_enter,
)
from backlog_common.menu import load_history as _load_history
from backlog_common.menu import save_history as _save_history
from backlog_common.runtime import make_console_safe

TOOL_DIR = Path(__file__).resolve().parent
SCRIPT = TOOL_DIR / "excel_to_backlog.py"
HISTORY_PATH = Path.home() / ".excel_to_backlog_menu.json"

ACTION_DRY_RUN = "dry_run"
ACTION_PREVIEW = "preview"
ACTION_EXECUTE = "execute"
ACTION_COLUMNS = "columns"
ACTION_MASTER = "master"

# 番号の並びは、メニューを並べるランチャーがこのツールに渡している選択肢と揃える。新しい項目は末尾に足す
ACTIONS = [
    (ACTION_DRY_RUN, "ドライラン", "変換結果と、作成・更新の予定を確かめる（Backlog は変えない）"),
    (ACTION_PREVIEW, "プレビュー", "登録する課題の本文全文を Markdown のファイルに出す"),
    (ACTION_EXECUTE, "実行", "Backlog に課題を作成・更新する（新規作成は 1 件ずつ確認する）"),
    (ACTION_COLUMNS, "列名の一覧", "Excel から読み取れる列名を表示する（Backlog には接続しない）"),
    (ACTION_MASTER, "使える名前の一覧", "種別・優先度・ステータス・担当者・カスタム属性の名前を表示する"),
]

#: 操作 → 本体に渡す引数
ACTION_ARGS = {
    ACTION_DRY_RUN: [],
    ACTION_PREVIEW: ["--preview"],
    ACTION_EXECUTE: ["--execute"],
    ACTION_COLUMNS: ["--show-columns"],
    ACTION_MASTER: ["--list-master"],
}


def load_history() -> dict:
    """前回の選択を読む。壊れていても既定値で続行する。"""
    return _load_history(HISTORY_PATH)


def save_history(data: dict) -> None:
    """選択を保存する。書けなくても実行は妨げない。"""
    _save_history(HISTORY_PATH, data)


def find_config(explicit: str | None) -> Path | None:
    """
    本体が読む設定ファイル。指定が無ければ作業フォルダ、無ければツールのフォルダの config.yaml（本体と同じ順）。
    menu.bat はツールのフォルダへ移ってから動くので、ふつうはツールのフォルダのものになる。
    """
    if explicit:
        return Path(explicit)
    for candidate in (Path.cwd() / "config.yaml", TOOL_DIR / "config.yaml"):
        if candidate.is_file():
            return candidate
    return None


def describe_config(explicit: str | None) -> str:
    path = find_config(explicit)
    if path is None:
        return "※ config.yaml がありません（config.minimal.yaml をコピーして作成してください）"
    if not path.is_file():
        return f"※ 設定ファイルがありません: {path}"
    return str(path)


def build_args(action: str, config: str | None) -> list[str]:
    """本体に渡すコマンドライン引数を組み立てる。"""
    args = ["--config", config] if config else []
    return args + ACTION_ARGS[action]


def run(args: list[str]) -> int:
    """本体を実行して終了コードを返す。"""
    return run_script(SCRIPT, args, TOOL_DIR)


def run_action(action: str, config: str | None, history: dict) -> int | None:
    """1 つの操作を実行する。戻る場合は None。"""
    if action == ACTION_EXECUTE:
        # 本体も新規作成を 1 件ずつ確認するが、更新は確認せずに行う。取り消せない操作なので、ここで 1 回確認する
        print()
        print("  Backlog に課題を作成・更新します。既存の課題は Excel の内容で上書きされます。")
        print("  先に「ドライラン」で、作成・更新の予定を見ておくことを勧めます。")
        if not confirm("実行しますか？"):
            print("  実行しませんでした。")
            return None
    history["action"] = action
    save_history(history)
    return run(build_args(action, config))


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        description="Excel → Backlog 課題登録 対話メニュー",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="無人実行には excel_to_backlog.py を直接使ってください。",
    )
    parser.add_argument("--config", help="設定ファイル（既定: 作業フォルダの config.yaml、無ければツールのフォルダ）")
    return parser


def main() -> None:
    # 入力されたパスなどに CP932 に無い文字があっても、Windows のコンソールが落ちないように
    make_console_safe()
    config = build_parser().parse_args().config
    if config:
        # 本体はツールのフォルダで動かすため、相対パスは起動した場所を基準に絶対パスにしておく
        config = str(Path(config).resolve())
    history = load_history()
    last_action = history.get("action")
    default_choice = next((i for i, (key, _, _) in enumerate(ACTIONS, 1) if key == last_action), None)
    # 前回が「実行」でも、既定にはしない（Enter だけで実行の確認まで進まないように）
    if last_action == ACTION_EXECUTE:
        default_choice = None
    items = [f"{label} ― {desc}" for _, label, desc in ACTIONS]

    def loop() -> None:
        nonlocal default_choice
        while True:
            print()
            hr()
            print("  Excel から Backlog へ課題を登録")
            hr()
            print(f"  設定ファイル: {describe_config(config)}")
            choice = print_menu("操作を選択", items, back_label="終了",
                                default=default_choice, default_mark="前回")
            if choice == 0:
                exit_menu()
            action = ACTIONS[choice - 1][0]
            rc = run_action(action, config, history)
            if rc is not None:
                show_result(f"終了コード: {rc}")
                if action != ACTION_EXECUTE:
                    default_choice = choice
                wait_enter()

    run_loop(loop)


if __name__ == "__main__":
    main()
