@echo off
rem ===========================================================
rem  excel_to_backlog - interactive menu launcher
rem  Double-click this file to start the menu.
rem
rem  Messages here are ASCII on purpose: this file must stay
rem  readable in any console code page.
rem ===========================================================

rem Move to this file's folder. pushd (not cd) so that a UNC
rem path on a shared drive also works.
pushd "%~dp0" || (
    echo [ERROR] Cannot enter the folder of this script.
    pause
    exit /b 1
)

rem Pick the Python to run the menu with. Candidates, in order: a .venv in
rem this folder, python on PATH, then the py launcher. The first one
rem that can import the libraries this tool needs is used: on a PC with
rem both Anaconda and the python.org Python, only one may have them.
rem If none can, the first one that runs is used, and the tool itself
rem says what is missing.
set PYTHON=
set FALLBACK=
if exist ".venv\Scripts\python.exe" call :try ".venv\Scripts\python.exe"
if not defined PYTHON call :try python
if not defined PYTHON call :try py -3
if not defined PYTHON set PYTHON=%FALLBACK%
if not defined PYTHON (
    echo [ERROR] Python 3 was not found.
    echo         Install Python 3.10 or later from https://www.python.org/
    echo         and make sure it is added to PATH.
    popd
    pause
    exit /b 1
)

rem "call" so that a python.cmd (e.g. from pyenv-win) returns here and
rem the exit code and pause below still run.
call %PYTHON% menu.py %*
set RC=%ERRORLEVEL%

popd
if not "%RC%"=="0" echo.& echo [exit code %RC%]

rem Pause only when double-clicked, so the window stays open to read errors.
rem With arguments (e.g. --config from a shortcut or Task Scheduler) the caller
rem owns the console, and pause would wait forever when nobody is watching.
if "%~1"=="" pause
exit /b %RC%

rem Use the given command as the Python if it runs. "call" lets a python.cmd
rem return here. Prefer the first one that can import openpyxl, yaml.
:try
call %* --version >nul 2>&1 || exit /b 0
if not defined FALLBACK set FALLBACK=%*
call %* -c "import openpyxl, yaml" >nul 2>&1 && set PYTHON=%*
exit /b 0
