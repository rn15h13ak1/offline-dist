"""
Backlog 課題クローンツール
==========================
指定した課題の description をコピーして新規課題を作成する CLI ツール。
親課題を指定した場合は、その子課題もまとめて複製する。

複製先の決め方は設定で 3 通りに変わる:
  どちらも省略             : 重複チェックせず毎回新規作成（単純複製）
  clone.summary_template   : その件名で探し、無ければ作成・あれば更新（定期作成）
  clone.target_issue_key   : 検索せずその課題（と子課題）を直接更新（直接更新）

使い方:
  python3 backlog_issue_cloner.py                    # ドライラン（デフォルト）
  python3 backlog_issue_cloner.py --execute          # 実際に作成/更新（対話確認あり）
  python3 backlog_issue_cloner.py --execute --yes    # 確認なしで実行（cron 向け）
  python3 backlog_issue_cloner.py --date 20260401    # 日付を指定
  python3 backlog_issue_cloner.py --execute --debug  # デバッグ出力付き
  python3 backlog_issue_cloner.py --config my.yaml   # 設定ファイルを指定
  python3 backlog_issue_cloner.py --detailed-exit-code
                                                     # 結果を終了コードで区別する

終了コード:
  0  正常終了
  2  設定エラー
  3  API / ネットワークエラー
  20 確認が得られずスキップした（--yes なしの非対話実行、またはユーザーが拒否）

  --detailed-exit-code を付けた場合、正常終了時は結果を区別して返す:
  0  変更なし / 10 新規作成した / 11 本文を更新した

依存:
  pip3 install pyyaml

詳細は README.md を参照。
"""

import argparse
import re
import sys
import time
import unicodedata
from dataclasses import dataclass
from datetime import datetime
from pathlib import Path

# 画面への出力の手当て（入口で先に呼ぶ）。5 つのツールで共通の部品にある。menu.py も cloner.make_console_safe で使う
# 設定ファイルと API キーの読み込みも共通の部品にある
from backlog_common import client as backlog_client
from backlog_common import config as config_files
from backlog_common.runtime import make_console_safe

try:
    import yaml  # noqa: F401  （設定ファイルを読む共通の部品が使う。無ければここで案内する）
except ModuleNotFoundError as e:
    # 依存が入っていない Python で起動したとき、トレースバックではなく
    # 対処を表示する。Windows では py ランチャ経由で複数の Python が
    # 入っていることがあり、入れた先と動かしている先が違うと
    # 「pip install したのに直らない」が起きるため、実行中のパスも出す。
    if e.name != "yaml":
        raise                      # 無関係な失敗は握り潰さない
    print("必要なライブラリ PyYAML が入っていません。", file=sys.stderr)
    print(f"実行中の Python: {sys.executable}", file=sys.stderr)
    print("次のコマンドでインストールしてください:", file=sys.stderr)
    print("    pip install pyyaml", file=sys.stderr)
    sys.exit(2)                    # EXIT_CONFIG_ERROR（定義はこの下）


# ===========================================================================
# 例外・定数
# ===========================================================================


# 設定ファイルの内容が不正、または前提条件を満たさないエラー。設定ファイルと API キーを読む共通の部品と同じもの
ConfigError = config_files.ConfigError


# Backlog API の呼び出しに失敗したエラー。通信の共通の部品のもの（BacklogNoChangeError も BacklogError の子）
BacklogError = backlog_client.BacklogError
BacklogAPIError = backlog_client.BacklogAPIError
BacklogNoChangeError = backlog_client.BacklogNoChangeError


# 実行結果
OUTCOME_NO_CHANGE = "no_change"
OUTCOME_CREATED = "created"
OUTCOME_UPDATED = "updated"
OUTCOME_SKIPPED = "skipped"

# 終了コード
EXIT_OK = 0
EXIT_CONFIG_ERROR = 2
EXIT_API_ERROR = 3
EXIT_CREATED = 10
EXIT_UPDATED = 11
EXIT_SKIPPED = 20

# 課題の状態 ID（Backlog 共通）: 1=未対応 2=処理中 3=処理済み 4=完了
STATUS_IDS_OPEN = [1, 2, 3]

MATCH_MODES = ("substring", "exact")

# 件名テンプレートの既定値。コピー元の件名をそのまま使う。
DEFAULT_SUMMARY_TEMPLATE = "{SOURCE_SUMMARY}"

# backlog セクションで受け付ける数値設定と、その最小値
NUMERIC_SETTINGS = (
    ("timeout", 1),
    ("max_retries", 0),
    ("retry_backoff", 0),
    ("retry_max_delay", 0),
)


# カスタム属性の種別 ID（Backlog 共通）
# 1 文字列 / 2 文章 / 3 数値 / 4 日付 / 5 単一リスト / 6 複数リスト
# 7 チェックボックス / 8 ラジオボタン
CUSTOM_FIELD_DATE = 4
CUSTOM_FIELD_SINGLE_SELECT = (5, 8)
CUSTOM_FIELD_MULTI_SELECT = (6, 7)

CUSTOM_FIELD_TYPE_NAMES = {
    1: "文字列", 2: "文章", 3: "数値", 4: "日付",
    5: "単一リスト", 6: "複数リスト", 7: "チェックボックス", 8: "ラジオボタン",
}


def configured_custom_field_params(spec) -> dict:
    """
    設定ファイルの clone.custom_fields を作成 API のパラメータ形式に変換する。
    コピー元に値が入っていない必須のカスタム属性を補うために使う。
    """
    if not spec:
        return {}
    if not isinstance(spec, dict):
        raise ConfigError(
            "config.yaml の clone.custom_fields は"
            "「カスタム属性の ID: 値」の形式で指定してください。"
        )
    params = {}
    for key, value in spec.items():
        field_id = str(key)
        if not field_id.isdigit():
            raise ConfigError(
                "config.yaml の clone.custom_fields のキーはカスタム属性の ID"
                f"（数値）で指定してください: {key!r}"
            )
        if value is None:
            continue
        params[f"customField_{field_id}"] = value
    return params


def inherited_issue_params(issue: dict) -> dict:
    """
    コピー元の課題から引き継ぐ属性を、課題作成 API のパラメータ形式に変換する。

    複製先はコピー元と同じプロジェクトに限られるため、カテゴリー・マイルストーン・
    バージョンの ID をそのまま使える。実績時間は「実際に掛かった時間」なので
    複製せず、添付ファイルは ID を渡しても複製できないため対象外。
    """
    params = {}

    assignee = issue.get("assignee") or {}
    if assignee.get("id") is not None:
        params["assigneeId"] = assignee["id"]

    for param, field in (("categoryId", "category"),
                         ("versionId", "versions"),
                         ("milestoneId", "milestone")):
        ids = [v["id"] for v in (issue.get(field) or [])
               if isinstance(v, dict) and v.get("id") is not None]
        if ids:
            params[param] = ids

    if issue.get("estimatedHours") is not None:
        params["estimatedHours"] = issue["estimatedHours"]

    return params


def custom_field_params(issue: dict) -> dict:
    """
    課題のカスタム属性を、課題作成 API のパラメータ形式に変換する。

    必須のカスタム属性があるプロジェクトでは、これを渡さないと課題の作成が
    「〜は必須です」で 400 になる。複製先はコピー元と同じプロジェクトに
    限られるため、属性 ID をそのまま使える。
    """
    params = {}
    for field in issue.get("customFields") or []:
        field_id = field.get("id")
        value = field.get("value")
        if field_id is None or value is None or value == []:
            continue

        key = f"customField_{field_id}"
        type_id = field.get("fieldTypeId")

        if type_id in CUSTOM_FIELD_MULTI_SELECT:
            ids = [v["id"] for v in value
                   if isinstance(v, dict) and v.get("id") is not None]
            if not ids:
                continue
            params[key] = ids
        elif type_id in CUSTOM_FIELD_SINGLE_SELECT:
            if not isinstance(value, dict) or value.get("id") is None:
                continue
            params[key] = value["id"]
        elif type_id == CUSTOM_FIELD_DATE:
            # 読み取り時は "2026-09-09T00:00:00Z" 形式だが、書き込みは日付のみ
            params[key] = str(value)[:10]
        else:
            params[key] = value

        # リスト系で「その他」が入力されている場合に付随する値
        other = field.get("otherValue")
        if other:
            params[f"{key}_otherValue"] = other
    return params


# パラメータを Backlog API の形（key[]=v1&key[]=v2）に展開する。共通の部品のもの
_flatten_params = backlog_client.flatten_params


# ===========================================================================
# Backlog API クライアント
# ===========================================================================


class BacklogClient(backlog_client.BacklogClient):
    """
    通信（送る・再送する・待つ・エラーにする）と、取得・作成・更新は共通の部品にある。
    ここには、本ツールだけの判定と検索（キーワード・子課題を必要な分だけ読む）を置く。
    """

    @classmethod
    def _is_no_change(cls, errors, detail) -> bool:
        """
        更新で HTTP 400 / code 7 が返れば「変更なし」とする。

        本ツールの更新は、コピー元から作った本文などを送るだけで、ステータスの遷移や
        件名の長さの超過は起こさない。以前からこの判定で動いており、変えない。
        """
        return any(err.get("code") == 7 for err in errors)

    def _http_hint(self, status, detail):
        if status == 400 and "必須" in detail:
            return (
                "必須のカスタム属性に値が入っていない可能性があります。"
                "--show-source でコピー元の値を確認し、"
                "コピー元に値を入れるか config.yaml の clone.custom_fields で指定してください。"
            )
        return super()._http_hint(status, detail)

    def _iter_issues(self, params: dict):
        """
        /issues をページネーションしながら遅延列挙する。
        ジェネレータのため、呼び出し元が途中で打ち切れば以降のページは取得しない。
        """
        offset = 0
        count = self.PAGE_SIZE
        while True:
            page = self._get("/issues", {**params, "count": count, "offset": offset})
            if not page:
                return
            yield from page
            if len(page) < count:
                return
            offset += count
            time.sleep(0.3)

    def search_issues_by_keyword(
        self, project_id: int, keyword: str, status_ids: list | None = None
    ):
        """
        keyword でプロジェクト内の課題を遅延列挙する。
        status_ids を渡すとその状態の課題のみに絞り込む。
        Backlog の keyword 検索は summary + description を対象とするため、
        呼び出し元で summary のフィルタを行うこと。
        """
        params = {"projectId": [project_id], "keyword": keyword}
        if status_ids:
            params["statusId"] = list(status_ids)
        return self._iter_issues(params)

    def get_child_issues(self, parent_issue_id: int):
        """
        親課題に紐づく子課題を遅延列挙する。
        親課題で絞り込むため状態によるフィルタは行わない
        （完了済みの子課題を再作成してしまうのを避けるため）。
        """
        return self._iter_issues({"parentIssueId": [parent_issue_id]})


def make_client(config: dict, debug: bool) -> BacklogClient:
    """
    設定ファイルの backlog 節から BacklogClient を作る。
    timeout・max_retries・retry_backoff・retry_max_delay は、書いてあればその値、無ければ共通の部品の既定
    （30 秒・3 回・2 秒・60 秒）。
    """
    backlog_cfg = config["backlog"]
    return BacklogClient(
        space_host=backlog_cfg["space_host"],
        api_key=backlog_cfg["api_key"],
        ssl_verify=backlog_cfg.get("ssl_verify", True),
        base_path=backlog_cfg.get("base_path", ""),
        debug=debug,
        timeout=backlog_cfg.get("timeout"),
        max_retries=backlog_cfg.get("max_retries"),
        retry_backoff=backlog_cfg.get("retry_backoff"),
        retry_max_delay=backlog_cfg.get("retry_max_delay"),
    )


# ===========================================================================
# 設定ファイル
# ===========================================================================


TOOL_DIR = Path(__file__).resolve().parent


def load_config(config_path: str) -> dict:
    """
    設定ファイルを読む。無い・UTF-8 でない・YAML の書き損じ・空は、トレースバックではなく
    設定の誤り（終了コード 2）にする。
    """
    return config_files.load_config(config_path)


def resolve_api_key(config: dict, config_path: str) -> str:
    """
    API キーを探して config["backlog"]["api_key"] に入れ、どこから読んだかを返す。

    環境変数 BACKLOG_API_KEY → 設定ファイルの backlog.api_key → .env（設定ファイルの隣 →
    このフォルダ → 作業フォルダ）の順。例の値のままの api_key は、書いていないものとみなす。
    """
    backlog = config["backlog"]
    key, source = config_files.locate_api_key(config_path, backlog.get("api_key"), tool_dir=TOOL_DIR)
    backlog["api_key"] = key
    return source


def _require_section(config: dict, name: str) -> dict:
    """必須セクションを取り出す。空・型不正なら ConfigError。"""
    section = config.get(name)
    if section is None:
        raise ConfigError(
            f"config.yaml に {name}: セクションがありません。"
            "config.example.yaml を参考に記述してください。"
        )
    if not isinstance(section, dict):
        raise ConfigError(
            f"config.yaml の {name}: セクションの形式が不正です（マッピングが必要です）。"
        )
    return section


def apply_cli_overrides(config: dict, args: argparse.Namespace) -> dict:
    """
    コマンドライン引数で設定ファイルの clone セクションを上書きする。
    設定ファイルには接続情報だけ置き、複製の対象は実行時に指定する使い方を可能にする。
    """
    if not isinstance(config, dict):
        return config  # 空ファイルなどは validate_config に任せる

    overrides = {
        "source_issue_key": getattr(args, "source_issue_key", None),
        "target_issue_key": getattr(args, "target_issue_key", None),
        "summary_template": getattr(args, "summary_template", None),
    }
    drop_template = bool(getattr(args, "no_summary_template", False))
    if not any(overrides.values()) and not drop_template:
        return config

    section = config.get("clone")
    clone = dict(section) if isinstance(section, dict) else {}
    for key, value in overrides.items():
        if value:
            clone[key] = value
    if drop_template:
        clone.pop("summary_template", None)
    # 件名テンプレートの指定（または無効化）はモードの指定でもある。
    # 設定ファイルの target_issue_key が残ると直接更新が優先され、
    # 単純複製・定期作成のつもりで既存課題の本文を書き換えてしまう。
    if (overrides["summary_template"] or drop_template) and not overrides["target_issue_key"]:
        clone.pop("target_issue_key", None)

    return {**config, "clone": clone}


def validate_config(config: dict) -> None:
    # yaml.safe_load は空ファイルに対して None を返すため最初に弾く
    if not isinstance(config, dict):
        raise ConfigError(
            "設定ファイルの内容が空か、形式が不正です。"
            "config.example.yaml を参考に記述してください。"
        )

    b = _require_section(config, "backlog")
    # api_key は resolve_api_key が探す（環境変数・.env にも置けるため、ここでは見ない）
    if not config_files.setting(b, "space_host"):
        raise ConfigError("config.yaml の backlog.space_host を設定してください。")

    c = config.get("clone")
    if c is None:
        raise ConfigError(
            "コピー元の課題が指定されていません。config.yaml の clone.source_issue_key に"
            "設定するか、--source-issue-key で指定してください"
            "（対話形式で選ぶ場合は menu.py を使ってください）。"
        )
    if not isinstance(c, dict):
        raise ConfigError("config.yaml の clone: セクションの形式が不正です（マッピングが必要です）。")

    # source_issue_key はサンプル値（PROJ-123）かどうかを見ない。
    # --source-issue-key や menu.py から実在のキーとして渡されることがあり、
    # 未編集のまま実行した場合も「コピー元課題が見つかりません」で十分に伝わるため。
    if not c.get("source_issue_key"):
        raise ConfigError(
            "コピー元の課題が指定されていません。config.yaml の clone.source_issue_key に"
            "設定するか、--source-issue-key で指定してください。"
        )
    # summary_template は省略可（省略時はコピー元の件名をそのまま使う）。
    # ただし空文字を指定した場合は件名が空になってしまうため弾く。
    if "summary_template" in c and not c["summary_template"]:
        raise ConfigError(
            "config.yaml の clone.summary_template を空にはできません。"
            "（省略すればコピー元の件名をそのまま使います）"
        )

    if "target_issue_key" in c and not c["target_issue_key"]:
        raise ConfigError(
            "config.yaml の clone.target_issue_key を空にはできません。"
            "（件名で複製先を探す場合はこの項目ごと省略してください）"
        )

    # 廃止された項目。黙って無視すると、意図した別プロジェクトではなく
    # コピー元のプロジェクトに作られてしまうため、明示的に止める。
    if "target_project_key" in c:
        raise ConfigError(
            "config.yaml の clone.target_project_key は廃止されました。"
            "プロジェクトを跨いだ複製には対応していないため、この項目を削除してください。"
            "（複製先はコピー元と同じプロジェクトになります）"
        )

    match_mode = c.get("match_mode", "substring")
    if match_mode not in MATCH_MODES:
        raise ConfigError(
            f"config.yaml の clone.match_mode が不正です: {match_mode!r}"
            f"（利用可能: {', '.join(MATCH_MODES)}）"
        )

    # 数値設定: bool は int のサブクラスなので明示的に除外する
    for key, minimum in NUMERIC_SETTINGS:
        if key not in b:
            continue
        val = b[key]
        if isinstance(val, bool) or not isinstance(val, (int, float)) or val < minimum:
            raise ConfigError(
                f"config.yaml の backlog.{key} は {minimum} 以上の数値で"
                f"指定してください: {val!r}"
            )

    if "child_summary_template" in c and not c["child_summary_template"]:
        raise ConfigError(
            "config.yaml の clone.child_summary_template を空にはできません。"
            "（省略時は {SOURCE_SUMMARY}、つまりコピー元の子課題の件名をそのまま使います）"
        )

    configured_custom_field_params(c.get("custom_fields"))

    # 真偽値設定: "false" のような文字列を真と誤解しないよう型を確認する
    for section_name, section, key in (
        ("backlog", b, "ssl_verify"),
        ("clone", c, "include_closed"),
        ("clone", c, "include_children"),
        ("clone", c, "copy_custom_fields"),
        ("clone", c, "copy_attributes"),
    ):
        if key in section and not isinstance(section[key], bool):
            raise ConfigError(
                f"config.yaml の {section_name}.{key} は true / false で"
                f"指定してください: {section[key]!r}"
            )


# ===========================================================================
# ユーティリティ
# ===========================================================================


def resolve_date(date_arg: str | None) -> str:
    """--date 引数または今日の日付を YYYYMMDD 形式で返す。"""
    if date_arg:
        try:
            datetime.strptime(date_arg, "%Y%m%d")
            return date_arg
        except ValueError:
            raise ConfigError(
                f"--date の形式が不正です（YYYYMMDD 形式で指定してください）: {date_arg}"
            ) from None
    return datetime.now().strftime("%Y%m%d")


def fetch_issue_types(client: BacklogClient, project_key: str) -> list:
    """プロジェクトの種別一覧を取得する。空なら ConfigError。"""
    types = client.get_issue_types(project_key)
    if not types:
        raise ConfigError(f"プロジェクト {project_key} の種別が取得できませんでした。")
    return types


def fetch_priorities(client: BacklogClient) -> list:
    """優先度一覧を取得する。空なら ConfigError。"""
    priorities = client.get_priorities()
    if not priorities:
        raise ConfigError("優先度一覧が取得できませんでした。")
    return priorities


def resolve_issue_type_id(
    types: list, name: str | None, source_issue: dict | None = None
) -> tuple[int, str]:
    """
    種別IDと種別名を返す。優先順位は次のとおり。

      1. 設定の clone.issue_type で指定された種別
      2. コピー元課題と同じ種別
      3. プロジェクトの最初の種別

    Backlog はカスタム属性の必須設定を種別ごとに持つため、既定でコピー元に
    揃えないと、コピー元では不要な属性が必須の種別で作成されて失敗する。
    """
    if name:
        matched = [t for t in types if t["name"] == name]
        if matched:
            return matched[0]["id"], matched[0]["name"]
        available = [t["name"] for t in types]
        print(
            f"警告: 種別「{name}」が見つかりません。"
            f"（利用可能: {available}）",
            file=sys.stderr,
        )

    source_name = ((source_issue or {}).get("issueType") or {}).get("name")
    if source_name:
        matched = [t for t in types if t["name"] == source_name]
        if matched:
            return matched[0]["id"], matched[0]["name"]
        print(
            f"警告: コピー元と同じ種別「{source_name}」が複製先にありません。"
            f"最初の種別「{types[0]['name']}」を使用します。",
            file=sys.stderr,
        )

    return types[0]["id"], types[0]["name"]


def resolve_priority_id(
    priorities: list, name: str | None, source_issue: dict | None = None
) -> tuple[int, str]:
    """
    優先度IDと優先度名を返す。優先順位は次のとおり。

      1. 設定の clone.priority で指定された優先度
      2. コピー元課題と同じ優先度
      3. 「中」
      4. 最初の優先度

    種別と同じく、既定ではコピー元に揃える。
    """
    if name:
        matched = [p for p in priorities if p["name"] == name]
        if matched:
            return matched[0]["id"], matched[0]["name"]
        available = [p["name"] for p in priorities]
        print(
            f"警告: 優先度「{name}」が見つかりません。（利用可能: {available}）",
            file=sys.stderr,
        )
    source_id = ((source_issue or {}).get("priority") or {}).get("id")
    if source_id is not None:
        matched = [p for p in priorities if p["id"] == source_id]
        if matched:
            return matched[0]["id"], matched[0]["name"]

    # フォールバック: "中" を探す
    chuu = [p for p in priorities if p["name"] == "中"]
    if chuu:
        return chuu[0]["id"], chuu[0]["name"]
    return priorities[0]["id"], priorities[0]["name"]


def find_existing_by_summary(
    client: BacklogClient,
    project_id: int,
    summary: str,
    *,
    match_mode: str = "substring",
    status_ids: list | None = None,
    exclude_id: int | None = None,
) -> dict | None:
    """
    件名が summary にマッチする課題を返す。なければ None。
    keyword 検索は summary + description を対象とするため、件名側でフィルタする。
    match_mode="exact" なら完全一致、"substring" なら部分一致。
    status_ids を渡すとその状態の課題のみを検索対象にする。
    exclude_id を渡すとその課題を検索結果から除外する。summary_template を
    省略するとコピー元と同じ件名になり、コピー元自身がヒットしてしまうため。
    検索結果は遅延列挙されるため、最初にマッチした時点で以降のページは取得しない。
    """
    for issue in client.search_issues_by_keyword(project_id, summary, status_ids):
        if exclude_id is not None and issue.get("id") == exclude_id:
            continue
        if summary_matches(summary, issue.get("summary", ""), match_mode):
            return issue
    return None


def summary_matches(wanted: str, candidate: str, match_mode: str) -> bool:
    """件名が一致するか。match_mode="exact" なら完全一致、"substring" なら部分一致。"""
    if match_mode == "exact":
        return candidate == wanted
    return wanted in candidate


# ===========================================================================
# 子課題の複製計画
# ===========================================================================


@dataclass
class ChildPlan:
    """1 件の子課題に対して行う操作。"""

    source: dict            # コピー元の子課題
    summary: str            # 作成・照合に使う件名
    action: str             # OUTCOME_CREATED / OUTCOME_UPDATED / OUTCOME_NO_CHANGE
    existing: dict | None = None  # 複製先に既にある子課題


_DIGITS_RE = re.compile(r"(\d+)")


def summary_sort_key(summary: str) -> list:
    """
    件名の並び順を決めるキー。数字は数値として比較するため
    「手順2」が「手順10」より前に来る（単純な文字列比較では逆になる）。
    """
    return [
        (0, int(part), "") if part.isdigit() else (1, 0, part)
        for part in _DIGITS_RE.split(summary or "") if part
    ]


def sort_issues_by_summary(issues: list) -> list:
    """
    課題を件名順に並べる。Backlog API の返却順は一定ではないため、
    実行するたびに作成順（＝採番される課題キーの順）が変わらないようにする。
    件名が同じ場合は課題 ID で並べて順序を確定させる。
    """
    return sorted(
        issues,
        key=lambda i: (summary_sort_key(i.get("summary", "")), i.get("id") or 0),
    )


def build_summary(template: str, source_summary: str, date_str: str) -> str:
    """
    件名テンプレートを展開する。親課題・子課題の双方で使う。
      {SOURCE_SUMMARY} : コピー元の件名
      {YYYYMMDD}       : --date または今日の日付
    """
    return template.replace("{SOURCE_SUMMARY}", source_summary).replace(
        "{YYYYMMDD}", date_str
    )


def build_child_plans(
    source_children: list,
    existing_children: list,
    *,
    template: str,
    date_str: str,
    match_mode: str,
) -> list[ChildPlan]:
    """
    コピー元の子課題と複製先の既存子課題を突き合わせ、各子課題の操作を決める。
    照合は複製先の親課題に紐づく子課題の中だけで行うため、
    プロジェクト全体のキーワード検索は不要。
    """
    plans = []
    used = set()
    for source in source_children:
        summary = build_summary(template, source.get("summary", ""), date_str)
        match = None
        for i, existing in enumerate(existing_children):
            if i in used:
                continue
            if summary_matches(summary, existing.get("summary", ""), match_mode):
                match = (i, existing)
                break
        if match is None:
            plans.append(ChildPlan(source=source, summary=summary, action=OUTCOME_CREATED))
            continue
        index, existing = match
        used.add(index)
        same = (existing.get("description") or "") == (source.get("description") or "")
        plans.append(
            ChildPlan(
                source=source,
                summary=summary,
                action=OUTCOME_NO_CHANGE if same else OUTCOME_UPDATED,
                existing=existing,
            )
        )
    return plans


def _issue_ref(issue: dict):
    """課題を識別するキー。id があれば id、無ければ issueKey。"""
    return issue.get("id", issue.get("issueKey"))


def find_unmatched_children(existing_children: list, plans: list[ChildPlan]) -> list:
    """
    複製先にあるが、コピー元のどの子課題とも照合できなかった子課題を返す。
    複製先で件名が変更されると照合に失敗し、同じ内容の子課題が
    重複して作られるため、実行前に気付けるようにする。
    """
    matched = {_issue_ref(p.existing) for p in plans if p.existing is not None}
    return [c for c in existing_children if _issue_ref(c) not in matched]


def resolve_child_issue_type(
    issue_types: list, source_child: dict, fallback: tuple[int, str]
) -> tuple[int, str]:
    """
    子課題の種別を複製先プロジェクトで解決する。
    コピー元と同名の種別があればそれを使い、無ければ親と同じ種別にフォールバックする。
    """
    name = (source_child.get("issueType") or {}).get("name")
    if name:
        for t in issue_types:
            if t["name"] == name:
                return t["id"], t["name"]
    return fallback


def aggregate_outcome(actions: list[str]) -> str:
    """親と子の操作をまとめて 1 つの実行結果にする。"""
    for outcome in (OUTCOME_SKIPPED, OUTCOME_CREATED, OUTCOME_UPDATED):
        if outcome in actions:
            return outcome
    return OUTCOME_NO_CHANGE


# ===========================================================================
# 確認プロンプト
# ===========================================================================


def _ask(prompt: str, assume_yes: bool) -> bool:
    """[y/N] の確認を取る。--yes 指定時は常に True、非対話時は False。"""
    if assume_yes:
        print(f"{prompt} y（--yes 指定）")
        return True
    if not sys.stdin.isatty():
        print(
            "  スキップ: 非対話環境のため確認できません。"
            "自動実行する場合は --yes を指定してください。",
            file=sys.stderr,
        )
        return False
    try:
        answer = input(prompt).strip().lower()
    except EOFError:
        answer = ""
    return answer in ("y", "yes")


ACTION_LABELS = {
    OUTCOME_CREATED: "新規作成",
    OUTCOME_UPDATED: "本文を更新",
    OUTCOME_NO_CHANGE: "変更なし",
}


def display_width(text: str) -> int:
    """端末上の表示幅。全角文字を 2 桁として数える。"""
    return sum(
        2 if unicodedata.east_asian_width(c) in ("W", "F") else 1 for c in text
    )


def pad(text: str, width: int) -> str:
    """表示幅を揃えて右側を空白で埋める。ラベルの文字数が違っても桁がずれない。"""
    return text + " " * max(0, width - display_width(text))


def print_plan(
    parent_action: str,
    parent_summary: str,
    parent_existing: dict | None,
    child_plans: list[ChildPlan],
    unmatched_children: list | None = None,
) -> None:
    """これから行う操作の一覧を表示する。"""
    print("\n実行内容:")
    where = f"（{parent_existing['issueKey']}）" if parent_existing else ""
    print(f"  [親] {pad(ACTION_LABELS[parent_action], 12)}{parent_summary}{where}")
    for plan in child_plans:
        where = f"（{plan.existing['issueKey']}）" if plan.existing else ""
        print(f"  [子] {pad(ACTION_LABELS[plan.action], 12)}{plan.summary}{where}")

    # 新規作成が発生し、かつ複製先に照合できなかった子課題がある場合のみ警告する。
    # 複製先で件名が変更されていると照合に失敗し、同じ内容の子課題が
    # 重複して作られるため。作成が無ければ重複しないので黙っておく。
    if unmatched_children and any(p.action == OUTCOME_CREATED for p in child_plans):
        print("\n  警告: 複製先に照合できなかった子課題があります:")
        for issue in unmatched_children:
            print(f"      {issue.get('issueKey')}: {issue.get('summary', '')}")
        print(
            "    複製先で件名が変更されていると照合できず、"
            "同じ内容の子課題が重複して作られます。"
        )
        print("    重複させたくない場合はここで中断してください。")


def confirm_plan(
    parent_action: str, child_plans: list[ChildPlan], assume_yes: bool = False
) -> bool:
    """作成・更新が 1 件でもあれば確認を取る。何もしない場合は確認しない。"""
    actions = [parent_action] + [p.action for p in child_plans]
    creates = actions.count(OUTCOME_CREATED)
    updates = actions.count(OUTCOME_UPDATED)
    if not creates and not updates:
        return True
    parts = []
    if creates:
        parts.append(f"新規作成 {creates} 件")
    if updates:
        parts.append(f"本文更新 {updates} 件")
    return _ask(
        f"  Backlog に反映しますか？（{' / '.join(parts)}） [y/N]: ", assume_yes
    )


# ===========================================================================
# メインロジック
# ===========================================================================


def run(args: argparse.Namespace, config: dict) -> str:
    """クローン処理を実行し、OUTCOME_* のいずれかを返す。"""
    dry_run = not args.execute
    assume_yes = bool(getattr(args, "yes", False))
    clone_cfg = config["clone"]

    # 1. 日付解決（件名テンプレートの展開はコピー元を取得した後）
    date_str = resolve_date(args.date)

    # 2. BacklogClient 初期化
    client = make_client(config, args.debug)

    # 3. コピー元課題を取得
    source_key = clone_cfg["source_issue_key"]
    print(f"コピー元課題を取得中: {source_key}")
    source_issue = client.get_issue(source_key)
    if source_issue is None:
        raise ConfigError(f"コピー元課題「{source_key}」が見つかりません。")
    source_desc = source_issue.get("description") or ""

    # 3b. コピー元の子課題を取得
    include_children = bool(clone_cfg.get("include_children", True))
    source_children = []
    if include_children:
        if source_issue.get("parentIssueId"):
            # Backlog の親子関係は 2 階層までで、子課題は子を持てない
            print(
                f"警告: {source_key} は子課題のため、子課題の複製は行いません。",
                file=sys.stderr,
            )
        else:
            print("コピー元の子課題を取得中...")
            source_children = sort_issues_by_summary(
                client.get_child_issues(source_issue["id"])
            )
            print(f"  子課題: {len(source_children)} 件")

    # 4. 重複検出の条件を確定
    match_mode = clone_cfg.get("match_mode", "substring")
    include_closed = bool(clone_cfg.get("include_closed", False))
    status_ids = None if include_closed else STATUS_IDS_OPEN
    copy_custom_fields = bool(clone_cfg.get("copy_custom_fields", True))
    copy_attributes = bool(clone_cfg.get("copy_attributes", True))
    # 設定で指定した値は、コピー元から引き継いだ値より優先する
    configured_fields = configured_custom_field_params(clone_cfg.get("custom_fields"))

    # 5. コピー先を確定する
    target_issue_key = clone_cfg.get("target_issue_key")
    summary_template = clone_cfg.get("summary_template")
    # summary_template も target_issue_key も無い場合、複製先を特定する手掛かりが
    # ないため重複チェックを行わず、実行のたびに新しい課題を作る。
    # コピー元と同じ件名で重複チェックしたい場合は summary_template に
    # "{SOURCE_SUMMARY}" を明示する。
    always_create = not target_issue_key and not summary_template

    # 複製はコピー元と同じプロジェクト内でのみ行う。
    # Backlog API の単一課題レスポンスには projectId（数値）のみ含まれ
    # project オブジェクトはないため、issueKey（例: PROJ-123）のプレフィックスを
    # プロジェクトキーとして使う。
    target_project_key = source_issue["issueKey"].rsplit("-", 1)[0]

    if target_issue_key:
        # 5a. コピー先が明示されている場合は件名で探さず直接取得する
        print(f"コピー先課題を取得中: {target_issue_key}")
        existing = client.get_issue(target_issue_key)
        if existing is None:
            raise ConfigError(f"コピー先課題「{target_issue_key}」が見つかりません。")
        if existing.get("id") == source_issue.get("id"):
            raise ConfigError(
                f"コピー元とコピー先が同じ課題です: {source_key}"
            )
        existing_project_key = existing["issueKey"].rsplit("-", 1)[0]
        if existing_project_key != target_project_key:
            raise ConfigError(
                f"コピー元（{target_project_key}）とコピー先（{existing_project_key}）の"
                "プロジェクトが異なります。"
                "プロジェクトを跨いだ複製には対応していません。"
            )
        summary = existing.get("summary", "")  # 件名は変更しない
        project_id = existing.get("projectId")
    else:
        # 5b. 件名テンプレートを展開する
        summary = build_summary(
            summary_template or DEFAULT_SUMMARY_TEMPLATE,
            source_issue.get("summary", ""),
            date_str,
        )
        # ID は取得済みの source_issue["projectId"] を流用して API 呼び出しを節約する
        project_id = source_issue.get("projectId")

    if project_id is None:
        print(f"対象プロジェクトを取得中: {target_project_key}")
        project_id = client.get_project(target_project_key)["id"]

    # 6. 解決済み設定値を表示
    # 種別・優先度は新規作成でしか使わないため、ここでは解決しない。
    # 更新・変更なしの経路で無駄な API 呼び出しを 2 回省くため。
    prefix = "[DRY RUN] " if dry_run else ""
    print(f"\n{prefix}設定値:")
    print(f"  件名        : {summary}")
    print(f"  コピー元    : {source_key}")
    print(f"  対象PJ      : {target_project_key} (id={project_id})")
    print(f"  本文文字数  : {len(source_desc)} 文字")
    if target_issue_key:
        print(f"  コピー先    : {target_issue_key}（件名は変更しません）")
        print(f"  子課題照合  : {match_mode}")
    elif always_create:
        print("  重複判定    : 行わない（毎回新しい課題を作成）")
    else:
        print(f"  重複判定    : {match_mode}"
              f"（完了済み課題を{'含む' if include_closed else '除く'}）")

    # 7. 複製先を検索する（コピー先が明示されている場合は 5a で確定済み）
    if not target_issue_key:
        if always_create:
            existing = None
        else:
            print(f"\n既存課題を検索中（件名: {summary!r}）...")
            existing = find_existing_by_summary(
                client, project_id, summary,
                match_mode=match_mode,
                status_ids=status_ids,
                # "{SOURCE_SUMMARY}" 指定時はコピー元と同じ件名になるため自分自身を除く
                exclude_id=source_issue.get("id"),
            )

    # 8. 親課題の操作を決める
    if existing is None:
        parent_action = OUTCOME_CREATED
        existing_children = []
    else:
        print(f"既存課題あり: {existing['issueKey']}")
        same = (existing.get("description") or "") == source_desc
        parent_action = OUTCOME_NO_CHANGE if same else OUTCOME_UPDATED
        # 既存の親に紐づく子課題を照合対象にする
        existing_children = (
            sort_issues_by_summary(client.get_child_issues(existing["id"]))
            if source_children else []
        )

    # 9. 子課題の操作を決める
    child_plans = build_child_plans(
        source_children,
        existing_children,
        template=clone_cfg.get("child_summary_template", "{SOURCE_SUMMARY}"),
        date_str=date_str,
        match_mode=match_mode,
    )

    print_plan(
        parent_action,
        summary,
        existing,
        child_plans,
        find_unmatched_children(existing_children, child_plans),
    )

    all_actions = [parent_action] + [p.action for p in child_plans]
    if OUTCOME_CREATED not in all_actions and OUTCOME_UPDATED not in all_actions:
        print("\n変更はありません。")
        return OUTCOME_NO_CHANGE

    # 10. 作成があるときだけ種別・優先度を解決する
    issue_types = priorities = None
    issue_type_id = priority_id = None
    if OUTCOME_CREATED in all_actions:
        issue_types = fetch_issue_types(client, target_project_key)
        priorities = fetch_priorities(client)
        issue_type_id, issue_type_name = resolve_issue_type_id(
            issue_types, clone_cfg.get("issue_type"), source_issue
        )
        priority_id, priority_name = resolve_priority_id(
            priorities, clone_cfg.get("priority"), source_issue
        )
        print(f"  種別（親）  : {issue_type_name} (id={issue_type_id})")
        print(f"  優先度（親）: {priority_name} (id={priority_id})")

    if dry_run:
        return aggregate_outcome(all_actions)

    # 11. 確認
    if not confirm_plan(parent_action, child_plans, assume_yes):
        print("スキップ（キャンセル）")
        return OUTCOME_SKIPPED

    # 12. 親課題を作成・更新して、子課題を紐づける親の ID を確定する
    if parent_action == OUTCOME_CREATED:
        created = client.create_issue({
            "projectId": project_id,
            "summary": summary,
            "issueTypeId": issue_type_id,
            "priorityId": priority_id,
            "description": source_desc,
            **(inherited_issue_params(source_issue) if copy_attributes else {}),
            **(custom_field_params(source_issue) if copy_custom_fields else {}),
            **configured_fields,
        })
        parent_id = created["id"]
        print(f"作成完了: {created['issueKey']} ― {created['summary']}")
    else:
        parent_id = existing["id"]
        if parent_action == OUTCOME_UPDATED:
            try:
                updated = client.update_issue(
                    existing["issueKey"], {"description": source_desc}
                )
                print(f"更新完了: {updated['issueKey']} ― {updated['summary']}")
            except BacklogNoChangeError as e:
                # Backlog はバリデーションエラーにも同じコードを返すため、
                # サーバのメッセージを併記して取り違えに気付けるようにする
                print(f"スキップ（変更なしと判断）: {existing['issueKey']} ― {e}")
                parent_action = OUTCOME_NO_CHANGE

    # 13. 子課題を作成・更新する
    done_actions = [parent_action]
    for plan in child_plans:
        done_actions.append(
            _apply_child_plan(
                client, plan, parent_id, project_id, issue_types,
                (issue_type_id, priority_id),
                copy_custom_fields=copy_custom_fields,
                copy_attributes=copy_attributes,
                configured_fields=configured_fields,
            )
        )

    return aggregate_outcome(done_actions)


def _apply_child_plan(
    client: BacklogClient,
    plan: ChildPlan,
    parent_id: int,
    project_id: int,
    issue_types: list | None,
    parent_defaults: tuple,
    *,
    copy_custom_fields: bool = True,
    copy_attributes: bool = True,
    configured_fields: dict | None = None,
) -> str:
    """1 件の子課題に対して計画した操作を実行し、実際の結果を返す。"""
    if plan.action == OUTCOME_NO_CHANGE:
        return OUTCOME_NO_CHANGE

    source_desc = plan.source.get("description") or ""

    if plan.action == OUTCOME_UPDATED:
        try:
            updated = client.update_issue(
                plan.existing["issueKey"], {"description": source_desc}
            )
        except BacklogNoChangeError as e:
            print(
                f"  [子] スキップ（変更なしと判断）: {plan.existing['issueKey']} ― {e}"
            )
            return OUTCOME_NO_CHANGE
        print(f"  [子] 更新完了: {updated['issueKey']} ― {updated['summary']}")
        return OUTCOME_UPDATED

    # 種別はコピー元の子課題に合わせ、優先度は Backlog 共通のため ID をそのまま使う
    fallback_type_id, fallback_priority_id = parent_defaults
    type_id, _ = resolve_child_issue_type(
        issue_types or [], plan.source, (fallback_type_id, "")
    )
    priority_id = (plan.source.get("priority") or {}).get("id") or fallback_priority_id

    source = plan.source
    # 課題一覧のレスポンスにカスタム属性が含まれない場合に備えて取得し直す
    if copy_custom_fields and "customFields" not in source:
        source = client.get_issue(source["issueKey"]) or source

    extra = inherited_issue_params(source) if copy_attributes else {}
    if copy_custom_fields:
        extra.update(custom_field_params(source))
    extra.update(configured_fields or {})

    created = client.create_issue({
        "projectId": project_id,
        "summary": plan.summary,
        "issueTypeId": type_id,
        "priorityId": priority_id,
        "description": source_desc,
        "parentIssueId": parent_id,
        **extra,
    })
    print(f"  [子] 作成完了: {created['issueKey']} ― {created['summary']}")
    return OUTCOME_CREATED


def show_source_issue(args: argparse.Namespace, config: dict) -> None:
    """コピー元課題のカスタム属性を一覧表示する（--show-source）。"""
    clone_cfg = config["clone"]
    client = make_client(config, args.debug)
    source_key = clone_cfg["source_issue_key"]
    issue = client.get_issue(source_key)
    if issue is None:
        raise ConfigError(f"コピー元課題「{source_key}」が見つかりません。")

    print(f"コピー元課題: {issue['issueKey']} ― {issue.get('summary', '')}")
    print(f"  種別: {(issue.get('issueType') or {}).get('name', '（不明）')}"
          "  ← 設定で指定しない限り、この種別で作成します")
    fields = issue.get("customFields")
    if fields is None:
        print("  カスタム属性: レスポンスに含まれていません")
        return
    if not fields:
        print("  カスタム属性: ありません")
        return

    print("  カスタム属性:")
    empty = []
    for field in fields:
        type_name = CUSTOM_FIELD_TYPE_NAMES.get(field.get("fieldTypeId"), "不明")
        value = field.get("value")
        shown = "（未設定）" if value is None or value == [] else repr(value)
        print(f"    id={field.get('id')}  {type_name}  "
              f"{field.get('name', '')!r}  値: {shown}")
        if value is None or value == []:
            empty.append(field)

    sent = custom_field_params(issue)
    print(f"\n  作成時に渡す値: {sent or 'なし'}")
    if empty:
        ids = "、".join(str(f.get("id")) for f in empty)
        print(
            f"\n  値が未設定の属性があります（id={ids}）。\n"
            "  これらが必須の場合、コピー元に値を入れるか、"
            "config.yaml の clone.custom_fields で指定してください。"
        )


def exit_code_for(outcome: str, detailed: bool) -> int:
    """実行結果を終了コードに変換する。"""
    if outcome == OUTCOME_SKIPPED:
        return EXIT_SKIPPED
    if not detailed:
        return EXIT_OK
    return {
        OUTCOME_NO_CHANGE: EXIT_OK,
        OUTCOME_CREATED: EXIT_CREATED,
        OUTCOME_UPDATED: EXIT_UPDATED,
    }[outcome]


# ===========================================================================
# エントリポイント
# ===========================================================================


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        description="Backlog 課題クローンツール",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
例:
  python3 backlog_issue_cloner.py                          # ドライラン（デフォルト）
  python3 backlog_issue_cloner.py --execute                # 実際に作成/更新
  python3 backlog_issue_cloner.py --execute --yes          # 確認なしで実行（cron 向け）
  python3 backlog_issue_cloner.py --date 20260401          # 日付を指定
  python3 backlog_issue_cloner.py --execute --debug        # デバッグ出力付きで実行
  python3 backlog_issue_cloner.py --config my_config.yaml  # 設定ファイルを指定

  # 作成/更新が起きたかを終了コードで判定する
  python3 backlog_issue_cloner.py --execute --yes --detailed-exit-code

終了コード:
  0  正常終了 / 2  設定エラー / 3  API・ネットワークエラー
  20 確認が得られずスキップ（--yes なしの非対話実行、またはユーザーが拒否）
  --detailed-exit-code 指定時は正常終了を細分化: 0 変更なし / 10 作成 / 11 更新
""",
    )
    default_config = str(Path(__file__).parent / "config.yaml")
    parser.add_argument(
        "--config",
        default=default_config,
        help="設定ファイルのパス（デフォルト: このスクリプトと同じフォルダの config.yaml）",
    )
    parser.add_argument(
        "--date",
        default=None,
        metavar="YYYYMMDD",
        help="日付（YYYYMMDD 形式）。省略時は今日の日付",
    )
    parser.add_argument(
        "--execute",
        action="store_true",
        help="実際に API を呼び出す（省略時はドライラン）",
    )
    parser.add_argument(
        "-y", "--yes",
        action="store_true",
        help="確認プロンプトを出さずに実行する（cron などの自動実行向け）",
    )
    parser.add_argument(
        "--detailed-exit-code",
        action="store_true",
        help="正常終了時に結果を終了コードで区別する（0 変更なし / 10 作成 / 11 更新）",
    )
    parser.add_argument(
        "--debug",
        action="store_true",
        help="API リクエストの詳細を表示する",
    )
    parser.add_argument(
        "--show-source",
        action="store_true",
        help="コピー元課題のカスタム属性を表示して終了する（作成・更新はしない）",
    )

    override = parser.add_argument_group(
        "設定の上書き",
        "設定ファイルの clone セクションを実行時に上書きする"
        "（設定ファイルには接続情報だけ置く運用向け）",
    )
    override.add_argument(
        "--source-issue-key",
        metavar="KEY",
        help="コピー元の課題キー（例: PROJ-123）",
    )
    override.add_argument(
        "--target-issue-key",
        metavar="KEY",
        help="複製先の課題キー。指定すると件名で検索せずこの課題を直接更新する",
    )
    template = override.add_mutually_exclusive_group()
    template.add_argument(
        "--summary-template",
        metavar="TEMPLATE",
        help="件名テンプレート（{SOURCE_SUMMARY} / {YYYYMMDD} が使える）。"
             "設定ファイルの複製先の課題キーは無視する",
    )
    template.add_argument(
        "--no-summary-template",
        action="store_true",
        help="設定ファイルの件名テンプレートと複製先の課題キーを無視し、"
             "重複チェックせず毎回新規作成する",
    )
    return parser


def main() -> None:
    make_console_safe()
    args = build_parser().parse_args()

    api_key_source = ""
    try:
        config = load_config(args.config)
        config = apply_cli_overrides(config, args)
        validate_config(config)
        api_key_source = resolve_api_key(config, args.config)

        dry_run = not args.execute
        print("=" * 55)
        print("Backlog 課題クローンツール")
        print("=" * 55)
        print(f"スペース  : {config['backlog']['space_host']}")
        print(
            "モード    : "
            + ("DRY RUN（実際の作成/更新は行いません）" if dry_run else "EXECUTE（Backlog に作成/更新します）")
        )
        print()

        if args.show_source:
            show_source_issue(args, config)
            sys.exit(EXIT_OK)

        outcome = run(args, config)
    except ConfigError as e:
        print(f"エラー: {e}", file=sys.stderr)
        sys.exit(EXIT_CONFIG_ERROR)
    except BacklogError as e:
        # 対処の案内は、エラーの文に入っている
        print(f"エラー: {e}", file=sys.stderr)
        if e.status in (401, 403) and api_key_source:
            # API キーは環境変数・設定ファイル・.env のどれからも読むので、直す場所が分かるように
            print(config_files.api_key_source_line(api_key_source), file=sys.stderr)
        sys.exit(EXIT_API_ERROR)

    sys.exit(exit_code_for(outcome, args.detailed_exit_code))


if __name__ == "__main__":
    main()
