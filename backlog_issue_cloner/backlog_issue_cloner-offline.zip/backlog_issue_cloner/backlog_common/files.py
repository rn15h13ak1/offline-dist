"""
出力するファイルの名前
======================
実行ログ・結果のファイルなど、日時を名前に入れるファイルの日時を決める。

古い Python でも読める書き方に保つ（f 文字列・注釈を使わない。開発のテストが確かめる）。
"""

import datetime
import os
import re


def timestamp(now=None):
    """ファイル名に使う日時（YYYYMMDD_HHMMSS）。"""
    return (now or datetime.datetime.now()).strftime("%Y%m%d_%H%M%S")


def unique_stamp(directory, names, now=None):
    """
    ファイル名に使う日時。names（"run_{}.csv" のような形）のどれかが既にあれば、
    _2, _3 … を付けて、どれとも重ならないものにする。

    日時は秒までなので、同じ秒に続けて実行すると同じ名前になる。重なったまま
    保存すると、前のファイル（どこまで反映したかを示す実行ログなど）が黙って消える。
    実行ログと結果のように対になるファイルは、同じ番号にそろえる。
    """
    base = timestamp(now)
    stamp, n = base, 2
    while any(os.path.exists(os.path.join(str(directory), name.format(stamp))) for name in names):
        stamp, n = "{}_{}".format(base, n), n + 1
    return stamp


def safe_filename(name, fallback="output"):
    """
    名前（ソース名・フィルター名など）を、ファイル名に使える文字列にする（5 つのツールで同じ決まり）。

    Windows でファイル名に使えない文字（\\ / : * ? " < > |）と空白（全角を含む）は、続いていれば 1 つの「_」にする。
    前後の「.」「_」は除く（「.」で始まると隠しファイルになり、Windows は末尾の「.」を消すため）。何も残らなければ fallback。
    """
    safe = re.sub(r'[\\/:*?"<>|\s]+', "_", str(name)).strip("._")
    return safe or fallback

