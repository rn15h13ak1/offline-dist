"""
対話メニューの部品
==================
各ツールの menu.py が使う、表示・入力・前回値の記憶・本体の起動。どのメニューを並べ、本体にどの引数を渡すかは、
各ツールの menu.py に残す。

- 終了コードはツールを起動する側（メニューを並べるランチャー）が見ているので変えない。
  正常に終了 0、入力の終わり（EOF）1、Python の版かライブラリが足りない 2、本体が見つからない 127、中断 130
- 画面の文字は CP932 に収める（Windows の日本語コンソールで落ちないように）
- 入口より先に読まれることがあるので、古い Python でも読める書き方にする（f 文字列・注釈を使わない）
"""

import json
import os
import subprocess
import sys

from backlog_common.runtime import make_console_safe, require_packages, require_python

WIDTH = 60

EXIT_OK = 0
EXIT_EOF = 1
# メニューを開いたところで、Python の版かライブラリが足りなくて止めた。入力の終わり（1）と分ける
EXIT_SETUP = 2
EXIT_NOT_FOUND = 127
EXIT_INTERRUPTED = 130


# ===========================================================================
# 表示・入力
# ===========================================================================


def check_runtime(packages):
    """
    メニューを開くときに、表示の手当てをしてから、Python の版とライブラリを確かめる。足りなければ案内して 2 で止める。

    packages は本体が要るライブラリ（require_packages と同じ形）。メニューが開いても、本体を選んだところで
    本体の番号で止まると、何が足りないのかが分かりにくい。案内の文は本体と同じ（共通の部品）。
    手当て（make_console_safe）を先にするのは、案内に出す Python のパスに CP932 に無い文字がありうるため。
    """
    make_console_safe()
    require_python(code=EXIT_SETUP)
    require_packages(packages, code=EXIT_SETUP)


def hr(char="="):
    print(char * WIDTH)


def print_menu(title, items, back_label="戻る", default=None, default_mark="既定"):
    """
    メニューを表示して選択番号を返す。0 = 戻る / 終了。
    default に番号を渡すと、空 Enter でその番号を選べる。default_mark は既定値の由来を示すラベル
    （前回の選択なら「前回」）。
    """
    while True:
        print()
        hr()
        print("  " + title)
        hr()
        for i, item in enumerate(items, 1):
            mark = " ←" + default_mark if default == i else ""
            print("  {}. {}{}".format(i, item, mark))
        hr("-")
        print("  0. " + back_label)
        hr()
        prompt = "番号を入力してください" + (" [Enter={}]: ".format(default) if default else ": ")
        choice = input(prompt).strip()
        if not choice and default:
            return default
        if choice == "0":
            return 0
        if choice.isdigit() and 1 <= int(choice) <= len(items):
            return int(choice)
        print("  ※ 無効な入力です。もう一度入力してください。")


def describe_config(path, example="config.example.yaml"):
    """
    メニューの見出しに出す「設定ファイル: …」の値。読むファイルのパス。無ければ、作り方を添えて示す。

    本体と同じ文（設定ファイルが見つかりません: …（… をコピーして作ってください））にする。
    """
    if not os.path.isfile(str(path)):
        return "※ 設定ファイルが見つかりません: {}（{} をコピーして作ってください）".format(path, example)
    return str(path)


def title_line(title, version=None):
    """見出しの行。version（「<ツール名> <版>」）を渡すと、名前の後ろに括弧で添える。"""
    return "  " + title + ("（" + version + "）" if version else "")


def print_config_header(title, path, example="config.example.yaml", version=None):
    """メニューの見出し。ツールの名前と版、読む設定ファイル（5 つのツールで同じ形）。"""
    print()
    hr()
    print(title_line(title, version))
    hr()
    print("  設定ファイル: " + describe_config(path, example))


def input_text(prompt, default="", validate=None, hint=""):
    """
    文字列を入力させる。空 Enter は default を採用する。
    default が無い状態で空 Enter を押した場合は None（戻る）を返す。
    validate を渡すと、通るまで hint を示して聞き直す。
    """
    suffix = " [Enter={}]".format(default) if default else "（空 Enter で戻る）"
    while True:
        answer = input("  {}{}: ".format(prompt, suffix)).strip()
        if not answer:
            return default or None
        if validate is None or validate(answer):
            return answer
        print("  ※ " + hint)


def confirm(prompt):
    """y/N で確認する。y / yes 以外はすべて「いいえ」"""
    return input("  {} [y/N]: ".format(prompt)).strip().lower() in ("y", "yes")


def clean_path(text):
    """ドラッグ＆ドロップで付く引用符や前後の空白を除く。"""
    text = text.strip()
    if len(text) >= 2 and text[0] == text[-1] and text[0] in "\"'":
        text = text[1:-1]
    return text.replace("\\ ", " ") if sys.platform != "win32" else text


def wait_enter():
    input("\n  Enter キーでメニューに戻ります...")


# メニューの側が返す終了コード（run_script）の意味。5 つのツールで同じ
MENU_EXIT_MEANINGS = {
    EXIT_NOT_FOUND: "本体が見つかりません",
    EXIT_INTERRUPTED: "中断しました",
}


def describe_exit(code, meanings):
    """
    本体を動かした後の「終了コード: N（意味）」の文。meanings は、そのツールの README の「終了コード」と揃えた表。
    表に無ければメニューの側の意味（127・130）、それにも無ければ想定外と示す。
    """
    meaning = meanings.get(code) or MENU_EXIT_MEANINGS.get(code) or "想定外の終了コードです"
    return "終了コード: {}（{}）".format(code, meaning)


def show_result(text):
    """本体を動かした後の結果（終了コードなど）を区切り線の下に出す。"""
    print()
    hr("-")
    print("  " + text)


# ===========================================================================
# 前回値の記憶
# ===========================================================================


def load_history(path):
    """前回の選択を読む。無い・壊れている・形が違うときは空で続ける。"""
    try:
        with open(str(path), encoding="utf-8") as f:
            data = json.load(f)
        return data if isinstance(data, dict) else {}
    except (OSError, ValueError):
        return {}


def save_history(path, data):
    """選択を保存する。書けなくても実行は妨げない。"""
    try:
        with open(str(path), "w", encoding="utf-8") as f:
            json.dump(data, f, ensure_ascii=False, indent=2)
    except OSError:
        pass


# ===========================================================================
# 本体の起動
# ===========================================================================


def run_script(script, args, cwd):
    """
    本体を別のプロセスで動かして終了コードを返す。本体が無ければ 127、中断したら 130。

    Ctrl+C は本体も同じものを受け、書きかけの記録を書き終えてから止まる。subprocess.run は
    本体をすぐ止めてしまうため、終わるまで待つ（もう一度押せば止める）。
    """
    if not script.is_file():
        print("\n  ※ 本体が見つかりません: {}".format(script))
        return EXIT_NOT_FOUND
    print()
    hr("-")
    process = subprocess.Popen([sys.executable, str(script)] + list(args), cwd=str(cwd))
    try:
        return process.wait()
    except KeyboardInterrupt:
        try:
            process.wait()
        except KeyboardInterrupt:
            process.kill()
            process.wait()
        print("\n  中断しました。")
        return EXIT_INTERRUPTED


def run_loop(loop):
    """
    メニューの繰り返し（loop）を動かし、入力の終わりと中断を終了コードにする。
    loop は「終了」を選んだら exit_menu() を呼ぶ。
    """
    try:
        loop()
    except EOFError:
        print("\n  入力が終了しました。")
        sys.exit(EXIT_EOF)
    except KeyboardInterrupt:
        print("\n  中断しました。")
        sys.exit(EXIT_INTERRUPTED)


def exit_menu():
    print("  終了します。")
    sys.exit(EXIT_OK)
