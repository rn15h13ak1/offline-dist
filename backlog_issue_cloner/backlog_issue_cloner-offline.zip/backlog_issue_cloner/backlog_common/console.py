"""
画面への表示と確認
==================
表の桁をそろえる表示と、書き込む前の [y/N] の確認。本体（メニューでなく）で使う。

古い Python でも読める書き方に保つ（f 文字列・注釈を使わない。開発のテストが確かめる）。
"""

import sys
import unicodedata


def display_width(text):
    """端末上の表示幅。全角文字を 2 桁として数える。"""
    return sum(2 if unicodedata.east_asian_width(c) in ("W", "F") else 1 for c in text)


def pad(text, width):
    """表示幅が width になるまで、後ろに空白を足す。"""
    return text + " " * max(0, width - display_width(text))


def has_tty():
    """
    人に尋ねられる（標準入力が端末）か。pythonw やサービスから動かすと sys.stdin が None になるので、それも端末でないとする。
    """
    return bool(sys.stdin and sys.stdin.isatty())


def not_tty_text(what, nothing, how):
    """
    端末でない所から動かして、人に確かめられなかったときの文（5 つのツールで同じ形）。

    「端末でない所から動かしているため、<what>を確かめられません。<nothing>。<how>」。
    何をしなかったか（nothing）と、続けるにはどうするか（how。--yes など）を必ず書く。
    呼んだ側（AI・定期実行）が、人に許可を求めればよいと分かるように。
    """
    return "端末でない所から動かしているため、{}を確かめられません。{}。{}".format(what, nothing, how)


def ask_yes(prompt, assume_yes, on_no_tty):
    """
    書き込む前の [y/N] の確認。y / yes なら True。

    - assume_yes（--yes）なら聞かずに True。問いの後ろに「y（--yes 指定）」と出して、確かめたことを残す
    - 端末でない所（タスクスケジューラ・ほかのプログラム）からは聞けないので、on_no_tty() の結果を返す。
      ツールによって、スキップとして False を返すか、例外で止めるかが違う（どちらも終了コードは 20）
    - 入力の終わり（Ctrl+Z / Ctrl+D）は「いいえ」
    """
    if assume_yes:
        print("{} y（--yes 指定）".format(prompt.rstrip()))
        return True
    if not has_tty():
        return on_no_tty()
    try:
        return input(prompt).strip().lower() in ("y", "yes")
    except EOFError:
        return False
