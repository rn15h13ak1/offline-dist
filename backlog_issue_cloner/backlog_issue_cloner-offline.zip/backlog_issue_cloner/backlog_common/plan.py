"""
書き込みの計画と結果のファイル
==============================
書き込む 4 つのツールで、人が許可した計画のまま書き込むための部品。

- 計画ファイル（--plan-out）: ドライランが、これから作る・変える・投稿するものを JSON で書く
- 計画との照合（--plan）: 書き込む前に計画を立て直し、渡された計画と違えば何も送らずに止める（終了コード 21）
- 結果のファイル（--result-out）: 書き込んだものを、1 件ごとに JSON で書き直す。途中で止まっても、そこまでの分が残る
- --yes を拒む設定: 環境変数 BACKLOG_TOOLS_NO_YES があれば --yes を受け付けない。最後の 1 回は人が端末で確かめる

計画の中身（操作の一覧）は各ツールが作る。操作は辞書で、"id"（実行のたびに同じになる名前。行番号など）と
"op"（create / update / comment）を必ず持つ。ほかの項目は、違えば止めたいもの（件名・送る値・本文の指紋など）。

古い Python でも読める書き方に保つ（f 文字列・注釈を使わない。開発のテストが確かめる）。
"""

import hashlib
import json
import os
import sys

# 計画ファイルの形の版。形を変えたら上げ、古い形のファイルは受け付けない
PLAN_FORMAT = 1

# 渡された計画と、今の状態で立て直した計画が違うので、何も送らずに止めたときの終了コード
EXIT_PLAN_MISMATCH = 21

# これがあれば --yes を受け付けない（"" と "0" は無いのと同じ）
NO_YES_ENV = "BACKLOG_TOOLS_NO_YES"

HELP_PLAN_OUT = "計画（作る・変える・投稿するもの）を JSON のファイルに書く。人に見せて許可を得るときに使う"
HELP_PLAN = ("--plan-out で書いた計画のファイル。今の状態で立て直した計画がこれと同じときだけ書き込み、"
             "違えば何も送らずに終了コード 21 で止まる")
HELP_RESULT_OUT = "書き込んだ結果を JSON のファイルに書く（1 件ごとに書き直す。書き込むときだけ）"


class PlanError(Exception):
    """計画のファイルを読めない・形が違う。"""


def add_plan_options(parser):
    """--plan-out・--plan・--result-out を、4 つのツールで同じ名前と説明で足す。"""
    parser.add_argument("--plan-out", metavar="FILE", help=HELP_PLAN_OUT)
    parser.add_argument("--plan", metavar="FILE", help=HELP_PLAN)
    parser.add_argument("--result-out", metavar="FILE", help=HELP_RESULT_OUT)


def jsonable(value):
    """JSON に書ける形にする。日付などは文字列にし、集合は並べてリストにする。"""
    if isinstance(value, dict):
        return dict((str(k), jsonable(v)) for k, v in value.items())
    if isinstance(value, (list, tuple)):
        return [jsonable(v) for v in value]
    if isinstance(value, (set, frozenset)):
        return sorted(jsonable(v) for v in value)
    if value is None or isinstance(value, (bool, int, float, str)):
        return value
    return str(value)


def text_digest(text):
    """文字列の SHA-256（本文など、計画に全文を入れたくないもの）。"""
    return hashlib.sha256(text.encode("utf-8")).hexdigest()


def file_digest(path):
    """
    ファイルの SHA-256。無ければ None。

    設定ファイルの api_key の行は除いてから数える。キーを差し替えただけで計画が合わなくなったり、
    計画ファイルからキーが推し量れたりしないように。
    """
    try:
        with open(path, "rb") as f:
            data = f.read()
    except OSError:
        return None
    lines = data.splitlines(True)
    kept = [line for line in lines if not line.lstrip().startswith(b"api_key")]
    return hashlib.sha256(b"".join(kept)).hexdigest()


def fingerprint(plan):
    """計画の指紋。ツール・版・引数・入力・操作から作る（書いた時刻などは含めない）。"""
    body = dict((k, plan.get(k)) for k in ("tool", "version", "args", "inputs", "operations"))
    text = json.dumps(jsonable(body), ensure_ascii=False, sort_keys=True, separators=(",", ":"))
    return text_digest(text)


def make_plan(tool, version, args, inputs, operations):
    """
    計画を作る。args は計画に効く引数、inputs は {名前: 指紋}、operations は操作の一覧。
    """
    plan = {
        "format": PLAN_FORMAT,
        "tool": tool,
        "version": version,
        "args": jsonable(args),
        "inputs": jsonable(inputs),
        "operations": jsonable(operations),
    }
    plan["fingerprint"] = fingerprint(plan)
    return plan


def _write_json(path, data):
    """途中で止まっても壊れたファイルを残さないよう、隣に書いてから置き換える。"""
    folder = os.path.dirname(os.path.abspath(path))
    if not os.path.isdir(folder):
        os.makedirs(folder)
    tmp = path + ".tmp"
    with open(tmp, "w", encoding="utf-8", newline="\n") as f:
        json.dump(data, f, ensure_ascii=False, indent=2)
        f.write("\n")
    os.replace(tmp, path)


def write_plan(path, plan):
    _write_json(path, plan)


def load_plan(path):
    """計画のファイルを読む。読めない・形が違うときは PlanError。"""
    try:
        with open(path, encoding="utf-8") as f:
            plan = json.load(f)
    except OSError as e:
        raise PlanError("計画のファイルを読めません: {}（{}）".format(path, e.strerror or e)) from None
    except ValueError as e:
        raise PlanError("計画のファイルが JSON ではありません: {}（{}）".format(path, e)) from None
    if not isinstance(plan, dict) or not isinstance(plan.get("operations"), list):
        raise PlanError("計画のファイルの形が違います: {}".format(path))
    if plan.get("format") != PLAN_FORMAT:
        raise PlanError("計画のファイルの形の版が違います: {}（{} を読めます）".format(path, PLAN_FORMAT))
    if plan.get("fingerprint") != fingerprint(plan):
        raise PlanError("計画のファイルが書いた後に変えられています: {}。--plan-out で書き直してください".format(path))
    return plan


def describe(op):
    """操作を 1 行で示す（違いの表示に使う）。"""
    parts = [str(op.get("id", "?")), str(op.get("op", "?"))]
    for key in ("issue", "summary", "date"):
        if op.get(key):
            parts.append(str(op[key]))
    return " ".join(parts)


def differences(saved, current):
    """
    渡された計画（saved）と、今立て直した計画（current）の違いを、人が読む行の一覧で返す。同じなら空。
    """
    lines = []
    if saved.get("tool") != current.get("tool"):
        lines.append("ツールが違います: 計画 {} / 今 {}".format(saved.get("tool"), current.get("tool")))
        return lines
    if saved.get("version") != current.get("version"):
        lines.append("版が違います: 計画 {} / 今 {}".format(saved.get("version"), current.get("version")))
    for key in sorted(set(saved.get("args") or {}) | set(current.get("args") or {})):
        old, new = (saved.get("args") or {}).get(key), (current.get("args") or {}).get(key)
        if old != new:
            lines.append("引数 {} が違います: 計画 {} / 今 {}".format(key, json.dumps(old, ensure_ascii=False),
                                                              json.dumps(new, ensure_ascii=False)))
    for key in sorted(set(saved.get("inputs") or {}) | set(current.get("inputs") or {})):
        if (saved.get("inputs") or {}).get(key) != (current.get("inputs") or {}).get(key):
            lines.append("入力のファイルが計画の後に変わりました: {}".format(key))
    old_ops = dict((op.get("id"), op) for op in saved.get("operations") or [])
    new_ops = dict((op.get("id"), op) for op in current.get("operations") or [])
    for op in current.get("operations") or []:
        if op.get("id") not in old_ops:
            lines.append("増えた操作: " + describe(op))
        elif old_ops[op.get("id")] != op:
            # 1 行の見え方が同じなら、中身（送る値・本文の指紋など）が違う
            old, new = describe(old_ops[op.get("id")]), describe(op)
            lines.append("変わった操作: " + (new if old == new else old + " → " + new))
    for op in saved.get("operations") or []:
        if op.get("id") not in new_ops:
            lines.append("減った操作: " + describe(op))
    if not lines and saved.get("fingerprint") != current.get("fingerprint"):
        # 並びだけが違う
        lines.append("操作の順が違います")
    return lines


def settle(current, plan_out=None, plan_path=None, saved=None, out=None, err=None):
    """
    立て直した計画（current）を、--plan-out なら書き、--plan なら渡された計画（saved）と照らし合わせる。
    計画と違えば違いをエラーの出力に出して False を返す（呼ぶ側は何も送らずに EXIT_PLAN_MISMATCH で止める）。
    どちらの引数も無ければ何も出さずに True を返す。
    """
    out = sys.stdout if out is None else out
    err = sys.stderr if err is None else err
    if plan_out:
        write_plan(plan_out, current)
        print("計画を書きました: {}（操作 {} 件）".format(plan_out, len(current["operations"])), file=out)
    if saved is None:
        return True
    lines = differences(saved, current)
    if lines:
        print(mismatch_text(plan_path, lines), file=err)
        return False
    print("計画のファイル（{}）と同じです（操作 {} 件）。".format(plan_path, len(current["operations"])), file=out)
    return True


def mismatch_text(path, lines):
    """計画と違ったときにエラーの出力へ出す文。"""
    head = ("エラー: 今の状態で立て直した計画が、計画のファイル（{}）と違います。何も送っていません。\n"
            "  計画を書いた後に、Backlog・入力のファイル・設定・引数のどれかが変わりました。"
            "ドライランで計画を書き直し、人に見せて許可を取り直してください。").format(path)
    return "\n".join([head] + ["  " + line for line in lines[:50]]
                     + (["  ほか {} 件".format(len(lines) - 50)] if len(lines) > 50 else []))


class ResultLog(object):
    """
    結果のファイル（--result-out）。1 件ごとにファイル全体を書き直す。path が None なら何もしない。

    作った時点で status を running にして書く（前の実行のファイルを残さない）。status は running →
    done / failed / interrupted。running のまま残っていれば、途中で止められた。results に載っていない操作は送っていない。
    """

    def __init__(self, path, tool, version):
        self.path = path
        self.data = {
            "format": PLAN_FORMAT,
            "tool": tool,
            "version": version,
            "plan_fingerprint": None,
            "status": "running",
            "exit_code": None,
            "results": [],
        }
        self._write()

    def _write(self):
        if self.path:
            _write_json(self.path, self.data)

    def start(self, plan):
        """照らし合わせた（または立て直した）計画の指紋を記録する。書き込む直前に呼ぶ。"""
        self.data["plan_fingerprint"] = plan.get("fingerprint")
        self._write()

    def __enter__(self):
        return self

    def __exit__(self, exc_type, exc, tb):
        # 例外で抜けたら、まだ終わりを記録していなければ記録する（例外はそのまま送る）
        if exc_type is not None:
            self.close("interrupted" if issubclass(exc_type, KeyboardInterrupt) else "failed")
        return False

    def add(self, op_id, op, status, issue=None, summary=None, message=None):
        """
        status は ok / failed / skipped / no_change。同じ id をもう一度記録すると、前の記録を置き換える
        （作成の直後の更新に失敗したときなど、後の方が実際の結果）。
        """
        entry = {"id": op_id, "op": op, "status": status}
        if issue:
            entry["issue"] = issue
        if summary:
            entry["summary"] = summary
        if message:
            entry["message"] = message
        results = self.data["results"]
        for i, old in enumerate(results):
            if old["id"] == op_id:
                results[i] = entry
                break
        else:
            results.append(entry)
        self._write()

    def close(self, status, exit_code=None):
        """終わったことを記録する。2 回目からは何もしない（先に記録した方を残す）。"""
        if self.data["status"] != "running":
            return
        self.data["status"] = status
        self.data["exit_code"] = exit_code
        self._write()


class PlanRequest(object):
    """
    1 回の実行での --plan-out・--plan の扱い。ツールは操作の一覧を作って settle() に渡す。

    args は計画に効く引数（辞書）、inputs は {名前: 入力のファイルの指紋}。
    """

    def __init__(self, tool, version, args=None, inputs=None, plan_out=None, plan_path=None, saved=None):
        self.tool = tool
        self.version = version
        self.args = args or {}
        self.inputs = inputs or {}
        self.plan_out = plan_out
        self.plan_path = plan_path
        self.saved = saved
        self.current = None

    @classmethod
    def from_args(cls, args, tool, version, plan_args=None, inputs=None):
        """argparse の結果（plan_out・plan）から作る。計画のファイルを読めなければ PlanError。"""
        saved = load_plan(args.plan) if getattr(args, "plan", None) else None
        return cls(tool, version, plan_args, inputs, getattr(args, "plan_out", None), getattr(args, "plan", None),
                   saved)

    def active(self):
        """--plan-out か --plan が渡されたか（計画を作る手間を省くかの判断に使う）。"""
        return bool(self.plan_out) or self.saved is not None

    def settle(self, operations, out=None, err=None):
        """計画を作って書く・照らし合わせる。計画と違えば False（何も送らずに止める）。"""
        self.current = make_plan(self.tool, self.version, self.args, self.inputs, operations)
        return settle(self.current, self.plan_out, self.plan_path, self.saved, out, err)


def yes_refused(yes, environ=None):
    """--yes が付いていて、それを拒む設定（環境変数）があるか。"""
    environ = os.environ if environ is None else environ
    return bool(yes) and environ.get(NO_YES_ENV, "") not in ("", "0")


def _quote(arg):
    if arg and not any(c in arg for c in " \t\"'&|<>^()"):
        return arg
    return '"' + arg.replace('"', '\\"') + '"'


def command_without_yes(script, argv):
    """--yes を除いたコマンド（人が端末で動かすもの）。"""
    kept = [a for a in argv if a not in ("-y", "--yes")]
    return " ".join(["python", os.path.basename(script)] + [_quote(a) for a in kept])


def refused_yes_text(script, argv):
    """--yes を拒んだときにエラーの出力へ出す文。"""
    return ("エラー: この端末では --yes を使えません（環境変数 {} が設定されています）。何も送っていません。\n"
            "  書き込むときは、人が端末で次のコマンドを動かしてください（確認が出たら人が答えます）:\n"
            "  {}").format(NO_YES_ENV, command_without_yes(script, argv))
