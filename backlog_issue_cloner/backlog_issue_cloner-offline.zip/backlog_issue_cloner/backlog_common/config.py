"""
設定ファイルと API キーの読み込み
=================================
5 つのツールで同じ意味のものだけを置く。設定ファイルの読み込み（UTF-8・BOM・YAML の書き損じを
案内にする）、backlog: の節の取り出しと例の値の扱い、API キーの探し方と、どこから読んだか。

知らない項目は、5 つとも止める（書き間違えた項目が黙って無視され、設定が効いていないことに気付けないため）。
その文と、似た項目の示し方はここに置く。どの節にどの項目を書けるか、設定ファイルを探す場所、止めるときの
終了コードは各ツールに残す。ここでは ConfigError を送出するか文を返すだけで、表示も終了もしない。

API キーは、環境変数 BACKLOG_API_KEY → 設定ファイルの backlog.api_key → .env の順に探す。
.env は、設定ファイルの隣 → ツールのフォルダ → 作業フォルダの順に探す。

ほかの部品と書き方を揃える（f 文字列・注釈を使わない）。PyYAML は読むときに初めて import する。
入っていないときの案内は、各ツールの入口が出す。
"""

import difflib
import math
import os
from pathlib import Path

API_KEY_ENV = "BACKLOG_API_KEY"

# 設定ファイルの例（config.example.yaml など）の値。コピーしたまま残っていても、書いていないものとして扱う
PLACEHOLDERS = frozenset((
    "yourcompany.backlog.com",
    "YOUR_API_KEY_HERE",
    "YOUR_PROJECT_KEY",
))


class ConfigError(Exception):
    """設定の誤り。人が直すもの。どう止めるか（終了コード）は各ツールが決める"""


# backlog: の節に書ける項目。5 つのツールで同じ。project_key は、プロジェクトを決めて動くツールだけが足す
BACKLOG_KEYS = (
    "space_host", "api_key", "ssl_verify", "base_path",
    "timeout", "max_retries", "retry_backoff", "retry_max_delay",
)

# backlog: の節の通信の設定（BacklogClient に同じ名前で渡す）と、受け付ける下限と上限。書かなければ BacklogClient の既定。
# 上限は、桁を誤った値を止めるため（timeout: 10000000000 は通信を始めたところで OverflowError になる）。
# どれも 1 時間・100 回より長く待つ使い方は無い
CLIENT_SETTINGS = (
    ("timeout", 1, 3600),
    ("max_retries", 0, 100),
    ("retry_backoff", 0, 3600),
    ("retry_max_delay", 0, 3600),
)

# 通信の設定のうち回数のもの。整数に限る（1.5 回は書き間違い）
COUNT_SETTINGS = ("max_retries",)


def suggest_key(key, candidates):
    """
    書き間違いと思われる項目に、似た項目を 1 つ返す。無ければ None。

    大文字・小文字だけの違いを先に見る。候補は名前順に並べてから比べるので、同じ書き間違いには毎回同じ項目を示す。
    """
    names = sorted(str(c) for c in candidates)
    lowered = str(key).lower()
    for name in names:
        if name.lower() == lowered:
            return name
    close = difflib.get_close_matches(str(key), names, n=1, cutoff=0.6)
    return close[0] if close else None


def unknown_keys(section, allowed, path=""):
    """
    section（辞書）の中の、allowed に無い項目の文の一覧。無ければ空のリスト。

    文は「backlog.ssl_verfy は知らない項目です（ssl_verify の書き間違いでは？）」の形。path は節の名前（最上位なら ""）。
    """
    if not isinstance(section, dict):
        return []
    problems = []
    for key in section:
        if key in allowed:
            continue
        name = "{}.{}".format(path, key) if path else str(key)
        near = suggest_key(key, allowed)
        hint = "（{} の書き間違いでは？）".format(near) if near else ""
        problems.append("{} は知らない項目です{}".format(name, hint))
    return problems


def client_settings(section):
    """
    backlog: の節の通信の設定（timeout・max_retries・retry_backoff・retry_max_delay）を、BacklogClient に渡す引数にする。

    書いていないものは入れない（BacklogClient の既定。30 秒・3 回・2 秒・60 秒）。数でない・下限と上限の外・
    NaN や inf・回数（max_retries）の整数でないものは ConfigError。NaN は比べると常に偽なので、
    大小だけでは通ってしまう。
    真偽値は数として扱わない（YAML の true は 1 と等しいが、書き間違いのため）。

    ssl_verify も、書いてあって真偽値でなければ ConfigError にする。"false" と書くと真になって証明書を確かめたままになり、
    値を空にする（None）と偽になって確かめなくなるため。ssl_verify は呼ぶ側が ssl_verify= で渡すので、返す引数には入れない。
    """
    problems = bool_problems(section, ["ssl_verify"], "backlog")
    if problems:
        raise ConfigError(problems[0])
    options = {}
    for key, minimum, maximum in CLIENT_SETTINGS:
        if section.get(key) is None:
            continue
        value = section[key]
        if key in COUNT_SETTINGS:
            problems = int_problems(section, [key], "backlog", minimum, maximum)
            if problems:
                raise ConfigError(problems[0])
        # 大きな int を isfinite に渡すと OverflowError になるので、見るのは float のときだけ
        elif (isinstance(value, bool) or not isinstance(value, (int, float)) or not minimum <= value <= maximum
              or (isinstance(value, float) and not math.isfinite(value))):
            raise ConfigError("backlog.{} は {}〜{} の数で書いてください: {!r}".format(key, minimum, maximum, value))
        options[key] = value
    return options


def _name(path, key):
    return "{}.{}".format(path, key) if path else str(key)


def bool_problems(section, keys, path=""):
    """
    keys のうち、書いてあって真偽値でないものの文の一覧（「upsert.enabled は true / false で書いてください: 'false'」）。

    "false"（文字列）や "no" は、使う側が真偽で判定すると真になり、無効のつもりの設定が有効になる。
    値を空にした（None）ものも止める（偽になって、書いた人の意図と違いうる）。section が辞書でなければ空。
    """
    if not isinstance(section, dict):
        return []
    return ["{} は true / false で書いてください: {!r}".format(_name(path, key), section[key])
            for key in keys if key in section and not isinstance(section[key], bool)]


def is_int(value):
    """整数か。真偽値（YAML の true は 1 と等しい）・小数・NaN・inf・文字列は整数でない"""
    return isinstance(value, int) and not isinstance(value, bool)


def int_problems(section, keys, path="", minimum=None, maximum=None):
    """
    keys のうち、書いてあって範囲の整数でないものの文の一覧（「excel.data_start_row は 1 以上の整数で書いてください: 1.5」）。

    int() を通すだけだと、1.5 と true は 1、"2" は 2 として黙って通り、NaN と inf は使うところでトレースバックになる。
    値を空にした（None）ものも止める。section が辞書でなければ空。
    """
    if not isinstance(section, dict):
        return []
    if minimum is not None and maximum is not None:
        want = " {}〜{} の整数".format(minimum, maximum)
    elif minimum is not None:
        want = " {} 以上の整数".format(minimum)
    else:
        want = "整数"
    problems = []
    for key in keys:
        if key not in section:
            continue
        value = section[key]
        if (not is_int(value) or (minimum is not None and value < minimum)
                or (maximum is not None and value > maximum)):
            problems.append("{} は{}で書いてください: {!r}".format(_name(path, key), want, value))
    return problems


def text_problems(section, keys, path=""):
    """keys のうち、書いてあって文字列でないものの文の一覧。値を空にした（None）ものは、書いていないものとして通す"""
    if not isinstance(section, dict):
        return []
    return ["{} は文字列で書いてください: {!r}".format(_name(path, key), section[key])
            for key in keys if section.get(key) is not None and not isinstance(section[key], str)]


def section_problems(config, name, required=False, example="config.example.yaml"):
    """
    (節, 誤りの文の一覧)。config の name の節を辞書で返す。

    - 辞書でない（「report: []」「target: P-1」など）なら、空の辞書と文。そのまま .get を呼ぶとトレースバックになる
    - 無い・中身が無い（子の行をすべてコメントにした）なら、空の辞書。required なら「節がありません」の文
    name は文に出す名前（「report.period」など、上の節を含めてよい）。config が辞書でなければ空の辞書だけ。
    """
    key = name.rsplit(".", 1)[-1]
    value = config.get(key) if isinstance(config, dict) else None
    if value is None:
        if required:
            return {}, ["{} の節がありません（{} を参考に書いてください）".format(name, example)]
        return {}, []
    if not isinstance(value, dict):
        return {}, ["{} の節の形が不正です（「項目: 値」を字下げして並べます）: {!r}".format(name, value)]
    return value, []


def backlog_problems(config, required=("space_host",), extra_keys=(), example="config.example.yaml"):
    """
    (backlog: の節, 誤りの文の一覧)。節の形・知らない項目・通信の設定と ssl_verify・書いていない必須の項目を、
    5 つのツールで同じ文と順で確かめる。

    extra_keys はツールが足す項目（project_key）。節が無ければ「backlog の節がありません」だけを示す
    （その下の必須の項目が空、を重ねない）。文は problems_text でまとめて示す。
    """
    section, problems = section_problems(config, "backlog", True, example)
    if problems:
        return section, problems
    problems = unknown_keys(section, set(BACKLOG_KEYS) | set(extra_keys), "backlog")
    try:
        client_settings(section)
    except ConfigError as e:
        problems.append(str(e))
    return section, problems + missing_problems(section, required)


def read_text_utf8(path, what):
    """
    UTF-8 のテキストを読む。BOM 付きでもよい（メモ帳の「UTF-8 (BOM 付き)」）。

    Windows では、メモ帳の ANSI（CP932）や PowerShell 5 の `echo ... > .env`（UTF-16）で
    作ったファイルがありうる。トレースバックにせず、保存し直す手順を示して止める。
    """
    try:
        return Path(path).read_text(encoding="utf-8-sig")
    except UnicodeDecodeError:
        raise ConfigError(
            "{}を UTF-8 として読めません: {}\n"
            "  → メモ帳で開き、「名前を付けて保存」で文字コードを「UTF-8」にして保存し直してください".format(what, path)
        ) from None


def find_config(explicit, candidates, example="config.example.yaml"):
    """
    設定ファイルの場所。explicit（--config）があればそれ、無ければ candidates の最初にあるもの。

    探す場所はツールごとに違う（作業フォルダを先に見るものと、スクリプトの隣だけのもの）ので、
    呼ぶ側が渡す。
    """
    if explicit:
        path = Path(explicit)
        if not path.is_file():
            raise ConfigError("設定ファイルが見つかりません: {}（{} をコピーして作ってください）".format(path, example))
        return path
    for candidate in candidates:
        if Path(candidate).is_file():
            return Path(candidate)
    places = "".join("\n    {}".format(c) for c in candidates)
    raise ConfigError(
        "設定ファイル config.yaml が見つかりません。{} をコピーして作ってください"
        "（--config で場所を指定することもできます）。探した場所:{}".format(example, places)
    )


def load_config(path, example="config.example.yaml"):
    """
    設定ファイルを読み、辞書で返す。中の項目は確かめない（各ツールが確かめる）。

    無い・UTF-8 でない・YAML の書き損じ・空・形が不正（辞書でない）は、ConfigError にする。
    """
    import yaml

    path = Path(path)
    if not path.is_file():
        raise ConfigError("設定ファイルが見つかりません: {}（{} をコピーして作ってください）".format(path, example))
    text = read_text_utf8(path, "設定ファイル")
    try:
        config = yaml.safe_load(text)
    except yaml.YAMLError as e:
        raise ConfigError(
            "設定ファイルを YAML として読めません: {}\n  {}\n"
            "  → 示された行の字下げ（空白の数）と、「:」の後の空白を確かめてください。"
            "値に「:」や「#」を含むときは \"\" で囲みます".format(path, e)
        ) from None
    if config is None:
        raise ConfigError("設定ファイルが空です: {}（{} を参考に書いてください）".format(path, example))
    if not isinstance(config, dict):
        raise ConfigError(
            "設定ファイルの形が不正です: {}（「backlog:」などの節を並べる形で書いてください。"
            "{} を参考にしてください）".format(path, example)
        )
    return config


def backlog_section(config):
    """
    backlog: の節。無ければ空の辞書。辞書でなければ ConfigError。

    節が無いときにどう伝えるか（ほかの誤りとまとめて示すか）は、各ツールが決める。
    """
    section = config.get("backlog")
    if section is None:
        return {}
    if not isinstance(section, dict):
        raise ConfigError(section_problems(config, "backlog")[1][0])
    return section


def is_placeholder(value):
    return isinstance(value, str) and value.strip() in PLACEHOLDERS


def setting(section, key):
    """
    節の値を文字列で返す。無い・空・例の値のままは ""（書いていないものとして扱う）。
    """
    value = section.get(key)
    if value is None or is_placeholder(value):
        return ""
    return str(value).strip()


def missing_settings(section, keys):
    """keys のうち、書いていない（空・例の値のまま）もの"""
    return [key for key in keys if not setting(section, key)]


def missing_problems(section, keys, path="backlog"):
    """
    keys のうち書いていないものの文の一覧（「backlog.space_host が空です」「backlog.project_key が例のままです」）。

    例の値のままなのか、書いていないのかを分けて示す。例をコピーして書き換え忘れたことに気付けるように。
    """
    problems = []
    for key in keys:
        value = section.get(key) if isinstance(section, dict) else None
        if is_placeholder(value):
            problems.append("{}.{} が例のままです".format(path, key))
        elif not setting(section if isinstance(section, dict) else {}, key):
            problems.append("{}.{} が空です".format(path, key))
    return problems


def problems_text(path, problems):
    """
    設定の誤りの文。1 行目に読んだ設定ファイル、2 行目からは誤りを 1 つずつ並べる（5 つのツールで同じ形）。

    以前は「config.yaml の backlog.space_host を…」と書くツールがあり、--config で別のファイルを渡しても
    config.yaml と出ていた。
    """
    return "設定ファイルに誤りがあります: {}\n  ".format(path) + "\n  ".join(problems)


def read_dotenv(path):
    """
    .env の KEY=VALUE の行を読む。# で始まる行と空行は飛ばす。無ければ空の辞書。

    書き方の揺れを受け付ける: 先頭の `export `、値の前後の引用符、cmd で `echo 'KEY=値' > .env` と
    打って行全体が引用符に入ったもの、BOM 付き。UTF-8 でなければ ConfigError。
    """
    values = {}  # type: dict
    path = Path(path)
    if not path.is_file():
        return values
    for line in read_text_utf8(path, ".env ファイル").splitlines():
        line = line.strip()
        if len(line) >= 2 and line[0] == line[-1] and line[0] in "\"'":
            line = line[1:-1].strip()
        if not line or line.startswith("#") or "=" not in line:
            continue
        key, _, value = line.partition("=")
        key = key.strip()
        if key.startswith("export "):
            key = key[len("export "):].strip()
        value = value.strip()
        if len(value) >= 2 and value[0] == value[-1] and value[0] in "\"'":
            value = value[1:-1]
        values[key] = value
    return values


def dotenv_candidates(config_path=None, tool_dir=None, cwd=None):
    """
    .env を探す場所（同じ場所は 1 度だけ）。設定ファイルの隣 → ツールのフォルダ → 作業フォルダ。

    設定ファイルを別の場所に置いたとき、その隣の .env が読まれないと気付きにくいため、まずそこを見る。
    """
    places = []
    if config_path is not None:
        places.append(Path(config_path).resolve().parent)
    if tool_dir is not None:
        places.append(Path(tool_dir).resolve())
    places.append(Path(cwd if cwd is not None else os.getcwd()).resolve())
    seen = []
    for place in places:
        candidate = place / ".env"
        if candidate not in seen:
            seen.append(candidate)
    return seen


def locate_api_key(config_path=None, config_value=None, tool_dir=None, env=None, cwd=None):
    """
    (API キー, どこから読んだか)。環境変数 → 設定ファイルの値（config_value）→ .env の順に探す。
    例の値のままのものは、書いていないものとして扱う。

    環境変数を先に見るのは、設定ファイルを書き換えずに差し替えられるようにするため。そのぶん、
    別の用途で設定した BACKLOG_API_KEY が先に使われうる。どこから読んだかは、認証・権限のエラーの
    ときに、どこを直せばよいかを示すのに使う。見つからなければ、探した場所を示して ConfigError。
    """
    source = os.environ if env is None else env
    value = (source.get(API_KEY_ENV) or "").strip()
    if value and not is_placeholder(value):
        return value, "環境変数 {}".format(API_KEY_ENV)
    if isinstance(config_value, str) and config_value.strip() and not is_placeholder(config_value):
        where = "設定ファイル {} の backlog.api_key".format(config_path) if config_path else "設定ファイルの backlog.api_key"
        return config_value.strip(), where
    candidates = dotenv_candidates(config_path, tool_dir, cwd)
    without_key = []
    for path in candidates:
        value = (read_dotenv(path).get(API_KEY_ENV) or "").strip()
        if value and not is_placeholder(value):
            return value, "{} の {}".format(path, API_KEY_ENV)
        if path.is_file():
            without_key.append(path)
    message = (
        "API キーがありません。次のどれかに書いてください（上から順に探します）。\n"
        "  - 環境変数 {key}\n"
        "  - 設定ファイルの backlog.api_key\n"
        "  - 次のどれかの .env（{key}=... の行）".format(key=API_KEY_ENV)
    )
    message += "".join("\n      {}".format(path) for path in candidates)
    for path in without_key:
        # 書いたつもりなのに読めていないことに、気付けるように
        message += "\n  {} はありますが、{}=... の行が見つかりませんでした".format(path, API_KEY_ENV)
    raise ConfigError(message)


def api_key_source_line(source):
    """認証・権限のエラー（401・403）のときに添える 1 行。どこを直せばよいかが分かるように"""
    return "  使った API キー: {}".format(source)
