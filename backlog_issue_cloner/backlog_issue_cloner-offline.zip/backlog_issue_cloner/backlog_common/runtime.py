"""
実行環境への手当て
==================
入口（本体・メニュー）で、ほかの処理より先に呼ぶ。

メニューはどの Python からでも起動されうるため、このファイルは古い Python でも読める書き方に保つ
（f 文字列・注釈を使わない。開発のテストが確かめる）。
"""

import importlib
import sys

# 本体が動く Python の下限（各ツールのパッケージの定義の requires-python と揃える。開発のテストが確かめる）
MIN_PYTHON = (3, 10)

# Ctrl+C で止めたときの終了コード（シェルが SIGINT で止まったものに使う値）
EXIT_INTERRUPTED = 130


def make_console_safe(streams=None):
    """
    UTF-8 でないコンソールで、表せない文字を「?」に置き換えて出すようにする。

    Windows の日本語コンソールは既定で CP932 で、CP932 に無い文字を print すると
    UnicodeEncodeError で落ちる。ソースの文字は開発のテストで CP932 に収めているが、
    課題の件名など Backlog から来る文字（絵文字など）は防げない。落ちるよりは、その文字だけ
    「?」になる方がよい。

    - コードページ（chcp）は変えない。同じ窓で次に動かすものに影響するため
    - 置き換えるのは画面の表示だけ。Backlog に送る内容や、ファイルに書く内容は変わらない
    - UTF-8 のコンソール（macOS など）では何もしない
    """
    for stream in (sys.stdout, sys.stderr) if streams is None else streams:
        encoding = (getattr(stream, "encoding", None) or "").lower().replace("-", "").replace("_", "")
        if encoding in ("", "utf8") or not hasattr(stream, "reconfigure"):
            continue
        try:
            stream.reconfigure(errors="replace")
        except (ValueError, OSError):
            pass


def require_python(version_info=None, stream=None, code=1):
    """
    Python が古ければ、入れ直す案内を出して止める（終了コード 1。違う番号を決めているツールは code で渡す）。

    本体は 3.10 以上の書き方（注釈の `str | None` など）を使うため、3.9 では import の途中で
    「unsupported operand type(s) for |」のトレースバックになる。macOS 付属の python3 は 3.9。
    ほかのモジュールを読み込む前に呼ぶ。案内は README を指す（節の名前はツールごとに違うので書かない）。
    """
    version = tuple(version_info or sys.version_info)[:2]
    if version >= MIN_PYTHON:
        return
    out = stream or sys.stderr
    need = ".".join(str(n) for n in MIN_PYTHON)
    print("Python {} 以上を入れてください。".format(need), file=out)
    print("  実行中の Python: {}（{}）".format(".".join(str(n) for n in version), sys.executable), file=out)
    print("  https://www.python.org/ から入れ、README の手順で依存も入れてください。", file=out)
    sys.exit(code)


def require_packages(packages, code=1, stream=None, importer=None):
    """
    ライブラリが入っていなければ、入れ方の案内を出して止める（終了コード 1。違う番号を決めているツールは code で渡す）。

    packages は [(import する名前, pip に渡す名前), ...]。2 つの名前は一致しない（yaml → pyyaml）。
    import の名前を案内に出すと、入らない名前を示すことになる。
    require_python() の後、ツールのモジュールを読み込む前に呼ぶ。

    - 入れる先は、実行中の Python を名指しする（"<python>" -m pip install）。Windows では Python が複数入っていることが
      あり、ただの pip install だと別の Python に入って「入れたのに直らない」が起きる
    - ライブラリの中の失敗（その依存が欠けているなど）は、入っていないとは案内せず、そのまま送出する
    """
    importer = importer or importlib.import_module
    missing = []
    for module, package in packages:
        try:
            importer(module)
        except ModuleNotFoundError as e:
            if e.name and e.name.split(".")[0] != module.split(".")[0]:
                raise
            missing.append(package)
    if not missing:
        return
    out = stream or sys.stderr
    names = " ".join(missing)
    print("必要なライブラリ {} が入っていません。".format(", ".join(missing)), file=out)
    print("  実行中の Python: {}".format(sys.executable), file=out)
    print("  次のコマンドで、この Python に入れてください:", file=out)
    print('      "{}" -m pip install {}'.format(sys.executable, names), file=out)
    print("  ライブラリが入っている別の Python（Anaconda など）があれば、そちらで動かしても構いません。", file=out)
    sys.exit(code)


def exit_on_interrupt(main, stream=None, code=EXIT_INTERRUPTED):
    """
    main() を呼び、その戻り値を返す。Ctrl+C で止めたら「中断しました。」と出して、終了コード 130 で終える。

    捕まえないと、トレースバックが出たうえ、終了コードが OS によって変わる（Windows では 3221225786）。
    起動する側（タスクスケジューラ・ランチャー・メニュー）が中断を見分けられるよう、130 にそろえる。
    途中で書いたものの後始末（finally）は、ここに来る前に済んでいる。
    中断を 130 でなく別の番号で知らせてきたツール（excel_to_backlog は 1）は、code でその番号を渡す。
    """
    try:
        return main()
    except KeyboardInterrupt:
        print("", file=stream or sys.stderr)
        print("中断しました。", file=stream or sys.stderr)
        sys.exit(code)


def exit_on_error(errors, code, func, *args, **kwargs):
    """
    func(*args, **kwargs) を呼び、その戻り値を返す。errors の例外なら「エラー: 〜」と出して、終了コード code で終える。

    設定の読み込み（backlog_common.config）は例外を送出するだけで、表示も終了もしない。どの終了コードで止めるかは
    ツールごとに違うので、入口でこれに包む。
    """
    try:
        return func(*args, **kwargs)
    except errors as e:
        print("エラー: {}".format(e), file=sys.stderr)
        sys.exit(code)


# 人の確認が要るのに確かめられず、何も送らず（書かず）に止めたときの終了コード。書き込む 4 つのツールと
# レポートで同じ値にする。呼び出した側（AI や定期実行）が、設定の誤り（2 など）と分けて
# 「人に許可を求める」と判断できるように
EXIT_NEEDS_CONFIRMATION = 20


def stop_on_sigterm():
    """
    外から止める合図（SIGTERM）を、Ctrl+C と同じ KeyboardInterrupt にする。

    コマンドを動かす道具は、時間の上限を超えると SIGTERM で止めることがある。何もしないと
    Python はその場で終わり、Ctrl+C のときに出す記録・結果のファイル・続きの案内が出ない。
    入口で呼び、Ctrl+C の後始末をそのまま効かせる。

    - 呼べるのはメインのスレッドだけ。呼べない環境（SIGTERM が無いなど）では何もしない
    - Windows では、捕まえられない止め方（プロセスを強制終了する）がある。そのときは今までどおり
    """
    import signal

    def _interrupt(signum, frame):
        raise KeyboardInterrupt

    try:
        signal.signal(signal.SIGTERM, _interrupt)
    except (AttributeError, ValueError, OSError):
        pass
