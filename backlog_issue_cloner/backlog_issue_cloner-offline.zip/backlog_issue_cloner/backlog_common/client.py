"""
Backlog API クライアント
========================
5 つのツールで共通の通信（送る・再送する・待つ・エラーにする）と、どのツールでも使う取得・課題の作成と更新。
ツールだけのもの（コメントの投稿・履歴の取得・キーワードでの検索など）は、各ツールがこのクラスの子クラスに書く。

再送の決まり:
  - GET              : 429・5xx・通信の失敗（タイムアウト・接続の失敗・応答の途中での切断・JSON でない応答）で再送する
  - PATCH            : GET と同じ。ただし params に comment を含むもの（コメントが付く更新）は、POST と同じ扱いにする
  - POST             : 429 と、届いていないと分かる失敗（接続を張る前後の URLError）だけ再送する。
                       5xx・タイムアウト・応答の途中での切断は、Backlog 側で処理済みかもしれないため再送しない
  - retry=False      : 429 を含めて再送しない（コメントの投稿など、二重になると困るもの）

待ち方: 429 の応答に X-RateLimit-Reset（制限が戻る時刻）があればその時刻まで（上限 120 秒）、
次に Retry-After（上限は retry_max_delay）、どちらも無ければ 2・4・8 秒にばらつきを足したもの。

入口より先に読まれることがあるので、ほかの部品と書き方を揃える（f 文字列・注釈を使わない）。
画面に出す文字は CP932 に収める（再試行の案内の頭は「(待機)」）。
"""

import http.client
import json
import random
import ssl
import sys
import time
import urllib.error
import urllib.parse
import urllib.request

from .config import api_key_source_line

# 書き込みにかかる時間の目安で使う、1 回の呼び出しの秒数。レート制限の待ちを考えて長めにとる
# （短く出すと、道具の時間の上限の内だと思って動かし、途中で止められる）
SECONDS_PER_WRITE = 1.0


def estimate_text(calls):
    """
    ドライランの最後に出す、書き込みの API の呼び出しの回数と、かかる時間の目安の 1 行。

    目安は回数に SECONDS_PER_WRITE を掛けた概算。429 で待てば延びる。
    """
    seconds = calls * SECONDS_PER_WRITE
    if seconds < 60:
        span = "1 分未満"
    else:
        span = "約 {0} 分".format(int(-(-seconds // 60)))
    return "書き込みの API 呼び出し: 約 {0} 回（かかる時間の目安: {1}）".format(calls, span)


class BacklogError(Exception):
    """このモジュールが送出する例外の基底クラス。"""

    status = None


class BacklogAPIError(BacklogError):
    """
    Backlog API がエラーを返した、または通信に失敗した。

    Attributes
    ----------
    status         : int | None   HTTP ステータスコード（通信の失敗では None）
    endpoint       : str          呼び出したエンドポイント（API キーを含まない）
    detail         : str          Backlog が返したエラーメッセージ、または通信の失敗の理由
    errors         : list         Backlog のエラーオブジェクトの配列
    raw_body       : str          応答の本文（JSON として読めなかったときの表示用）
    fatal          : bool         True のとき実行全体を止めるべき（認証・権限のエラー）
    api_key_source : str          API キーをどこから読んだか（認証・権限のエラーの案内に使う）
    """

    def __init__(self, message, status=None, endpoint="", detail="", errors=None,
                 fatal=False, raw_body="", api_key_source=""):
        super(BacklogAPIError, self).__init__(message)
        self.status = status
        self.endpoint = endpoint
        self.detail = detail
        self.errors = errors or []
        self.fatal = fatal
        self.raw_body = raw_body
        self.api_key_source = api_key_source

    @property
    def status_code(self):
        """status の別名（以前のクライアントの名前）。"""
        return self.status


class BacklogNoChangeError(BacklogError):
    """更新の内容が今の課題と同じで、Backlog が変更なしとして断った。スキップとして扱う呼び出し元が使う。"""

    def __init__(self, message, status=None):
        super(BacklogNoChangeError, self).__init__(message)
        self.status = status


def _close_quietly(resource):
    """HTTPError の応答を、例外を出さずに閉じる（閉じないと ResourceWarning が出る）。"""
    try:
        resource.close()
    except Exception:
        pass


def flatten_params(params):
    """パラメータの dict を (キー, 値) の並びにする。リストの値は Backlog の key[]=v1&key[]=v2 の形に展開する。"""
    pairs = []
    for key, value in (params or {}).items():
        if isinstance(value, list):
            for v in value:
                pairs.append((str(key) + "[]", str(v)))
        else:
            pairs.append((str(key), str(value)))
    return pairs


class BacklogClient:
    # 再送の既定。インスタンスを作るときに変えられる（設定ファイルで変えられるツールがある）
    TIMEOUT = 30                 # 1 リクエストのタイムアウト（秒）
    MAX_RETRIES = 3              # 初回を除く再送の回数
    RETRY_BACKOFF = 2.0          # 既定の待ちの基準（2 → 4 → 8 秒）
    RETRY_MAX_DELAY = 60.0       # 既定の待ちと Retry-After の上限
    RETRY_JITTER = 0.5           # 既定の待ちに足すばらつき（基準の何倍までか）
    MAX_RATE_LIMIT_WAIT = 120.0  # X-RateLimit-Reset まで待つときの上限
    PAGE_SIZE = 100              # Backlog API が 1 回で返す件数の上限

    # HTTP のステータスごとの対処の案内
    HTTP_ERROR_HINTS = {
        400: "リクエストパラメータを確認してください。",
        # API キーは環境変数・設定ファイル・.env のどれからも読むため、項目名（api_key）で名指ししない。
        # どこから読んだかは呼び出し側が添える
        401: "API キーを確認してください。",
        403: "API キーの持ち主に、この操作の権限があるか確認してください"
             "（プロジェクトへの参加、課題の追加・編集の権限など）。",
        # 設定に project_key の無いツールは、確かめる項目を子クラスで上書きする
        404: "space_host・base_path・project_key を確認してください。",
        429: "API のレート制限に達しました。時間をおいて再実行してください。",
    }
    SERVER_ERROR_HINT = "Backlog 側の一時的な障害の可能性があります。時間をおいて再実行してください。"
    NETWORK_HINT = "space_host・base_path とネットワーク接続を確認してください。"
    # 処理済みかもしれない失敗で再送しなかったときの案内
    NOT_RESENT_NOTE = "Backlog 側で処理済みの可能性があるため再送しません。Backlog 側を確認してください。"

    # 「変更内容がない」ことを示す Backlog のエラーメッセージの断片。
    # error code 7（InvalidRequestError）は不正なステータスの遷移・不正なカスタム属性の値・件名の長さの超過などにも
    # 使われる汎用のコードのため、コードだけで「変更なし」と判断すると本当の更新の失敗を握り潰してしまう。
    # メッセージが次のどれかを含むときだけ「変更なし」と判定する。
    NO_CHANGE_MESSAGE_HINTS = (
        # Backlog は「更新する内容が無く、コメントも付いていない」PATCH にこのメッセージを返す。
        # 実質的に「変更なし」を意味する。実運用で最初に確認できた文言
        "No comment content",
        "コメントが入力されていません",
        # 環境・言語の設定によって返りうる表現
        "変更されていません",
        "変更がありません",
        "No changes",
        "not changed",
        "nothing to update",
    )

    def __init__(self, space_host, api_key, ssl_verify=True, base_path="", debug=False,
                 api_key_source="", timeout=None, max_retries=None, retry_backoff=None,
                 retry_max_delay=None):
        base_path = "/" + base_path.strip("/") if base_path.strip("/") else ""
        self.base_url = "https://{0}{1}/api/v2".format(space_host, base_path)
        self.api_key = api_key
        #: API キーをどこから読んだか。エラーに付けて、認証・権限のエラーの案内に使う
        self.api_key_source = api_key_source
        self.debug = debug
        self.timeout = self.TIMEOUT if timeout is None else timeout
        self.max_retries = self.MAX_RETRIES if max_retries is None else max_retries
        self.retry_backoff = self.RETRY_BACKOFF if retry_backoff is None else retry_backoff
        self.retry_max_delay = self.RETRY_MAX_DELAY if retry_max_delay is None else retry_max_delay

        if ssl_verify:
            self.ssl_context = None
        else:
            self.ssl_context = ssl.create_default_context()
            self.ssl_context.check_hostname = False
            self.ssl_context.verify_mode = ssl.CERT_NONE

    # ------------------------------------------------------------------
    # エラーにする
    # ------------------------------------------------------------------

    @classmethod
    def _is_no_change(cls, errors, detail):
        """HTTP 400 / code 7 のエラーが「変更なし」を意味するか。"""
        if not any(err.get("code") == 7 for err in errors):
            return False
        lowered = detail.lower()
        return any(hint.lower() in lowered for hint in cls.NO_CHANGE_MESSAGE_HINTS)

    def _http_hint(self, status, detail):
        """HTTP のエラーに添える対処の案内。無ければ None。"""
        hint = self.HTTP_ERROR_HINTS.get(status)
        if hint is None and 500 <= status < 600:
            hint = self.SERVER_ERROR_HINT
        return hint

    @staticmethod
    def _retried_text(retried):
        """再送した回数の 1 行。再送していなければ空（再送しない POST などで「再送しても」と書かないため）。"""
        return "\n  （{0} 回再送しても直りませんでした）".format(retried) if retried else ""

    def _handle_http_error(self, e, endpoint, raise_no_change=False, note=None, retried=0):
        """
        HTTPError を BacklogAPIError（または BacklogNoChangeError）にして送出する。

        raise_no_change=True のとき、HTTP 400 かつ Backlog のエラーコード 7 で、かつメッセージが「変更なし」を
        示すときだけ BacklogNoChangeError を送出する。判定できない code 7 は安全側に倒して BacklogAPIError にする
        （本当の更新の失敗を「変更なし」と表示して握り潰さないため）。note は案内の後に足す 1 行。
        """
        detail = ""
        raw_body = ""
        # 変数の注釈は古い Python で読めないため、型はコメントで書く
        errors = []  # type: list
        try:
            raw_body = e.read().decode("utf-8")
            body = json.loads(raw_body)
            errors = body.get("errors", []) or []
            if errors:
                detail = " / ".join(
                    "{0}（code={1}）".format(err.get("message", ""), err.get("code"))
                    for err in errors
                )
        except Exception:
            pass
        finally:
            _close_quietly(e)

        if raise_no_change and e.code == 400 and self._is_no_change(errors, detail):
            raise BacklogNoChangeError(detail or "HTTP 400 / code 7（変更なし）", status=e.code)

        message = "API 呼び出しに失敗しました（HTTP {0}）: {1}".format(e.code, endpoint)
        if detail:
            message += "\n  詳細: " + detail
        elif raw_body:
            message += "\n  レスポンス: " + raw_body[:500]
        message += self._retried_text(retried)
        hint = self._http_hint(e.code, detail)
        if hint:
            message += "\n  → " + hint
        if note:
            message += "\n  → " + note

        raise BacklogAPIError(
            message,
            status=e.code,
            endpoint=endpoint,
            detail=detail,
            errors=errors,
            # 認証・権限の誤りは、行ごとに再試行しても必ず失敗するため実行全体を止める
            fatal=e.code in (401, 403),
            raw_body=raw_body,
            api_key_source=self.api_key_source,
        )

    @staticmethod
    def _transport_reason(e):
        """通信の失敗の理由を 1 行にする。"""
        if isinstance(e, urllib.error.URLError):
            return str(e.reason)
        if isinstance(e, ValueError):
            return "応答が JSON ではありません（プロキシや認証の画面が返った可能性があります）"
        return "{0}: {1}".format(type(e).__name__, e) if str(e) else type(e).__name__

    # ------------------------------------------------------------------
    # 待つ
    # ------------------------------------------------------------------

    def _rate_limit_wait(self, reset):
        """
        X-RateLimit-Reset（制限が戻る時刻。UNIX 時刻の秒）までの待機秒数。読めなければ None。

        Backlog はレート制限の窓を分単位で数える。Retry-After が無いと既定の待ち（合計 14 秒ほど）で諦めてしまい、
        制限が戻る前に失敗していた。実際の応答にこのヘッダーがあるかは、まだ確かめていない（無ければ既定の待ち方）。
        """
        if not reset:
            return None
        try:
            remaining = float(reset) - time.time()
        except ValueError:
            return None
        return min(max(remaining, 0) + 1, self.MAX_RATE_LIMIT_WAIT)

    def _retry_wait(self, attempt, retry_after=None, rate_limit_reset=None):
        """
        次の再送までの待機秒数。

        X-RateLimit-Reset があればその時刻まで、次に Retry-After、どちらも無ければ既定の待ち
        （retry_backoff の 1・2・4 倍にばらつきを足したもの。並べて取得しているときに、同時に再送して
        また衝突しないため。ばらつきは足すだけで、短くはしない）。
        """
        reset_wait = self._rate_limit_wait(rate_limit_reset)
        if reset_wait is not None:
            return reset_wait
        if retry_after:
            try:
                return min(float(retry_after), self.retry_max_delay)
            except ValueError:
                pass  # HTTP-date の形は読まずに既定の待ちにする
        base = self.retry_backoff * (2 ** attempt)
        return min(base + random.uniform(0, base * self.RETRY_JITTER), self.retry_max_delay)

    def _wait_before_retry(self, attempt, wait, reason, endpoint):
        print(
            "  (待機) {0} のため {1:.0f} 秒待って再試行します（{2}/{3}）: {4}".format(
                reason, wait, attempt + 1, self.max_retries, endpoint),
            file=sys.stderr,
        )
        time.sleep(wait)

    # ------------------------------------------------------------------
    # 送る
    # ------------------------------------------------------------------

    def _send(self, req, endpoint, raise_no_change=False, idempotent=True, retry=True,
              allow_404=False, note=None):
        """
        リクエストを送って JSON を返す。一時的な失敗は条件付きで再送する。

        idempotent : 同じリクエストを送り直しても副作用が重ならないか。GET と PATCH は True、
                     POST とコメントの付く PATCH は False。False のときは 429 と、届いていないと分かる失敗
                     （URLError）だけ再送する
        retry      : False なら 429 を含めて再送しない
        allow_404  : True なら 404 で None を返す
        note       : 処理済みかもしれない失敗で再送しなかったときの案内（既定は NOT_RESENT_NOTE）

        HTTPError は _handle_http_error() で BacklogAPIError にする。通信の失敗（URLError・タイムアウト）と、
        応答を受け取る段階・本文を読む段階の失敗（http.client.HTTPException・OSError・JSON でない応答の
        ValueError）も BacklogAPIError にする。urllib が URLError に包むのは送るところまでで、その後の失敗は
        生の例外のまま出る。捕まえないと送信の途中でトレースバックになり、それまでの結果の表示も抜ける。
        """
        note = note or self.NOT_RESENT_NOTE
        attempt = 0
        while True:
            last_try = attempt >= self.max_retries
            try:
                with urllib.request.urlopen(req, timeout=self.timeout, context=self.ssl_context) as res:
                    return json.loads(res.read().decode("utf-8"))

            except urllib.error.HTTPError as e:
                # HTTPError は URLError の子なので先に捕まえる
                if allow_404 and e.code == 404:
                    _close_quietly(e)
                    return None
                server_error = 500 <= e.code < 600
                # 429 は断られた＝処理されていないことが確かなので、POST でも送り直してよい
                retryable = retry and (e.code == 429 or (idempotent and server_error))
                if not retryable or last_try:
                    unsafe = server_error and not idempotent
                    self._handle_http_error(e, endpoint, raise_no_change=raise_no_change,
                                            note=note if unsafe else None, retried=attempt)
                headers = e.headers
                retry_after = headers.get("Retry-After") if headers else None
                rate_limit_reset = headers.get("X-RateLimit-Reset") if headers and e.code == 429 else None
                _close_quietly(e)
                wait = self._retry_wait(attempt, retry_after, rate_limit_reset)
                self._wait_before_retry(attempt, wait, "HTTP {0}".format(e.code), endpoint)

            except (urllib.error.URLError, http.client.HTTPException, OSError, ValueError) as e:
                # URLError は送るところまでの失敗で、Backlog に届いていない。それ以外（タイムアウト・接続のリセット・
                # 応答の途中での切断・JSON でない応答）は、届いて処理された後かもしれない
                unsent = isinstance(e, urllib.error.URLError)
                retryable = retry and (idempotent or unsent)
                if not retryable or last_try:
                    raise self._transport_error(e, endpoint, note=None if unsent or idempotent else note,
                                                retried=attempt) from e
                wait = self._retry_wait(attempt)
                self._wait_before_retry(attempt, wait, "通信エラー", endpoint)

            attempt += 1

    def _transport_error(self, e, endpoint, note=None, retried=0):
        if isinstance(e, TimeoutError):
            reason = "timeout"
            message = "通信がタイムアウトしました（{0}秒）: {1}".format(self.timeout, endpoint)
        else:
            reason = self._transport_reason(e)
            message = "通信に失敗しました: {0}\n  理由: {1}".format(endpoint, reason)
        message += self._retried_text(retried)
        message += "\n  → " + (note or self.NETWORK_HINT)
        return BacklogAPIError(message, endpoint=endpoint, detail=reason,
                               api_key_source=self.api_key_source)

    def _build_query(self, params):
        """パラメータの dict をクエリ文字列にする（リストの値は [] で展開。[] は %5B%5D にする）。"""
        return "&".join(
            "{0}={1}".format(urllib.parse.quote(k), urllib.parse.quote(v))
            for k, v in flatten_params(params)
        )

    def _get(self, endpoint, params=None, allow_404=False):
        """GET を送って JSON を返す。"""
        query = self._build_query(params)
        if self.debug:
            print("  [DEBUG GET] {0} ?{1}".format(endpoint, query), file=sys.stderr)
        key = "apiKey=" + urllib.parse.quote(self.api_key)
        url = "{0}{1}?{2}".format(self.base_url, endpoint, query + "&" + key if query else key)
        return self._send(urllib.request.Request(url), endpoint, allow_404=allow_404)

    def _form(self, method, endpoint, params):
        """フォームの本文を持つリクエスト（POST・PATCH）を組み立てる。"""
        url = "{0}{1}?apiKey={2}".format(self.base_url, endpoint, urllib.parse.quote(self.api_key))
        # キー名の [] はエンコードしない。%5B%5D にすると Backlog がリストの表記として読めない。
        # 値だけを quote_plus でエンコードする
        pairs = flatten_params(params)
        body = "&".join("{0}={1}".format(k, urllib.parse.quote_plus(v)) for k, v in pairs).encode("utf-8")
        if self.debug:
            print("  [DEBUG {0}] {1}".format(method, endpoint), file=sys.stderr)
            for k, v in pairs:
                print("    {0}={1}".format(k, v), file=sys.stderr)
        return urllib.request.Request(
            url, data=body, method=method,
            headers={"Content-Type": "application/x-www-form-urlencoded"},
        )

    def _post(self, endpoint, params, retry=True, note=None):
        """
        POST を送って JSON を返す。冪等でないので、5xx・タイムアウト・応答の途中での切断では再送しない
        （課題などが二重に作られるため）。retry=False なら 429 でも再送しない。
        """
        req = self._form("POST", endpoint, params)
        result = self._send(req, endpoint, idempotent=False, retry=retry, note=note)
        if self.debug:
            self._debug_custom_fields("POST", result)
        return result

    def _patch(self, endpoint, params, raise_no_change=False):
        """
        PATCH を送って JSON を返す。同じ更新を送り直しても結果は変わらないので、5xx・タイムアウトでも再送する。
        ただし comment を含む更新は、送り直すとコメントが二重に付くため POST と同じ扱いにする。
        """
        req = self._form("PATCH", endpoint, params)
        idempotent = "comment" not in (params or {})
        result = self._send(req, endpoint, raise_no_change=raise_no_change, idempotent=idempotent)
        if self.debug:
            self._debug_custom_fields("PATCH", result)
        return result

    @staticmethod
    def _debug_custom_fields(method, result):
        """カスタム属性が反映されたかを確かめるため、応答のカスタム属性を出す。"""
        custom_fields = (result or {}).get("customFields", []) if isinstance(result, dict) else []
        if not custom_fields:
            print("  [DEBUG {0} response] customFields: (なし または 空)".format(method), file=sys.stderr)
            return
        print("  [DEBUG {0} response] customFields:".format(method), file=sys.stderr)
        for cf in custom_fields:
            print("    id={0} name={1!r} value={2!r}".format(cf.get("id"), cf.get("name"), cf.get("value")),
                  file=sys.stderr)

    @staticmethod
    def _quote(value):
        return urllib.parse.quote(str(value))

    # ------------------------------------------------------------------
    # 取得
    # ------------------------------------------------------------------

    def get_myself(self):
        """API キーの持ち主。"""
        return self._get("/users/myself")

    def get_project(self, project_id_or_key):
        """プロジェクト。"""
        return self._get("/projects/" + self._quote(project_id_or_key))

    def get_issue_types(self, project_id_or_key):
        """種別の一覧。"""
        return self._get("/projects/{0}/issueTypes".format(self._quote(project_id_or_key)))

    def get_custom_fields(self, project_id_or_key):
        """カスタム属性の一覧。"""
        return self._get("/projects/{0}/customFields".format(self._quote(project_id_or_key)))

    def get_statuses(self, project_id_or_key):
        """ステータスの一覧。"""
        return self._get("/projects/{0}/statuses".format(self._quote(project_id_or_key)))

    def get_project_users(self, project_id_or_key):
        """プロジェクトのメンバーの一覧。"""
        return self._get("/projects/{0}/users".format(self._quote(project_id_or_key)))

    def get_priorities(self):
        """優先度の一覧。"""
        return self._get("/priorities")

    def get_issues(self, project_id, params=None, limit=None):
        """
        課題の一覧を全件取得する（100 件ずつ、ページを送って読む）。
        limit を渡すと、その件数を読んだところで止める（先頭から limit 件を返す）。
        """
        all_issues = []
        offset = 0
        base_params = dict(params or {})
        base_params["projectId"] = [project_id]
        base_params["count"] = self.PAGE_SIZE
        while True:
            base_params["offset"] = offset
            issues = self._get("/issues", dict(base_params))
            if not issues:
                break
            all_issues.extend(issues)
            if limit is not None and len(all_issues) >= limit:
                return all_issues[:limit]
            if len(issues) < self.PAGE_SIZE:
                break
            offset += self.PAGE_SIZE
            time.sleep(0.3)
        return all_issues

    def get_issue(self, issue_id_or_key):
        """課題キー（PROJ-123）か数値の ID で課題を 1 件取得する。無ければ（404）None。"""
        return self._get("/issues/" + self._quote(issue_id_or_key), allow_404=True)

    # ------------------------------------------------------------------
    # 課題の作成・更新
    # ------------------------------------------------------------------

    def create_issue(self, params):
        """
        課題を作成する。必須: projectId・summary・issueTypeId・priorityId。
        任意: description・startDate・dueDate（YYYY-MM-DD）・assigneeId・categoryId（リスト）・
        milestoneId（リスト）・customField_<id> など。
        """
        return self._post(
            "/issues", params,
            note="課題が作成済みの可能性があるため再送しません。Backlog 側を確認してください。",
        )

    def update_issue(self, issue_id_or_key, params):
        """
        課題を更新する。params は create_issue と同じキー（どれも任意）。
        内容が今の課題と同じで Backlog が断ったときは BacklogNoChangeError を送出する。
        """
        return self._patch("/issues/" + self._quote(issue_id_or_key), params, raise_no_change=True)


def format_api_error(err):
    """
    BacklogAPIError を、利用者向けの日本語の文にする（API キーを含む URL は出さない）。

    文は例外の文そのもの（HTTP のステータスごとの案内は BacklogClient.HTTP_ERROR_HINTS。ツールが子クラスで上書きする）に、
    認証・権限のエラーなら、API キーをどこから読んだかの行を足したもの。5 つのツールで同じ文になる
    （以前は、この関数と BacklogClient が別々の案内の表を持ち、403 などで文が違った）。
    """
    lines = ["エラー: {}".format(err)]
    if err.status in (401, 403) and err.api_key_source:
        # API キーは環境変数・設定ファイル・.env のどれからも読むので、直す場所が分かるように
        lines.append(api_key_source_line(err.api_key_source))
    return "\n".join(lines)
