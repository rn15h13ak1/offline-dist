"""
コマンドラインの引数
====================
5 つのツールの入口（本体・メニュー・接続の確かめ・課題を調べる道具）で、--help を日本語で出し、
同じ意味の引数を同じ名前・同じ説明にする。

- 見出しは「使い方:」「引数」「オプション」、-h は「この説明を出して終わる」。argparse の既定は英語（usage: / options:）
- 使い方に出す名前は「python <入口>.py」。打ち込む形と同じにする
- オプションの省略形を受け付けない（allow_abbrev=False。--exec が --execute にならないように）
- 引数の誤りのときの argparse の文（「error: unrecognized arguments」など）は英語のまま

古い Python でも読める書き方に保つ（f 文字列・注釈を使わない。開発のテストが確かめる）。
"""

import argparse
import os

# 同じ意味の引数の説明。5 つのツールで同じ文にする
HELP_CONFIG = "設定ファイルのパス（既定: ツールのフォルダの config.yaml）"
HELP_DEBUG = "API リクエストの内容を表示する（作成・更新では応答のカスタム属性も。API キーは表示しない）"
# 読むだけの道具（check_api.py・backlog_lookup.py）。作成・更新をしないので、その説明を付けない
HELP_DEBUG_READ_ONLY = "API リクエストの内容を表示する（API キーは表示しない）"
HELP_EXECUTE = "実際に Backlog へ書き込む（省略するとドライラン。何も送らない）"
HELP_YES = "書き込んでよいことを示す。端末では確認を省き、端末でない所（定期実行・ほかのプログラム）から書き込むときはこれが要る"
# 出力先。--output-dir の相対パスは作業フォルダから、設定ファイルに書いたもの（と既定）は設定ファイルの場所から（5 つで同じ決まり）
HELP_OUTPUT_DIR = "{what}（ここで渡す相対パスは作業フォルダから。省くと設定ファイルの {setting}、無ければ {default} で、どちらも設定ファイルの場所から）"


class HelpFormatter(argparse.RawDescriptionHelpFormatter):
    """「usage:」を「使い方:」にする。説明と使い方の例（epilog）は改行をそのまま出す。"""

    def add_usage(self, usage, actions, groups, prefix=None):
        return super(HelpFormatter, self).add_usage(usage, actions, groups,
                                                    prefix="使い方: " if prefix is None else prefix)


def japanese(parser):
    """--help の見出しと -h の説明を日本語にする。add_help=False で作った parser に使う。"""
    parser._positionals.title = "引数"
    parser._optionals.title = "オプション"
    parser.add_argument("-h", "--help", action="help", help="この説明を出して終わる")
    return parser


def make_parser(script, description=None, epilog=None):
    """
    入口の ArgumentParser。script は入口のファイル（__file__）。使い方に「python <入口>.py」と出す。
    """
    return japanese(argparse.ArgumentParser(
        prog="python " + os.path.basename(script), description=description, epilog=epilog,
        formatter_class=HelpFormatter, add_help=False, allow_abbrev=False,
    ))


def add_command(subparsers, name, help, parents=()):
    """サブコマンド（issue_sheet の import など）。親と同じく日本語にし、省略形を受け付けない。"""
    return japanese(subparsers.add_parser(
        name, parents=list(parents), help=help, description=help, formatter_class=HelpFormatter,
        add_help=False, allow_abbrev=False,
    ))


def add_version(parser, name, version):
    """--version。「<ツール名> <版>」を出して終える。版はツールの version.py の __version__。"""
    parser.add_argument("--version", action="version", version=name + " " + version, help="版を出して終わる")


def add_config(parser, default=None):
    parser.add_argument("--config", default=default, metavar="PATH", help=HELP_CONFIG)


def add_debug(parser, read_only=False):
    parser.add_argument("--debug", action="store_true", help=HELP_DEBUG_READ_ONLY if read_only else HELP_DEBUG)


def add_execute(parser):
    parser.add_argument("--execute", action="store_true", help=HELP_EXECUTE)


def add_yes(parser):
    parser.add_argument("-y", "--yes", action="store_true", help=HELP_YES)


def add_output_dir(parser, setting, default, what="出力先のフォルダ"):
    """--output-dir DIR。setting は設定ファイルの項目の名前、default は書いていないときのフォルダ"""
    parser.add_argument("--output-dir", metavar="DIR",
                        help=HELP_OUTPUT_DIR.format(what=what, setting=setting, default=default))


def positive_int(text):
    """1 以上の整数（--limit など）。違えば argparse の誤りとして示す。"""
    try:
        value = int(text)
    except ValueError:
        value = 0
    if value < 1:
        raise argparse.ArgumentTypeError("1 以上の数を指定してください: {}".format(text))
    return value
