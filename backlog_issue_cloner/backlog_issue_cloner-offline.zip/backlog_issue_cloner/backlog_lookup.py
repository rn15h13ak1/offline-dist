#!/usr/bin/env python3
"""
Backlog の課題を調べる（読むだけ）
==================================
課題 1 件の中身・課題の検索・書ける名前の一覧を、表か JSON で出す。Backlog へは何も書かない。

  python backlog_lookup.py issue PROJ-123            課題 1 件（子課題・カスタム属性を含む）
  python backlog_lookup.py search --keyword 帳票     課題の検索（既定は完了以外・更新の新しい順に 100 件まで）
  python backlog_lookup.py master                    種別・状態・優先度・担当者・カテゴリー・マイルストーン・カスタム属性
  python backlog_lookup.py issue PROJ-123 --json     機械で読む形（JSON）で出す

設定ファイルは、既定でこのファイルの隣の config.yaml（--config で変えられる）。backlog: の節の space_host と、
project_key（--project で変えられる）を使う。API キーの探し方は、隣のツールと同じ。

終了コード: 0 = 出し終えた / 1 = 課題が無い・API の失敗 / 2 = 設定・引数の誤り、または必要なライブラリが無い。

入口の隣に置いて単独で動かすので、古い Python でも版を示して止まれるよう、f 文字列・注釈を使わない。
画面に出す文字は CP932 に収める。
"""

import argparse
import ast
import json
import os
import sys

from backlog_common import cli
from backlog_common.runtime import make_console_safe, require_packages, require_python

HERE = os.path.dirname(os.path.abspath(__file__))

EXIT_OK = 0
EXIT_FAILED = 1
EXIT_USAGE = 2

# 完了の状態の ID（全プロジェクト共通）。検索の既定では除く
STATUS_CLOSED_ID = 4
DEFAULT_MAX = 100


def name_of(value):
    """{"name": ...} の名前。リストなら名前のリスト。どちらでもなければそのまま。"""
    if isinstance(value, dict):
        return value.get("name")
    if isinstance(value, list):
        return [name_of(v) for v in value]
    return value


def issue_record(issue, parent_key=None, children=None):
    """課題を、読む人と機械のどちらにも分かる形にそろえる（名前で示す）。"""
    record = {
        "issueKey": issue.get("issueKey"),
        "summary": issue.get("summary"),
        "issueType": name_of(issue.get("issueType")),
        "status": name_of(issue.get("status")),
        "priority": name_of(issue.get("priority")),
        "resolution": name_of(issue.get("resolution")),
        "assignee": name_of(issue.get("assignee")),
        "categories": name_of(issue.get("category") or []),
        "milestones": name_of(issue.get("milestone") or []),
        "versions": name_of(issue.get("versions") or []),
        "startDate": (issue.get("startDate") or "")[:10] or None,
        "dueDate": (issue.get("dueDate") or "")[:10] or None,
        "estimatedHours": issue.get("estimatedHours"),
        "actualHours": issue.get("actualHours"),
        "parentIssueKey": parent_key,
        "created": issue.get("created"),
        "updated": issue.get("updated"),
        "description": issue.get("description") or "",
        "customFields": [
            {"name": f.get("name"), "value": name_of(f.get("value"))}
            for f in issue.get("customFields") or []
        ],
    }
    if children is not None:
        record["children"] = [
            {"issueKey": c.get("issueKey"), "summary": c.get("summary"), "status": name_of(c.get("status"))}
            for c in children
        ]
    return record


def list_record(issue):
    return {
        "issueKey": issue.get("issueKey"),
        "summary": issue.get("summary"),
        "issueType": name_of(issue.get("issueType")),
        "status": name_of(issue.get("status")),
        "assignee": name_of(issue.get("assignee")),
        "dueDate": (issue.get("dueDate") or "")[:10] or None,
        "updated": issue.get("updated"),
    }


def shown(value):
    """表に出す値。空は「（なし）」、リストは「、」でつなぐ。"""
    if isinstance(value, list):
        value = "、".join(str(v) for v in value if v not in (None, ""))
    if value in (None, ""):
        return "（なし）"
    return str(value)


def print_issue(record):
    print("{} ― {}".format(record["issueKey"], record["summary"]))
    labels = (
        ("種別", "issueType"), ("状態", "status"), ("優先度", "priority"), ("完了理由", "resolution"),
        ("担当者", "assignee"), ("カテゴリー", "categories"), ("マイルストーン", "milestones"),
        ("発生バージョン", "versions"), ("開始日", "startDate"), ("期限日", "dueDate"),
        ("予定時間", "estimatedHours"), ("実績時間", "actualHours"), ("親課題", "parentIssueKey"),
        ("作成", "created"), ("更新", "updated"),
    )
    for label, key in labels:
        print("  {}: {}".format(label, shown(record[key])))
    for field in record["customFields"]:
        print("  {}: {}".format(field["name"], shown(field["value"])))
    print("  本文:")
    for line in (record["description"] or "（なし）").splitlines():
        print("    " + line)
    if "children" in record:
        print("  子課題（{} 件）:".format(len(record["children"])))
        for child in record["children"]:
            print("    {} [{}] {}".format(child["issueKey"], shown(child["status"]), child["summary"]))


def print_list(records):
    for r in records:
        print("{} [{}] {}（担当: {} / 期限: {} / 更新: {}）".format(
            r["issueKey"], shown(r["status"]), r["summary"], shown(r["assignee"]), shown(r["dueDate"]),
            shown((r["updated"] or "")[:10])))
    print("{} 件".format(len(records)))


def print_master(master):
    titles = (
        ("issueTypes", "種別"), ("statuses", "状態"), ("priorities", "優先度"), ("users", "担当者"),
        ("categories", "カテゴリー"), ("milestones", "マイルストーン・バージョン"),
    )
    for key, title in titles:
        print("{}: {}".format(title, shown(master[key])))
    print("カスタム属性:")
    if not master["customFields"]:
        print("  （なし）")
    for field in master["customFields"]:
        mark = "（必須）" if field["required"] else ""
        items = "  選択肢: " + shown(field["items"]) if field["items"] else ""
        print("  {}{}{}".format(field["name"], mark, items))


def emit(as_json, value, printer):
    if as_json:
        print(json.dumps(value, ensure_ascii=False, indent=2))
    else:
        printer(value)


def make_client_class():
    """共通の部品のクライアントに、カテゴリーとマイルストーンの取得を足したもの"""
    from backlog_common.client import BacklogClient

    class LookupClient(BacklogClient):
        def get_categories(self, project_id_or_key):
            return self._get("/projects/{0}/categories".format(self._quote(project_id_or_key)))

        def get_versions(self, project_id_or_key):
            return self._get("/projects/{0}/versions".format(self._quote(project_id_or_key)))

    return LookupClient


def connect(args):
    """(クライアント, プロジェクトキー)。設定の誤りは ConfigError。"""
    from backlog_common import config as config_files

    path = args.config or os.path.join(HERE, "config.yaml")
    config = config_files.load_config(path, example="同じフォルダの設定のひな形")
    # 節の形・知らない項目・通信の設定（timeout など）と ssl_verify・space_host の誤りは、ツールの本体と同じ文で、
    # 読んだ設定ファイルを示して通信の前に止める
    section, problems = config_files.backlog_problems(config, ["space_host"], ["project_key"],
                                                      example="同じフォルダの設定のひな形")
    if problems:
        raise config_files.ConfigError(config_files.problems_text(path, problems))
    options = config_files.client_settings(section)
    api_key, source = config_files.locate_api_key(path, section.get("api_key"), tool_dir=HERE)
    client = make_client_class()(
        config_files.setting(section, "space_host"), api_key,
        ssl_verify=section.get("ssl_verify", True), base_path=config_files.setting(section, "base_path"),
        debug=args.debug, api_key_source=source, **options
    )
    return client, (args.project or config_files.setting(section, "project_key"))


def need_project(project_key):
    from backlog_common.config import ConfigError

    if not project_key:
        raise ConfigError("プロジェクトが決まりません。--project <プロジェクトキー> を付けてください"
                          "（設定ファイルに backlog.project_key があれば、それを使います）")
    return project_key


def cmd_issue(args, client, project_key):
    issue = client.get_issue(args.key)
    if issue is None:
        print("エラー: 課題 {} が見つかりません。".format(args.key), file=sys.stderr)
        return EXIT_FAILED
    parent_key = None
    children = None
    if issue.get("parentIssueId"):
        parent = client.get_issue(issue["parentIssueId"])
        parent_key = parent.get("issueKey") if parent else None
    else:
        children = client.get_issues(issue["projectId"], {"parentIssueId": [issue["id"]]})
    emit(args.json, issue_record(issue, parent_key, children), print_issue)
    return EXIT_OK


def ids_by_name(items, names, what):
    from backlog_common.config import ConfigError

    table = dict((item.get("name"), item.get("id")) for item in items)
    unknown = [n for n in names if n not in table]
    if unknown:
        raise ConfigError("知らない{}です: {}（使える名前: {}）".format(
            what, "、".join(unknown), "、".join(str(k) for k in table)))
    return [table[n] for n in names]


def cmd_search(args, client, project_key):
    project = client.get_project(need_project(project_key))
    params = {"sort": "updated", "order": "desc"}
    if args.keyword:
        params["keyword"] = args.keyword
    statuses = client.get_statuses(project["projectKey"])
    if args.status:
        params["statusId"] = ids_by_name(statuses, args.status, "状態")
    elif not args.include_closed:
        params["statusId"] = [s["id"] for s in statuses if s.get("id") != STATUS_CLOSED_ID]
    if args.type:
        params["issueTypeId"] = ids_by_name(client.get_issue_types(project["projectKey"]), args.type, "種別")
    issues = client.get_issues(project["id"], params, limit=args.max)
    emit(args.json, [list_record(i) for i in issues], print_list)
    return EXIT_OK


def cmd_master(args, client, project_key):
    key = need_project(project_key)
    custom_fields = client.get_custom_fields(key)
    master = {
        "issueTypes": name_of(client.get_issue_types(key)),
        "statuses": name_of(client.get_statuses(key)),
        "priorities": name_of(client.get_priorities()),
        "users": name_of(client.get_project_users(key)),
        "categories": name_of(client.get_categories(key)),
        "milestones": name_of(client.get_versions(key)),
        "customFields": [
            {"name": f.get("name"), "required": bool(f.get("required")), "items": name_of(f.get("items") or [])}
            for f in custom_fields
        ],
    }
    emit(args.json, master, print_master)
    return EXIT_OK


def tool_version(folder=None):
    """
    隣のツールの (ツール名, 版)。ツールの入口と同じく --version に出す。

    zip ではツールの version.py が隣にある。開発機の shared/ には無いので None（--version を付けない）。
    読み込まずに、値の行だけを読む（隣のツールのモジュールを import しない）。
    """
    path = os.path.join(folder or HERE, "version.py")
    if not os.path.isfile(path):
        return None
    with open(path, encoding="utf-8") as f:
        tree = ast.parse(f.read())
    values = {}
    for node in tree.body:
        if isinstance(node, ast.Assign) and isinstance(node.value, ast.Constant):
            for target in node.targets:
                if isinstance(target, ast.Name):
                    values[target.id] = node.value.value
    if "TOOL_NAME" in values and "__version__" in values:
        return values["TOOL_NAME"], values["__version__"]
    return None


def build_parser():
    # --help の日本語と、同じ意味の引数の説明は、5 つのツールで共通の部品
    common = argparse.ArgumentParser(add_help=False, allow_abbrev=False)
    cli.add_config(common)
    common.add_argument("--project", metavar="KEY", help="プロジェクトキー（既定: 設定ファイルの backlog.project_key）")
    common.add_argument("--json", action="store_true", help="機械で読む形（JSON）で出す")
    cli.add_debug(common, read_only=True)

    parser = cli.make_parser(__file__, description="Backlog の課題を調べる（読むだけ。Backlog へは何も書かない）")
    version = tool_version()
    if version:
        cli.add_version(parser, *version)
    sub = parser.add_subparsers(dest="command", metavar="コマンド")
    sub.required = True

    p = cli.add_command(sub, "issue", "課題 1 件の中身（子課題・カスタム属性を含む）", parents=[common])
    p.add_argument("key", metavar="課題キー")
    p.set_defaults(func=cmd_issue)

    p = cli.add_command(sub, "search", "課題を検索する（更新の新しい順）", parents=[common])
    p.add_argument("--keyword", metavar="文字列", help="件名・本文・コメントを探す")
    p.add_argument("--status", nargs="+", metavar="名前", help="状態で絞る（既定: 完了以外）")
    p.add_argument("--type", nargs="+", metavar="名前", help="種別で絞る")
    p.add_argument("--include-closed", action="store_true", help="完了した課題も含める")
    p.add_argument("--max", type=cli.positive_int, default=DEFAULT_MAX, metavar="N",
                   help="出す件数の上限（既定: {}）".format(DEFAULT_MAX))
    p.set_defaults(func=cmd_search)

    p = cli.add_command(sub, "master", "種別・状態・優先度・担当者・カテゴリー・マイルストーン・カスタム属性の名前",
                        parents=[common])
    p.set_defaults(func=cmd_master)
    return parser


def main(argv=None):
    make_console_safe()
    require_python()
    args = build_parser().parse_args(argv)
    # PyYAML は設定ファイルを読む共通の部品が使う。無ければ入れ方を案内して止める（--help は無くても出せるよう、引数の後で確かめる）
    require_packages([("yaml", "pyyaml")], code=EXIT_USAGE)

    from backlog_common.client import BacklogError
    from backlog_common.config import ConfigError, api_key_source_line

    client = None
    try:
        client, project_key = connect(args)
        return args.func(args, client, project_key)
    except ConfigError as e:
        print("エラー: {}".format(e), file=sys.stderr)
        return EXIT_USAGE
    except BacklogError as e:
        print("エラー: {}".format(e), file=sys.stderr)
        if getattr(e, "status", None) in (401, 403) and client is not None:
            print(api_key_source_line(client.api_key_source), file=sys.stderr)
        return EXIT_FAILED
    except KeyboardInterrupt:
        print("\n中断しました。", file=sys.stderr)
        return 130


if __name__ == "__main__":
    sys.exit(main())
