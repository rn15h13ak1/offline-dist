@echo off
rem ===========================================================
rem  Back up local changes to this tool, then undo them
rem  Double-click this file when update.bat stopped because files
rem  of the tool were changed in this folder. The changed files
rem  are copied to backup\<date-time>\ (ignored by git), then
rem  "git checkout -- ." puts the files back as they were.
rem  config.yaml and other untracked files are not touched.
rem
rem  The work is done by undo_changes.py: a "for /f" here would
rem  garble Japanese file names from git.
rem
rem  Messages here are ASCII on purpose: this file must stay
rem  readable in any console code page.
rem ===========================================================

pushd "%~dp0" || (
    echo [ERROR] Cannot enter the folder of this script.
    pause
    exit /b 1
)

rem Pick the Python to run this with. Candidates, in order: a .venv in
rem this folder, python on PATH, then the py launcher. Only the
rem standard library is used, so the first one that runs is used.
set PYTHON=
if exist ".venv\Scripts\python.exe" call :try ".venv\Scripts\python.exe"
if not defined PYTHON call :try python
if not defined PYTHON call :try py -3
if not defined PYTHON (
    echo [ERROR] Python 3 was not found.
    echo         Install Python 3.10 or later from https://www.python.org/
    echo         and make sure it is added to PATH.
    popd
    pause
    exit /b 1
)

rem "call" so that a python.cmd (e.g. from pyenv-win) returns here and
rem the exit code and pause below still run.
call %PYTHON% undo_changes.py %*
set RC=%ERRORLEVEL%

popd
if not "%RC%"=="0" echo.& echo [exit code %RC%]

rem Pause only when double-clicked. With arguments this runs unattended,
rem where pause would wait forever.
if "%~1"=="" pause
exit /b %RC%

rem Use the given command as the Python if it runs. "call" lets a python.cmd
rem return here.
:try
call %* --version >nul 2>&1 && set PYTHON=%*
exit /b 0
