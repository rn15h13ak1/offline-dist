@echo off
rem ===========================================================
rem  Backlog issue cloner - back up local changes, then undo them
rem  Double-click this file when update.bat stopped because files
rem  of the tool were changed in this folder. The changed files
rem  are copied to backup\<date-time>\ (ignored by git), then
rem  "git checkout -- ." puts the files back as they were.
rem  config.yaml and other untracked files are not touched.
rem
rem  The work is done by undo_changes.py: a "for /f" here would
rem  garble Japanese file names from git.
rem
rem  Messages here are ASCII on purpose: this file must stay
rem  readable in any console code page.
rem ===========================================================

pushd "%~dp0" || (
    echo [ERROR] Cannot enter the folder of this script.
    pause
    exit /b 1
)

rem Only the standard library is used. A .venv in this folder comes
rem first, then the py launcher, then python on PATH.
set PYTHON=
if exist ".venv\Scripts\python.exe" set PYTHON=".venv\Scripts\python.exe"
if not defined PYTHON (
    py -3 --version >nul 2>&1 && set PYTHON=py -3
)
if not defined PYTHON (
    python --version >nul 2>&1 && set PYTHON=python
)
if not defined PYTHON (
    echo [ERROR] Python 3 was not found.
    echo         Install Python 3.10 or later from https://www.python.org/
    echo         and make sure it is added to PATH.
    popd
    pause
    exit /b 1
)

%PYTHON% undo_changes.py %*
set RC=%ERRORLEVEL%

popd
if not "%RC%"=="0" echo.& echo [exit code %RC%]

rem Pause only when double-clicked. With arguments this runs unattended,
rem where pause would wait forever.
if "%~1"=="" pause
exit /b %RC%
